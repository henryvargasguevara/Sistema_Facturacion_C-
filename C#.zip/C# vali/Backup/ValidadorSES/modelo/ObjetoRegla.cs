﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class ObjetoRegla
    {
        public string codigoObjetoRegla { get; set; }
        public string codigoObjeto { get; set; }
        public int codigoRegla { get; set; }
        public string estado { get; set; }

        public DateTime fechaCreacion { get; set; }
        public DateTime fechaModificacion { get; set; }
        public int usuarioCreador { get; set; }
        public int usuarioModificador { get; set; }
    }
}
