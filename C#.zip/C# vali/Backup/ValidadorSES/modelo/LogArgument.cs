﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogArgument
    {
        public string oleType { get; set; }
        public string argumentType { get; set; }
        public string nameArgRoutine { get; set; }
        public string descArgRoutine { get; set; }

        public string estadoArgumentDescripcion { get; set; }
        public string estadoArgumentCodigo { get; set; }
        public string mensaje { get; set; }
        public bool hayError { get; set; }
        public bool hayObservacion { get; set; }

        public Objeto objeto { get; set; }
        public LogRoutine routine { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }

        public LogArgument() 
        {
            this.nameArgRoutine = "";
            this.descArgRoutine = "";
        }
    }
}
