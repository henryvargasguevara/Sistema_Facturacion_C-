﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStageNotificationActivity
    {
        public string asunto { get; set; }  //JT
        public string InputPins { get; set; } //JT
    }
}
