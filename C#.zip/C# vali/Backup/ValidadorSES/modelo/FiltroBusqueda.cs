﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class FiltroBusqueda
    {
        public string codigo { get; set; }
        public string stage { get; set; }
        public bool check { get; set; }
        public FiltroBusqueda filtroPadre { get; set; }

        public List<FiltroBusqueda> listaFiltroPropiedad { get; set; }

        public FiltroBusqueda() 
        {
            this.codigo = "";
            this.stage = "";
            this.check = false;
            this.listaFiltroPropiedad = new List<FiltroBusqueda>();
        }

        public FiltroBusqueda(string codigo, string stage, bool check, FiltroBusqueda filtroPadre)
        {
            this.codigo = codigo;
            this.stage = stage;
            this.check = check;
            this.filtroPadre = filtroPadre;
            this.listaFiltroPropiedad = new List<FiltroBusqueda>();
        }
    }
}
