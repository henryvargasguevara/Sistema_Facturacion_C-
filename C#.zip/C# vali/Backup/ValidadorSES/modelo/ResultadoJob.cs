﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class ResultadoJob
    {
        public string nombreJob { get; set; }
        public string rutaJob { get; set; }
        public string tipoJob { get; set; }
        public List<ResultadoStage> listaStage { get; set; }

        public LogJob job;

        public ResultadoJob() 
        {
            this.nombreJob = "";
            this.rutaJob = "";
            this.tipoJob = "";
            this.listaStage = new List<ResultadoStage>();
        }
    }
}
