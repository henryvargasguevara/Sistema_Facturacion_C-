﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogJob
    {
        public string oleType { get; set; }
        public string jobType { get; set; }
        public string identifierJob { get; set; }
        public string category { get; set; }
        public string dateModified { get; set; }
        public string timeModified { get; set; }

        public bool PKenTablaDU { get; set; }
        public bool stageDB2DuJob { get; set; }
        public bool probandoPKJob { get; set; }
        public string vamosviendo { get; set; }

        public string codigoJob { get; set; }
        public int numStageCorrecto { get; set; }
        public int numStageObservado { get; set; }
        public int numStageIncorrecto { get; set; }
        public string estadoJobDescripcion { get; set; }
        public string estadoJobCodigo { get; set; }
        public DateTime fechaModificacion { get; set; }
        public string mensaje { get; set; }

        public LogDSX dsx { get; set; }
        public Carpeta carpeta { get; set; }
        public Objeto objeto { get; set; }
        public List<LogStage> listaStage { get; set; }
        public List<LogObjetoParam> listaParamJob { get; set; }
        public LogObjetoDocumentacionInterna docInterna { get; set; }
        public string checkpoints { get; set; }
        public string logjoberrors { get; set; }
        public string logjobreports { get; set; }
        
        public List<LogObjetoValidacion> listaValidacion { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }

        public LogJob() 
        {
            this.docInterna = new LogObjetoDocumentacionInterna();
            this.listaValidacion = new List<LogObjetoValidacion>();
            this.checkpoints = "";
            this.logjoberrors = "";
            this.logjobreports = "";
            this.listaStage = new List<LogStage>();
        }
        //public bool dependecy { get; set; }
        //public string check { get; set; }
    }
}
