﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo.view;

namespace ValidadorSES.modelo
{
    public class LogObjetoValidacion
    {
        public string mensaje;
        public string estado;
        public ObjetoReglaView regla;
        public LogJob job;

        public LogObjetoValidacion() { }

        public LogObjetoValidacion(string mensaje, string estado, ObjetoReglaView regla, LogJob job) 
        {
            this.mensaje = mensaje;
            this.estado = estado;
            this.regla = regla;
            this.job = job;
        }

        public LogObjetoValidacion(string mensaje, string estado, ObjetoReglaView regla)
        {
            this.mensaje = mensaje;
            this.estado = estado;
            this.regla = regla;
        }
    }
}
