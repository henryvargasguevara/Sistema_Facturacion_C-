﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    class AsignarRequerimiento
    {

        public string codigo {get;set;}
        public int codigo_usuario {get;set;}
        public string codigo_requerimiento {get;set;}
        public DateTime fecha_asignacion {get;set;}
        public DateTime fecha_creacion {get;set;}
        public string estado { get; set; }
        public string estadoValidacion { get; set; }
    }
}
