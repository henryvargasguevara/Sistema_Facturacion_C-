﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStageBaseDato
    {
        public bool estaComentario { get; set; }
        public string recordCount { get; set; }
        public string recordCountModidy { get; set; } //JT
        public string arraySize { get; set; }  //JT
        public string arrayZizeModidy {get; set;}  //JT
        public string LockWaitMode { get; set; } //JT
        public string LockWaitModeModify { get; set; } //JT
        public string pk_du { get; set; }  //JT
        public string autoCommitMode { get; set;}
        public string writeMode { get; set;}
        public string beforeAfter { get; set;}
        public string keepConductorConnectionAlive { get; set;}        

        //conexion
        public string database { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public bool protectedPassword { get; set; }
        
        public List<string> listaSQLValida { get; set; }
        public List<string> listaTabla { get; set; }
    }
}
