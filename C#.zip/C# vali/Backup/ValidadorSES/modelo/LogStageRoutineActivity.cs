﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStageRoutineActivity
    {
        public string routineName { get; set; }
        public List<LogObjetoParam> listaParametroRoutine { get; set; }
    }
}
