﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES
{
    public class LogHeader
    {
        public string fecha { get; set; }
        public string hora { get; set; }
    }
}
