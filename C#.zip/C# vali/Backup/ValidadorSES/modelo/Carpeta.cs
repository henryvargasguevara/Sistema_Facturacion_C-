﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.util;

namespace ValidadorSES.modelo
{
    public class Carpeta
    {
        public string nombre { get; set; }
        public string nombreFull { get; set; }
        public Carpeta carpetaPadre { get; set; }
        public List<LogJob> listaJob { get; set; }
        public List<Carpeta> listaCarpeta { get; set; }

        public Carpeta()
        {
            this.carpetaPadre = null;
            this.listaCarpeta = new List<Carpeta>();
            this.listaJob = new List<LogJob>();
        }

        public Carpeta agregarHijo(string nombre, string nombreFull) 
        {
            Carpeta hijoExistente = UtilDataStage.getCarpetaByNombre(nombre, this.listaCarpeta);

            if (hijoExistente == null)
            {
                Carpeta c = new Carpeta();
                c.nombre = nombre;
                c.nombreFull = nombreFull;
                c.carpetaPadre = this;

                this.listaCarpeta.Add(c);

                return c;
            }

            return hijoExistente;
        }
    }
}
