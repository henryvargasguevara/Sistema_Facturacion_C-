﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class Regla
    {
        public int codigoRegla { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public string sugerencia { get; set; }
        public string tipoObjeto { get; set; }
        public string estado { get; set; }
        public string estadoFull { get; set; }
        public string estadoExpress { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }
        public DateTime fechaModificacion { get; set; }
        public int usuarioModificador { get; set; }
    }
}
