﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    class Maestro
    {
        public int codigo { get; set; }
        public string descripcion { get; set; }
        public List<DetalleMaestro> listaDetalleMaestro { get; set; }
    }
}
