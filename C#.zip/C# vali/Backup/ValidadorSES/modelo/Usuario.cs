﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class Usuario
    {
       public int codigo_Usuario{get;set;}
       public string nombres{get;set;}
       public string apellidos{get;set;}
       public int cargo_usuario{get;set;}
       public int lider { get; set; }
       public string estado { get; set; }
       public string usuario { get; set; }
       public string contraseña { get; set; }
       public DateTime fecha_creacion {get;set;}
       public DateTime fecha_modificacion {get;set;}
       public int usuario_creador{get;set;}
       public int usuario_modificador{get;set;}
       public string fullName { get; set; }
       public string pregunta { get; set; }
       public string respuesta { get; set; }
       
      
    }
}
