﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStageAnnotation
    {
        public string type { get; set; }
        public string text { get; set; }

        public LogStageAnnotation() 
        {
            this.type = "";
            this.text = "";
        }
    }
}
