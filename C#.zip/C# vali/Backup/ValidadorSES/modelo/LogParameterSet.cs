﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogParameterSet
    {
        public string oleType { get; set; }
        public string parameterSetType { get; set; }
        public string identifierParameterSet { get; set; }
        public string category { get; set; }
        public string descripcion_ParameterSet { get; set; }
        public string descripcion_Breve { get; set; }
        public string dateModified { get; set; }
        public string timeModified { get; set; }

        public string codigoParameter { get; set; }
        public string mensaje { get; set; }
        public List<LogObjetoValidacion> listaValidacion { get; set; }
        public int numParamCorrecto { get; set; }
        public int numParamIncorrecto { get; set; }
        public int numParamObservado { get; set; }
        public bool hayError { get; set; }
        public string estadoParameterDescripcion { get; set; }
        public string estadoParameterCodigo { get; set; }

        public LogDSX dsx { get; set; }
        public Objeto objeto { get; set; }
        public List<LogParam> listaParam { get; set; }
        public LogObjetoDocumentacionInterna docInterna { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }

        public LogParameterSet() 
        {
            this.listaValidacion = new List<LogObjetoValidacion>();
            this.docInterna = new LogObjetoDocumentacionInterna();
            this.listaParam = new List<LogParam>();
            this.oleType = "";
            this.parameterSetType = "";
            this.descripcion_ParameterSet = "";
            this.descripcion_Breve = "";
            this.identifierParameterSet = "";
            this.category = "";
        }
    }
}
