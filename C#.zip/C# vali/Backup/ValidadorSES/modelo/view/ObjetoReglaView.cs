﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    [Serializable]
    public class ObjetoReglaView
    {
        public string codigoObjeto { get; set; }
        public string typeObjeto { get; set; }
        public string clasificacion { get; set; }
        public string clasificacionAndType { get; set; }
        public string nombreObjeto { get; set; }
        public string estadoObjRegla { get; set; }
        public int codigoRegla { get; set; }
        public string codigoObjetoRegla { get; set; }
        public string nombreRegla { get; set; }
    }
}
