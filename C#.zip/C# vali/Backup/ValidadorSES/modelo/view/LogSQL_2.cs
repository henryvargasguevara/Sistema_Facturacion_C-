﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogSQL_2
    {
        public string nombreTabla  { get; set; }
        public string lengthNombre { get; set; }
     //   public string prefijoTabla { get; set; }

    }
}
