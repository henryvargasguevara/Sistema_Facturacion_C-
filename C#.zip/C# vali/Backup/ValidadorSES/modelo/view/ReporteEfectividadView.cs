﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    class ReporteEfectividadView
    {
        public string codigoAsignacion { get; set; }
        public string descripcion { get; set; }
        public string colaborador { get; set; }
        public string estadoDsx { get; set; }
        public string fechaCreacion { get; set; }
        public int numJobValidado { get; set; }
    }
}
