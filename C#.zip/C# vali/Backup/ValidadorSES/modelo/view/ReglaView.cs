﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    public class ReglaView
    {
        public int codigoRegla { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public string sugerencia { get; set; }
        public string tipoObjeto { get; set; }
        public string estado { get; set; }
        public string estadoFull { get; set; }
        public string estadoExpress { get; set; }

        public string fechaCreacion { get; set; }
        public string usuarioCreador { get; set; }
        public string fechaModificacion { get; set; }
        public string usuarioModificador { get; set; }   
    }
}
