﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    [Serializable]
    public class ObjetoView
    {
        public string codigoObjeto { get; set; }
        public string clasificacion { get; set; }
        public string oletype { get; set; }
        public string type { get; set; }
        public string prefijo { get; set; }
        public string estado { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public string mnemonico { get; set; }
        public string clasificacionAndType { get; set; }

        public string fechaCreacion { get; set; }
        public string usuarioCreador { get; set; }
        public string fechaModificacion { get; set; }
        public string usuarioModificador { get; set; }

        public List<ObjetoReglaView> listaObjetoRegla { get; set; }
    }
}
