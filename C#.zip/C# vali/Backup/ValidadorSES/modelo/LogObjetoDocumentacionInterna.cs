﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogObjetoDocumentacionInterna
    {
        public string aplicativo { get; set; }
        public string nombre { get; set; }
        public List<string> listaDependencias { get; set; }
        public List<string> listaFuentes { get; set; }
        public List<string> listaDestino { get; set; }
        public string objetivo { get; set; }
        public string reprocesable { get; set; }
        public string scheduler { get; set; }
        public List<string> listaVersion { get; set; }

        public string description { get; set; }

        public bool tieneCampoAplicativo { get; set; }
        public bool tieneCampoNombre { get; set; }
        public bool tieneCampoDependencias { get; set; }
        public bool tieneCampoDestino { get; set; }
        public bool tieneCampoFuentes { get; set; }
        public bool tieneCampoObjetivo { get; set; }
        public bool tieneCampoReprocesable { get; set; }
        public bool tieneCampoScheduler { get; set; }
        public bool tieneCampoVersiones { get; set; }

        public string shortDesc { get; set; } //shortDesc, ParameterSet

        public LogObjetoDocumentacionInterna() 
        {
            this.aplicativo = "";
            this.nombre = "";
            this.description = "";
            this.listaDependencias = new List<string>();
            this.listaFuentes = new List<string>();
            this.listaDestino = new List<string>();
            this.objetivo = "";
            this.reprocesable = "";
            this.scheduler = "";
            this.listaVersion = new List<string>();

            this.tieneCampoAplicativo = false;
            this.tieneCampoNombre = false;
            this.tieneCampoDependencias = false;
            this.tieneCampoDestino = false;
            this.tieneCampoFuentes = false;
            this.tieneCampoObjetivo = false;
            this.tieneCampoReprocesable = false;
            this.tieneCampoScheduler = false;
            this.tieneCampoVersiones = false;
            
            this.shortDesc = "";
        }
    }
}
