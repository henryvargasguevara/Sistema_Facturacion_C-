﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    [Serializable]
    public class Objeto
    {
        public string codigoObjeto { get; set; }
        public string clasificacion { get; set; }
        public string oletype { get; set; }
        public string type { get; set; }
        public string prefijo { get; set; }
        public string estado { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public string mnemonico { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }
        public DateTime fechaModificacion { get; set; }
        public int usuarioModificador { get; set; }    
    }
}
