﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStage
    {
        public string oleType { get; set; }
        public string stageType { get; set; }

        public string identifierStage { get; set; }
        public string inputPins { get; set; }
        public string outputPins { get; set; }
        public string nameStage { get; set; }
        public int TotalColumnas { get; set; }
        public int TotalTableDef { get; set; }

        public string sourceId { get; set; } //CJSActivityInput
        public string partner { get; set; } //CJSActivityInput
        public string conditionType { get; set; } //CJSActivityOutput

        public Objeto objeto { get; set; }
        public LogJob job { get; set; }
        public List<LogStage> listaStageOutput { get; set; }

        public LogStageBaseDato stageBaseDato { get; set; }
        public LogStageArchivo stageArchivo { get; set; }
        public LogStageAggregator stageAggregator { get; set; }  //JT
        public LogStageTransformer stageTransformer { get; set; }        
        public LogStageJobActivity stageJobActivity { get; set; }
        public LogStageRoutineActivity stageRoutineActivity { get; set; }
        public LogStageTerminatorActivity stageTerminatorActivity { get; set; }
        public LogStageUserVarsActivity stageUserVarsActivity { get; set; }
        public LogStageNotificationActivity stageNotificationActivity { get; set; } //JT
        //public LogStageAnnotation stageAnnotacion { get; set; }

        public string mensaje { get; set; }
        public string estadoStageCodigo { get; set; }
        public string estadoStageDescripcion { get; set; }
        public bool hayError { get; set; }
        public bool hayObservacion { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }

        public LogStage() 
        {
            stageBaseDato = new LogStageBaseDato();
            stageArchivo = new LogStageArchivo();
            stageTransformer = new LogStageTransformer();
            stageAggregator = new LogStageAggregator();   //JT
            stageJobActivity = new LogStageJobActivity();
            stageRoutineActivity = new LogStageRoutineActivity();
            stageTerminatorActivity = new LogStageTerminatorActivity();
            stageUserVarsActivity = new LogStageUserVarsActivity();
            stageNotificationActivity = new LogStageNotificationActivity(); //JT
            //stageAnnotacion = new LogStageAnnotation();
        }

        //public string propiedadDB2 { get; set; }
        //public string propiedadJobActivity { get; set; }
        //public string parmSecuencial { get; set; }
        //public bool finalMessage { get; set; }
        //public bool logText { get; set; }
        //public bool fullDescription { get; set; }
        //public string parmRoutine { get; set; }
        //public string nombrerutina { get; set; }
        //public string descripcionTipoStage { get; set; }
        //public string propiedadDataset { get; set; }
        //public string propiedadFile { get; set; }
        //public string propiedadTransformerStageVariable { get; set; }
        //public string propiedadTransformerLoopVariable { get; set; }
        //public string estadoNomenclatura { get; set; }
    }
}
