﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.service;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormBuscadorFiltro : Form
    {
        public List<FiltroBusqueda> listaFiltro { get; set; }
        public bool filtroByNombreStage { get; set; }

        public FormBuscadorFiltro()
        {
            InitializeComponent();
        }

        public void cargarPantalla() 
        {
            //setear el check de Filtro por nombre de stage
            checkBoxNombreStage.Checked = filtroByNombreStage;

            //llenar la lista de checks de los stages
            cargarListaStage();

            if (listaFiltro != null && listaFiltro.Count > 1)
            {
                //cargar la lista de propiedades del primer stage
                FiltroBusqueda fb = listaFiltro[0];
                if (fb.check)
                {
                    cargarListaPropiedad(fb);
                }
            }
        }

        private void cargarListaStage() 
        {
            int totalChecked = 0;
            int totalUnchecked = 0;

            checkedListBoxStage.Items.Clear();
            for (int i = 0; i < listaFiltro.Count; i++)
            {
                checkedListBoxStage.Items.Insert(i, listaFiltro[i]);
                if (listaFiltro[i].check)
                {
                    checkedListBoxStage.SetItemCheckState(i, CheckState.Checked);
                    totalChecked++;
                }
                else
                {
                    checkedListBoxStage.SetItemCheckState(i, CheckState.Unchecked);
                    totalUnchecked++;
                }
            }
                        
            checkedListBoxStage.DisplayMember = "stage";
            checkedListBoxStage.ValueMember = "codigo";

            checkBoxTodosStage.Checked = false;
            checkBoxNingunoStage.Checked = false;

            if (totalChecked == listaFiltro.Count)
            {
                checkBoxTodosStage.Checked = true;
            }
            if (totalUnchecked == listaFiltro.Count)
            {
                checkBoxNingunoStage.Checked = true;
            }
        }

        private void cargarListaPropiedad(FiltroBusqueda fb)
        {
            checkedListBoxPropiedad.Items.Clear();

            for (int i = 0; i < fb.listaFiltroPropiedad.Count; i++)
            {
                checkedListBoxPropiedad.Items.Insert(i, fb.listaFiltroPropiedad[i]);

                if (fb.listaFiltroPropiedad[i].check)
                {
                    checkedListBoxPropiedad.SetItemCheckState(i, CheckState.Checked);
                }
                else
                {
                    checkedListBoxPropiedad.SetItemCheckState(i, CheckState.Unchecked);
                }
            }
            checkedListBoxPropiedad.DisplayMember = "stage";
            checkedListBoxPropiedad.ValueMember = "codigo";
        }

        private void checkedListBoxStage_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            Object o = checkedListBoxStage.Items[e.Index];
            FiltroBusqueda fb = (FiltroBusqueda)o;

            checkedListBoxPropiedad.Items.Clear();
            if (e.NewValue == CheckState.Checked)
            {
                cargarListaPropiedad(fb);
            }
        }
        
        private void checkedListBoxPropiedad_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            Object o = checkedListBoxPropiedad.Items[e.Index];
            FiltroBusqueda fbactual = (FiltroBusqueda)o; //propiedad
            bool checkedPropiedad = false;

            if (e.NewValue == CheckState.Checked)
            {
                checkedPropiedad = true;
            }

            FiltroBusqueda fbpadre = fbactual.filtroPadre;

            FiltroBusqueda fb = UtilBusqueda.getFiltroByNombre(fbactual.stage, fbpadre.listaFiltroPropiedad);
            fb.check = checkedPropiedad;
        }

        private void btnGuardarFiltro_Click(object sender, EventArgs e)
        {
            guardarFiltro();
            this.Hide();
        }

        private void guardarFiltro()
        {
            foreach (Object item in checkedListBoxStage.Items)
            {
                FiltroBusqueda fbactual = (FiltroBusqueda)item;

                if (checkedListBoxStage.CheckedItems.Contains(item))
                {
                    fbactual.check = true;
                }
                else
                {
                    fbactual.check = false;
                }

                FiltroBusqueda fb = UtilBusqueda.getFiltroByNombre(fbactual.stage, listaFiltro);
                if(fb != null)
                {
                    fb.check = fbactual.check;
                }
            }

            filtroByNombreStage = checkBoxNombreStage.Checked;
        }

        private void checkBoxTodosStage_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTodosStage.Checked)
            {
                int total = checkedListBoxStage.Items.Count;

                for (int i = 0; i < total; i++)
                {
                    checkedListBoxStage.SetItemCheckState(i, CheckState.Checked);
                }
            }

            checkBoxNingunoStage.Checked = false;
        }

        private void checkBoxNingunoStage_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxNingunoStage.Checked)
            {
                int total = checkedListBoxStage.Items.Count;

                for (int i = 0; i < total; i++)
                {
                    checkedListBoxStage.SetItemCheckState(i, CheckState.Unchecked);
                }
            }

            checkBoxTodosStage.Checked = false;
        }

        private void FormBuscadorFiltro_FormClosed(object sender, FormClosedEventArgs e)
        {
            guardarFiltro();
            this.Hide();
        }

        private void checkBoxTodosPropiedad_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTodosPropiedad.Checked)
            {
                int total = checkedListBoxPropiedad.Items.Count;

                for (int i = 0; i < total; i++)
                {
                    checkedListBoxPropiedad.SetItemCheckState(i, CheckState.Checked);

                    FiltroBusqueda fbactual = (FiltroBusqueda)checkedListBoxPropiedad.Items[i];

                    FiltroBusqueda fbpadre = fbactual.filtroPadre;

                    FiltroBusqueda fb = UtilBusqueda.getFiltroByNombre(fbactual.stage, fbpadre.listaFiltroPropiedad);
                    fb.check = true;
                }
            }

            checkBoxNingunoPropiedad.Checked = false;
        }

        private void checkBoxNingunoPropiedad_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxNingunoPropiedad.Checked)
            {
                int total = checkedListBoxPropiedad.Items.Count;

                for (int i = 0; i < total; i++)
                {
                    checkedListBoxPropiedad.SetItemCheckState(i, CheckState.Unchecked);

                    FiltroBusqueda fbactual = (FiltroBusqueda)checkedListBoxPropiedad.Items[i];

                    FiltroBusqueda fbpadre = fbactual.filtroPadre;

                    FiltroBusqueda fb = UtilBusqueda.getFiltroByNombre(fbactual.stage, fbpadre.listaFiltroPropiedad);
                    fb.check = false;
                }
            }

            checkBoxTodosPropiedad.Checked = false;

        }
    }
}
