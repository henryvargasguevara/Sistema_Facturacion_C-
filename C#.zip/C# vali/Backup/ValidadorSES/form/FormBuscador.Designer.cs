﻿namespace ValidadorSES.form
{
    partial class FormBuscador
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBuscador));
            this.lblruta = new System.Windows.Forms.Label();
            this.txtRutaDSX = new System.Windows.Forms.TextBox();
            this.progressBar_Load = new System.Windows.Forms.ProgressBar();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.backgroundWorker_Carga = new System.ComponentModel.BackgroundWorker();
            this.label5 = new System.Windows.Forms.Label();
            this.seleccionarDSX = new System.Windows.Forms.Button();
            this.tabControlObjeto = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridViewJob = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridViewRoutine = new System.Windows.Forms.DataGridView();
            this.tabPageParameterSet = new System.Windows.Forms.TabPage();
            this.dataGridViewParameterSet = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNroStage = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNroParameterSet = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtNroRoutine = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNroJob = new System.Windows.Forms.TextBox();
            this.txtNroResultado = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExportarResultadoBusqueda = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCargarDSX = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.groupBoxCriterioBusqueda = new System.Windows.Forms.GroupBox();
            this.btnEscogerFiltro = new System.Windows.Forms.Button();
            this.checkBoxOmitirMayMin = new System.Windows.Forms.CheckBox();
            this.checkBoxPalabraExacta = new System.Windows.Forms.CheckBox();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.lblPalabraAdicional = new System.Windows.Forms.Label();
            this.tabControlObjeto.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewJob)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRoutine)).BeginInit();
            this.tabPageParameterSet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParameterSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBoxCriterioBusqueda.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblruta
            // 
            this.lblruta.AutoSize = true;
            this.lblruta.Location = new System.Drawing.Point(26, 88);
            this.lblruta.Name = "lblruta";
            this.lblruta.Size = new System.Drawing.Size(139, 13);
            this.lblruta.TabIndex = 2;
            this.lblruta.Text = "Ubicación de archivo DSX :";
            this.lblruta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtRutaDSX
            // 
            this.txtRutaDSX.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRutaDSX.Enabled = false;
            this.txtRutaDSX.Location = new System.Drawing.Point(171, 85);
            this.txtRutaDSX.Name = "txtRutaDSX";
            this.txtRutaDSX.ReadOnly = true;
            this.txtRutaDSX.Size = new System.Drawing.Size(597, 20);
            this.txtRutaDSX.TabIndex = 24;
            this.txtRutaDSX.TextChanged += new System.EventHandler(this.txtRutaDSX_TextChanged);
            // 
            // progressBar_Load
            // 
            this.progressBar_Load.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar_Load.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.progressBar_Load.Location = new System.Drawing.Point(171, 111);
            this.progressBar_Load.Name = "progressBar_Load";
            this.progressBar_Load.Size = new System.Drawing.Size(705, 23);
            this.progressBar_Load.TabIndex = 5;
            // 
            // backgroundWorker_Carga
            // 
            this.backgroundWorker_Carga.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_Carga_DoWork);
            this.backgroundWorker_Carga.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_Carga_RunWorkerCompleted);
            this.backgroundWorker_Carga.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_Carga_ProgressChanged);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(257, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(631, 39);
            this.label5.TabIndex = 19;
            this.label5.Text = "Buscador de Objetos DataStage";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // seleccionarDSX
            // 
            this.seleccionarDSX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.seleccionarDSX.Location = new System.Drawing.Point(774, 83);
            this.seleccionarDSX.Name = "seleccionarDSX";
            this.seleccionarDSX.Size = new System.Drawing.Size(102, 23);
            this.seleccionarDSX.TabIndex = 26;
            this.seleccionarDSX.Text = "Seleccionar DSX";
            this.seleccionarDSX.UseVisualStyleBackColor = true;
            this.seleccionarDSX.Click += new System.EventHandler(this.seleccionarDSX_Click);
            // 
            // tabControlObjeto
            // 
            this.tabControlObjeto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlObjeto.Controls.Add(this.tabPage1);
            this.tabControlObjeto.Controls.Add(this.tabPage2);
            this.tabControlObjeto.Controls.Add(this.tabPageParameterSet);
            this.tabControlObjeto.Location = new System.Drawing.Point(12, 223);
            this.tabControlObjeto.Name = "tabControlObjeto";
            this.tabControlObjeto.SelectedIndex = 0;
            this.tabControlObjeto.Size = new System.Drawing.Size(896, 465);
            this.tabControlObjeto.TabIndex = 28;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridViewJob);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(888, 439);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "JOB";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridViewJob
            // 
            this.dataGridViewJob.AllowUserToAddRows = false;
            this.dataGridViewJob.AllowUserToDeleteRows = false;
            this.dataGridViewJob.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewJob.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewJob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewJob.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewJob.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewJob.Name = "dataGridViewJob";
            this.dataGridViewJob.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewJob.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewJob.Size = new System.Drawing.Size(856, 398);
            this.dataGridViewJob.TabIndex = 1;
            this.dataGridViewJob.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewJob_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridViewRoutine);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(888, 439);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ROUTINE";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridViewRoutine
            // 
            this.dataGridViewRoutine.AllowUserToAddRows = false;
            this.dataGridViewRoutine.AllowUserToDeleteRows = false;
            this.dataGridViewRoutine.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRoutine.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewRoutine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewRoutine.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewRoutine.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewRoutine.Name = "dataGridViewRoutine";
            this.dataGridViewRoutine.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRoutine.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewRoutine.Size = new System.Drawing.Size(850, 356);
            this.dataGridViewRoutine.TabIndex = 2;
            this.dataGridViewRoutine.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRoutine_CellContentClick);
            // 
            // tabPageParameterSet
            // 
            this.tabPageParameterSet.Controls.Add(this.dataGridViewParameterSet);
            this.tabPageParameterSet.Location = new System.Drawing.Point(4, 22);
            this.tabPageParameterSet.Name = "tabPageParameterSet";
            this.tabPageParameterSet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageParameterSet.Size = new System.Drawing.Size(888, 439);
            this.tabPageParameterSet.TabIndex = 2;
            this.tabPageParameterSet.Text = "PARAMETER SET";
            this.tabPageParameterSet.UseVisualStyleBackColor = true;
            // 
            // dataGridViewParameterSet
            // 
            this.dataGridViewParameterSet.AllowUserToAddRows = false;
            this.dataGridViewParameterSet.AllowUserToDeleteRows = false;
            this.dataGridViewParameterSet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewParameterSet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewParameterSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewParameterSet.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewParameterSet.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewParameterSet.Name = "dataGridViewParameterSet";
            this.dataGridViewParameterSet.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewParameterSet.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewParameterSet.Size = new System.Drawing.Size(850, 356);
            this.dataGridViewParameterSet.TabIndex = 2;
            this.dataGridViewParameterSet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewParameterSet_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtNroStage);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNroParameterSet);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtNroRoutine);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtNroJob);
            this.groupBox1.Controls.Add(this.txtNroResultado);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(914, 223);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(174, 209);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Total Objetos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Stage";
            // 
            // txtNroStage
            // 
            this.txtNroStage.Enabled = false;
            this.txtNroStage.Location = new System.Drawing.Point(107, 96);
            this.txtNroStage.Name = "txtNroStage";
            this.txtNroStage.Size = new System.Drawing.Size(48, 20);
            this.txtNroStage.TabIndex = 11;
            this.txtNroStage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Job";
            // 
            // txtNroParameterSet
            // 
            this.txtNroParameterSet.Enabled = false;
            this.txtNroParameterSet.Location = new System.Drawing.Point(107, 148);
            this.txtNroParameterSet.Name = "txtNroParameterSet";
            this.txtNroParameterSet.Size = new System.Drawing.Size(48, 20);
            this.txtNroParameterSet.TabIndex = 9;
            this.txtNroParameterSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "ParameterSet:";
            // 
            // txtNroRoutine
            // 
            this.txtNroRoutine.Enabled = false;
            this.txtNroRoutine.Location = new System.Drawing.Point(107, 122);
            this.txtNroRoutine.Name = "txtNroRoutine";
            this.txtNroRoutine.Size = new System.Drawing.Size(48, 20);
            this.txtNroRoutine.TabIndex = 7;
            this.txtNroRoutine.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Routine:";
            // 
            // txtNroJob
            // 
            this.txtNroJob.Enabled = false;
            this.txtNroJob.Location = new System.Drawing.Point(107, 70);
            this.txtNroJob.Name = "txtNroJob";
            this.txtNroJob.Size = new System.Drawing.Size(48, 20);
            this.txtNroJob.TabIndex = 3;
            this.txtNroJob.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNroResultado
            // 
            this.txtNroResultado.Enabled = false;
            this.txtNroResultado.Location = new System.Drawing.Point(107, 30);
            this.txtNroResultado.Name = "txtNroResultado";
            this.txtNroResultado.Size = new System.Drawing.Size(48, 20);
            this.txtNroResultado.TabIndex = 2;
            this.txtNroResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total Resultado:";
            // 
            // btnExportarResultadoBusqueda
            // 
            this.btnExportarResultadoBusqueda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportarResultadoBusqueda.Image = global::ValidadorSES.Properties.Resources.icono_Excel;
            this.btnExportarResultadoBusqueda.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportarResultadoBusqueda.Location = new System.Drawing.Point(914, 532);
            this.btnExportarResultadoBusqueda.Name = "btnExportarResultadoBusqueda";
            this.btnExportarResultadoBusqueda.Size = new System.Drawing.Size(174, 57);
            this.btnExportarResultadoBusqueda.TabIndex = 23;
            this.btnExportarResultadoBusqueda.Text = "     RESULTADOS DE        BÚSQUEDA";
            this.btnExportarResultadoBusqueda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExportarResultadoBusqueda.UseVisualStyleBackColor = true;
            this.btnExportarResultadoBusqueda.Click += new System.EventHandler(this.btnExportarResultadoBusqueda_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ValidadorSES.Properties.Resources.logo_ses;
            this.pictureBox1.Location = new System.Drawing.Point(32, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 80);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // btnCargarDSX
            // 
            this.btnCargarDSX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCargarDSX.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCargarDSX.Font = new System.Drawing.Font("Vrinda", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCargarDSX.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCargarDSX.Image = global::ValidadorSES.Properties.Resources.Folder_Mac_Documents;
            this.btnCargarDSX.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCargarDSX.Location = new System.Drawing.Point(910, 144);
            this.btnCargarDSX.Name = "btnCargarDSX";
            this.btnCargarDSX.Size = new System.Drawing.Size(136, 46);
            this.btnCargarDSX.TabIndex = 4;
            this.btnCargarDSX.Text = "BUSCAR";
            this.btnCargarDSX.UseVisualStyleBackColor = true;
            this.btnCargarDSX.Click += new System.EventHandler(this.buttonCargar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.AllowDrop = true;
            this.btnLimpiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLimpiar.Font = new System.Drawing.Font("Vrinda", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLimpiar.Image = global::ValidadorSES.Properties.Resources.edit_clear;
            this.btnLimpiar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiar.Location = new System.Drawing.Point(1052, 144);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(32, 46);
            this.btnLimpiar.TabIndex = 1;
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // groupBoxCriterioBusqueda
            // 
            this.groupBoxCriterioBusqueda.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxCriterioBusqueda.Controls.Add(this.btnEscogerFiltro);
            this.groupBoxCriterioBusqueda.Controls.Add(this.checkBoxOmitirMayMin);
            this.groupBoxCriterioBusqueda.Controls.Add(this.checkBoxPalabraExacta);
            this.groupBoxCriterioBusqueda.Controls.Add(this.txtKeyword);
            this.groupBoxCriterioBusqueda.Controls.Add(this.lblPalabraAdicional);
            this.groupBoxCriterioBusqueda.Location = new System.Drawing.Point(16, 140);
            this.groupBoxCriterioBusqueda.Name = "groupBoxCriterioBusqueda";
            this.groupBoxCriterioBusqueda.Size = new System.Drawing.Size(888, 77);
            this.groupBoxCriterioBusqueda.TabIndex = 34;
            this.groupBoxCriterioBusqueda.TabStop = false;
            this.groupBoxCriterioBusqueda.Text = "Criterios de Búsqueda";
            // 
            // btnEscogerFiltro
            // 
            this.btnEscogerFiltro.Location = new System.Drawing.Point(590, 39);
            this.btnEscogerFiltro.Name = "btnEscogerFiltro";
            this.btnEscogerFiltro.Size = new System.Drawing.Size(111, 23);
            this.btnEscogerFiltro.TabIndex = 30;
            this.btnEscogerFiltro.Text = "Escoger filtros";
            this.btnEscogerFiltro.UseVisualStyleBackColor = true;
            this.btnEscogerFiltro.Click += new System.EventHandler(this.btnEscogerFiltro_Click);
            // 
            // checkBoxOmitirMayMin
            // 
            this.checkBoxOmitirMayMin.AutoSize = true;
            this.checkBoxOmitirMayMin.Checked = true;
            this.checkBoxOmitirMayMin.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxOmitirMayMin.Location = new System.Drawing.Point(342, 43);
            this.checkBoxOmitirMayMin.Name = "checkBoxOmitirMayMin";
            this.checkBoxOmitirMayMin.Size = new System.Drawing.Size(173, 17);
            this.checkBoxOmitirMayMin.TabIndex = 29;
            this.checkBoxOmitirMayMin.Text = "Omitir mayúsculas y minúsculas";
            this.checkBoxOmitirMayMin.UseVisualStyleBackColor = true;
            // 
            // checkBoxPalabraExacta
            // 
            this.checkBoxPalabraExacta.AutoSize = true;
            this.checkBoxPalabraExacta.Location = new System.Drawing.Point(155, 43);
            this.checkBoxPalabraExacta.Name = "checkBoxPalabraExacta";
            this.checkBoxPalabraExacta.Size = new System.Drawing.Size(150, 17);
            this.checkBoxPalabraExacta.TabIndex = 28;
            this.checkBoxPalabraExacta.Text = "Buscar por palabra exacta";
            this.checkBoxPalabraExacta.UseVisualStyleBackColor = true;
            // 
            // txtKeyword
            // 
            this.txtKeyword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKeyword.Location = new System.Drawing.Point(155, 17);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(705, 20);
            this.txtKeyword.TabIndex = 26;
            // 
            // lblPalabraAdicional
            // 
            this.lblPalabraAdicional.AutoSize = true;
            this.lblPalabraAdicional.Location = new System.Drawing.Point(74, 20);
            this.lblPalabraAdicional.Name = "lblPalabraAdicional";
            this.lblPalabraAdicional.Size = new System.Drawing.Size(75, 13);
            this.lblPalabraAdicional.TabIndex = 27;
            this.lblPalabraAdicional.Text = "Palabra clave:";
            // 
            // FormBuscador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1100, 700);
            this.Controls.Add(this.groupBoxCriterioBusqueda);
            this.Controls.Add(this.btnExportarResultadoBusqueda);
            this.Controls.Add(this.btnCargarDSX);
            this.Controls.Add(this.tabControlObjeto);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.seleccionarDSX);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.progressBar_Load);
            this.Controls.Add(this.txtRutaDSX);
            this.Controls.Add(this.lblruta);
            this.Controls.Add(this.btnLimpiar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1100, 700);
            this.Name = "FormBuscador";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buscador SES v2.0";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControlObjeto.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewJob)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRoutine)).EndInit();
            this.tabPageParameterSet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParameterSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBoxCriterioBusqueda.ResumeLayout(false);
            this.groupBoxCriterioBusqueda.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label lblruta;
        private System.Windows.Forms.TextBox txtRutaDSX;
        private System.Windows.Forms.Button btnCargarDSX;
        private System.Windows.Forms.ProgressBar progressBar_Load;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.ComponentModel.BackgroundWorker backgroundWorker_Carga;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button seleccionarDSX;
        private System.Windows.Forms.TabControl tabControlObjeto;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnExportarResultadoBusqueda;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNroJob;
        private System.Windows.Forms.TextBox txtNroResultado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewJob;
        private System.Windows.Forms.TextBox txtNroRoutine;
        private System.Windows.Forms.DataGridView dataGridViewRoutine;
        private System.Windows.Forms.TabPage tabPageParameterSet;
        private System.Windows.Forms.DataGridView dataGridViewParameterSet;
        private System.Windows.Forms.TextBox txtNroParameterSet;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBoxCriterioBusqueda;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.Label lblPalabraAdicional;
        private System.Windows.Forms.CheckBox checkBoxOmitirMayMin;
        private System.Windows.Forms.CheckBox checkBoxPalabraExacta;
        private System.Windows.Forms.Button btnEscogerFiltro;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNroStage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
    }
}

