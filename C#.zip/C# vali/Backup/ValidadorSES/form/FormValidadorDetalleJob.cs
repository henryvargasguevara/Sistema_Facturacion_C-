﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormValidadorDetalleJob : Form
    {
        public const string TBL_DET_JOB_NOMBRE_VALIDACION = "Nombre de Validación";
        public const string TBL_DET_JOB_ESTADO_VALIDACION = "Estado";
        public const string TBL_DET_JOB_MENSAJE_VALIDACION = "Mensaje";
        public const string TBL_DET_JOB_AMPLIAR_DESCRIPCION = "ver más";
        public const int TBL_DET_JOB_POS_ABRIR = 0;
        public const int TBL_DET_JOB_POS_DISPLAY_ABRIR = 2;

        public const string TBL_STAGE_NOMBRE_STAGE = "Nombre Stage";
        public const string TBL_STAGE_TIPO_STAGE = "Tipo Stage";
        public const string TBL_STAGE_ESTADO = "Estado";
        public const string TBL_STAGE_DESCRIPCION_VALIDACION = "Descripción de validación del Stage";
        public const string TBL_STAGE_IDENTIFIER = "Identifier";
        public const string TBL_STAGE_AMPLIAR_DESCRIPCION = "ver más";
        public const int TBL_STAGE_POS_ABRIR = 0;
        public const int TBL_STAGE_POS_DISPLAY_ABRIR = 3;

        private LogJob job { get; set; }

        public FormValidadorDetalleJob()
        {
            InitializeComponent();
        }

        private void FormDetalleJob_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape){
                this.Close();
            }
        }

        public void cargarDetalleJob(LogJob job)
        {
            this.job = job; 

            //jobDescripcionValidacionJob = job.mensaje;
            Text = "Detalle del Job " + job.objeto.nombre + " - " + job.identifierJob;
            lblNombreJob.Text = job.identifierJob;
            txtRutaJob.Text = job.category;
            //formDetalle.txtDescripcionValidacionJob.Text = job.mensaje;




            cargarDetalleValidacionJob(job);
            cargarDetalleValidacionStage(job);

            //totales
            txtTotalStage.Text = Convert.ToString(job.listaStage.Count);
            txtNroCorrectos.Text = Convert.ToString(job.numStageCorrecto);
            txtNroIncorrecto.Text = Convert.ToString(job.numStageIncorrecto);
            txtNroObservacion.Text = Convert.ToString(job.numStageObservado);
        }

        private void cargarDetalleValidacionJob(LogJob job)
        {
            double porExito = 0;
            int totalOK = 0;
            int totalObs = 0;
            int totalError = 0;
            int totalValidacion = 1;
            //declaración de tabla y columnas
            DataTable table = new DataTable();

            table.Columns.Add(UtilForm.getColumnString(TBL_DET_JOB_NOMBRE_VALIDACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_DET_JOB_ESTADO_VALIDACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_DET_JOB_MENSAJE_VALIDACION));

            //logica
            if (job != null && job.listaValidacion.Count > 0)
            {
                totalValidacion = job.listaValidacion.Count;
                for (int v = 0; v < totalValidacion; v++)
                {
                    LogObjetoValidacion val = job.listaValidacion[v];

                    if (val.estado == ConstanteMaestro.DES_EST_VALIDACION_OK)
                    {
                        totalOK++;
                    }
                    if (val.estado == ConstanteMaestro.DES_EST_VALIDACION_OBS)
                    {
                        totalObs++;
                    }
                    if (val.estado == ConstanteMaestro.DES_EST_VALIDACION_ERROR)
                    {
                        totalError++;
                    }

                    DataRow row = table.NewRow();

                    row[TBL_DET_JOB_NOMBRE_VALIDACION] = val.regla.nombreRegla;
                    row[TBL_DET_JOB_ESTADO_VALIDACION] = val.estado;
                    row[TBL_DET_JOB_MENSAJE_VALIDACION] = val.mensaje;

                    table.Rows.Add(row);
                }
            }

            //pintar el Progressbar
            porExito = 100 * ((totalOK +0.0)/ totalValidacion);
            prgBarDocInterna.Value = Convert.ToInt32(porExito);

            //pintar titulo de tab
            String mensajeTab = "";
            if (totalObs > 0)
            {
                mensajeTab += totalObs + " obs";
            }
            if (totalError > 0)
            {
                if (mensajeTab != "")
                {
                    mensajeTab += ", ";
                }
                if (totalError == 1)
                {
                    mensajeTab += totalError + " error";
                }
                else
                {
                    mensajeTab += totalError + " errores";
                }
            }
            if (mensajeTab != "") 
            {
                mensajeTab = "(" + mensajeTab + ")";
            }

            tabPageDocInterna.Text = "Validación de Documentación Interna y otros " + mensajeTab;

            //pintar en el detalle
            DataGridView dgv = dataGridViewDetalleJob;
            dgv.Visible = true;
            dgv.RowHeadersVisible = false;
            dgv.DataSource = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dgv.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "";
            buttonColumn.Text = "...";
            buttonColumn.Name = TBL_DET_JOB_AMPLIAR_DESCRIPCION;
            buttonColumn.DisplayIndex = TBL_DET_JOB_POS_DISPLAY_ABRIR;
            buttonColumn.UseColumnTextForButtonValue = true;
            buttonColumn.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);

            dgv.Columns[TBL_DET_JOB_NOMBRE_VALIDACION].Width = 300;
            dgv.Columns[TBL_DET_JOB_ESTADO_VALIDACION].Width = 80;
            dgv.Columns[TBL_DET_JOB_MENSAJE_VALIDACION].Width = 650;
            dgv.Columns[TBL_DET_JOB_AMPLIAR_DESCRIPCION].Width = 50;

            dgv.Columns[TBL_STAGE_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //dataViewDetalle.Columns[TBL_STAGE_ESTADO].DefaultCellStyle.Font = new Font(this.Font, FontStyle.Bold);
        }
        
        private void cargarDetalleValidacionStage(LogJob job)
        {
            
            double porExito = 0;
            int totalOK = 0;
            int totalObs = 0;
            int totalError = 0;
            int totalValidacion = 1;
            List<LogStage> listaStage = new List<LogStage>();
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView viewDetalle = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_STAGE_NOMBRE_STAGE));
            table.Columns.Add(UtilForm.getColumnString(TBL_STAGE_TIPO_STAGE));
            table.Columns.Add(UtilForm.getColumnString(TBL_STAGE_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_STAGE_DESCRIPCION_VALIDACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_STAGE_IDENTIFIER));

            //logica
            if (job != null && job.listaStage.Count>0)
            {
                listaStage = UtilValidacion.getListaStagePriorizada(job.listaStage);
                int totalStage = listaStage.Count;
                totalValidacion = totalStage;
                
                for (int j = 0; j < totalStage; j++)
                {                    
                    LogStage stage = listaStage[j];                    
                    if (stage.estadoStageCodigo == ConstanteMaestro.COD_EST_VALIDACION_OK)
                    {
                        totalOK++;
                    }
                    if (stage.estadoStageCodigo == ConstanteMaestro.COD_EST_VALIDACION_OBS)
                    {
                        totalObs++;
                    }
                    if (stage.estadoStageCodigo == ConstanteMaestro.COD_EST_VALIDACION_ERROR)
                    {
                        totalError++;
                    }
                    if (stage.objeto != null)
                    {
                        DataRow row = table.NewRow();

                        row[TBL_STAGE_NOMBRE_STAGE] = stage.nameStage;
                        row[TBL_STAGE_TIPO_STAGE] = stage.objeto.nombre;
                        row[TBL_STAGE_ESTADO] = stage.estadoStageDescripcion;
                        row[TBL_STAGE_DESCRIPCION_VALIDACION] = stage.mensaje;
                        row[TBL_STAGE_IDENTIFIER] = stage.identifierStage;

                        table.Rows.Add(row);
                    }
                }
            }
                        
            //pintar el Progressbar
            porExito = 100 * ((totalOK + 0.0) / totalValidacion);
            prgBarStage.Value = Convert.ToInt32(porExito);

            //pintar titulo de tab
            String mensajeTab = "";
            if (totalObs > 0)
            {
                mensajeTab += totalObs + " obs";
            }
            if (totalError > 0)
            {
                if (mensajeTab != "")
                {
                    mensajeTab += ", ";
                }
                if (totalError == 1)
                {
                    mensajeTab += totalError + " error";
                }
                else
                {
                    mensajeTab += totalError + " errores";
                }
            }
            if (mensajeTab != "")
            {
                mensajeTab = "(" + mensajeTab + ")";
            }
            tabPageStage.Text = "Validación de Stages " + mensajeTab;

            //pintar en el detalle
            viewDetalle = new DataView(table);

            DataGridView dgv = dataGridViewDetalleStage;
            dgv.Visible = true;
            dgv.RowHeadersVisible = false;
            dgv.DataSource = viewDetalle;

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dgv.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "";
            buttonColumn.Text = "...";
            buttonColumn.Name = TBL_STAGE_AMPLIAR_DESCRIPCION;
            buttonColumn.DisplayIndex = TBL_STAGE_POS_DISPLAY_ABRIR;
            buttonColumn.UseColumnTextForButtonValue = true;
            buttonColumn.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);

            dgv.Columns[TBL_STAGE_NOMBRE_STAGE].Width = 300;
            dgv.Columns[TBL_STAGE_TIPO_STAGE].Width = 120;
            dgv.Columns[TBL_STAGE_ESTADO].Width = 80;
            dgv.Columns[TBL_STAGE_DESCRIPCION_VALIDACION].Width = 510;
            dgv.Columns[TBL_STAGE_IDENTIFIER].Visible = false; 
            dgv.Columns[TBL_STAGE_AMPLIAR_DESCRIPCION].Width = 50;

            dgv.Columns[TBL_STAGE_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //dataViewDetalle.Columns[TBL_STAGE_ESTADO].DefaultCellStyle.Font = new Font(this.Font, FontStyle.Bold);
        }

        private void dataGridViewDetalleStage_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewDetalleStage.Columns[e.ColumnIndex].Name.Equals(TBL_STAGE_ESTADO))
            {
                string estado = dataGridViewDetalleStage.Rows[e.RowIndex].Cells[TBL_STAGE_ESTADO].Value.ToString();
                if (estado == ConstanteMaestro.DES_EST_VALIDACION_OK)
                {
                    dataGridViewDetalleStage.Rows[e.RowIndex].Cells[TBL_STAGE_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado == ConstanteMaestro.DES_EST_VALIDACION_ERROR)
                    {
                        dataGridViewDetalleStage.Rows[e.RowIndex].Cells[TBL_STAGE_ESTADO].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        //dataGridViewDetalle.Rows[e.RowIndex].Cells[FormPrincipal.TBL_STAGE_ESTADO].Style.ForeColor = Color.GreenYellow;
                    }

                }

            }
        }

        private void dataGridViewDetalleJob_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewDetalleJob.Columns[e.ColumnIndex].Name.Equals(TBL_DET_JOB_ESTADO_VALIDACION))
            {
                string estado = dataGridViewDetalleJob.Rows[e.RowIndex].Cells[TBL_DET_JOB_ESTADO_VALIDACION].Value.ToString();

                if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_OK))
                {
                    dataGridViewDetalleJob.Rows[e.RowIndex].Cells[TBL_DET_JOB_ESTADO_VALIDACION].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_ERROR))
                    {
                        dataGridViewDetalleJob.Rows[e.RowIndex].Cells[TBL_DET_JOB_ESTADO_VALIDACION].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

        private void dataGridViewDetalleStage_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewDetalleStage.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == TBL_STAGE_POS_ABRIR) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewDetalleStage.CurrentCell.RowIndex;

                string identifierStage = dataGridViewDetalleStage.Rows[filaSeleccionada].Cells[TBL_STAGE_IDENTIFIER].Value.ToString();

                LogStage stage = UtilDataStage.getStageByIdentifier(identifierStage, job.listaStage);
                mostrarMensajeStage(stage);

                dataGridViewDetalleStage.Rows[filaSeleccionada].Cells[columnaSeleccionada].Selected = false;
                dataGridViewDetalleStage.Rows[filaSeleccionada].Cells[TBL_STAGE_NOMBRE_STAGE].Selected = true;
            }
        }

        private void dataGridViewDetalleJob_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewDetalleJob.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == TBL_DET_JOB_POS_ABRIR) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewDetalleJob.CurrentCell.RowIndex;

                string mensaje = dataGridViewDetalleJob.Rows[filaSeleccionada].Cells[TBL_DET_JOB_MENSAJE_VALIDACION].Value.ToString();

                mostrarMensajeJob(mensaje);

                dataGridViewDetalleJob.Rows[filaSeleccionada].Cells[columnaSeleccionada].Selected = false;
                dataGridViewDetalleJob.Rows[filaSeleccionada].Cells[TBL_DET_JOB_NOMBRE_VALIDACION].Selected = true;
            }

        }

        private void mostrarMensajeStage(LogStage stage)
        {
            if (stage.mensaje != null && stage.mensaje != "")
            {
                string desConSalto = stage.mensaje;
                desConSalto = desConSalto.Replace(": ", ": \n");
                desConSalto = desConSalto.Replace(". ", ". \n\n");
                MessageBox.Show(desConSalto, "Validación de Stage", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void mostrarMensajeJob(string mensaje)
        {
            if (mensaje != null && mensaje != "")
            {
                string desConSalto = mensaje;
                desConSalto = desConSalto.Replace(": ", ": \n");
                desConSalto = desConSalto.Replace(". ", ". \n\n");
                MessageBox.Show(desConSalto, "Validación de Job", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
