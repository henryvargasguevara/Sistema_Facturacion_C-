﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;

namespace ValidadorSES.form
{
    public partial class FormReglaListado : Form
    {
        public Usuario usuarioLogueado { get; set; }

        public const string TBL_REGLA_EDITAR= "Editar";
        public const int TBL_REGLA_POS_EDITAR = 0;
        public const string TBL_REGLA_CODIGO = "Código";
        public const string TBL_REGLA_OBJETO = "Objeto";
        public const string TBL_REGLA_NOMBRE = "Nombre";
        public const string TBL_REGLA_ESTADO = "Estado";
        public const string TBL_REGLA_ESTADO_FULL = "FULL";
        public const string TBL_REGLA_ESTADO_EXPRESS = "EXPRESS";
        public const string TBL_REGLA_DESCRIPCION = "Descripción";
        public const string TBL_REGLA_SUGERENCIA = "Sugerencia de solución";
        public const string TBL_REGLA_USUARIO_REGISTRO = "Usuario creación";
        public const string TBL_REGLA_FECHA_REGISTRO = "Fecha creación";
        public const string TBL_REGLA_USUARIO_MODIFICACION = "Usuario modificación";
        public const string TBL_REGLA_FECHA_MODIFICACION = "Fecha modificación";
        
        public FormReglaListado()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_MANTENIMIENTO_REGLA_VALIDACION;

            txtBuscar.Text = txtBuscar.Text.Trim();
            string textoBuscar = txtBuscar.Text;

            if (textoBuscar == "")
            {
                mostrarTablaListadoRegla();
            }
            btnBuscar.Visible = false;
        }
        
        private void lnkRegistroRegla_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormReglaRegistroModificacion formRegistro = new FormReglaRegistroModificacion();
            formRegistro.ShowDialog();
            mostrarTablaListadoRegla();
        }

        private void mostrarTablaListadoRegla() {
            List<ReglaView> lista = new List<ReglaView>();

            try
            {
                ReglaDAO rdao = new ReglaDAO();
                lista = rdao.getListaReglaView();
            }catch(Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            llenarTabla(lista);
        }

        private void llenarTabla(List<ReglaView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_CODIGO));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_OBJETO));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_ESTADO_FULL));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_ESTADO_EXPRESS));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_DESCRIPCION));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_SUGERENCIA));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_USUARIO_REGISTRO));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_FECHA_REGISTRO));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_USUARIO_MODIFICACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_FECHA_MODIFICACION));
            
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    ReglaView rv = lista[j];
                    DataRow row = table.NewRow();
                    row[TBL_REGLA_CODIGO] = rv.codigoRegla;
                    row[TBL_REGLA_OBJETO] = rv.tipoObjeto;
                    row[TBL_REGLA_NOMBRE] = rv.nombre;
                    row[TBL_REGLA_ESTADO_FULL] = rv.estadoFull;
                    row[TBL_REGLA_ESTADO_EXPRESS] = rv.estadoExpress;
                    row[TBL_REGLA_ESTADO] = rv.estado;
                    row[TBL_REGLA_DESCRIPCION] = rv.descripcion;
                    row[TBL_REGLA_SUGERENCIA] = rv.sugerencia;
                    row[TBL_REGLA_USUARIO_REGISTRO] = rv.usuarioCreador;
                    row[TBL_REGLA_FECHA_REGISTRO] = rv.fechaCreacion;
                    row[TBL_REGLA_USUARIO_MODIFICACION] = rv.usuarioModificador;
                    row[TBL_REGLA_FECHA_MODIFICACION] = rv.fechaModificacion;

                    table.Rows.Add(row);
                }
            }

            dataGridViewRegla.Columns.Clear();
            DataView view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewRegla.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = TBL_REGLA_EDITAR;
            buttonColumn.Text = ">";
            buttonColumn.Name = TBL_REGLA_EDITAR;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewRegla.Visible = true;
            dataGridViewRegla.RowHeadersVisible = false;
            dataGridViewRegla.DataSource = view;

            dataGridViewRegla.Columns[TBL_REGLA_EDITAR].Width = 40;
            dataGridViewRegla.Columns[TBL_REGLA_OBJETO].Width = 100;
            dataGridViewRegla.Columns[TBL_REGLA_NOMBRE].Width = 300;
            dataGridViewRegla.Columns[TBL_REGLA_ESTADO_FULL].Width = 80;
            dataGridViewRegla.Columns[TBL_REGLA_ESTADO_EXPRESS].Width = 80;
            dataGridViewRegla.Columns[TBL_REGLA_ESTADO].Width = 80;
            dataGridViewRegla.Columns[TBL_REGLA_DESCRIPCION].Width = 250;
            dataGridViewRegla.Columns[TBL_REGLA_SUGERENCIA].Width = 250;
            dataGridViewRegla.Columns[TBL_REGLA_USUARIO_REGISTRO].Width = 150;
            dataGridViewRegla.Columns[TBL_REGLA_FECHA_REGISTRO].Width = 150;
            dataGridViewRegla.Columns[TBL_REGLA_USUARIO_MODIFICACION].Width = 150;
            dataGridViewRegla.Columns[TBL_REGLA_FECHA_MODIFICACION].Width = 150;

            dataGridViewRegla.Columns[TBL_REGLA_CODIGO].Visible = false;

            dataGridViewRegla.Columns[TBL_REGLA_EDITAR].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewRegla.Columns[TBL_REGLA_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewRegla.Columns[TBL_REGLA_ESTADO_FULL].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewRegla.Columns[TBL_REGLA_ESTADO_EXPRESS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewRegla.Columns[TBL_REGLA_FECHA_REGISTRO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewRegla.Columns[TBL_REGLA_FECHA_MODIFICACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void dataGridViewRegla_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnaSeleccionada = dataGridViewRegla.CurrentCell.ColumnIndex;
            int f = dataGridViewRegla.CurrentCell.RowIndex;

            if (columnaSeleccionada == TBL_REGLA_POS_EDITAR) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewRegla.CurrentCell.RowIndex;

                string codigoRegla = dataGridViewRegla.Rows[filaSeleccionada].Cells[TBL_REGLA_CODIGO].Value.ToString();
                int codigo = Convert.ToInt32(codigoRegla);

                try
                {
                    ReglaDAO rdao = new ReglaDAO();
                    ReglaView regla = rdao.getReglaViewByCodigo(codigo);

                    FormReglaRegistroModificacion formModificacion = new FormReglaRegistroModificacion();
                    formModificacion.usuarioLogueado = usuarioLogueado;
                    formModificacion.cargarReglaView(regla);
                    formModificacion.ShowDialog();

                    dataGridViewRegla.Rows[filaSeleccionada].Cells[TBL_REGLA_EDITAR].Selected = false;

                    mostrarTablaListadoRegla();
                    txtBuscar.Text = "";
                    this.Visible = true;
                }
                catch (Exception)
                {
                    MessageBox.Show("Ocurrió un error de BD");
                }

            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            txtBuscar.Text = txtBuscar.Text.Trim();
            string textoBuscar = txtBuscar.Text;

            if (textoBuscar != "")
            {
                List<ReglaView> lista = new List<ReglaView>();

                try
                {
                    ReglaDAO rdao = new ReglaDAO();
                    lista = rdao.getListaReglaViewByKeyWord(textoBuscar);
                }
                catch (Exception)
                {
                    MessageBox.Show("Ocurrió un error de BD");
                }

                llenarTabla(lista);
            }
            else
            {
                mostrarTablaListadoRegla();
                //string mensaje = "Debe ingresar un texto a buscar";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            //txtBuscar.Text = txtBuscar.Text.Trim();
            string textoBuscar = txtBuscar.Text;

            if (textoBuscar != "")
            {
                List<ReglaView> lista = new List<ReglaView>();

                try
                {
                    ReglaDAO rdao = new ReglaDAO();
                    lista = rdao.getListaReglaViewByKeyWord(textoBuscar);
                }
                catch (Exception)
                {
                    MessageBox.Show("Ocurrió un error de BD");
                }

                llenarTabla(lista);
            }
            else
            {
                mostrarTablaListadoRegla();
                //string mensaje = "Debe ingresar un texto a buscar";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
