﻿namespace ValidadorSES.form
{
    partial class FormMantenimientoUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMantenimientoUsuario));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMantNombreUser = new System.Windows.Forms.TextBox();
            this.txtMantApellidoUser = new System.Windows.Forms.TextBox();
            this.txtMantUsuarioUser = new System.Windows.Forms.TextBox();
            this.txtMantContraseñaUser = new System.Windows.Forms.TextBox();
            this.cboMantCargoUser = new System.Windows.Forms.ComboBox();
            this.cboMantLiderUser = new System.Windows.Forms.ComboBox();
            this.cboMantEstadoUser = new System.Windows.Forms.ComboBox();
            this.btnMantUserRegistrar = new System.Windows.Forms.Button();
            this.btnManUserNuevo = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMantBuscarUser = new System.Windows.Forms.TextBox();
            this.dgMantUsuario = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblRespuesta = new System.Windows.Forms.Label();
            this.txtRespuestaSecreta = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboPreguntaSecreta = new System.Windows.Forms.ComboBox();
            this.txtcodigoUsuario = new System.Windows.Forms.TextBox();
            this.btnMantModificarUser = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgMantUsuario)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombres";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellidos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(90, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cargo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(95, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Lider";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(85, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Estado";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(82, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Usuario";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(303, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Contraseña";
            // 
            // txtMantNombreUser
            // 
            this.txtMantNombreUser.Location = new System.Drawing.Point(131, 17);
            this.txtMantNombreUser.Name = "txtMantNombreUser";
            this.txtMantNombreUser.Size = new System.Drawing.Size(251, 20);
            this.txtMantNombreUser.TabIndex = 1;
            // 
            // txtMantApellidoUser
            // 
            this.txtMantApellidoUser.Location = new System.Drawing.Point(131, 41);
            this.txtMantApellidoUser.Name = "txtMantApellidoUser";
            this.txtMantApellidoUser.Size = new System.Drawing.Size(251, 20);
            this.txtMantApellidoUser.TabIndex = 2;
            // 
            // txtMantUsuarioUser
            // 
            this.txtMantUsuarioUser.Location = new System.Drawing.Point(131, 151);
            this.txtMantUsuarioUser.Name = "txtMantUsuarioUser";
            this.txtMantUsuarioUser.Size = new System.Drawing.Size(121, 20);
            this.txtMantUsuarioUser.TabIndex = 6;
            // 
            // txtMantContraseñaUser
            // 
            this.txtMantContraseñaUser.Location = new System.Drawing.Point(370, 149);
            this.txtMantContraseñaUser.Name = "txtMantContraseñaUser";
            this.txtMantContraseñaUser.Size = new System.Drawing.Size(112, 20);
            this.txtMantContraseñaUser.TabIndex = 7;
            this.txtMantContraseñaUser.UseSystemPasswordChar = true;
            // 
            // cboMantCargoUser
            // 
            this.cboMantCargoUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMantCargoUser.FormattingEnabled = true;
            this.cboMantCargoUser.Location = new System.Drawing.Point(131, 70);
            this.cboMantCargoUser.Name = "cboMantCargoUser";
            this.cboMantCargoUser.Size = new System.Drawing.Size(121, 21);
            this.cboMantCargoUser.TabIndex = 3;
            this.cboMantCargoUser.SelectedIndexChanged += new System.EventHandler(this.cboMantCargoUser_SelectedIndexChanged_1);
            // 
            // cboMantLiderUser
            // 
            this.cboMantLiderUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMantLiderUser.FormattingEnabled = true;
            this.cboMantLiderUser.Location = new System.Drawing.Point(131, 96);
            this.cboMantLiderUser.Name = "cboMantLiderUser";
            this.cboMantLiderUser.Size = new System.Drawing.Size(251, 21);
            this.cboMantLiderUser.TabIndex = 4;
            // 
            // cboMantEstadoUser
            // 
            this.cboMantEstadoUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMantEstadoUser.FormattingEnabled = true;
            this.cboMantEstadoUser.Location = new System.Drawing.Point(131, 124);
            this.cboMantEstadoUser.Name = "cboMantEstadoUser";
            this.cboMantEstadoUser.Size = new System.Drawing.Size(121, 21);
            this.cboMantEstadoUser.TabIndex = 5;
            // 
            // btnMantUserRegistrar
            // 
            this.btnMantUserRegistrar.Location = new System.Drawing.Point(407, 40);
            this.btnMantUserRegistrar.Name = "btnMantUserRegistrar";
            this.btnMantUserRegistrar.Size = new System.Drawing.Size(75, 23);
            this.btnMantUserRegistrar.TabIndex = 15;
            this.btnMantUserRegistrar.Text = "Grabar";
            this.btnMantUserRegistrar.UseVisualStyleBackColor = true;
            this.btnMantUserRegistrar.Click += new System.EventHandler(this.btnMantUserRegistrar_Click);
            // 
            // btnManUserNuevo
            // 
            this.btnManUserNuevo.Location = new System.Drawing.Point(407, 11);
            this.btnManUserNuevo.Name = "btnManUserNuevo";
            this.btnManUserNuevo.Size = new System.Drawing.Size(75, 23);
            this.btnManUserNuevo.TabIndex = 16;
            this.btnManUserNuevo.Text = "Nuevo";
            this.btnManUserNuevo.UseVisualStyleBackColor = true;
            this.btnManUserNuevo.Click += new System.EventHandler(this.btnManUserNuevo_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(46, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Ingrese criterio ";
            // 
            // txtMantBuscarUser
            // 
            this.txtMantBuscarUser.Location = new System.Drawing.Point(131, 19);
            this.txtMantBuscarUser.Name = "txtMantBuscarUser";
            this.txtMantBuscarUser.Size = new System.Drawing.Size(240, 20);
            this.txtMantBuscarUser.TabIndex = 18;
            this.txtMantBuscarUser.TextChanged += new System.EventHandler(this.txtMantBuscarUser_TextChanged);
            // 
            // dgMantUsuario
            // 
            this.dgMantUsuario.AllowUserToAddRows = false;
            this.dgMantUsuario.AllowUserToDeleteRows = false;
            this.dgMantUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgMantUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgMantUsuario.Location = new System.Drawing.Point(12, 294);
            this.dgMantUsuario.Name = "dgMantUsuario";
            this.dgMantUsuario.ReadOnly = true;
            this.dgMantUsuario.Size = new System.Drawing.Size(497, 205);
            this.dgMantUsuario.TabIndex = 20;
            this.dgMantUsuario.SelectionChanged += new System.EventHandler(this.dgMantUsuario_SelectionChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblRespuesta);
            this.groupBox1.Controls.Add(this.txtRespuestaSecreta);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cboPreguntaSecreta);
            this.groupBox1.Controls.Add(this.txtcodigoUsuario);
            this.groupBox1.Controls.Add(this.btnMantModificarUser);
            this.groupBox1.Controls.Add(this.txtMantNombreUser);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnMantUserRegistrar);
            this.groupBox1.Controls.Add(this.btnManUserNuevo);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cboMantEstadoUser);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cboMantLiderUser);
            this.groupBox1.Controls.Add(this.txtMantApellidoUser);
            this.groupBox1.Controls.Add(this.cboMantCargoUser);
            this.groupBox1.Controls.Add(this.txtMantUsuarioUser);
            this.groupBox1.Controls.Add(this.txtMantContraseñaUser);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(497, 211);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos Generales";
            // 
            // lblRespuesta
            // 
            this.lblRespuesta.AutoSize = true;
            this.lblRespuesta.Location = new System.Drawing.Point(268, 181);
            this.lblRespuesta.Name = "lblRespuesta";
            this.lblRespuesta.Size = new System.Drawing.Size(96, 13);
            this.lblRespuesta.TabIndex = 22;
            this.lblRespuesta.Text = "Respuesta secreta";
            // 
            // txtRespuestaSecreta
            // 
            this.txtRespuestaSecreta.Location = new System.Drawing.Point(370, 178);
            this.txtRespuestaSecreta.Name = "txtRespuestaSecreta";
            this.txtRespuestaSecreta.Size = new System.Drawing.Size(112, 20);
            this.txtRespuestaSecreta.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 180);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Pregunta secreta";
            // 
            // cboPreguntaSecreta
            // 
            this.cboPreguntaSecreta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPreguntaSecreta.FormattingEnabled = true;
            this.cboPreguntaSecreta.Location = new System.Drawing.Point(131, 177);
            this.cboPreguntaSecreta.Name = "cboPreguntaSecreta";
            this.cboPreguntaSecreta.Size = new System.Drawing.Size(121, 21);
            this.cboPreguntaSecreta.TabIndex = 8;
            // 
            // txtcodigoUsuario
            // 
            this.txtcodigoUsuario.Location = new System.Drawing.Point(442, 120);
            this.txtcodigoUsuario.Name = "txtcodigoUsuario";
            this.txtcodigoUsuario.Size = new System.Drawing.Size(40, 20);
            this.txtcodigoUsuario.TabIndex = 18;
            this.txtcodigoUsuario.Visible = false;
            // 
            // btnMantModificarUser
            // 
            this.btnMantModificarUser.Location = new System.Drawing.Point(407, 70);
            this.btnMantModificarUser.Name = "btnMantModificarUser";
            this.btnMantModificarUser.Size = new System.Drawing.Size(75, 23);
            this.btnMantModificarUser.TabIndex = 17;
            this.btnMantModificarUser.Text = "Modificar";
            this.btnMantModificarUser.UseVisualStyleBackColor = true;
            this.btnMantModificarUser.Click += new System.EventHandler(this.btnMantModificarUser_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtMantBuscarUser);
            this.groupBox2.Location = new System.Drawing.Point(12, 229);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(497, 59);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Busqueda";
            // 
            // FormMantenimientoUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 511);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgMantUsuario);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMantenimientoUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mantenimiento de Usuarios - Validador SES 2.0";
            ((System.ComponentModel.ISupportInitialize)(this.dgMantUsuario)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMantNombreUser;
        private System.Windows.Forms.TextBox txtMantApellidoUser;
        private System.Windows.Forms.TextBox txtMantUsuarioUser;
        private System.Windows.Forms.TextBox txtMantContraseñaUser;
        private System.Windows.Forms.ComboBox cboMantCargoUser;
        private System.Windows.Forms.ComboBox cboMantLiderUser;
        private System.Windows.Forms.ComboBox cboMantEstadoUser;
        private System.Windows.Forms.Button btnMantUserRegistrar;
        private System.Windows.Forms.Button btnManUserNuevo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMantBuscarUser;
        private System.Windows.Forms.DataGridView dgMantUsuario;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnMantModificarUser;
        private System.Windows.Forms.TextBox txtcodigoUsuario;
        private System.Windows.Forms.Label lblRespuesta;
        private System.Windows.Forms.TextBox txtRespuestaSecreta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboPreguntaSecreta;
    }
}