﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo;
using ValidadorSES.dao;
//using System.Web.ClientServices.Providers;
//using System.Web.Security;
using ValidadorSES.util;


namespace ValidadorSES.form
{
    public partial class FormLogin : Form
    {
        public Singleton sesion { get; set; }
        public FormLogin()
        {
            InitializeComponent();

            txtUsuario.Text = "";
            txtContraseña.Text = "";
            this.Text = ConstanteTituloForm.TITULO_LOGIN;
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            UsuarioDAO dao = new UsuarioDAO();
            Usuario obj = new Usuario();
            obj.usuario = txtUsuario.Text;
            obj.contraseña = txtContraseña.Text;

            if (string.IsNullOrEmpty(txtUsuario.Text) || string.IsNullOrEmpty(txtContraseña.Text))
            {
                MessageBox.Show("Usuario o contraseña se encuentra vacío", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUsuario.Text = string.Empty;
                txtContraseña.Text = string.Empty;
            }
            else
            {
                Usuario usu = dao.Login(obj);
                if (usu != null)
                {
                    this.Hide();
                    FormPrincipal formMenu = new FormPrincipal();
                    //sesion = Singleton.GetInstance(usu);
                    //formMenu.usuariologeado1 = sesion.usuario;
                    formMenu.usuarioLogueado = usu;

                    //*Validaciones para Que muestre Menú según el tipo de cargo del usuario*//
                    if (usu.cargo_usuario == 1)
                    {
                        formMenu.btnAsignacionColaborador.Visible = false;
                        formMenu.btnAsignacionRequerimiento.Visible = false;
                    }
                    else if (usu.cargo_usuario == 2)
                    {
                        formMenu.btnMenuManUsers.Visible = false;
                        formMenu.btnGestionarRequerimiento.Visible = false;
                        formMenu.btnMenuAsignReglas.Visible = false;
                        formMenu.btnMenuManObj.Visible = false;
                        formMenu.btnMenuManReglas.Visible = false;
                        formMenu.btn_Reportes.Visible = false;
                        formMenu.btnValidacionExpressFull.Visible = false;
                    }
                    else
                    {
                        formMenu.btnMenuManUsers.Visible = false;
                        formMenu.btnGestionarRequerimiento.Visible = false;
                        formMenu.btnMenuAsignReglas.Visible = false;
                        formMenu.btnMenuManObj.Visible = false;
                        formMenu.btnMenuManReglas.Visible = false;
                        formMenu.btnAsignacionRequerimiento.Visible = false;
                        formMenu.btn_Reportes.Visible = false;
                        formMenu.btnValidacionExpressFull.Visible = false;
                    }
                    //**************************************************************//

                    formMenu.ShowDialog();
                    txtUsuario.Text = string.Empty;
                    txtContraseña.Text = string.Empty;

                }
                else
                {
                    MessageBox.Show("Usuario y contraseña incorrectos o usuario Inhabilitado ", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsuario.Text = string.Empty;
                    txtContraseña.Text = string.Empty;
                }
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormRegistrarUsuario formCrearUsuario = new FormRegistrarUsuario();
            formCrearUsuario.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormRecuperarContraseña frRecuperarContraseña = new FormRecuperarContraseña();
            frRecuperarContraseña.Show();
        }

        private void FormLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}

