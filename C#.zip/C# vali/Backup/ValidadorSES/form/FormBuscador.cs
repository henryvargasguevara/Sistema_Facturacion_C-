﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.service;

namespace ValidadorSES.form
{
    public partial class FormBuscador : Form
    {
        private LogDSX dsx = new LogDSX();
        private ResultadoBusqueda resultadoBusqueda = new ResultadoBusqueda();
        private bool filtroByNombreStage = true;
        private List<FiltroBusqueda> listaFiltro = new List<FiltroBusqueda>();
        private bool estaCargadoDSX = false;

        private bool mostrarResultado = true;

        public const string TBL_JOB_ABRIR_DETALLE = "Abrir";
        public const int TBL_JOB_POS_ABRIR_DETALLE = 0;
        public const string TBL_JOB_NOMBRE_JOB = "Nombre Job";
        public const string TBL_JOB_TIPO_JOB = "Tipo de Job";
        public const string TBL_JOB_TIPO_STAGE = "Tipo de Stage";
        public const string TBL_JOB_NOMBRE_STAGE = "Nombre de Stage";
        public const string TBL_JOB_TIPO_FILTRO = "Tipo de Filtro";
        public const string TBL_JOB_RESULTADO = "Resultado";
        public const string TBL_JOB_VER_MAS_PROPIEDADES_STAGE = "ver más propiedades";
        public const int TBL_JOB_POS_PROPIEDADES_STAGE = 5;
        public const string TBL_JOB_PROPIEDADES_STAGE = "Propiedades de Stage";
        public const string TBL_JOB_RUTA = "Ruta de Job";
        
        public const string TBL_ROUTINE_ABRIR_DETALLE = "Abrir";
        public const int TBL_ROUTINE_POS_ABRIR_DETALLE = 0;
        public const string TBL_ROUTINE_NOMBRE_ROUTINE = "Nombre Routine";
        public const string TBL_ROUTINE_TIPO_ROUTINE = "Tipo de Routine";
        public const string TBL_ROUTINE_TOTAL_ARGUMENTOS = "Nro Arg.";
        public const string TBL_ROUTINE_RUTA = "Ruta de Routine";
        
        public const string TBL_PARAMETER_SET_ABRIR_DETALLE = "Abrir";
        public const int TBL_PARAMETER_SET_POS_ABRIR_DETALLE = 0;
        public const string TBL_PARAMETER_SET_NOMBRE = "Nombre Parameter Set";
        public const string TBL_PARAMETER_SET_TOTAL_PARAMETROS = "Nro Parámetros";
        public const string TBL_PARAMETER_SET_RUTA = "Ruta de ParameterSet";

        public FormBuscador()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_BUSCADOR;
            mostrarResultado = true;
            backgroundWorker_Carga.WorkerReportsProgress = true;

            cargarListaFiltro();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridViewJob.Visible = false;
            progressBar_Load.Visible = false;

            btnExportarResultadoBusqueda.Visible = false;
            btnLimpiar.Visible = false;

            groupBoxCriterioBusqueda.Visible = true;

            lblPalabraAdicional.Visible = true;
            txtKeyword.Visible = true;
        }

        private void cargarListaFiltro()
        {
            List<FiltroBusqueda> lista = new List<FiltroBusqueda>();

            try
            {
                lista = BuscadorService.getListaFiltroBusquedaStage();
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            listaFiltro = lista;
        }

        private void buttonCargar_Click(object sender, EventArgs e)
        {            
            progressBar_Load.Visible = false;
            dataGridViewJob.Visible = false;
            dataGridViewRoutine.Visible = false;
            dataGridViewParameterSet.Visible = false;

            btnLimpiar.Visible = false;

            //validación de formulario
            string mensaje = "";
            if (!UtilArchivo.esValidoArchivoDSX(txtRutaDSX.Text))
            {
                mensaje += ConstanteCadena.MSG_VAL_ARCHIVO_DSX + "\n";
            }
            if (txtKeyword.Text == "")
            {
                mensaje += ConstanteCadena.MSG_VAL_KEYWORD + "\n";
            }

            //procesar
            if (mensaje=="")
            {
                progressBar_Load.Visible = true;
                backgroundWorker_Carga.RunWorkerAsync();
            }
            else
            {
                MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        /*
         * Ejecutar el proceso de validación en segundo plano 
         * */
        private void backgroundWorker_Carga_DoWork(object sender, DoWorkEventArgs e)
        {
            System.Threading.Thread.Sleep(5); //simulamos trabajo
            backgroundWorker_Carga.ReportProgress(0);

            string textoBuscar = txtKeyword.Text;
            bool busquedaExacta = checkBoxPalabraExacta.Checked;
            bool omitirMayMin = checkBoxOmitirMayMin.Checked;
            
            if (!estaCargadoDSX)
            {
                //obtener la lista de variables de entorno del archivo .ENV
                List<VariableEntorno> listaVariableEntorno = new List<VariableEntorno>();
                LogDSX dsxAdicional = new LogDSX();

                //obtener datos del archivo DSX
                ProcesoService procesoService = new ProcesoService();

                int totalLineas = UtilArchivo.contarLineasArchivo(txtRutaDSX.Text);
                dsx = procesoService.getObjetoDSXFromArchivo(txtRutaDSX.Text, backgroundWorker_Carga, totalLineas);
                estaCargadoDSX = true;
            }
            resultadoBusqueda = BuscadorService.getResultadoBusquedaByNombreStage(textoBuscar, dsx, busquedaExacta, omitirMayMin, listaFiltro, filtroByNombreStage);

            //salida de la función, ver backgroundWorker_Carga_RunWorkerCompleted
            e.Result = "";
        }

        private void backgroundWorker_Carga_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage <= 100)
            {
                progressBar_Load.Value = e.ProgressPercentage; //actualizamos la barra de progreso
            }
            else
            {
                progressBar_Load.Value = 100;
            }
        }

        private void backgroundWorker_Carga_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                MessageBox.Show("Se canceló la carga del archivo");
            }
            else if (e.Error != null)
            {
                MessageBox.Show("Error. Detalles: " + (e.Error as Exception).ToString());
            }
            else
            {
                //llenar la tabla principal
                if (mostrarResultado)
                {
                    cargarPantallaPrincipal();
                }
                else
                {
                    progressBar_Load.Visible = false;
                    limpiarEventoText();
                }
            }
        }

        private void cargarPantallaPrincipal()
        {
            this.progressBar_Load.Visible = false;
            dataGridViewJob.Visible = false;
            dataGridViewRoutine.Visible = false;
            dataGridViewParameterSet.Visible = false;

            btnExportarResultadoBusqueda.Visible = true;
            btnLimpiar.Visible = true;

            cargarTotalObjetos();
            cargarTablaJob();
            //cargarTablaRoutine();
            //cargarTablaParameterSet();
        }

        private void cargarTotalObjetos()
        {
            //Cuadro de total de jobs
            txtNroResultado.Text = Convert.ToString(resultadoBusqueda.totalResultado);
            txtNroJob.Text = Convert.ToString(resultadoBusqueda.totalJob);
            txtNroStage.Text = Convert.ToString(resultadoBusqueda.totalStage);
            txtNroRoutine.Text = Convert.ToString(resultadoBusqueda.totalRoutine);
            txtNroParameterSet.Text = Convert.ToString(resultadoBusqueda.totalParameterSet); 
        }

        private void cargarTablaJob()
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_TIPO_JOB));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_NOMBRE_JOB));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_TIPO_STAGE));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_NOMBRE_STAGE));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_TIPO_FILTRO));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_RESULTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_RUTA));

            //creacion de la tabla
            List<ResultadoJob> listaJob = resultadoBusqueda.listaJob;
            int totalJobs = listaJob.Count;
            for (int j = 0; j < totalJobs; j++)
            {
                ResultadoJob job = listaJob[j];
                List<ResultadoStage> listaStage = job.listaStage;

                for (int s = 0; s<listaStage.Count; s++)
                {
                    ResultadoStage stage = listaStage[s];

                    for (int f = 0; f<stage.listaResultado.Count; f++)
                    {
                        ResultadoFiltro filtro = stage.listaResultado[f];

                        DataRow row = table.NewRow();
                        row[TBL_JOB_TIPO_JOB] = job.tipoJob;
                        row[TBL_JOB_NOMBRE_JOB] = job.nombreJob;
                        row[TBL_JOB_TIPO_STAGE] = stage.tipoStage;
                        row[TBL_JOB_NOMBRE_STAGE] = stage.nombreStage;
                        row[TBL_JOB_TIPO_FILTRO] = filtro.descripcionFiltro;
                        row[TBL_JOB_RESULTADO] = filtro.resultado;
                        row[TBL_JOB_RUTA] = job.rutaJob;

                        table.Rows.Add(row);                      
                    }              
                }
            }

            dataGridViewJob.Columns.Clear();
            view = new DataView(table);
            
            dataGridViewJob.Visible = true;
            dataGridViewJob.RowHeadersVisible = false;
            dataGridViewJob.DataSource = view;

            dataGridViewJob.Columns[TBL_JOB_NOMBRE_JOB].Width = 250;
            dataGridViewJob.Columns[TBL_JOB_TIPO_JOB].Width = 90;
            dataGridViewJob.Columns[TBL_JOB_TIPO_STAGE].Width = 100;
            dataGridViewJob.Columns[TBL_JOB_NOMBRE_STAGE].Width = 300;
            dataGridViewJob.Columns[TBL_JOB_TIPO_FILTRO].Width = 100;
            dataGridViewJob.Columns[TBL_JOB_RESULTADO].Width = 500;
            dataGridViewJob.Columns[TBL_JOB_RUTA].Width = 500;
        }

        private void cargarTablaRoutine() 
        {
            ////declaración de tabla y columnas
            //DataTable table = new DataTable();
            //DataView view = new DataView();

            //table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_NOMBRE_ROUTINE));
            //table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_TIPO_ROUTINE));
            //table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_TOTAL_ARGUMENTOS));

            ////creacion de la tabla
            //List<LogRoutine> listaRoutine = dsx.listaRoutine;
            //if (listaRoutine != null && listaRoutine.Count > 0)
            //{
            //    int totalRoutine = listaRoutine.Count;
            //    for (int j = 0; j < totalRoutine; j++)
            //    {
            //        DataRow row = table.NewRow();
            //        row[TBL_ROUTINE_NOMBRE_ROUTINE] = listaRoutine[j].identifier;
            //        row[TBL_ROUTINE_TIPO_ROUTINE] = listaRoutine[j].objeto.nombre;
            //        row[TBL_ROUTINE_TOTAL_ARGUMENTOS] = listaRoutine[j].listaArgumentoRoutine.Count;

            //        table.Rows.Add(row);
            //    }
            //}

            //dataGridViewRoutine.Columns.Clear();
            //view = new DataView(table);

            //DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            //dataGridViewRoutine.Columns.Add(buttonColumn);
            //buttonColumn.HeaderText = "Abrir";
            //buttonColumn.Text = ">";
            //buttonColumn.Name = TBL_ROUTINE_ABRIR_DETALLE;
            //buttonColumn.DisplayIndex = 0;
            //buttonColumn.UseColumnTextForButtonValue = true;

            //dataGridViewRoutine.Visible = true;
            //dataGridViewRoutine.RowHeadersVisible = false;
            //dataGridViewRoutine.DataSource = view;

            //dataGridViewRoutine.Columns[TBL_ROUTINE_ABRIR_DETALLE].Width = 40;
            //dataGridViewRoutine.Columns[TBL_ROUTINE_NOMBRE_ROUTINE].Width = 301;
            //dataGridViewRoutine.Columns[TBL_ROUTINE_TIPO_ROUTINE].Width = 110; 
            //dataGridViewRoutine.Columns[TBL_ROUTINE_TOTAL_ARGUMENTOS].Width = 70;
        }

        private void cargarTablaParameterSet()
        {
            ////declaración de tabla y columnas
            //DataTable table = new DataTable();
            //DataView view = new DataView();

            //table.Columns.Add(UtilForm.getColumnString(TBL_PARAMETER_SET_NOMBRE));
            //table.Columns.Add(UtilForm.getColumnString(TBL_PARAMETER_SET_TOTAL_PARAMETROS));

            ////creacion de la tabla
            //List<LogParameterSet> listaParameterSet = dsx.listaParameterSet;
            //int totalParameterSet = 0;
            //if (listaParameterSet != null && listaParameterSet.Count > 0)
            //{
            //    totalParameterSet = listaParameterSet.Count;
            //    for (int j = 0; j < totalParameterSet; j++)
            //    {
            //        DataRow row = table.NewRow();
            //        row[TBL_PARAMETER_SET_NOMBRE] = listaParameterSet[j].identifierParameterSet;
            //        row[TBL_PARAMETER_SET_TOTAL_PARAMETROS] = listaParameterSet[j].listaParam.Count;

            //        table.Rows.Add(row);
            //    }
            //}

            //dataGridViewParameterSet.Columns.Clear();
            //view = new DataView(table);

            //dataGridViewParameterSet.Visible = true;
            //dataGridViewParameterSet.RowHeadersVisible = false;
            //dataGridViewParameterSet.DataSource = view;

            //dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_ABRIR_DETALLE].Width = 40;
            //dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_NOMBRE].Width = 371; //110 de tipo, 301 de nombre
            //dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_TOTAL_PARAMETROS].Width = 110; //70 de nro
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtRutaDSX.Clear();
            txtKeyword.Clear();

            tabControlObjeto.SelectedIndex = 0;

            limpiarEventoText();

            //obtener la lista de filtro, sin distinciones
            cargarListaFiltro();
        }

        private void txtRutaDSX_TextChanged(object sender, EventArgs e)
        {
            limpiarEventoText();
        }
        
        private void txtRutaENV_TextChanged(object sender, EventArgs e)
        {
            limpiarEventoText();
        }

        private void limpiarEventoText()
        {
            txtNroJob.Clear();
            txtNroResultado.Clear();
            txtNroStage.Clear();
            txtNroRoutine.Clear();
            txtNroParameterSet.Clear();

            dataGridViewJob.DataSource = null;
            dataGridViewJob.Visible = false;
            dataGridViewRoutine.DataSource = null;
            dataGridViewRoutine.Visible = false;
            dataGridViewParameterSet.DataSource = null;
            dataGridViewParameterSet.Visible = false;

            btnExportarResultadoBusqueda.Visible = false;
            btnLimpiar.Visible = false;
        }

        private void seleccionarDSX_Click(object sender, EventArgs e)
        {
            txtRutaDSX.Text = "";
            OpenFileDialog path = new OpenFileDialog();

            if (path.ShowDialog() == DialogResult.OK)
            {
                txtRutaDSX.Text = path.FileName;
                estaCargadoDSX = false;
            }
        }
                
        /*
         * Click para abrir una nueva pantalla que muestra la lista de stages del job seleccionado
         * */
        private void dataGridViewJob_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewJob.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 7) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewJob.CurrentCell.RowIndex;

                string propiedades = dataGridViewJob.Rows[filaSeleccionada].Cells[TBL_JOB_PROPIEDADES_STAGE].Value.ToString();

                if (propiedades != "")
                {
                    MessageBox.Show(propiedades, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        /*
         * Click para abrir una nueva pantalla que muestra la lista de argumentos de la rutina seleccionada
         * */
        private void dataGridViewRoutine_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnaSeleccionada = dataGridViewRoutine.CurrentCell.ColumnIndex;

            if (columnaSeleccionada == TBL_ROUTINE_POS_ABRIR_DETALLE) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewRoutine.CurrentCell.RowIndex;
                
                string nombreRoutine = dataGridViewRoutine.Rows[filaSeleccionada].Cells[TBL_ROUTINE_NOMBRE_ROUTINE].Value.ToString();
                
            }
        }

        private void dataGridViewParameterSet_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnaSeleccionada = dataGridViewParameterSet .CurrentCell.ColumnIndex;

            if (columnaSeleccionada == TBL_PARAMETER_SET_POS_ABRIR_DETALLE) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewParameterSet.CurrentCell.RowIndex;

            }
        }

        private void btnExportarResultadoBusqueda_Click_1(object sender, EventArgs e)
        {
            UtilExcel.exportarToExcelResultadoBusqueda(resultadoBusqueda, saveFileDialog, txtRutaDSX.Text);
        }

        private void btnEscogerFiltro_Click(object sender, EventArgs e)
        {
            FormBuscadorFiltro formFiltro = new FormBuscadorFiltro();
            formFiltro.listaFiltro = listaFiltro;
            formFiltro.filtroByNombreStage = filtroByNombreStage;
            formFiltro.cargarPantalla();
            formFiltro.ShowDialog();

            listaFiltro = formFiltro.listaFiltro;
            filtroByNombreStage = formFiltro.filtroByNombreStage;
        }

    }
}

