﻿namespace ValidadorSES.form
{
    partial class FormValidadorCerrarValidacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormValidadorCerrarValidacion));
            this.dataGridViewNotok = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNota = new System.Windows.Forms.TextBox();
            this.btnCerrarValidacion = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNotok)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewNotok
            // 
            this.dataGridViewNotok.AllowUserToAddRows = false;
            this.dataGridViewNotok.AllowUserToDeleteRows = false;
            this.dataGridViewNotok.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewNotok.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNotok.Location = new System.Drawing.Point(12, 47);
            this.dataGridViewNotok.Name = "dataGridViewNotok";
            this.dataGridViewNotok.ReadOnly = true;
            this.dataGridViewNotok.Size = new System.Drawing.Size(669, 212);
            this.dataGridViewNotok.TabIndex = 2;
            this.dataGridViewNotok.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewNotok_CellFormatting);
            this.dataGridViewNotok.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewNotok_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Lista de errores y observaciones:";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nota:";
            // 
            // txtNota
            // 
            this.txtNota.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNota.Location = new System.Drawing.Point(12, 300);
            this.txtNota.Multiline = true;
            this.txtNota.Name = "txtNota";
            this.txtNota.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtNota.Size = new System.Drawing.Size(666, 129);
            this.txtNota.TabIndex = 5;
            // 
            // btnCerrarValidacion
            // 
            this.btnCerrarValidacion.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCerrarValidacion.Location = new System.Drawing.Point(287, 444);
            this.btnCerrarValidacion.Name = "btnCerrarValidacion";
            this.btnCerrarValidacion.Size = new System.Drawing.Size(118, 34);
            this.btnCerrarValidacion.TabIndex = 6;
            this.btnCerrarValidacion.Text = "Cerrar validación";
            this.btnCerrarValidacion.UseVisualStyleBackColor = true;
            this.btnCerrarValidacion.Click += new System.EventHandler(this.btnCerrarValidacion_Click);
            // 
            // FormValidadorCerrarValidacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(693, 490);
            this.Controls.Add(this.btnCerrarValidacion);
            this.Controls.Add(this.txtNota);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewNotok);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormValidadorCerrarValidacion";
            this.Text = "FormCerrarValidacion";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNotok)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewNotok;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNota;
        private System.Windows.Forms.Button btnCerrarValidacion;
    }
}