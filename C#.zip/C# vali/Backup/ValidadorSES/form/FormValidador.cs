﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.service;

namespace ValidadorSES.form
{
    public partial class FormValidador : Form
    {
        public bool isQA = false;
        public bool isDEV = false;

        public Usuario usuariologeado { get; set; }
        public string codigoAsignacion { get; set; }
        private LogDSX dsx = null;
        private AsignarRequerimientoView requerimientoActual = null;        
        private bool mostrarResultado = false;

        public const string TBL_JOB_ABRIR_DETALLE = "Abrir";
        public const int TBL_JOB_POS_ABRIR_DETALLE = 0;
        public const string TBL_JOB_NOMBRE_JOB = "Nombre Job";
        public const string TBL_JOB_TIPO_JOB = "Tipo de Job";
        public const string TBL_JOB_TOTAL_STAGES = "Nro Stages";
        public const string TBL_JOB_ESTADO = "Estado";
        public const string TBL_JOB_FECHA_EXPORTACION = "Fecha Exportación";
        public const string TBL_JOB_FECHA_MOD = "Fecha últ. mod.";
        public const string TBL_JOB_HORA_MOD = "Hora últ. mod.";
        public const string TBL_JOB_TOTAL_STAGES_CORRECTOS = "Nro correctos";
        public const string TBL_JOB_TOTAL_STAGES_ERRORES = "Nro incorrectos";
        public const string TBL_JOB_TOTAL_STAGES_OBSERVACIONES = "Nro Observaciones";
        public const string TBL_JOB_DESCRIPCION_VALIDACION = "Descripción de validación del Job";
        public const string TBL_JOB_RUTA = "Ruta de Job";
        
        public const string TBL_ROUTINE_ABRIR_DETALLE = "Abrir";
        public const int TBL_ROUTINE_POS_ABRIR_DETALLE = 0;
        public const string TBL_ROUTINE_NOMBRE_ROUTINE = "Nombre Routine";
        public const string TBL_ROUTINE_TIPO_ROUTINE = "Tipo de Routine";
        public const string TBL_ROUTINE_TOTAL_ARGUMENTOS = "Nro Arg.";
        public const string TBL_ROUTINE_ESTADO = "Estado";
        public const string TBL_ROUTINE_FECHA_EXPORTACION = "Fecha Exportación";
        public const string TBL_ROUTINE_FECHA_MOD = "Fecha últ. mod.";
        public const string TBL_ROUTINE_TOTAL_ARGUMENT_CORRECTOS = "Nro correctos";
        public const string TBL_ROUTINE_TOTAL_ARGUMENT_ERRORES = "Nro incorrectos";
        public const string TBL_ROUTINE_TOTAL_ARGUMENT_OBSERVACIONES = "Nro Observaciones";
        public const string TBL_ROUTINE_DESCRIPCION_VALIDACION = "Descripción de validación de Routine";
        public const string TBL_ROUTINE_RUTA = "Ruta de Routine";
        
        public const string TBL_PARAMETER_SET_ABRIR_DETALLE = "Abrir";
        public const int TBL_PARAMETER_SET_POS_ABRIR_DETALLE = 0;
        public const string TBL_PARAMETER_SET_NOMBRE = "Nombre Parameter Set";
        public const string TBL_PARAMETER_SET_TOTAL_PARAMETROS = "Nro Parámetros";
        public const string TBL_PARAMETER_SET_ESTADO = "Estado";
        public const string TBL_PARAMETER_SET_FECHA_EXPORTACION = "Fecha Exportación";
        public const string TBL_PARAMETER_SET_FECHA_MOD = "Fecha últ. mod.";
        public const string TBL_PARAMETER_SET_TOTAL_PARAM_CORRECTOS = "Nro correctos";
        public const string TBL_PARAMETER_SET_TOTAL_PARAM_ERRORES = "Nro incorrectos";
        public const string TBL_PARAMETER_SET_TOTAL_PARAM_OBSERVACIONES = "Nro Observaciones";
        public const string TBL_PARAMETER_SET_DESCRIPCION_VALIDACION = "Descripción de validación de ParameterSet";
        public const string TBL_PARAMETER_SET_RUTA = "Ruta de ParameterSet";

        public FormValidador()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_VALIDADOR;

            mostrarResultado = false;
            backgroundWorker_Carga.WorkerReportsProgress = true;
            if (ConstanteSistema.TIPO_VERSION_SISTEMA == ConstanteSistema.VERSION_SISTEMA_DATABASE)
            {
            }
            else {
                lnkVerTipoObjeto.Visible = false;
                lnkVerReglaValidacion.Visible = false;
                lnkCerrarValidacion.Visible = false;
            }

            if (ConstanteSistema.TIPO_PANTALLA_INICIAL == ConstanteSistema.PANTALLA_INICIAL_VALIDADOR)
            {
                isDEV = true;
            }

            if (isQA)
            {
                usuariologeado = new Usuario();//TODO quitar
                usuariologeado.codigo_Usuario = 5;//TODO quitar
                codigoAsignacion = "A001-5";//TODO quitar
                codigoAsignacion = "A002-5";//TODO quitar
                txtRutaDSX.Text = "";
                iniciarPantalla();
                
            }

            if (isDEV)
            {
                usuariologeado = new Usuario();//TODO quitar
                usuariologeado.codigo_Usuario = 5;//TODO quitar
                codigoAsignacion = "A002-5";//TODO quitar
                txtRutaDSX.Text = "";
                iniciarPantalla();
            }
        }

        public void iniciarPantalla()
        {
            List<AsignarRequerimientoView> listaAsigReq = null;
            List<DetalleMaestro> listaTipoValidacion = null;
            List<DetalleMaestro> listaTipoCargaJob = null;            

            if (ConstanteSistema.TIPO_VERSION_SISTEMA == ConstanteSistema.VERSION_SISTEMA_DATABASE)
            {
                AsignacionReqDAO ardao = new AsignacionReqDAO();
                listaAsigReq = ardao.getListaRequerimientoAsignadosPorColaboradorParaValidador(usuariologeado.codigo_Usuario);

                MaestroDAO mdao = new MaestroDAO();
                listaTipoValidacion = mdao.getListaTipoValidacion();
                listaTipoCargaJob = mdao.getListaTipoCargaJob();
            }
            else
            {
                listaAsigReq = new List<AsignarRequerimientoView>();
                AsignarRequerimientoView arv = new AsignarRequerimientoView();
                arv.codigo = "A002-5";
                arv.codigo_requerimiento = "A002";
              //arv.descripcionAndCodigoRequerimiento = "A999 - Test de requerimiento";
                arv.descripcionAndCodigoRequerimiento = "A002 - Validación de Requerimiento";
                arv.tipoCargaJob = "ODS_DBS_OT";                
                arv.tipoValidacion = "F";

                listaAsigReq.Add(arv);

                listaTipoValidacion = new List<DetalleMaestro>();
                DetalleMaestro dmTipVal = new DetalleMaestro();
                dmTipVal.codigo = 0;
                dmTipVal.codigo_maestro = null;
                dmTipVal.nombre = "Full";
                dmTipVal.valor_key = "F";

                listaTipoValidacion.Add(dmTipVal);

                //MaestroDAO mdao = new MaestroDAO();
                //listaTipoValidacion = mdao.getListaCargoAlone();
                //listaTipoCargaJob = mdao.getListaTipoCargaJob();


                listaTipoCargaJob = new List<DetalleMaestro>();
                DetalleMaestro dmTipCarga = new DetalleMaestro();
                dmTipCarga.codigo = 0;
                dmTipCarga.codigo_maestro = null;
                dmTipCarga.nombre = "Carga ODS,BDS y otros";                
                dmTipCarga.valor_key = "ODS_DBS_OT";
                listaTipoCargaJob.Add(dmTipCarga);

                DetalleMaestro dmTipCarga2 = new DetalleMaestro();
                dmTipCarga2.codigo = 1;
                dmTipCarga2.codigo_maestro = null;
                dmTipCarga2.nombre = "Carga Staging";                
                dmTipCarga2.valor_key = "STAGING";
                listaTipoCargaJob.Add(dmTipCarga2);
            }

            //llenar combo requerimiento
            comboBoxRequerimiento.DataSource = listaAsigReq;
            comboBoxRequerimiento.DisplayMember = "descripcionAndCodigoRequerimiento";
            comboBoxRequerimiento.ValueMember = "codigo";

            //llenar combo tipo de validacion
            comboBoxTipoValidacion.DataSource = listaTipoValidacion;
            comboBoxTipoValidacion.DisplayMember = "nombre";
            comboBoxTipoValidacion.ValueMember = "valor_key";

            //llenar combo tipo de carga de job
            comboBoxTipoCargaJob.DataSource = listaTipoCargaJob;
            comboBoxTipoCargaJob.DisplayMember = "nombre";
            comboBoxTipoCargaJob.ValueMember = "valor_key";

            if (codigoAsignacion != null && codigoAsignacion != "")
            {
                comboBoxRequerimiento.SelectedValue = codigoAsignacion;
                comboBoxRequerimiento.Enabled = false;
            }

            requerimientoActual = (AsignarRequerimientoView)comboBoxRequerimiento.SelectedItem;
            //comboBoxTipoValidacion.SelectedValue = requerimientoActual.tipoValidacion;
            comboBoxTipoCargaJob.SelectedValue = requerimientoActual.tipoCargaJob;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridViewJob.Visible = false;
            progressBar_Load.Visible = false;

            btnExportarResultadoValidacion.Visible = false;
            btnLimpiar.Visible = false;

            groupBoxArchivoAdicional.Visible = false;

            labelENV.Visible = false;
            txtRutaENV.Visible = false;
            btnSeleccionarENV.Visible = false;

            lblDSXAdicional.Visible = false;
            txtRutaDSXAdicional.Visible = false;
            btnSeleccionarDSXAdicional.Visible = false;
        }

        private void buttonCargar_Click(object sender, EventArgs e)
        {
            btnCargarDSX.Visible = false;
            progressBar_Load.Visible = false;
            dataGridViewJob.Visible = false;
            dataGridViewRoutine.Visible = false;
            dataGridViewParameterSet.Visible = false;
          //  requerimientoActual.tipoCargaJob = comboBoxTipoCargaJob.SelectedValue.ToString();
          //  requerimientoActual.tipoCargaJob = comboBoxTipoCargaJob.SelectedItem.ToString();

            btnLimpiar.Visible = false;
            requerimientoActual = (AsignarRequerimientoView)comboBoxRequerimiento.SelectedItem;
            string codigoAsigReq = requerimientoActual.codigo;
            //asignar valor del combo al req
            DetalleMaestro dmTipoCargaJob = (DetalleMaestro)comboBoxTipoCargaJob.SelectedItem;
            string valor_key = dmTipoCargaJob.valor_key;
            requerimientoActual.tipoCargaJob = valor_key;


            if (ConstanteSistema.TIPO_VERSION_SISTEMA == ConstanteSistema.VERSION_SISTEMA_DATABASE)
            {
                RequerimientoDAO rdao = new RequerimientoDAO();
                string codigoReq = requerimientoActual.codigo_requerimiento;
                RequerimientoView rv = rdao.getRequerimientoByCodigo(codigoReq);

                AsignacionReqDAO ardao = new AsignacionReqDAO();
                AsignarRequerimientoView arv = ardao.getAsigReqByCodigo(requerimientoActual.codigo);

                if (!isQA)
                {
                    if (arv.estado == ConstanteMaestro.COD_EST_ASIG_FINALIZADO
                        || arv.estado == ConstanteMaestro.COD_EST_ASIG_FINALIZADO_JUSTIFICACION)//Finalizado
                    {
                        MessageBox.Show("La asignación del requerimiento se encuentra Finalizada", "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.Hide();
                        return;
                    }

                    //if (rv.estado == ConstanteMaestro.COD_EST_REQ_SUCCESS
                    //    || rv.estado == ConstanteMaestro.COD_EST_REQ_RECHAZADO)//SUCCESS 
                    //{
                    //    MessageBox.Show("El requerimiento se encuentra cerrado", "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    this.Hide();
                    //    return;
                    //}
                }
            }


            //validación de archivos
                string mensaje = "";
                if (codigoAsigReq == "" || codigoAsigReq == "") /////genere el cambio
                {
                    mensaje += ConstanteCadena.MSG_VAL_REQUERIMIENTO + "\n";
                }
                if (!UtilArchivo.esValidoArchivoDSX(txtRutaDSX.Text))
                {
                    mensaje += ConstanteCadena.MSG_VAL_ARCHIVO_DSX;
                }
                if (txtRutaDSXAdicional.Text != "" && !UtilArchivo.esValidoArchivoDSX(txtRutaDSXAdicional.Text))
                {
                    mensaje += ConstanteCadena.MSG_VAL_ARCHIVO_DSX_ADICIONAL + "\n";
                }
                if (txtRutaENV.Text != "" && !UtilArchivo.esValidoArchivoENV(txtRutaENV.Text))
                {
                    mensaje += ConstanteCadena.MSG_VAL_ARCHIVO_ENV + "\n";
                }

                //procesar
                if (mensaje == "" && !btnCargarDSX.Visible)
                {
                    progressBar_Load.Visible = true;
                    backgroundWorker_Carga.RunWorkerAsync();
                }
                else
                {
                    MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btnCargarDSX.Enabled = true;
                    btnCargarDSX.Visible = true;
                }
            }
        
        /*
         * Ejecutar el proceso de validación en segundo plano 
         * */
        private void backgroundWorker_Carga_DoWork(object sender, DoWorkEventArgs e)
        {
            System.Threading.Thread.Sleep(5); //simulamos trabajo
            backgroundWorker_Carga.ReportProgress(0);
            
            DateTime fechaValidacion = DateTime.Now;

            //obtener la lista de variables de entorno del archivo .ENV
            List<VariableEntorno> listaVariableEntorno = new List<VariableEntorno>();
            LogDSX dsxAdicional = new LogDSX();
            if (checkBoxENV.Checked)
            {
                VariableEntornoService ves = new VariableEntornoService();
                listaVariableEntorno = ves.getListaVariableEntorno(txtRutaENV.Text);

                int totalLineasAdicional = UtilArchivo.contarLineasArchivo(txtRutaDSXAdicional.Text);
                if (totalLineasAdicional > 0)
                {
                    ProcesoService pc = new ProcesoService();
                    dsxAdicional = pc.getObjetoDSXFromArchivo(txtRutaDSXAdicional.Text, backgroundWorker_Carga, totalLineasAdicional);
                }
            }

            //obtener datos del archivo DSX
            ProcesoService procesoService = new ProcesoService();
            ValidadorService validadorService = new ValidadorService();

            int totalLineas = UtilArchivo.contarLineasArchivo(txtRutaDSX.Text);
            dsx = procesoService.getObjetoDSXFromArchivo(txtRutaDSX.Text, backgroundWorker_Carga, totalLineas);
            dsx.tipoValidacion = requerimientoActual.tipoValidacion;
            dsx.tipoCarga = requerimientoActual.tipoCargaJob;
            dsx.codigoRequerimiento = requerimientoActual.codigo_requerimiento;
            dsx.codigoUsuarioRequerimiento = requerimientoActual.codigo;
            dsx.fechaCreacion = DateTime.Now;
            dsx.usuarioCreador = usuariologeado.codigo_Usuario;
            dsx.fechaDSXValidacion = fechaValidacion;
            dsx = ValidadorService.getValidacionFromDSX(dsx, listaVariableEntorno, dsxAdicional);

            if (dsx.esNecesarioArchivoAdicional)
            {

                BeginInvoke(new Action(() =>
                {
                    FormValidadorObjetoFaltante formObjetoFaltante = new FormValidadorObjetoFaltante();
                    formObjetoFaltante.listaFaltanteJob = dsx.listaFaltanteJob;
                    formObjetoFaltante.listaFaltanteRoutine = dsx.listaFaltanteRoutine;
                    formObjetoFaltante.listaFaltanteVariableEntorno = dsx.listaFaltanteVariableEntorno;
                    formObjetoFaltante.inicializarPantalla();
                    formObjetoFaltante.ShowDialog();

                    this.Show();
                    
                    bool continuarVal = formObjetoFaltante.continuarValidacion;
                    if (continuarVal)
                    {
                        if (ConstanteSistema.TIPO_VERSION_SISTEMA == ConstanteSistema.VERSION_SISTEMA_DATABASE)
                        {
                            ValidadorService.guardarValidacionBD(dsx);
                        }
                        mostrarResultado = true;
                    }
                    else
                    {
                        mostrarResultado = false;
                    }

                    if (mostrarResultado)
                    {
                        cargarPantallaPrincipal();
                    }
                    else
                    {
                        progressBar_Load.Visible = false;
                        limpiarEventoText();
                    }

                    e.Result = "";
                }));
            }
            else
            {
                if (ConstanteSistema.TIPO_VERSION_SISTEMA == ConstanteSistema.VERSION_SISTEMA_DATABASE)
                {
                    ValidadorService.guardarValidacionBD(dsx);
                }

                BeginInvoke(new Action(() =>
                {
                    mostrarResultado = true;

                    if (mostrarResultado)
                    {
                        cargarPantallaPrincipal();
                    }
                    else
                    {
                        progressBar_Load.Visible = false;
                        limpiarEventoText();
                    }
                }));

            }

            //salida de la función, ver backgroundWorker_Carga_RunWorkerCompleted
            e.Result = "";
        }

        private void backgroundWorker_Carga_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage <= 100)
            {
                progressBar_Load.Value = e.ProgressPercentage; //actualizamos la barra de progreso
            }
            else
            {
                progressBar_Load.Value = 100;
            }
        }

        private void backgroundWorker_Carga_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                MessageBox.Show("Se canceló la carga del archivo");
            }
            else if (e.Error != null)
            {
                MessageBox.Show("Error. Detalles: " + (e.Error as Exception).ToString());
            }
            else
            {
                //llenar la tabla principal
                //if (mostrarResultado)
                //{
                //    cargarPantallaPrincipal();
                //}
                //else
                //{
                //    progressBar_Load.Visible = false;
                //    limpiarEventoText();
                //}
            }
            btnCargarDSX.Enabled = true;
            btnCargarDSX.Visible = true;
        }

        private void cargarPantallaPrincipal()
        {
            this.progressBar_Load.Visible = false;
            dataGridViewJob.Visible = false;
            dataGridViewRoutine.Visible = false;
            dataGridViewParameterSet.Visible = false;

            btnExportarResultadoValidacion.Visible = true;
            btnLimpiar.Visible = true;

            cargarTotalObjetos();
            cargarTablaJob();
            cargarTablaRoutine();
            cargarTablaParameterSet();

            if (dsx.codigoEstado != ConstanteMaestro.COD_EST_VALIDACION_OK)
            {
                lnkCerrarValidacion.Visible = true;
            }
        }

        private void cargarTotalObjetos()
        {
            //Cuadro de total de jobs
            txtNroSequence.Text = Convert.ToString(dsx.numJobSequence);
            txtNroParallel.Text = Convert.ToString(dsx.numJobParallel);
            txtNroServer.Text = Convert.ToString(dsx.numJobServer);
            txtNroRoutine.Text = Convert.ToString(dsx.numRoutine);
            txtNroParameterSet.Text = Convert.ToString(dsx.numParameterSet); 
        }

        private void cargarTablaJob()
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_NOMBRE_JOB));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_TIPO_JOB));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_TOTAL_STAGES));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_FECHA_EXPORTACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_JOB_FECHA_MOD));

            //creacion de la tabla
            List<LogJob> listaJob = dsx.listaJob;
            if (listaJob != null && listaJob.Count > 0)
            {
                int totalJobs = listaJob.Count;
                for (int j = 0; j < totalJobs; j++)
                {
                    DataRow row = table.NewRow();
                    row[TBL_JOB_NOMBRE_JOB] = listaJob[j].identifierJob;
                    row[TBL_JOB_TIPO_JOB] = listaJob[j].objeto.nombre;
                    row[TBL_JOB_TOTAL_STAGES] = listaJob[j].listaStage.Count;
                    row[TBL_JOB_ESTADO] = listaJob[j].estadoJobDescripcion;
                    row[TBL_JOB_FECHA_EXPORTACION] = dsx.header.fecha + " " + dsx.header.hora;
                    row[TBL_JOB_FECHA_MOD] = listaJob[j].dateModified + " " + listaJob[j].timeModified;

                    table.Rows.Add(row);
                }
            }

            dataGridViewJob.Columns.Clear();
            view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewJob.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = ">";
            buttonColumn.Name = TBL_JOB_ABRIR_DETALLE;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewJob.Visible = true;
            dataGridViewJob.RowHeadersVisible = false;
            dataGridViewJob.DataSource = view;

            dataGridViewJob.Columns[TBL_JOB_ABRIR_DETALLE].Width = 40;
            dataGridViewJob.Columns[TBL_JOB_NOMBRE_JOB].Width = 301;
            dataGridViewJob.Columns[TBL_JOB_TIPO_JOB].Width = 90;
            dataGridViewJob.Columns[TBL_JOB_TOTAL_STAGES].Width = 90;
            dataGridViewJob.Columns[TBL_JOB_ESTADO].Width = 74;
            dataGridViewJob.Columns[TBL_JOB_FECHA_EXPORTACION].Width = 120;
            dataGridViewJob.Columns[TBL_JOB_FECHA_MOD].Width = 115;
                        
            dataGridViewJob.Columns[TBL_JOB_TOTAL_STAGES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewJob.Columns[TBL_JOB_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewJob.Columns[TBL_JOB_FECHA_EXPORTACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewJob.Columns[TBL_JOB_FECHA_MOD].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void cargarTablaRoutine() 
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_NOMBRE_ROUTINE));
            table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_TIPO_ROUTINE));
            table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_TOTAL_ARGUMENTOS));
            table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_FECHA_EXPORTACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_ROUTINE_FECHA_MOD));

            //creacion de la tabla
            List<LogRoutine> listaRoutine = dsx.listaRoutine;
            if (listaRoutine != null && listaRoutine.Count > 0)
            {
                int totalRoutine = listaRoutine.Count;
                for (int j = 0; j < totalRoutine; j++)
                {
                    DataRow row = table.NewRow();
                    row[TBL_ROUTINE_NOMBRE_ROUTINE] = listaRoutine[j].identifier;
                    row[TBL_ROUTINE_TIPO_ROUTINE] = listaRoutine[j].objeto.nombre;
                    row[TBL_ROUTINE_TOTAL_ARGUMENTOS] = listaRoutine[j].listaArgumentoRoutine.Count;
                    row[TBL_ROUTINE_ESTADO] = listaRoutine[j].estadoRutinaDescripcion;
                    row[TBL_ROUTINE_FECHA_EXPORTACION] = dsx.header.fecha + " " + dsx.header.hora;
                    row[TBL_ROUTINE_FECHA_MOD] = listaRoutine[j].dateModified + " " + listaRoutine[j].timeModified;

                    table.Rows.Add(row);
                }
            }

            dataGridViewRoutine.Columns.Clear();
            view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewRoutine.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = ">";
            buttonColumn.Name = TBL_ROUTINE_ABRIR_DETALLE;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewRoutine.Visible = true;
            dataGridViewRoutine.RowHeadersVisible = false;
            dataGridViewRoutine.DataSource = view;

            dataGridViewRoutine.Columns[TBL_ROUTINE_ABRIR_DETALLE].Width = 40;
            dataGridViewRoutine.Columns[TBL_ROUTINE_NOMBRE_ROUTINE].Width = 301;
            dataGridViewRoutine.Columns[TBL_ROUTINE_TIPO_ROUTINE].Width = 110; 
            dataGridViewRoutine.Columns[TBL_ROUTINE_TOTAL_ARGUMENTOS].Width = 70;
            dataGridViewRoutine.Columns[TBL_ROUTINE_ESTADO].Width = 74;
            dataGridViewRoutine.Columns[TBL_ROUTINE_FECHA_EXPORTACION].Width = 120;
            dataGridViewRoutine.Columns[TBL_ROUTINE_FECHA_MOD].Width = 115;

            dataGridViewRoutine.Columns[TBL_ROUTINE_TOTAL_ARGUMENTOS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewRoutine.Columns[TBL_ROUTINE_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewRoutine.Columns[TBL_ROUTINE_FECHA_EXPORTACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewRoutine.Columns[TBL_ROUTINE_FECHA_MOD].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;        
        }

        private void cargarTablaParameterSet()
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_PARAMETER_SET_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(TBL_PARAMETER_SET_TOTAL_PARAMETROS));
            table.Columns.Add(UtilForm.getColumnString(TBL_PARAMETER_SET_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_PARAMETER_SET_FECHA_EXPORTACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_PARAMETER_SET_FECHA_MOD));

            //creacion de la tabla
            List<LogParameterSet> listaParameterSet = dsx.listaParameterSet;
            int totalParameterSet = 0;
            if (listaParameterSet != null && listaParameterSet.Count > 0)
            {
                totalParameterSet = listaParameterSet.Count;
                for (int j = 0; j < totalParameterSet; j++)
                {
                    DataRow row = table.NewRow();
                    row[TBL_PARAMETER_SET_NOMBRE] = listaParameterSet[j].identifierParameterSet;
                    row[TBL_PARAMETER_SET_TOTAL_PARAMETROS] = listaParameterSet[j].listaParam.Count;
                    row[TBL_PARAMETER_SET_ESTADO] = listaParameterSet[j].estadoParameterDescripcion;
                    row[TBL_PARAMETER_SET_FECHA_EXPORTACION] = dsx.header.fecha + " " + dsx.header.hora;
                    row[TBL_PARAMETER_SET_FECHA_MOD] = listaParameterSet[j].dateModified + " " + listaParameterSet[j].timeModified;

                    table.Rows.Add(row);
                }
            }

            dataGridViewParameterSet.Columns.Clear();
            view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewParameterSet.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = ">";
            buttonColumn.Name = TBL_PARAMETER_SET_ABRIR_DETALLE;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewParameterSet.Visible = true;
            dataGridViewParameterSet.RowHeadersVisible = false;
            dataGridViewParameterSet.DataSource = view;

            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_ABRIR_DETALLE].Width = 40;
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_NOMBRE].Width = 371; //110 de tipo, 301 de nombre
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_TOTAL_PARAMETROS].Width = 110; //70 de nro
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_ESTADO].Width = 74;
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_FECHA_EXPORTACION].Width = 120;
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_FECHA_MOD].Width = 115;

            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_TOTAL_PARAMETROS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_FECHA_EXPORTACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewParameterSet.Columns[TBL_PARAMETER_SET_FECHA_MOD].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtRutaDSX.Clear();
            txtRutaENV.Clear();
            txtRutaDSXAdicional.Clear();

            tabControlObjeto.SelectedIndex = 0;

            checkBoxENV.Checked = false;

            lnkCerrarValidacion.Visible = false;

            limpiarEventoText();
        }

        private void txtRutaDSX_TextChanged(object sender, EventArgs e)
        {
            limpiarEventoText();
        }
        
        private void txtRutaDSXAdicional_TextChanged(object sender, EventArgs e)
        {
            limpiarEventoText();
        }

        private void txtRutaENV_TextChanged(object sender, EventArgs e)
        {
            limpiarEventoText();
        }

        private void limpiarEventoText()
        {
            txtNroParallel.Clear();
            txtNroSequence.Clear();
            txtNroServer.Clear();
            txtNroRoutine.Clear();
            txtNroParameterSet.Clear();

            dataGridViewJob.DataSource = null;
            dataGridViewJob.Visible = false;
            dataGridViewRoutine.DataSource = null;
            dataGridViewRoutine.Visible = false;
            dataGridViewParameterSet.DataSource = null;
            dataGridViewParameterSet.Visible = false;

            btnExportarResultadoValidacion.Visible = false;
            btnLimpiar.Visible = false;
            lnkCerrarValidacion.Visible = false;
        }

        private void btnSeleccionarENV_Click(object sender, EventArgs e)
        {
            txtRutaENV.Text = "";
            OpenFileDialog path = new OpenFileDialog();

            if (path.ShowDialog() == DialogResult.OK)
            {
                txtRutaENV.Text = path.FileName;
            }
        }

        private void seleccionarDSX_Click(object sender, EventArgs e)
        {
            txtRutaDSX.Text = "";
            OpenFileDialog path = new OpenFileDialog();

            if (path.ShowDialog() == DialogResult.OK)
            {
                txtRutaDSX.Text = path.FileName;
            }
        }
        
        private void btnSeleccionarDSXAdicional_Click(object sender, EventArgs e)
        {
            txtRutaDSXAdicional.Text = "";
            OpenFileDialog path = new OpenFileDialog();

            if (path.ShowDialog() == DialogResult.OK)
            {
                txtRutaDSXAdicional.Text = path.FileName;
            }
        }

        private void dataGridViewJob_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewJob.Columns[e.ColumnIndex].Name.Equals(TBL_JOB_ESTADO))
            {
                string estado = dataGridViewJob.Rows[e.RowIndex].Cells[TBL_JOB_ESTADO].Value.ToString();
                if (estado.Equals("OK"))
                {
                    dataGridViewJob.Rows[e.RowIndex].Cells[TBL_JOB_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals("NOTOK"))
                    {
                        dataGridViewJob.Rows[e.RowIndex].Cells[TBL_JOB_ESTADO].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        //dataGridViewPrincipal.Rows[e.RowIndex].Cells[TBL_JOB_ESTADO].Style.ForeColor = Color.YellowGreen;
                    }
                }
            }
        }

        private void dataGridViewRoutine_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewRoutine.Columns[e.ColumnIndex].Name.Equals(TBL_ROUTINE_ESTADO))
            {
                string estado = dataGridViewRoutine.Rows[e.RowIndex].Cells[TBL_ROUTINE_ESTADO].Value.ToString();
                if (estado.Equals("OK"))
                {
                    dataGridViewRoutine.Rows[e.RowIndex].Cells[TBL_ROUTINE_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals("NOTOK"))
                    {
                        dataGridViewRoutine.Rows[e.RowIndex].Cells[TBL_ROUTINE_ESTADO].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        //dataGridViewPrincipal.Rows[e.RowIndex].Cells[TBL_JOB_ESTADO].Style.ForeColor = Color.YellowGreen;
                    }
                }
            }
        }

        private void dataGridViewParameterSet_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewParameterSet.Columns[e.ColumnIndex].Name.Equals(TBL_PARAMETER_SET_ESTADO))
            {
                string estado = dataGridViewParameterSet.Rows[e.RowIndex].Cells[TBL_PARAMETER_SET_ESTADO].Value.ToString();
                if (estado.Equals("OK"))
                {
                    dataGridViewParameterSet.Rows[e.RowIndex].Cells[TBL_PARAMETER_SET_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals("NOTOK"))
                    {
                        dataGridViewParameterSet.Rows[e.RowIndex].Cells[TBL_PARAMETER_SET_ESTADO].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        //dataGridViewPrincipal.Rows[e.RowIndex].Cells[TBL_JOB_ESTADO].Style.ForeColor = Color.YellowGreen;
                    }
                }
            }
        }
        /*
         * Exportación de la tabla detalle a Excel
         */
        private void btnExportarResultadoValidacion_Click(object sender, EventArgs e)
        {
            UtilExcel.exportarToExcelResultadoValidacion(dsx, saveFileDialog, txtRutaDSX.Text);
        }

        private void checkBoxENV_CheckedChanged(object sender, EventArgs e)
        {
            txtRutaENV.Clear();
            txtRutaDSXAdicional.Clear();

            if (checkBoxENV.Checked)
            {
                groupBoxArchivoAdicional.Visible = true;
                labelENV.Visible = true;
                txtRutaENV.Visible = true;
                btnSeleccionarENV.Visible = true;

                lblDSXAdicional.Visible = true;
                txtRutaDSXAdicional.Visible = true;
                btnSeleccionarDSXAdicional.Visible = true;
            }
            else
            {
                groupBoxArchivoAdicional.Visible = false;
                labelENV.Visible = false;
                txtRutaENV.Visible = false;
                btnSeleccionarENV.Visible = false;

                lblDSXAdicional.Visible = false;
                txtRutaDSXAdicional.Visible = false;
                btnSeleccionarDSXAdicional.Visible = false;
            }
        }

        private void comboBoxRequerimiento_SelectedValueChanged(object sender, EventArgs e)
        {
            AsignarRequerimientoView arv = (AsignarRequerimientoView)comboBoxRequerimiento.SelectedItem;

            if (arv != null)
            {
                string val = arv.tipoValidacion;

                comboBoxTipoValidacion.SelectedValue = val;
            }
        }
        
        /*
         * Click para abrir una nueva pantalla que muestra la lista de stages del job seleccionado
         * */
        private void dataGridViewJob_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewJob.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == TBL_JOB_POS_ABRIR_DETALLE) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewJob.CurrentCell.RowIndex;

                string nombreJob = dataGridViewJob.Rows[filaSeleccionada].Cells[TBL_JOB_NOMBRE_JOB].Value.ToString();
                List<LogJob> listaJob = dsx.listaJob;
                LogJob job = UtilObjeto.getJobByName(nombreJob, listaJob);

                FormValidadorDetalleJob formDetalle = new FormValidadorDetalleJob();
                formDetalle.cargarDetalleJob(job);
                formDetalle.ShowDialog();

                dataGridViewJob.Rows[filaSeleccionada].Cells[TBL_JOB_ABRIR_DETALLE].Selected = false;
                dataGridViewJob.Rows[filaSeleccionada].Selected = true;
                dataGridViewJob.Rows[filaSeleccionada].Cells[TBL_JOB_NOMBRE_JOB].Selected = true;
            }

        }

        /*
         * Click para abrir una nueva pantalla que muestra la lista de argumentos de la rutina seleccionada
         * */
        private void dataGridViewRoutine_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewRoutine.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == TBL_ROUTINE_POS_ABRIR_DETALLE) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewRoutine.CurrentCell.RowIndex;
                
                string nombreRoutine = dataGridViewRoutine.Rows[filaSeleccionada].Cells[TBL_ROUTINE_NOMBRE_ROUTINE].Value.ToString();
                List<LogRoutine> listaRoutine = dsx.listaRoutine;
                LogRoutine routine = UtilObjeto.getRoutineByName(nombreRoutine, listaRoutine);

                FormValidadorDetalleRoutine formDetalle = new FormValidadorDetalleRoutine();
                formDetalle.cargarDetalleRoutine(routine);
                formDetalle.ShowDialog();

                dataGridViewRoutine.Rows[filaSeleccionada].Selected = false;
            }
        }

        private void dataGridViewParameterSet_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewParameterSet .CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == TBL_PARAMETER_SET_POS_ABRIR_DETALLE) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewParameterSet.CurrentCell.RowIndex;

                string nombreParameter = dataGridViewParameterSet.Rows[filaSeleccionada].Cells[TBL_PARAMETER_SET_NOMBRE].Value.ToString();
                List<LogParameterSet> listaParameter = dsx.listaParameterSet;
                LogParameterSet parameter = UtilObjeto.getParameterSetByName(nombreParameter, listaParameter);

                FormValidadorDetalleParameterSet formDetalle = new FormValidadorDetalleParameterSet();
                formDetalle.cargarDetalleParameterSet(parameter);
                formDetalle.ShowDialog();

                dataGridViewParameterSet.Rows[filaSeleccionada].Selected = false;
            }
        }

        private void lnkVerReglaValidacion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormValidadorListadoRegla formListado = new FormValidadorListadoRegla();
            formListado.tipoValidacion = requerimientoActual.tipoValidacion;
            formListado.ShowDialog();
        }

        private void lnkVerTipoObjeto_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormValidadorListadoObjeto formListado = new FormValidadorListadoObjeto();
            formListado.ShowDialog();
        }

        private void lnkCerrarValidacion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (dsx != null && dsx.codigoEstado != ConstanteMaestro.COD_EST_VALIDACION_OK)
            {
                FormValidadorCerrarValidacion formNota = new FormValidadorCerrarValidacion();
                formNota.dsx = dsx;
                formNota.cargarPantalla();
                formNota.ShowDialog();

                if (formNota.cerrarFormValidador)
                {
                    this.Hide();
                }
                else
                {
                    this.Show();
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormValidaSQL fvalidasql = new FormValidaSQL();
            this.Hide();
            fvalidasql.ShowDialog();
            this.Close();
        }

        private void lnk_cerrar_sesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormLoginGeneral fgeneral = new FormLoginGeneral();
            this.Hide();
            fgeneral.ShowDialog();
            this.Close();
        }

    }
}

