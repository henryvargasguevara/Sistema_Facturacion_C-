﻿namespace ValidadorSES.form
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            this.btnMenuManObj = new System.Windows.Forms.Button();
            this.btnMenuManUsers = new System.Windows.Forms.Button();
            this.btnMenuManReglas = new System.Windows.Forms.Button();
            this.btnGestionarRequerimiento = new System.Windows.Forms.Button();
            this.btnMenuAsignReglas = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Reportes = new System.Windows.Forms.Button();
            this.btnAsignacionColaborador = new System.Windows.Forms.Button();
            this.btnAsignacionRequerimiento = new System.Windows.Forms.Button();
            this.btnValidacionExpressFull = new System.Windows.Forms.Button();
            this.btnBuscador = new System.Windows.Forms.Button();
            this.lnkCerrarSesion = new System.Windows.Forms.LinkLabel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMenuManObj
            // 
            this.btnMenuManObj.Location = new System.Drawing.Point(49, 194);
            this.btnMenuManObj.Name = "btnMenuManObj";
            this.btnMenuManObj.Size = new System.Drawing.Size(159, 29);
            this.btnMenuManObj.TabIndex = 0;
            this.btnMenuManObj.Text = "Mantenimiento de Objeto";
            this.btnMenuManObj.UseVisualStyleBackColor = true;
            this.btnMenuManObj.Click += new System.EventHandler(this.btnMenuManObj_Click);
            // 
            // btnMenuManUsers
            // 
            this.btnMenuManUsers.Location = new System.Drawing.Point(49, 107);
            this.btnMenuManUsers.Name = "btnMenuManUsers";
            this.btnMenuManUsers.Size = new System.Drawing.Size(159, 29);
            this.btnMenuManUsers.TabIndex = 2;
            this.btnMenuManUsers.Text = "Mantenimiento de usuarios";
            this.btnMenuManUsers.UseVisualStyleBackColor = true;
            this.btnMenuManUsers.Click += new System.EventHandler(this.btnMenuManUsers_Click);
            // 
            // btnMenuManReglas
            // 
            this.btnMenuManReglas.Location = new System.Drawing.Point(49, 149);
            this.btnMenuManReglas.Name = "btnMenuManReglas";
            this.btnMenuManReglas.Size = new System.Drawing.Size(159, 29);
            this.btnMenuManReglas.TabIndex = 3;
            this.btnMenuManReglas.Text = "Mantenimiento de reglas";
            this.btnMenuManReglas.UseVisualStyleBackColor = true;
            this.btnMenuManReglas.Click += new System.EventHandler(this.btnMenuManReglas_Click);
            // 
            // btnGestionarRequerimiento
            // 
            this.btnGestionarRequerimiento.Location = new System.Drawing.Point(238, 107);
            this.btnGestionarRequerimiento.Name = "btnGestionarRequerimiento";
            this.btnGestionarRequerimiento.Size = new System.Drawing.Size(162, 29);
            this.btnGestionarRequerimiento.TabIndex = 4;
            this.btnGestionarRequerimiento.Text = "Gestionar Requerimiento";
            this.btnGestionarRequerimiento.UseVisualStyleBackColor = true;
            this.btnGestionarRequerimiento.Click += new System.EventHandler(this.btnGestionarRequerimiento_Click);
            // 
            // btnMenuAsignReglas
            // 
            this.btnMenuAsignReglas.Location = new System.Drawing.Point(49, 240);
            this.btnMenuAsignReglas.Name = "btnMenuAsignReglas";
            this.btnMenuAsignReglas.Size = new System.Drawing.Size(159, 29);
            this.btnMenuAsignReglas.TabIndex = 5;
            this.btnMenuAsignReglas.Text = "Asignación de reglas";
            this.btnMenuAsignReglas.UseVisualStyleBackColor = true;
            this.btnMenuAsignReglas.Click += new System.EventHandler(this.btnMenuAsignReglas_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_Reportes);
            this.groupBox1.Controls.Add(this.btnAsignacionColaborador);
            this.groupBox1.Controls.Add(this.btnAsignacionRequerimiento);
            this.groupBox1.Controls.Add(this.btnValidacionExpressFull);
            this.groupBox1.Controls.Add(this.btnMenuAsignReglas);
            this.groupBox1.Controls.Add(this.btnMenuManObj);
            this.groupBox1.Controls.Add(this.btnGestionarRequerimiento);
            this.groupBox1.Controls.Add(this.btnBuscador);
            this.groupBox1.Controls.Add(this.btnMenuManReglas);
            this.groupBox1.Controls.Add(this.btnMenuManUsers);
            this.groupBox1.Location = new System.Drawing.Point(25, 75);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 301);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menú Principal";
            // 
            // btn_Reportes
            // 
            this.btn_Reportes.Location = new System.Drawing.Point(238, 194);
            this.btn_Reportes.Name = "btn_Reportes";
            this.btn_Reportes.Size = new System.Drawing.Size(162, 29);
            this.btn_Reportes.TabIndex = 10;
            this.btn_Reportes.Text = "Reportes";
            this.btn_Reportes.UseVisualStyleBackColor = true;
            this.btn_Reportes.Click += new System.EventHandler(this.btn_Reportes_Click);
            // 
            // btnAsignacionColaborador
            // 
            this.btnAsignacionColaborador.Location = new System.Drawing.Point(49, 61);
            this.btnAsignacionColaborador.Name = "btnAsignacionColaborador";
            this.btnAsignacionColaborador.Size = new System.Drawing.Size(159, 29);
            this.btnAsignacionColaborador.TabIndex = 9;
            this.btnAsignacionColaborador.Text = "Requerimientos asignados";
            this.btnAsignacionColaborador.UseVisualStyleBackColor = true;
            this.btnAsignacionColaborador.Click += new System.EventHandler(this.btnAsignacionColaborador_Click);
            // 
            // btnAsignacionRequerimiento
            // 
            this.btnAsignacionRequerimiento.Location = new System.Drawing.Point(238, 61);
            this.btnAsignacionRequerimiento.Name = "btnAsignacionRequerimiento";
            this.btnAsignacionRequerimiento.Size = new System.Drawing.Size(162, 29);
            this.btnAsignacionRequerimiento.TabIndex = 7;
            this.btnAsignacionRequerimiento.Text = "Gestionar Asignaciones";
            this.btnAsignacionRequerimiento.UseVisualStyleBackColor = true;
            this.btnAsignacionRequerimiento.Click += new System.EventHandler(this.btnAsignacionRequerimiento_Click);
            // 
            // btnValidacionExpressFull
            // 
            this.btnValidacionExpressFull.Location = new System.Drawing.Point(238, 149);
            this.btnValidacionExpressFull.Name = "btnValidacionExpressFull";
            this.btnValidacionExpressFull.Size = new System.Drawing.Size(162, 29);
            this.btnValidacionExpressFull.TabIndex = 6;
            this.btnValidacionExpressFull.Text = "Validación EXPRESS / FULL";
            this.btnValidacionExpressFull.UseVisualStyleBackColor = true;
            this.btnValidacionExpressFull.Click += new System.EventHandler(this.btnValidacionExpressFull_Click);
            // 
            // btnBuscador
            // 
            this.btnBuscador.Location = new System.Drawing.Point(238, 240);
            this.btnBuscador.Name = "btnBuscador";
            this.btnBuscador.Size = new System.Drawing.Size(162, 29);
            this.btnBuscador.TabIndex = 1;
            this.btnBuscador.Text = "Buscador";
            this.btnBuscador.UseVisualStyleBackColor = true;
            this.btnBuscador.Click += new System.EventHandler(this.btnBuscador_Click);
            // 
            // lnkCerrarSesion
            // 
            this.lnkCerrarSesion.AutoSize = true;
            this.lnkCerrarSesion.Location = new System.Drawing.Point(405, 31);
            this.lnkCerrarSesion.Name = "lnkCerrarSesion";
            this.lnkCerrarSesion.Size = new System.Drawing.Size(70, 13);
            this.lnkCerrarSesion.TabIndex = 8;
            this.lnkCerrarSesion.TabStop = true;
            this.lnkCerrarSesion.Text = "Cerrar Sesión";
            this.lnkCerrarSesion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCerrarSesion_LinkClicked);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 409);
            this.Controls.Add(this.lnkCerrarSesion);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Menú Principal - Validador SES 2.0";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnAsignacionColaborador;
        public System.Windows.Forms.Button btnAsignacionRequerimiento;
        public System.Windows.Forms.Button btnMenuManUsers;
        public System.Windows.Forms.Button btnGestionarRequerimiento;
        public System.Windows.Forms.Button btnMenuManObj;
        public System.Windows.Forms.Button btnMenuManReglas;
        public System.Windows.Forms.Button btnMenuAsignReglas;
        private System.Windows.Forms.LinkLabel lnkCerrarSesion;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.Button btn_Reportes;
        public System.Windows.Forms.Button btnValidacionExpressFull;
        public System.Windows.Forms.Button btnBuscador;
    }
}