﻿namespace ValidadorSES.form
{
    partial class FormTipoValidacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTipoValidacion));
            this.label1 = new System.Windows.Forms.Label();
            this.checkedListBoxFull = new System.Windows.Forms.CheckedListBox();
            this.checkedListBoxExpress = new System.Windows.Forms.CheckedListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnGuardarFull = new System.Windows.Forms.Button();
            this.btnCancelarFull = new System.Windows.Forms.Button();
            this.btnCancelarExpress = new System.Windows.Forms.Button();
            this.btnGuardarExpress = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(372, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo de validación";
            // 
            // checkedListBoxFull
            // 
            this.checkedListBoxFull.CheckOnClick = true;
            this.checkedListBoxFull.FormattingEnabled = true;
            this.checkedListBoxFull.Location = new System.Drawing.Point(114, 96);
            this.checkedListBoxFull.Name = "checkedListBoxFull";
            this.checkedListBoxFull.Size = new System.Drawing.Size(331, 304);
            this.checkedListBoxFull.TabIndex = 1;
            // 
            // checkedListBoxExpress
            // 
            this.checkedListBoxExpress.CheckOnClick = true;
            this.checkedListBoxExpress.FormattingEnabled = true;
            this.checkedListBoxExpress.Location = new System.Drawing.Point(545, 96);
            this.checkedListBoxExpress.Name = "checkedListBoxExpress";
            this.checkedListBoxExpress.Size = new System.Drawing.Size(313, 304);
            this.checkedListBoxExpress.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Validación FULL";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(542, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Validación EXPRESS";
            // 
            // btnGuardarFull
            // 
            this.btnGuardarFull.Location = new System.Drawing.Point(168, 422);
            this.btnGuardarFull.Name = "btnGuardarFull";
            this.btnGuardarFull.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarFull.TabIndex = 5;
            this.btnGuardarFull.Text = "GUARDAR";
            this.btnGuardarFull.UseVisualStyleBackColor = true;
            this.btnGuardarFull.Click += new System.EventHandler(this.btnGuardarFull_Click);
            // 
            // btnCancelarFull
            // 
            this.btnCancelarFull.Location = new System.Drawing.Point(277, 422);
            this.btnCancelarFull.Name = "btnCancelarFull";
            this.btnCancelarFull.Size = new System.Drawing.Size(76, 23);
            this.btnCancelarFull.TabIndex = 6;
            this.btnCancelarFull.Text = "CANCELAR";
            this.btnCancelarFull.UseVisualStyleBackColor = true;
            this.btnCancelarFull.Click += new System.EventHandler(this.btnCancelarFull_Click);
            // 
            // btnCancelarExpress
            // 
            this.btnCancelarExpress.Location = new System.Drawing.Point(721, 422);
            this.btnCancelarExpress.Name = "btnCancelarExpress";
            this.btnCancelarExpress.Size = new System.Drawing.Size(76, 23);
            this.btnCancelarExpress.TabIndex = 8;
            this.btnCancelarExpress.Text = "CANCELAR";
            this.btnCancelarExpress.UseVisualStyleBackColor = true;
            this.btnCancelarExpress.Click += new System.EventHandler(this.btnCancelarExpress_Click);
            // 
            // btnGuardarExpress
            // 
            this.btnGuardarExpress.Location = new System.Drawing.Point(612, 422);
            this.btnGuardarExpress.Name = "btnGuardarExpress";
            this.btnGuardarExpress.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarExpress.TabIndex = 7;
            this.btnGuardarExpress.Text = "GUARDAR";
            this.btnGuardarExpress.UseVisualStyleBackColor = true;
            this.btnGuardarExpress.Click += new System.EventHandler(this.btnGuardarExpress_Click);
            // 
            // FormTipoValidacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 471);
            this.Controls.Add(this.btnCancelarExpress);
            this.Controls.Add(this.btnGuardarExpress);
            this.Controls.Add(this.btnCancelarFull);
            this.Controls.Add(this.btnGuardarFull);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkedListBoxExpress);
            this.Controls.Add(this.checkedListBoxFull);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormTipoValidacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Asignación de Reglas de Validación por Tipo de Validación - Validador SES 2.0";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox checkedListBoxFull;
        private System.Windows.Forms.CheckedListBox checkedListBoxExpress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnGuardarFull;
        private System.Windows.Forms.Button btnCancelarFull;
        private System.Windows.Forms.Button btnCancelarExpress;
        private System.Windows.Forms.Button btnGuardarExpress;
    }
}