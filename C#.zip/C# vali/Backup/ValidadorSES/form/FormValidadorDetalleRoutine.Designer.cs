﻿namespace ValidadorSES.form
{
    partial class FormValidadorDetalleRoutine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormValidadorDetalleRoutine));
            this.btnMostrarDesValid = new System.Windows.Forms.Button();
            this.txtDescripcionValidacionRoutine = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblNombreRoutine = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNroCorrectos = new System.Windows.Forms.TextBox();
            this.txtNroIncorrecto = new System.Windows.Forms.TextBox();
            this.txtTotalStage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewDetalle = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRutaRoutine = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNroObservacion = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalle)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMostrarDesValid
            // 
            this.btnMostrarDesValid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMostrarDesValid.Location = new System.Drawing.Point(962, 86);
            this.btnMostrarDesValid.Name = "btnMostrarDesValid";
            this.btnMostrarDesValid.Size = new System.Drawing.Size(33, 23);
            this.btnMostrarDesValid.TabIndex = 14;
            this.btnMostrarDesValid.Text = "...";
            this.btnMostrarDesValid.UseVisualStyleBackColor = true;
            this.btnMostrarDesValid.Click += new System.EventHandler(this.btnMostrarDesValid_Click);
            // 
            // txtDescripcionValidacionRoutine
            // 
            this.txtDescripcionValidacionRoutine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDescripcionValidacionRoutine.Enabled = false;
            this.txtDescripcionValidacionRoutine.Location = new System.Drawing.Point(145, 84);
            this.txtDescripcionValidacionRoutine.Name = "txtDescripcionValidacionRoutine";
            this.txtDescripcionValidacionRoutine.Size = new System.Drawing.Size(811, 20);
            this.txtDescripcionValidacionRoutine.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Validación de Routine:";
            // 
            // lblNombreRoutine
            // 
            this.lblNombreRoutine.AutoSize = true;
            this.lblNombreRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreRoutine.Location = new System.Drawing.Point(145, 12);
            this.lblNombreRoutine.Name = "lblNombreRoutine";
            this.lblNombreRoutine.Size = new System.Drawing.Size(103, 29);
            this.lblNombreRoutine.TabIndex = 11;
            this.lblNombreRoutine.Text = "Routine";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtNroObservacion);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtNroCorrectos);
            this.groupBox1.Controls.Add(this.txtNroIncorrecto);
            this.groupBox1.Controls.Add(this.txtTotalStage);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(1012, 132);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 189);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos";
            // 
            // txtNroCorrectos
            // 
            this.txtNroCorrectos.Enabled = false;
            this.txtNroCorrectos.Location = new System.Drawing.Point(128, 72);
            this.txtNroCorrectos.Name = "txtNroCorrectos";
            this.txtNroCorrectos.Size = new System.Drawing.Size(60, 20);
            this.txtNroCorrectos.TabIndex = 6;
            this.txtNroCorrectos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNroIncorrecto
            // 
            this.txtNroIncorrecto.Enabled = false;
            this.txtNroIncorrecto.Location = new System.Drawing.Point(128, 104);
            this.txtNroIncorrecto.Name = "txtNroIncorrecto";
            this.txtNroIncorrecto.Size = new System.Drawing.Size(60, 20);
            this.txtNroIncorrecto.TabIndex = 5;
            this.txtNroIncorrecto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalStage
            // 
            this.txtTotalStage.Enabled = false;
            this.txtTotalStage.Location = new System.Drawing.Point(128, 40);
            this.txtTotalStage.Name = "txtTotalStage";
            this.txtTotalStage.Size = new System.Drawing.Size(60, 20);
            this.txtTotalStage.TabIndex = 4;
            this.txtTotalStage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Incorrectos:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Correctos:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Total Argumentos:";
            // 
            // dataGridViewDetalle
            // 
            this.dataGridViewDetalle.AllowUserToAddRows = false;
            this.dataGridViewDetalle.AllowUserToDeleteRows = false;
            this.dataGridViewDetalle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDetalle.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewDetalle.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewDetalle.Location = new System.Drawing.Point(12, 132);
            this.dataGridViewDetalle.Name = "dataGridViewDetalle";
            this.dataGridViewDetalle.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDetalle.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewDetalle.Size = new System.Drawing.Size(983, 389);
            this.dataGridViewDetalle.TabIndex = 9;
            this.dataGridViewDetalle.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewDetalle_CellFormatting);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nombre de Routine:";
            // 
            // txtRutaRoutine
            // 
            this.txtRutaRoutine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRutaRoutine.Enabled = false;
            this.txtRutaRoutine.Location = new System.Drawing.Point(145, 54);
            this.txtRutaRoutine.Name = "txtRutaRoutine";
            this.txtRutaRoutine.Size = new System.Drawing.Size(811, 20);
            this.txtRutaRoutine.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(51, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Ruta de Routine:";
            // 
            // txtNroObservacion
            // 
            this.txtNroObservacion.Enabled = false;
            this.txtNroObservacion.Location = new System.Drawing.Point(128, 138);
            this.txtNroObservacion.Name = "txtNroObservacion";
            this.txtNroObservacion.Size = new System.Drawing.Size(60, 20);
            this.txtNroObservacion.TabIndex = 9;
            this.txtNroObservacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Con observaciones:";
            // 
            // FormDetalleRoutine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1224, 533);
            this.Controls.Add(this.txtRutaRoutine);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnMostrarDesValid);
            this.Controls.Add(this.txtDescripcionValidacionRoutine);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblNombreRoutine);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridViewDetalle);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "FormDetalleRoutine";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detalle de Routine";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormDetalleRoutine_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMostrarDesValid;
        public System.Windows.Forms.TextBox txtDescripcionValidacionRoutine;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label lblNombreRoutine;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox txtNroCorrectos;
        public System.Windows.Forms.TextBox txtNroIncorrecto;
        public System.Windows.Forms.TextBox txtTotalStage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.DataGridView dataGridViewDetalle;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtRutaRoutine;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txtNroObservacion;
        private System.Windows.Forms.Label label5;
    }
}