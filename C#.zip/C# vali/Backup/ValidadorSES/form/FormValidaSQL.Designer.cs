﻿namespace ValidadorSES.form
{
    partial class FormValidaSQL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormValidaSQL));
            this.label5 = new System.Windows.Forms.Label();
            this.seleccionarSQL = new System.Windows.Forms.Button();
            this.txtRutaSQL = new System.Windows.Forms.TextBox();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.DataGridSQL = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabValidaccion = new System.Windows.Forms.TabPage();
            this.tabtablas = new System.Windows.Forms.TabPage();
            this.dgvTablas = new System.Windows.Forms.DataGridView();
            this.descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ESTADO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ESTADO2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridSQL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabValidaccion.SuspendLayout();
            this.tabtablas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTablas)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(383, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(276, 44);
            this.label5.TabIndex = 23;
            this.label5.Text = "Validador SQL";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // seleccionarSQL
            // 
            this.seleccionarSQL.Location = new System.Drawing.Point(651, 114);
            this.seleccionarSQL.Name = "seleccionarSQL";
            this.seleccionarSQL.Size = new System.Drawing.Size(102, 23);
            this.seleccionarSQL.TabIndex = 43;
            this.seleccionarSQL.Text = "Seleccionar SQL";
            this.seleccionarSQL.UseVisualStyleBackColor = true;
            this.seleccionarSQL.Click += new System.EventHandler(this.seleccionarSQL_Click);
            // 
            // txtRutaSQL
            // 
            this.txtRutaSQL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRutaSQL.Enabled = false;
            this.txtRutaSQL.Location = new System.Drawing.Point(95, 116);
            this.txtRutaSQL.Name = "txtRutaSQL";
            this.txtRutaSQL.ReadOnly = true;
            this.txtRutaSQL.Size = new System.Drawing.Size(537, 20);
            this.txtRutaSQL.TabIndex = 42;
            this.txtRutaSQL.TextChanged += new System.EventHandler(this.txtRutaSQL_TextChanged);
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(809, 104);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(117, 42);
            this.btnProcesar.TabIndex = 44;
            this.btnProcesar.Text = "PROCESAR";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // DataGridSQL
            // 
            this.DataGridSQL.AllowUserToAddRows = false;
            this.DataGridSQL.AllowUserToDeleteRows = false;
            this.DataGridSQL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridSQL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.descripcion,
            this.resultado,
            this.ESTADO});
            this.DataGridSQL.Location = new System.Drawing.Point(0, 2);
            this.DataGridSQL.Name = "DataGridSQL";
            this.DataGridSQL.ReadOnly = true;
            this.DataGridSQL.Size = new System.Drawing.Size(744, 202);
            this.DataGridSQL.TabIndex = 45;
            this.DataGridSQL.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DataGridSQL_CellFormatting);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ValidadorSES.Properties.Resources.logo_ses;
            this.pictureBox1.Location = new System.Drawing.Point(12, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 80);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(823, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(103, 13);
            this.linkLabel1.TabIndex = 46;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Validar Objetos DSX";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabValidaccion);
            this.tabControl1.Controls.Add(this.tabtablas);
            this.tabControl1.Location = new System.Drawing.Point(95, 155);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(752, 229);
            this.tabControl1.TabIndex = 47;
            // 
            // tabValidaccion
            // 
            this.tabValidaccion.Controls.Add(this.DataGridSQL);
            this.tabValidaccion.Location = new System.Drawing.Point(4, 22);
            this.tabValidaccion.Name = "tabValidaccion";
            this.tabValidaccion.Padding = new System.Windows.Forms.Padding(3);
            this.tabValidaccion.Size = new System.Drawing.Size(744, 203);
            this.tabValidaccion.TabIndex = 0;
            this.tabValidaccion.Text = "Validación";
            this.tabValidaccion.UseVisualStyleBackColor = true;
            // 
            // tabtablas
            // 
            this.tabtablas.Controls.Add(this.dgvTablas);
            this.tabtablas.Location = new System.Drawing.Point(4, 22);
            this.tabtablas.Name = "tabtablas";
            this.tabtablas.Padding = new System.Windows.Forms.Padding(3);
            this.tabtablas.Size = new System.Drawing.Size(744, 203);
            this.tabtablas.TabIndex = 1;
            this.tabtablas.Text = "Nomenclatura de Tablas";
            this.tabtablas.UseVisualStyleBackColor = true;
            // 
            // dgvTablas
            // 
            this.dgvTablas.AllowUserToAddRows = false;
            this.dgvTablas.AllowUserToDeleteRows = false;
            this.dgvTablas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTablas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.ESTADO2});
            this.dgvTablas.Location = new System.Drawing.Point(0, 2);
            this.dgvTablas.Name = "dgvTablas";
            this.dgvTablas.ReadOnly = true;
            this.dgvTablas.Size = new System.Drawing.Size(744, 202);
            this.dgvTablas.TabIndex = 46;
            this.dgvTablas.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvTablas_CellFormatting);
            this.dgvTablas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTablas_CellContentClick);
            // 
            // descripcion
            // 
            this.descripcion.HeaderText = "DESCRIPCION";
            this.descripcion.Name = "descripcion";
            this.descripcion.ReadOnly = true;
            this.descripcion.Width = 245;
            // 
            // resultado
            // 
            this.resultado.HeaderText = "RESULTADO";
            this.resultado.Name = "resultado";
            this.resultado.ReadOnly = true;
            this.resultado.Width = 340;
            // 
            // ESTADO
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.ESTADO.DefaultCellStyle = dataGridViewCellStyle1;
            this.ESTADO.HeaderText = "ESTADO";
            this.ESTADO.Name = "ESTADO";
            this.ESTADO.ReadOnly = true;
            this.ESTADO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.ESTADO.Width = 115;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "NOMBRE TABLA";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 245;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "RESULTADO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 340;
            // 
            // ESTADO2
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.ESTADO2.DefaultCellStyle = dataGridViewCellStyle2;
            this.ESTADO2.HeaderText = "ESTADO";
            this.ESTADO2.Name = "ESTADO2";
            this.ESTADO2.ReadOnly = true;
            this.ESTADO2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.ESTADO2.Width = 115;
            // 
            // FormValidaSQL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(934, 396);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.btnProcesar);
            this.Controls.Add(this.seleccionarSQL);
            this.Controls.Add(this.txtRutaSQL);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormValidaSQL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validador SES 2.0";
            this.Load += new System.EventHandler(this.FormValidaSQL_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridSQL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabValidaccion.ResumeLayout(false);
            this.tabtablas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTablas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button seleccionarSQL;
        private System.Windows.Forms.TextBox txtRutaSQL;
        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.DataGridView DataGridSQL;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabValidaccion;
        private System.Windows.Forms.TabPage tabtablas;
        private System.Windows.Forms.DataGridView dgvTablas;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultado;
        private System.Windows.Forms.DataGridViewTextBoxColumn ESTADO;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ESTADO2;
    }
}