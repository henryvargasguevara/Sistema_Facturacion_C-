﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormValidadorDetalleParameterSet : Form
    {
        public const string TBL_PARAM_NOMBRE = "Nombre Parámetro";
        public const string TBL_PARAM_DESCRIPCION = "Descripción";
        public const string TBL_PARAM_ESTADO = "Estado";
        public const string TBL_PARAM_DESCRIPCION_VALIDACION = "Descripción de validación del Parámetro";
        public const string TBL_PARAM_NOMBRE_PARAMETER_SET = "Nombre ParameterSet";

        public string parameterSetDescripcionValidacion { get; set; }

        public FormValidadorDetalleParameterSet()
        {
            InitializeComponent();
        }

        private void btnMostrarDesValid_Click(object sender, EventArgs e)
        {

            if (parameterSetDescripcionValidacion != null && parameterSetDescripcionValidacion != "")
            {
                string desConSalto = parameterSetDescripcionValidacion;
                desConSalto = desConSalto.Replace(": ", ": \n");
                desConSalto = desConSalto.Replace(". ", ". \n\n");
                MessageBox.Show(desConSalto, "Validación de ParameterSet", MessageBoxButtons.OK);
            }
        }

        private void dataGridViewDetalle_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewDetalle.Columns[e.ColumnIndex].Name.Equals(TBL_PARAM_ESTADO))
            {
                string estado = dataGridViewDetalle.Rows[e.RowIndex].Cells[TBL_PARAM_ESTADO].Value.ToString();
                if (estado.Equals("OK"))
                {
                    dataGridViewDetalle.Rows[e.RowIndex].Cells[TBL_PARAM_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals("NOTOK"))
                    {
                        dataGridViewDetalle.Rows[e.RowIndex].Cells[TBL_PARAM_ESTADO].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        //dataGridViewDetalle.Rows[e.RowIndex].Cells[FormPrincipal.TBL_STAGE_ESTADO].Style.ForeColor = Color.GreenYellow;
                    }

                }

            }
        }

        private void FormDetalleRoutine_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        public void cargarDetalleParameterSet(LogParameterSet parameter)
        {
            parameterSetDescripcionValidacion = parameter.mensaje;
            Text = "Detalle de ParameterSet - " + parameter.identifierParameterSet;
            lblNombreParameter.Text = parameter.identifierParameterSet;
            txtRutaParameter.Text = parameter.category;
            txtDescripcionValidacionParameter.Text = parameter.mensaje;

            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView viewDetalle = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_PARAM_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(TBL_PARAM_DESCRIPCION));
            table.Columns.Add(UtilForm.getColumnString(TBL_PARAM_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_PARAM_DESCRIPCION_VALIDACION));

            //logica
            if (parameter != null)
            {
                int totalParam = parameter.listaParam.Count;
                for (int j = 0; j < totalParam; j++)
                {
                    LogParam param = parameter.listaParam[j];
                    DataRow row = table.NewRow();

                    row[TBL_PARAM_NOMBRE] = param.name;
                    row[TBL_PARAM_DESCRIPCION] = param.textoAyuda;
                    row[TBL_PARAM_ESTADO] = param.estadoParamDescripcion;
                    row[TBL_PARAM_DESCRIPCION_VALIDACION] = param.mensaje;

                    table.Rows.Add(row);
                }
            }

            viewDetalle = new DataView(table);

            //pintar en el detalle
            DataGridView dataViewDetalle = dataGridViewDetalle;
            dataViewDetalle.Visible = true;
            dataViewDetalle.RowHeadersVisible = false;
            dataViewDetalle.DataSource = viewDetalle;

            dataViewDetalle.Columns[TBL_PARAM_NOMBRE].Width = 200;
            dataViewDetalle.Columns[TBL_PARAM_DESCRIPCION].Width = 200;
            dataViewDetalle.Columns[TBL_PARAM_ESTADO].Width = 90;
            dataViewDetalle.Columns[TBL_PARAM_DESCRIPCION_VALIDACION].Width = 600;

            dataViewDetalle.Columns[TBL_PARAM_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //totales
            txtTotalParam.Text = Convert.ToString(parameter.listaParam.Count);
            txtNroCorrectos.Text = Convert.ToString(parameter.numParamCorrecto);
            txtNroIncorrecto.Text = Convert.ToString(parameter.numParamIncorrecto);
            txtNroObservacion.Text = Convert.ToString(parameter.numParamObservado);
        }
    }
}
