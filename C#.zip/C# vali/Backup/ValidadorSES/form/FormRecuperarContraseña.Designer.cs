﻿namespace ValidadorSES.form
{
    partial class FormRecuperarContraseña
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRecuperarContraseña));
            this.label2 = new System.Windows.Forms.Label();
            this.txtPregunta = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRespuesta = new System.Windows.Forms.TextBox();
            this.btnValidarRespuesta = new System.Windows.Forms.Button();
            this.gbValidarRespuesta = new System.Windows.Forms.GroupBox();
            this.gbActualizarClave = new System.Windows.Forms.GroupBox();
            this.txtcodigo = new System.Windows.Forms.TextBox();
            this.btnGrabarContraseña = new System.Windows.Forms.Button();
            this.txtConfirmarContraseña = new System.Windows.Forms.TextBox();
            this.txtNuevaContraseña = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsuarioOlvidado = new System.Windows.Forms.TextBox();
            this.btnObtenerPregunta = new System.Windows.Forms.Button();
            this.gbValidarRespuesta.SuspendLayout();
            this.gbActualizarClave.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pregunta :";
            // 
            // txtPregunta
            // 
            this.txtPregunta.Location = new System.Drawing.Point(146, 37);
            this.txtPregunta.Name = "txtPregunta";
            this.txtPregunta.ReadOnly = true;
            this.txtPregunta.Size = new System.Drawing.Size(156, 20);
            this.txtPregunta.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Respuesta :";
            // 
            // txtRespuesta
            // 
            this.txtRespuesta.Location = new System.Drawing.Point(146, 63);
            this.txtRespuesta.Name = "txtRespuesta";
            this.txtRespuesta.Size = new System.Drawing.Size(157, 20);
            this.txtRespuesta.TabIndex = 4;
            // 
            // btnValidarRespuesta
            // 
            this.btnValidarRespuesta.Location = new System.Drawing.Point(338, 37);
            this.btnValidarRespuesta.Name = "btnValidarRespuesta";
            this.btnValidarRespuesta.Size = new System.Drawing.Size(75, 40);
            this.btnValidarRespuesta.TabIndex = 5;
            this.btnValidarRespuesta.Text = "Validar Respuesta";
            this.btnValidarRespuesta.UseVisualStyleBackColor = true;
            this.btnValidarRespuesta.Click += new System.EventHandler(this.btnValidarRespuesta_Click);
            // 
            // gbValidarRespuesta
            // 
            this.gbValidarRespuesta.Controls.Add(this.btnValidarRespuesta);
            this.gbValidarRespuesta.Controls.Add(this.label2);
            this.gbValidarRespuesta.Controls.Add(this.txtRespuesta);
            this.gbValidarRespuesta.Controls.Add(this.txtPregunta);
            this.gbValidarRespuesta.Controls.Add(this.label3);
            this.gbValidarRespuesta.Location = new System.Drawing.Point(12, 59);
            this.gbValidarRespuesta.Name = "gbValidarRespuesta";
            this.gbValidarRespuesta.Size = new System.Drawing.Size(436, 100);
            this.gbValidarRespuesta.TabIndex = 6;
            this.gbValidarRespuesta.TabStop = false;
            this.gbValidarRespuesta.Text = "Pregunta Secreta";
            this.gbValidarRespuesta.Visible = false;
            // 
            // gbActualizarClave
            // 
            this.gbActualizarClave.Controls.Add(this.txtcodigo);
            this.gbActualizarClave.Controls.Add(this.btnGrabarContraseña);
            this.gbActualizarClave.Controls.Add(this.txtConfirmarContraseña);
            this.gbActualizarClave.Controls.Add(this.txtNuevaContraseña);
            this.gbActualizarClave.Controls.Add(this.label5);
            this.gbActualizarClave.Controls.Add(this.label4);
            this.gbActualizarClave.Location = new System.Drawing.Point(13, 165);
            this.gbActualizarClave.Name = "gbActualizarClave";
            this.gbActualizarClave.Size = new System.Drawing.Size(436, 91);
            this.gbActualizarClave.TabIndex = 7;
            this.gbActualizarClave.TabStop = false;
            this.gbActualizarClave.Text = "Actualizar Contraseña";
            this.gbActualizarClave.Visible = false;
            // 
            // txtcodigo
            // 
            this.txtcodigo.Location = new System.Drawing.Point(402, 8);
            this.txtcodigo.Name = "txtcodigo";
            this.txtcodigo.Size = new System.Drawing.Size(33, 20);
            this.txtcodigo.TabIndex = 11;
            this.txtcodigo.Visible = false;
            // 
            // btnGrabarContraseña
            // 
            this.btnGrabarContraseña.Location = new System.Drawing.Point(337, 34);
            this.btnGrabarContraseña.Name = "btnGrabarContraseña";
            this.btnGrabarContraseña.Size = new System.Drawing.Size(75, 40);
            this.btnGrabarContraseña.TabIndex = 7;
            this.btnGrabarContraseña.Text = "Cambiar Contraseña";
            this.btnGrabarContraseña.UseVisualStyleBackColor = true;
            this.btnGrabarContraseña.Click += new System.EventHandler(this.btnGrabarContraseña_Click);
            // 
            // txtConfirmarContraseña
            // 
            this.txtConfirmarContraseña.Location = new System.Drawing.Point(148, 58);
            this.txtConfirmarContraseña.Name = "txtConfirmarContraseña";
            this.txtConfirmarContraseña.Size = new System.Drawing.Size(157, 20);
            this.txtConfirmarContraseña.TabIndex = 6;
            this.txtConfirmarContraseña.UseSystemPasswordChar = true;
            // 
            // txtNuevaContraseña
            // 
            this.txtNuevaContraseña.Location = new System.Drawing.Point(148, 32);
            this.txtNuevaContraseña.Name = "txtNuevaContraseña";
            this.txtNuevaContraseña.Size = new System.Drawing.Size(156, 20);
            this.txtNuevaContraseña.TabIndex = 5;
            this.txtNuevaContraseña.UseSystemPasswordChar = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Confirmar Contraseña :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Nueva Contraseña :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ingrese Usuario :";
            // 
            // txtUsuarioOlvidado
            // 
            this.txtUsuarioOlvidado.Location = new System.Drawing.Point(158, 21);
            this.txtUsuarioOlvidado.Name = "txtUsuarioOlvidado";
            this.txtUsuarioOlvidado.Size = new System.Drawing.Size(156, 20);
            this.txtUsuarioOlvidado.TabIndex = 9;
            // 
            // btnObtenerPregunta
            // 
            this.btnObtenerPregunta.Location = new System.Drawing.Point(350, 14);
            this.btnObtenerPregunta.Name = "btnObtenerPregunta";
            this.btnObtenerPregunta.Size = new System.Drawing.Size(75, 39);
            this.btnObtenerPregunta.TabIndex = 10;
            this.btnObtenerPregunta.Text = "Obtener pregunta";
            this.btnObtenerPregunta.UseVisualStyleBackColor = true;
            this.btnObtenerPregunta.Click += new System.EventHandler(this.btnObtenerPregunta_Click);
            // 
            // FormRecuperarContraseña
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 268);
            this.Controls.Add(this.btnObtenerPregunta);
            this.Controls.Add(this.txtUsuarioOlvidado);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gbActualizarClave);
            this.Controls.Add(this.gbValidarRespuesta);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormRecuperarContraseña";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cambiar Contraseña - Validador SES 2.0";
            this.gbValidarRespuesta.ResumeLayout(false);
            this.gbValidarRespuesta.PerformLayout();
            this.gbActualizarClave.ResumeLayout(false);
            this.gbActualizarClave.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPregunta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRespuesta;
        private System.Windows.Forms.Button btnValidarRespuesta;
        private System.Windows.Forms.GroupBox gbValidarRespuesta;
        private System.Windows.Forms.GroupBox gbActualizarClave;
        private System.Windows.Forms.Button btnGrabarContraseña;
        private System.Windows.Forms.TextBox txtConfirmarContraseña;
        private System.Windows.Forms.TextBox txtNuevaContraseña;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsuarioOlvidado;
        private System.Windows.Forms.Button btnObtenerPregunta;
        private System.Windows.Forms.TextBox txtcodigo;
    }
}