﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormTipoValidacion : Form
    {
        public FormTipoValidacion()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_ASIGNACION_REGLA_VALIDACION_POR_TIPO_VALIDACION;

            cargarCheckListBoxExpress();
            cargarCheckListBoxFull();
        }
        private void cargarCheckListBoxExpress() 
        {
            List<ReglaView> listaRV = new List<ReglaView>();

            try
            {
                ReglaDAO rdao = new ReglaDAO();
                listaRV = rdao.getListaReglaViewSimple();
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            checkedListBoxExpress.Items.Clear();

            for (int i = 0; i < listaRV.Count; i++)
            {
                checkedListBoxExpress.Items.Insert(i, listaRV[i]);

                if (listaRV[i].estadoExpress == "S")
                {
                    checkedListBoxExpress.SetItemCheckState(i, CheckState.Checked);
                }
                else
                {
                    checkedListBoxExpress.SetItemCheckState(i, CheckState.Unchecked);
                }
            }

            checkedListBoxExpress.DisplayMember = "nombre";
            checkedListBoxExpress.ValueMember = "codigoRegla";
        }

        private void cargarCheckListBoxFull() 
        {
            List<ReglaView> listaRV = new List<ReglaView>();

            try
            {
                ReglaDAO rdao = new ReglaDAO();
                listaRV = rdao.getListaReglaViewSimple();
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            checkedListBoxFull.Items.Clear();

            for (int i = 0; i < listaRV.Count; i++)
            {
                checkedListBoxFull.Items.Insert(i, listaRV[i]);

                if (listaRV[i].estadoFull == "S")
                {
                    checkedListBoxFull.SetItemCheckState(i, CheckState.Checked);
                }
                else
                {
                    checkedListBoxFull.SetItemCheckState(i, CheckState.Unchecked);
                }
            }

            checkedListBoxFull.DisplayMember = "nombre";
            checkedListBoxFull.ValueMember = "codigoRegla";
        }

        private void guardarListaExpress()
        {
            //Validacion EXPRESS
            List<Regla> listaRVExpress = new List<Regla>();

            foreach (Object item in checkedListBoxExpress.Items)
            {
                ReglaView rv = (ReglaView)item;
                string estado = "N";

                if (checkedListBoxExpress.CheckedItems.Contains(item))
                {
                    estado = "S";
                }

                Regla r = new Regla();
                r.codigoRegla = rv.codigoRegla;
                r.estadoExpress = estado;
                r.usuarioModificador = 1;
                r.fechaModificacion = DateTime.Now;

                listaRVExpress.Add(r);
            }

            try
            {
                ReglaDAO rdao = new ReglaDAO();
                rdao.actualizarListaReglaExpress(listaRVExpress);

                MessageBox.Show("Se actualizó correctamente");
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }
        
        }

        private void guardarListaFull() {
            //validacion FULL
            List<Regla> listaRVFull = new List<Regla>();

            foreach (Object item in checkedListBoxFull.Items)
            {
                ReglaView rv = (ReglaView)item;
                string estado = "N";

                if (checkedListBoxFull.CheckedItems.Contains(item))
                {
                    estado = "S";
                }

                Regla r = new Regla();
                r.codigoRegla = rv.codigoRegla;
                r.estadoFull = estado;
                r.usuarioModificador = 1;
                r.fechaModificacion = DateTime.Now;

                listaRVFull.Add(r);
            }
            
            try
            {
                ReglaDAO rdao = new ReglaDAO();
                rdao.actualizarListaReglaFull(listaRVFull);

                MessageBox.Show("Se actualizó correctamente");
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }
        }

        private void btnGuardarExpress_Click(object sender, EventArgs e)
        {
            guardarListaExpress();
           
        }

        private void btnCancelarExpress_Click(object sender, EventArgs e)
        {
            cargarCheckListBoxExpress();
        }

        private void btnGuardarFull_Click(object sender, EventArgs e)
        {
            guardarListaFull();
            
        }

        private void btnCancelarFull_Click(object sender, EventArgs e)
        {
            cargarCheckListBoxFull();
        }
    }
}
