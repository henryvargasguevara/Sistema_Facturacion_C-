﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;
using System.Collections;
using System.IO;

namespace ValidadorSES.form
{
    public partial class FormMantenimientoRequerimiento : Form
    {
        public Usuario usuariologeado { get; set; }
        MaestroDAO daomaestro = new MaestroDAO();
        UsuarioDAO daoUsuario = new UsuarioDAO();
        RequerimientoDAO daorequerimiento = new RequerimientoDAO();

        public FormMantenimientoRequerimiento()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_MANTENIMIENTO_REQUERIMIENTO;
        }

        public void mostrarPantalla()
        {
            /*CARGAR LISTADO CLIENTES*/
            cboCliente.DataSource = daomaestro.getListaClientes();
            cboCliente.DisplayMember = "nombre";
            cboCliente.ValueMember = "valor_key";

            /*CARGAR LISTADO ESTADO DE REQUERIMIENTO*/
            cboEstadoReq.DataSource = daomaestro.getListaEstadoRequerimiento();
            cboEstadoReq.DisplayMember = "nombre";
            cboEstadoReq.ValueMember = "valor_key";

            /*CARGAR LISTADO LIDERES*/
            List<Usuario> lista = daoUsuario.getListaLideres();
            cboLiderResponsable.DataSource = lista;
            cboLiderResponsable.DisplayMember = "fullName";
            cboLiderResponsable.ValueMember = "codigo_Usuario";
            /*CARGAR LISTADO PRIORIDAD*/
            cboPrioridadRequerimiento.DataSource = daomaestro.getListaPrioridad();
            cboPrioridadRequerimiento.DisplayMember = "nombre";
            cboPrioridadRequerimiento.ValueMember = "valor_key";

            /*CARGAR LISTADO TIPO VALIDACION*/
            cboTipoValidacion.DataSource = daomaestro.getListaTipoValidacion();
            cboTipoValidacion.DisplayMember = "nombre";
            cboTipoValidacion.ValueMember = "valor_key";

            /*CARGAR LISTADO TIPO CARGA DE JOB*/
            cboTipoCargaJob.DataSource = daomaestro.getListaTipoCargaJob();
            cboTipoCargaJob.DisplayMember = "nombre";
            cboTipoCargaJob.ValueMember = "valor_key";

            mostrarTablaListadorequerimiento();
            deshabilitarCampos();
            dgListadoRequerimiento.ReadOnly = true;

            cboLiderResponsable.Enabled = false;
            cboPrioridadRequerimiento.Enabled = false;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            habilitarCampos();
            limpiarcampos();
            cboEstadoReq.Visible = false;
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {

            Requerimiento obj = getRequerimientoValidado();

            if (obj != null)
            {
                if (obj.codigo.Trim() == ""
                    || obj.cliente == -1
                    || obj.num_pase.Trim() == ""
                    || obj.descripcion.Trim() == "" 
                    || obj.liderResponsable == -1 
                    || obj.prioridad.Trim() == "" 
                    || obj.tipoValidacion.Trim() == "" 
                    || obj.tipoCargaJob.Trim() == "")
                {
                    MessageBox.Show("Completar todos los campos", "Error!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                }
                else
                {

                    int dia = obj.fecha_inicio.Day;
                    int mes = obj.fecha_inicio.Month;
                    int año = obj.fecha_inicio.Year;

                    int dia2 = obj.fecha_fin.Day;
                    int mes2 = obj.fecha_fin.Month;
                    int año2 = obj.fecha_fin.Year;
                    bool validarFecha = UtilRequerimiento.getValidarDia(dia, dia2, mes, mes2, año, año2);

                    //if (obj.fecha_inicio < obj.fecha_fin || obj.fecha_inicio == obj.fecha_fin)
                    if (validarFecha)
                    {
                        List<RequerimientoView> lista = new List<RequerimientoView>();
                        // string cod = txtCodigoRequerimiento.Text;
                        bool estado = cboEstadoReq.Visible;
                        try
                        {
                            RequerimientoDAO odao = new RequerimientoDAO();
                            if (!estado)
                            {
                                RequerimientoView rv = odao.getRequerimientoByCodigo(obj.codigo);
                                if (rv.codigo == null)
                                {
                                    odao.insertarRequerimiento(obj);
                                    MessageBox.Show("Requerimiento Registrado correctamente", "AVISO");
                                }
                                else 
                                {
                                    MessageBox.Show("Requerimiento con código ["+obj.codigo+"] ya se encuentra registrado", "AVISO");
                                    return;
                                }
                            }
                            else
                            {
                                odao.actualizarRequerimiento(obj);
                                MessageBox.Show("Requerimiento actualizado correctamente", "AVISO");
                                int columnaSeleccionada = dgListadoRequerimiento.CurrentCell.ColumnIndex;
                                int filaseleccionada = dgListadoRequerimiento.CurrentCell.RowIndex;

                            }
                            lista = odao.getListaRequerimientoView();
                            //limpiarInterfaz();
                            llenarTabla(lista);
                            deshabilitarCampos();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ocurrió un error al registrar el objeto a la BD." + ex);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Fecha de fin es menor a la fecha de inicio", "ERROR!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private Requerimiento getRequerimientoValidado()
        {
            string mensaje = "";
            Requerimiento obj = null;

            string codigo = txtCodigoRequerimiento.Text;
            string numeroPase = txtNumPase.Text;
            int cliente = UtilRequerimiento.getCodigocliente(cboCliente.Text);
            string descripcion = txtDescripcionReq.Text;
            DateTime fechaIni = dtpFechaIni.Value;
            DateTime fechafin = dtpFechaFin.Value;
            string estado = UtilRequerimiento.getCodigoEstadoReq(cboEstadoReq.Text);
            Usuario usercombo = (Usuario)cboLiderResponsable.SelectedItem;
            int lider = usercombo.codigo_Usuario;
            DetalleMaestro dmTipoPrioridad = (DetalleMaestro)cboPrioridadRequerimiento.SelectedItem;
            string prioridad = dmTipoPrioridad.valor_key;
            string tipoValidacion = UtilRequerimiento.getCodigoTipoValidacion(cboTipoValidacion.Text);
            DetalleMaestro dmTipoCargaJob = (DetalleMaestro)cboTipoCargaJob.SelectedItem;
            string tipoCargaJob = dmTipoCargaJob.valor_key;

            if (mensaje == "")
            {
                obj = new Requerimiento();
                obj.codigo = codigo;
                obj.num_pase = numeroPase;
                obj.cliente = cliente;
                obj.descripcion = descripcion;
                obj.fecha_inicio = fechaIni;
                obj.fecha_fin = fechafin;
                obj.estado = estado;
                obj.fecha_creacion = DateTime.Now;
                obj.fecha_modificacion = DateTime.Now;
                obj.usuario_creador = usuariologeado.codigo_Usuario; ;
                obj.usuario_modificador = usuariologeado.codigo_Usuario;
                obj.liderResponsable = lider;
                obj.prioridad = prioridad;
                obj.tipoValidacion = tipoValidacion;
                obj.tipoCargaJob = tipoCargaJob;
            }

            return obj;
        }

        private void llenarTabla(List<RequerimientoView> lista)
        {
            dgListadoRequerimiento.Columns.Clear();

            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString("CODIGO"));
            table.Columns.Add(UtilForm.getColumnString("CLIENTE"));
            table.Columns.Add(UtilForm.getColumnString("N° PASE"));
            table.Columns.Add(UtilForm.getColumnString("DESCRIPCION"));
            table.Columns.Add(UtilForm.getColumnString("FECHA INICIO"));
            table.Columns.Add(UtilForm.getColumnString("FECHA FIN"));
            table.Columns.Add(UtilForm.getColumnString("LIDER RESPONSABLE"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO"));
            table.Columns.Add(UtilForm.getColumnString("PRIORIDAD"));
            table.Columns.Add(UtilForm.getColumnString("TIPO CARGA JOB"));
            table.Columns.Add(UtilForm.getColumnString("TIPO VALIDACIÓN"));
            table.Columns.Add(UtilForm.getColumnString("CREADO POR"));
            table.Columns.Add(UtilForm.getColumnString("CREADO EL"));
            table.Columns.Add(UtilForm.getColumnString("ACTUALIZADO POR"));
            table.Columns.Add(UtilForm.getColumnString("ACTUALIZADO EL"));
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                RequerimientoDAO dao = new RequerimientoDAO();
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    RequerimientoView ov = lista[j];
                    DataRow row = table.NewRow();
                    row["CODIGO"] = ov.codigo;
                    row["CLIENTE"] = ov.cliente;
                    row["N° PASE"] = ov.num_pase;
                    row["DESCRIPCION"] = ov.descripcion;
                    row["FECHA INICIO"] = ov.fecha_inicio;
                    row["FECHA FIN"] = ov.fecha_fin;
                    row["ESTADO"] = ov.estado;
                    row["CREADO POR"] = ov.usuario_creador;
                    row["CREADO EL"] = ov.fecha_creacion;
                    row["ACTUALIZADO POR"] = ov.usuario_modificador;
                    row["ACTUALIZADO EL"] = ov.fecha_modificacion;
                    row["LIDER RESPONSABLE"] = ov.LiderResponsable;
                    row["PRIORIDAD"] = ov.prioridad;
                    row["TIPO CARGA JOB"] = ov.tipoCargaJob;
                    row["TIPO VALIDACIÓN"] = ov.tipoValidacion;

                    table.Rows.Add(row);
                }
            }

            dgListadoRequerimiento.Columns.Clear();
            DataView view = new DataView(table);

            dgListadoRequerimiento.Visible = true;
            dgListadoRequerimiento.RowHeadersVisible = false;
            dgListadoRequerimiento.DataSource = view;

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dgListadoRequerimiento.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = ">";
            buttonColumn.Name = "Abrir";
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dgListadoRequerimiento.Columns["Abrir"].Width = 40;
            dgListadoRequerimiento.Columns["CODIGO"].Width = 60;
            dgListadoRequerimiento.Columns["CLIENTE"].Width = 80;
            dgListadoRequerimiento.Columns["N° PASE"].Width = 80;
            dgListadoRequerimiento.Columns["DESCRIPCION"].Width = 150;
            dgListadoRequerimiento.Columns["FECHA INICIO"].Width = 140;
            dgListadoRequerimiento.Columns["FECHA FIN"].Width = 140;
            dgListadoRequerimiento.Columns["ESTADO"].Width = 70;
            dgListadoRequerimiento.Columns["CREADO POR"].Width = 110;
            dgListadoRequerimiento.Columns["CREADO EL"].Width = 140;
            dgListadoRequerimiento.Columns["ACTUALIZADO POR"].Width = 135;
            dgListadoRequerimiento.Columns["ACTUALIZADO EL"].Width = 140;
            dgListadoRequerimiento.Columns["LIDER RESPONSABLE"].Width = 110;
            dgListadoRequerimiento.Columns["PRIORIDAD"].Width = 70;
            dgListadoRequerimiento.Columns["TIPO CARGA JOB"].Width = 130;
            dgListadoRequerimiento.Columns["TIPO VALIDACIÓN"].Width = 110;
        }

        private void mostrarTablaListadorequerimiento()
        {
            List<RequerimientoView> lista = new List<RequerimientoView>();

            try
            {
                RequerimientoDAO dao = new RequerimientoDAO();
                lista = dao.getListaRequerimientoView();
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de usuario");
            }

            llenarTabla(lista);
        }

        private void dgListadoRequerimiento_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                //if (dgListadoRequerimiento.Rows.Count < 0)
                //{

                //}
                //else
                //{
                //string opcion = (string)dgListadoRequerimiento.CurrentRow.Cells["OPCION"].Value;
                string codigo = (string)dgListadoRequerimiento.CurrentRow.Cells["CODIGO"].Value;
                string cliente = (string)dgListadoRequerimiento.CurrentRow.Cells["CLIENTE"].Value;
                string numPase = (string)dgListadoRequerimiento.CurrentRow.Cells["N° PASE"].Value;
                string descripcion = (string)dgListadoRequerimiento.CurrentRow.Cells["DESCRIPCION"].Value;
                string fecha_ini = (string)dgListadoRequerimiento.CurrentRow.Cells["FECHA INICIO"].Value;
                string fecha_fin = (string)dgListadoRequerimiento.CurrentRow.Cells["FECHA FIN"].Value;
                string estado = (string)dgListadoRequerimiento.CurrentRow.Cells["ESTADO"].Value;
                //string usuarioCreador = (string)dgListadoRequerimiento.CurrentRow.Cells[8].Value;
                //string fecha_creacion = (string)dgListadoRequerimiento.CurrentRow.Cells[9].Value;
                //string usuario_Modificador = (string)dgListadoRequerimiento.CurrentRow.Cells[10].Value;
                //string fecha_Modificador = (string)dgListadoRequerimiento.CurrentRow.Cells[11].Value;
                string LiderResponsable = (string)dgListadoRequerimiento.CurrentRow.Cells["LIDER RESPONSABLE"].Value;
                string prioridad = (string)dgListadoRequerimiento.CurrentRow.Cells["PRIORIDAD"].Value;
                string tipoValidacion = (string)dgListadoRequerimiento.CurrentRow.Cells["TIPO VALIDACIÓN"].Value;
                string tipoCargaJob = (string)dgListadoRequerimiento.CurrentRow.Cells["TIPO CARGA JOB"].Value;

                txtCodigoRequerimiento.Text = codigo;
                cboCliente.Text = cliente;
                txtNumPase.Text = numPase;
                txtDescripcionReq.Text = descripcion;
                dtpFechaIni.Text = fecha_ini;
                dtpFechaFin.Text = fecha_fin;
                cboEstadoReq.Text = estado;
                cboLiderResponsable.Text = LiderResponsable;
                cboPrioridadRequerimiento.Text = prioridad;
                cboTipoValidacion.Text = tipoValidacion;
                cboTipoCargaJob.Text = tipoCargaJob;

                deshabilitarCampos();
                lblEstado.Visible = false;
                cboEstadoReq.Visible = false;
                //}
            }
            catch (Exception)
            {
                MessageBox.Show("Error al seleccionar usuario");
            }
        }

        public void deshabilitarCampos()
        {
            txtCodigoRequerimiento.ReadOnly = true;
            txtDescripcionReq.ReadOnly = true;
            txtNumPase.ReadOnly = true;
            cboCliente.Enabled = false;
            cboEstadoReq.Enabled = false;
            dtpFechaIni.Enabled = false;
            dtpFechaFin.Enabled = false;
            cboLiderResponsable.Enabled = false;
            cboPrioridadRequerimiento.Enabled = false;
            cboTipoValidacion.Enabled = false;
            cboTipoCargaJob.Enabled = false;
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            habilitarCampos();
            lblEstado.Visible = true;
            cboEstadoReq.Visible = true;
        }

        public void habilitarCampos()
        {
            txtCodigoRequerimiento.ReadOnly = false;
            txtDescripcionReq.ReadOnly = false;
            txtNumPase.ReadOnly = false;
            cboCliente.Enabled = true;
            cboEstadoReq.Enabled = true;
            cboLiderResponsable.Enabled = true;
            
            cboPrioridadRequerimiento.Enabled = true;

            dtpFechaFin.Enabled = true;
            dtpFechaIni.Enabled = true;
            cboTipoValidacion.Enabled = true;
            cboTipoCargaJob.Enabled = true;
        }

        public void limpiarcampos()
        {
            txtCodigoRequerimiento.Clear();
            txtDescripcionReq.Clear();
            txtNumPase.Clear();
            cboCliente.SelectedIndex = 0;
            cboEstadoReq.SelectedIndex = 0;
            cboLiderResponsable.SelectedIndex = 0;
            cboPrioridadRequerimiento.SelectedIndex = 2; //ALTA
            cboTipoValidacion.SelectedIndex = 1; //FULL
            dtpFechaFin.Value = DateTime.Now;
            dtpFechaIni.Value = DateTime.Now;
        }

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {
            //txtMantBuscarUser.Text = txtMantBuscarUser.Text.Trim();
            string textoBuscar = txtFiltro.Text;

            if (textoBuscar != "")
            {
                List<RequerimientoView> lista = new List<RequerimientoView>();

                try
                {
                    RequerimientoDAO odao = new RequerimientoDAO();
                    lista = odao.getBuscarRequerimiento(textoBuscar);
                }
                catch (Exception e2)
                {
                    MessageBox.Show("Ocurrió un error de BD " + e2);
                }

                llenarTabla(lista);
            }
            else
            {
                List<RequerimientoView> lista = new List<RequerimientoView>();

                try
                {
                    RequerimientoDAO odao = new RequerimientoDAO();
                    lista = odao.getBuscarRequerimiento(textoBuscar);
                }
                catch (Exception e2)
                {
                    MessageBox.Show("Ocurrió un error de BD " + e2);
                }

                llenarTabla(lista);
            }
        }

        private void dgListadoRequerimiento_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dgListadoRequerimiento.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && (columnaSeleccionada == 0 || columnaSeleccionada == 15)) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dgListadoRequerimiento.CurrentCell.RowIndex;

                string codigoRequerimiento = dgListadoRequerimiento.Rows[filaSeleccionada].Cells["CODIGO"].Value.ToString();

                try
                {
                    AsignacionReqDAO ardao = new AsignacionReqDAO();
                    List<AsignarRequerimientoView> listaAsig = ardao.getListaRequerimientoAsignadosPorRequerimiento(codigoRequerimiento);
                    if (listaAsig == null || listaAsig.Count == 0)
                    {
                        MessageBox.Show("La asignación no tiene colaboradores asignados", "¡Aviso!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error consulta BD: " + ex);
                }

                FormMantenimientoRequerimientoRecursoAsignados formRecAsig = new FormMantenimientoRequerimientoRecursoAsignados();
                formRecAsig.codigoRequerimiento = codigoRequerimiento;
                formRecAsig.cargarPantalla();
                formRecAsig.ShowDialog();

                //FormValidadorDetalleRoutine formDetalle = new FormValidadorDetalleRoutine();
                //formDetalle.cargarDetalleRoutine(routine);
                //formDetalle.ShowDialog();

                dgListadoRequerimiento.Rows[filaSeleccionada].Selected = true;
            }
        }

        private void dgListadoRequerimiento_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgListadoRequerimiento.Columns[e.ColumnIndex].Name.Equals("ESTADO"))
            {
                string estado = dgListadoRequerimiento.Rows[e.RowIndex].Cells["ESTADO"].Value.ToString();
                if (estado.Equals(ConstanteMaestro.DES_EST_REQ_SUCCESS))
                {
                    dgListadoRequerimiento.Rows[e.RowIndex].Cells["ESTADO"].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals(ConstanteMaestro.DES_EST_REQ_RECHAZADO))
                    {
                        dgListadoRequerimiento.Rows[e.RowIndex].Cells["ESTADO"].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

        //private void dgListadoRequerimiento_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    //int columnaSeleccionada = dgListadoRequerimiento.CurrentCell.ColumnIndex;
        //    //int f = dgListadoRequerimiento.CurrentCell.RowIndex;

        //    //if (columnaSeleccionada == 0) //posición del boton
        //    //{
        //    //    int filaSeleccionada = dgListadoRequerimiento.CurrentCell.RowIndex;

        //    //    string codigoRequerimiento = dgListadoRequerimiento.Rows[filaSeleccionada].Cells["CODIGO"].Value.ToString();
        //    //    string descripcionRequerimiento = dgListadoRequerimiento.Rows[filaSeleccionada].Cells["DESCRIPCION"].Value.ToString();
        //    //    string estado = dgListadoRequerimiento.Rows[filaSeleccionada].Cells["ESTADO"].Value.ToString();

        //    //    if (estado == "Pendiente")
        //    //    {
        //    //        FormAsignacionRequerimiento formAsignacion = new FormAsignacionRequerimiento();
        //    //        formAsignacion.codigoRequerimiento = codigoRequerimiento;
        //    //        formAsignacion.lblCodigoAsiganción.Text = codigoRequerimiento;
        //    //        formAsignacion.txtCodigoReq.Text = codigoRequerimiento;
        //    //        formAsignacion.lblDescripcion.Text = descripcionRequerimiento;
        //    //        formAsignacion.usuariologeado = usuariologeado;
        //    //        formAsignacion.ShowDialog();
        //    //    }
        //    //    else
        //    //    {
        //    //        MessageBox.Show("Seleccione un requerimiento Pendiente");
        //    //    }
        //    //}
        //}


    }
}

