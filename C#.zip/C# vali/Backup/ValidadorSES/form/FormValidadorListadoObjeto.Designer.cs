﻿namespace ValidadorSES.form
{
    partial class FormValidadorListadoObjeto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormValidadorListadoObjeto));
            this.dataGridViewObjeto = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewObjeto)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewObjeto
            // 
            this.dataGridViewObjeto.AllowUserToAddRows = false;
            this.dataGridViewObjeto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewObjeto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewObjeto.Location = new System.Drawing.Point(12, 94);
            this.dataGridViewObjeto.Name = "dataGridViewObjeto";
            this.dataGridViewObjeto.Size = new System.Drawing.Size(973, 354);
            this.dataGridViewObjeto.TabIndex = 0;
            this.dataGridViewObjeto.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRegla_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(148, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(581, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Listado de Objetos DataStage que son validados";
            // 
            // FormValidadorListadoObjeto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(997, 473);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridViewObjeto);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormValidadorListadoObjeto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lisado de Objetos DataStage que son validados- Validador SES 2.0";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewObjeto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewObjeto;
        private System.Windows.Forms.Label label2;
    }
}