﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormReglaAsignacion : Form
    {
        public FormReglaAsignacion()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_ASIGNACION_REGLA_VALIDACION;

            cargarPantalla();
        }

        private void cargarPantalla() 
        {            
            //Llenar combo de Tipo de objeto
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            try
            {
                MaestroDAO mdao = new MaestroDAO();
                lista = mdao.getListaClasificacion();
                if (lista != null && lista.Count >= 1)
                {
                    cargarComboRegla(lista[0].valor_key);
                }
            }
            catch (Exception)
            {
                //string mensaje = "Ocurrió un error al registrar la regla en la BD";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            comboBoxTipoObjeto.DataSource = lista;
            comboBoxTipoObjeto.DisplayMember = "nombre";
            comboBoxTipoObjeto.ValueMember = "valor_key";

        }

        private void cargarComboRegla(string tipo)
        {
            checkBoxTodosObjetos.Checked = false;
            checkedListBoxObjeto.Items.Clear();

            //Llenar combo de Regla de validacion
            List<ReglaView> listaRV = new List<ReglaView>();

            try
            {
                ReglaDAO rdao = new ReglaDAO();
                listaRV = rdao.getListaReglaViewSimpleByTipoObjeto(tipo);
                if (listaRV != null && listaRV.Count >= 1)
                {
                    cargarCheckListBox(listaRV[0].codigoRegla, tipo);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            comboBoxRegla.DataSource = listaRV;
            comboBoxRegla.DisplayMember = "nombre";
            comboBoxRegla.ValueMember = "codigoRegla";
        }

        private void cargarCheckListBox(int codigoRegla, string tipoObjeto)
        {
            //Llenar combo de ObjetoRegla
            List<ObjetoReglaView> listaROV = new List<ObjetoReglaView>();

            try
            {
                ObjetoReglaDAO ordao = new ObjetoReglaDAO();
                listaROV = ordao.getListaObjetoReglaViewByRegla(codigoRegla, tipoObjeto);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            checkBoxTodosObjetos.Checked = false;
            checkedListBoxObjeto.Items.Clear();

            for (int i = 0; i < listaROV.Count; i++)
            {
                checkedListBoxObjeto.Items.Insert(i, listaROV[i]);
                if (listaROV[i].estadoObjRegla == "1")
                {
                    checkedListBoxObjeto.SetItemCheckState(i, CheckState.Checked);
                }
                if (listaROV[i].estadoObjRegla == "2")
                {
                    checkedListBoxObjeto.SetItemCheckState(i, CheckState.Unchecked);
                }
                //estado 3 deshabilitado
            }

            checkedListBoxObjeto.DisplayMember = "clasificacionAndType";
            checkedListBoxObjeto.ValueMember = "codigoObjeto";
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            List<ObjetoRegla> listaOR = new List<ObjetoRegla>();

            foreach (Object item in checkedListBoxObjeto.Items)
            {
                ObjetoReglaView ovr = (ObjetoReglaView)item;
                string estado = "2";
                
                if (checkedListBoxObjeto.CheckedItems.Contains(item))
                {
                    estado = "1";
                }

                ObjetoRegla or = new ObjetoRegla();
                or.codigoObjetoRegla = ovr.codigoRegla + "-" + ovr.codigoObjeto;
                or.codigoRegla = ovr.codigoRegla;
                or.codigoObjeto = ovr.codigoObjeto;
                or.estado = estado;

                or.usuarioCreador = 1;
                or.fechaCreacion = DateTime.Now;
                or.usuarioModificador = 1;
                or.fechaModificacion = DateTime.Now;

                listaOR.Add(or);
            }

            try
            {
                ObjetoReglaDAO ordao = new ObjetoReglaDAO();
                ordao.guardarListaObjetoRegla(listaOR);
                MessageBox.Show("Se actualizó correctamente la asignación");
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DetalleMaestro dm = (DetalleMaestro)comboBoxTipoObjeto.SelectedItem;
            ReglaView rv = (ReglaView)comboBoxRegla.SelectedItem;

            if (dm!=null && rv != null)
            {
                cargarCheckListBox(rv.codigoRegla, dm.valor_key);
            }
        }

        private void comboBoxRegla_SelectedValueChanged(object sender, EventArgs e)
        {
            DetalleMaestro dm = (DetalleMaestro)comboBoxTipoObjeto.SelectedItem;
            ReglaView rv = (ReglaView)comboBoxRegla.SelectedItem;

            if (dm != null && rv != null)
            {
                cargarCheckListBox(rv.codigoRegla, dm.valor_key);
            }
        }

        private void comboBoxTipoObjeto_SelectedValueChanged(object sender, EventArgs e)
        {
            DetalleMaestro dm = (DetalleMaestro)comboBoxTipoObjeto.SelectedItem;
            if(dm!=null)
            {
                cargarComboRegla(dm.valor_key);
            }

        }

        private void checkBoxTodosObjetos_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTodosObjetos.Checked)
            {
                int total = checkedListBoxObjeto.Items.Count;

                for(int i=0;i<total;i++)
                {

                    checkedListBoxObjeto.SetItemCheckState(i, CheckState.Checked);
                }
            }

            checkBox1.Checked = false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                int total = checkedListBoxObjeto.Items.Count;

                for (int i = 0; i < total; i++)
                {

                    checkedListBoxObjeto.SetItemCheckState(i, CheckState.Unchecked);
                }
            }
            checkBoxTodosObjetos.Checked = false;
        }

        private void checkedListBoxObjeto_Click(object sender, EventArgs e)
        {

            checkBoxTodosObjetos.Checked = false;
            checkBox1.Checked = false;
        }
    }
}
