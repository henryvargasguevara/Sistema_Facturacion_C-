﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo;
using ValidadorSES.dao;
using ValidadorSES.modelo.view;
using ValidadorSES.util;
using System.Windows.Forms.VisualStyles;


namespace ValidadorSES.form
{
    public partial class FormAsignacionRequerimiento : Form
    {
        public DataGridView newGRid = new DataGridView();
        public Usuario usuariologeado { get; set; }
        UsuarioDAO daousuario = new UsuarioDAO();
        RequerimientoDAO daoRequerimiento = new RequerimientoDAO();
        MaestroDAO daoMaestro = new MaestroDAO();
        public string codigoRequerimiento { get; set; }
        AsignacionReqDAO dao = new AsignacionReqDAO();
        //string codigoRequerimiento = lblCodigoAsiganción.Text;

        public FormAsignacionRequerimiento()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_ASIGNACION_REQUERIMIENTO;
        }

        public void mostrarPantalla() 
        {
            if (chkHabilitar.Checked == false)
            {
                List<Usuario> lista = daousuario.getListaColaboradoresDeLideres(usuariologeado.codigo_Usuario);

                cboColaboradores.DataSource = lista;
                cboColaboradores.DisplayMember = "fullName";
                cboColaboradores.ValueMember = "codigo_Usuario";
                cboColaboradores.SelectedIndex = -1;

                cboOtroLider.Visible = false;
                lblOtrosColaboradores.Visible = false;
                
            }
                cboOtroLider.DataSource = dao.getListaLideres();
                cboOtroLider.DisplayMember = "nombres";
                cboOtroLider.ValueMember = "codigo_Usuario";

                mostrarTablaListadoRequerimiento();
                mostrarTablaListadoAsignacionrequerimiento();

            //FormAsignacionRequerimiento formDinamico = new FormAsignacionRequerimiento();
            //formDinamico.Width = dgAsignacionRequerimiento.Width;

        }

        private void cboLider_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string cod = "";

            //Usuario user = (Usuario) cboColaboradores.SelectedItem;

            //cod = "-" + user.codigo_Usuario;
            //lblCodigoAsiganción.Text = codigoRequerimiento + cod;
            //lblCodigo.Text = user.codigo_Usuario+"";
            
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            AsignarRequerimiento obj = getASignarRequerimientoValidado();

            if (obj != null)
            {
                string estado = obj.estado;


                string[] listacodigo = obj.codigo.Split('-');
                //for (int i = 0; i < listacodigo.Count(); i++) 
                //{
                //if (listacodigo.Count() == 1) 
                //{
                //MessageBox.Show("
                //}
                    //if (listacodigo[1] == "" || listacodigo[1] == null)
                if (listacodigo.Count()==1)
                    {
                        MessageBox.Show("Escoga un colaborador para asignar el requerimiento", "ERROR!",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
                        // string cod = txtCodigoRequerimiento.Text;
                        //bool estado = cboEstadoAsignacionReq.Visible;
                        try
                        {
                            RequerimientoDAO odao = new RequerimientoDAO();
                            AsignacionReqDAO daoAsignar = new AsignacionReqDAO();

                            RequerimientoView rv = odao.getRequerimientoByCodigo(obj.codigo_requerimiento);
                            //if (rv.estado == ConstanteMaestro.COD_EST_REQ_SUCCESS 
                            //    || rv.estado == ConstanteMaestro.COD_EST_REQ_RECHAZADO)
                            //{
                            //    MessageBox.Show("El requerimiento se encuentra cerrado", "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //    return;
                            //}

                            //if (!estado)
                            //{
                            bool encontrado=daoAsignar.getExisteAsignacion(obj.codigo);
                            if (!encontrado)
                            {

                                daoAsignar.insertarAsignacionRequerimiento(obj);
                                
                                MessageBox.Show("Asignacion de requerimiento Registrado correctamente", "AVISO");

                                string codigoREq = obj.codigo_requerimiento;
                                odao.actualizarEstadoRequerimiento(codigoREq);
                                MessageBox.Show("Se actualizo el estado de Requerimiento a asignado correctamente", "AVISO");
                            }
                            else
                            {
                                MessageBox.Show("El requerimiento ya fue asignadon a este usuario", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            
                            //mostrarTablaListadoRequerimiento();
                            //mostrarTablaListadoAsignacionrequerimiento();


                            //}
                            //else
                            //{
                            //    odao.actualizarRequerimiento(obj);
                            //    MessageBox.Show("Requerimiento actualizado correctamente", "AVISO");
                            //    int columnaSeleccionada = dgListadoRequerimiento.CurrentCell.ColumnIndex;
                            //    int filaseleccionada = dgListadoRequerimiento.CurrentCell.RowIndex;

                            //}
                            //lista = odao.getListaAsignacionRequerimientoView();
                            ////limpiarInterfaz();
                            //llenarTablaAsignacion(lista);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ocurrió un error al registrar el objeto a la BD." + ex);
                        }
                        mostrarTablaListadoRequerimiento();
                        mostrarTablaListadoAsignacionrequerimiento();
                    }

                
               

            }
        }

        private void llenarTablaAsignacion(List<AsignarRequerimientoView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString("CODIGO"));
            table.Columns.Add(UtilForm.getColumnString("RESPONSABLE"));
            table.Columns.Add(UtilForm.getColumnString("ID REQUERIMIENTO"));
            table.Columns.Add(UtilForm.getColumnString("FECHA ENTREGA"));
            table.Columns.Add(UtilForm.getColumnString("CREADO EL"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO VALIDACIÓN"));
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                RequerimientoDAO dao = new RequerimientoDAO();
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    AsignarRequerimientoView ov = lista[j];
                    DataRow row = table.NewRow();
                    row["CODIGO"] = ov.codigo;
                    row["RESPONSABLE"] = ov.fullName;
                    row["ID REQUERIMIENTO"] = ov.codigo_requerimiento;
                    row["FECHA ENTREGA"] = ov.fecha_asignacion;
                    row["CREADO EL"] = ov.fecha_creacion;
                    row["ESTADO"] = ov.estado;
                    row["ESTADO VALIDACIÓN"] = ov.estadoValidacion;

                    table.Rows.Add(row);
                }
            }

            dgAsignacionRequerimiento.Columns.Clear();
            DataView view = new DataView(table);

            dgAsignacionRequerimiento.Visible = true;
            dgAsignacionRequerimiento.RowHeadersVisible = false;
            dgAsignacionRequerimiento.DataSource = view;

            dgAsignacionRequerimiento.Columns["CODIGO"].Width = 60;
            dgAsignacionRequerimiento.Columns["RESPONSABLE"].Width = 95;
            dgAsignacionRequerimiento.Columns["ID REQUERIMIENTO"].Width = 135;
            dgAsignacionRequerimiento.Columns["FECHA ENTREGA"].Width = 150;
            dgAsignacionRequerimiento.Columns["CREADO EL"].Width = 140;
            dgAsignacionRequerimiento.Columns["ESTADO"].Width = 90;
            dgAsignacionRequerimiento.Columns["ESTADO VALIDACIÓN"].Width = 143;
          
        }

        private void llenarTablaRequerimiento(List<RequerimientoView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString("CODIGO"));
            table.Columns.Add(UtilForm.getColumnString("DESCRIPCIÓN"));
            table.Columns.Add(UtilForm.getColumnString("FECHA INICIO"));
            table.Columns.Add(UtilForm.getColumnString("FECHA FIN"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO"));
            table.Columns.Add(UtilForm.getColumnString("CREADO POR"));
            table.Columns.Add(UtilForm.getColumnString("PRIORIDAD"));
            table.Columns.Add(UtilForm.getColumnString("TIPO VALIDACIÓN"));
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                //RequerimientoDAO dao = new RequerimientoDAO();
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    RequerimientoView ov = lista[j];
                    DataRow row = table.NewRow();
                    row["CODIGO"] = ov.codigo;
                    row["DESCRIPCIÓN"] = ov.descripcion;
                    row["FECHA INICIO"] = ov.fecha_inicio;
                    row["FECHA FIN"] = ov.fecha_fin;
                    row["ESTADO"] = ov.estado;
                    row["CREADO POR"] = ov.usuario_creador;
                    row["PRIORIDAD"] = ov.prioridad;
                    row["TIPO VALIDACIÓN"] = ov.tipoValidacion;

                    table.Rows.Add(row);
                }
            }

            dgRequerimiento.Columns.Clear();
            DataView view = new DataView(table);

            dgRequerimiento.Visible = true;
            dgRequerimiento.RowHeadersVisible = false;
            dgRequerimiento.DataSource = view;

            dgRequerimiento.Columns["CODIGO"].Width = 60;
            dgRequerimiento.Columns["DESCRIPCIÓN"].Width = 120;
            dgRequerimiento.Columns["FECHA INICIO"].Width = 150;
            dgRequerimiento.Columns["FECHA FIN"].Width = 150;
            dgRequerimiento.Columns["ESTADO"].Width = 70;
            dgRequerimiento.Columns["CREADO POR"].Width = 105;
            dgRequerimiento.Columns["ESTADO"].Width = 75;
            dgRequerimiento.Columns["PRIORIDAD"].Width = 80;
            dgRequerimiento.Columns["TIPO VALIDACIÓN"].Width = 130;

        }
        
        private void mostrarTablaListadoAsignacionrequerimiento()
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();

            try
            {
                
                 
                lista = dao.getListaRequerimientoAsignadosView(usuariologeado.codigo_Usuario);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaAsignacion(lista);
        }

        private void mostrarTablaListadoRequerimiento()
        {
            List<RequerimientoView> lista = new List<RequerimientoView>();

            try
            {
                AsignacionReqDAO dao = new AsignacionReqDAO();
                int codigoLider = usuariologeado.codigo_Usuario;
                lista = dao.getListaRequerimientoView(codigoLider);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaRequerimiento(lista);
        }
        
        private AsignarRequerimiento getASignarRequerimientoValidado()
        {
            string mensaje = "";
            AsignarRequerimiento obj = null;

            string codigo = lblCodigoAsiganción.Text;
            int codigoColaborador = int.Parse(lblCodigo.Text);
            string codigo_requerimiento = txtCodigoReq.Text;
            DateTime fechaEntrega = dtpFechaAsignacion.Value;
            string estado =lblEstadoReq.Text;
            //string prioridad = lblPrioridad.Text;
            //string tipoValidacion = lblTipoValidación.Text;
            
      
            if (mensaje == "")
            {
                obj = new AsignarRequerimiento();
                obj.codigo = codigo;
                obj.codigo_usuario = codigoColaborador;
                obj.codigo_requerimiento = codigo_requerimiento;
                obj.fecha_asignacion = fechaEntrega;
                //obj.prioridad=prioridad;
                obj.estado = estado;
                obj.fecha_creacion = DateTime.Now;
                //obj.usuario_creador = usuariologeado.codigo_Usuario; ;
                //obj.TipoValidacion = tipoValidacion;
            }

            return obj;
        }

        private void dgRequerimiento_SelectionChanged(object sender, EventArgs e)
        {
            string codigoReq = (string)dgRequerimiento.CurrentRow.Cells["CODIGO"].Value;
            string DesReq = (string)dgRequerimiento.CurrentRow.Cells["DESCRIPCIÓN"].Value;
            string prioridad = (string)dgRequerimiento.CurrentRow.Cells["PRIORIDAD"].Value;
            string estado = (string)dgRequerimiento.CurrentRow.Cells["ESTADO"].Value;
            string tipoValidacion = (string)dgRequerimiento.CurrentRow.Cells["TIPO VALIDACIÓN"].Value;

            lblCodigoAsiganción.Text = codigoReq;
            txtCodigoReq.Text = codigoReq;
            lblDescripcion.Text = DesReq;
            lblPrioridad.Text = prioridad;
            lblTipoValidación.Text = tipoValidacion;
            lblEstadoReq.Text = estado;


            int filaSeleccionada = dgRequerimiento.CurrentCell.RowIndex;
            string fechaInicio = dgRequerimiento.Rows[filaSeleccionada].Cells["FECHA INICIO"].Value.ToString();
            string nuevofecha1 = fechaInicio.Substring(0, 10);  

            int filaseleccionada2 = dgRequerimiento.CurrentCell.RowIndex;
            string fechaFin = dgRequerimiento.Rows[filaseleccionada2].Cells["FECHA FIN"].Value.ToString();
            string nuevofecha2 = fechaFin.Substring(0, 10);

            DateTime fecha1 = DateTime.Parse(fechaInicio);
            DateTime fecha2 = DateTime.Parse(fechaFin);

            int dia = fecha1.Day;
            int mes = fecha1.Month;
            int año = fecha1.Year;

            int dia2 = fecha2.Day;
            int mes2 = fecha2.Month;
            int año2 = fecha2.Year;
            bool validarFecha = UtilRequerimiento.getValidarDia(dia, dia2, mes, mes2, año, año2);

            DateTime fechaFinTiempo = UtilDataStage.getLastDate();
            dtpFechaAsignacion.MaxDate = fechaFinTiempo;
            dtpFechaAsignacion.MinDate = fechaFinTiempo;

            if (validarFecha)
            {
                dtpFechaAsignacion.MinDate = fecha1;
                dtpFechaAsignacion.MaxDate = fecha2;
            }
            else
            {
                dtpFechaAsignacion.MinDate = fecha1;
                dtpFechaAsignacion.MaxDate = fecha1;
            }
        }

        private void cboColaboradores_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Usuario user = (Usuario)cboColaboradores.SelectedItem;
                string cod = user.codigo_Usuario.ToString();

                string codigoRequerimiento = txtCodigoReq.Text + "-";

                lblCodigoAsiganción.Text = codigoRequerimiento + cod;

                lblCodigo.Text = user.codigo_Usuario + "";
            }
            catch (Exception) { }
        }

        private void dtpFechaAsignacion_Validating(object sender, CancelEventArgs e)
        {
            
            int filaSeleccionada = dgRequerimiento.CurrentCell.RowIndex;
            string fechaInicio = dgRequerimiento.Rows[filaSeleccionada].Cells["FECHA INICIO"].Value.ToString();
            string nuevofecha1 =fechaInicio.Substring(0, 10);          
            

            int filaseleccionada2 = dgRequerimiento.CurrentCell.RowIndex;
            string fechaFin = dgRequerimiento.Rows[filaseleccionada2].Cells["FECHA FIN"].Value.ToString();
            string nuevofecha2 = fechaFin.Substring(0, 10);

            DateTime fecha1 = DateTime.Parse(fechaInicio);
            DateTime fecha2 = DateTime.Parse(fechaFin);
            
            dtpFechaAsignacion.MinDate = fecha1;
            dtpFechaAsignacion.MaxDate = fecha2;
            


            
        }

        private void txtFiltrar_TextChanged(object sender, EventArgs e)
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            string filtro = txtFiltrar.Text;
            try
            {
                lista = dao.getListaRequerimientoAsignadoPorFiltro(filtro);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaAsignacion(lista);
        }

        private void cboOtroLider_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chkHabilitar.Checked == true)
            {

                int codigoLider = dao.getCodigoPorNombreLider(cboOtroLider.Text);
                if (codigoLider != 0)
                {
                    List<Usuario> lista = dao.getListaColaboradoresPorLider(codigoLider);

                    cboColaboradores.DataSource = lista;
                    cboColaboradores.DisplayMember = "fullName";
                    cboColaboradores.ValueMember = "codigo_Usuario";
                }
            }
            else {
                int codigoLider = dao.getCodigoPorNombreLider(cboOtroLider.Text);
                if (codigoLider != 0)
                {
                    List<Usuario> lista = dao.getListaColaboradoresPorLider(usuariologeado.codigo_Usuario);

                    cboColaboradores.DataSource = lista;
                    cboColaboradores.DisplayMember = "fullName";
                    cboColaboradores.ValueMember = "codigo_Usuario";
                }
                 }
           
        }

        private void chkHabilitar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkHabilitar.Checked == true)
            {
                lblOtrosColaboradores.Visible = true;
                cboOtroLider.Visible = true;

            }
            else
            {
                List<Usuario> lista = daousuario.getListaColaboradoresDeLideres(usuariologeado.codigo_Usuario);

                cboColaboradores.DataSource = lista;
                cboColaboradores.DisplayMember = "fullName";
                cboColaboradores.ValueMember = "codigo_Usuario";
                cboColaboradores.SelectedIndex = -1;

                lblOtrosColaboradores.Visible = false;
                cboOtroLider.Visible = false;
            }
        }

       
    }
}
