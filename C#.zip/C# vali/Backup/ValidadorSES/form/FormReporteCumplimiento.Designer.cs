﻿namespace ValidadorSES.form
{
    partial class FormReporteCumplimiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormReporteCumplimiento));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnVer = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.dtpF2 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpF1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFiltro = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblNegativo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblPositivo = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgReporteCumplimiento = new System.Windows.Forms.DataGridView();
            this.lblEstadoColaborador = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.gbResultado = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgReporteCumplimiento)).BeginInit();
            this.gbResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnVer);
            this.groupBox1.Controls.Add(this.btnBuscar);
            this.groupBox1.Controls.Add(this.dtpF2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.dtpF1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtFiltro);
            this.groupBox1.Location = new System.Drawing.Point(23, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(750, 88);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filtros de Reporte";
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(580, 50);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(164, 23);
            this.btnVer.TabIndex = 13;
            this.btnVer.Text = "Ver Resultado de cumplimiento";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.btnVer_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(580, 18);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 6;
            this.btnBuscar.Text = "buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // dtpF2
            // 
            this.dtpF2.Location = new System.Drawing.Point(364, 21);
            this.dtpF2.Name = "dtpF2";
            this.dtpF2.Size = new System.Drawing.Size(200, 20);
            this.dtpF2.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(323, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Hasta";
            // 
            // dtpF1
            // 
            this.dtpF1.Location = new System.Drawing.Point(100, 21);
            this.dtpF1.Name = "dtpF1";
            this.dtpF1.Size = new System.Drawing.Size(200, 20);
            this.dtpF1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "De";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese criterio de búsqueda";
            // 
            // txtFiltro
            // 
            this.txtFiltro.Location = new System.Drawing.Point(224, 47);
            this.txtFiltro.Name = "txtFiltro";
            this.txtFiltro.Size = new System.Drawing.Size(340, 20);
            this.txtFiltro.TabIndex = 0;
            this.txtFiltro.TextChanged += new System.EventHandler(this.txtFiltro_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(586, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "%";
            // 
            // lblNegativo
            // 
            this.lblNegativo.AutoSize = true;
            this.lblNegativo.Location = new System.Drawing.Point(545, 25);
            this.lblNegativo.Name = "lblNegativo";
            this.lblNegativo.Size = new System.Drawing.Size(35, 13);
            this.lblNegativo.TabIndex = 11;
            this.lblNegativo.Text = "label8";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(262, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "%";
            // 
            // lblPositivo
            // 
            this.lblPositivo.AutoSize = true;
            this.lblPositivo.Location = new System.Drawing.Point(221, 25);
            this.lblPositivo.Name = "lblPositivo";
            this.lblPositivo.Size = new System.Drawing.Size(35, 13);
            this.lblPositivo.TabIndex = 9;
            this.lblPositivo.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(384, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Trabajos con valor negativo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(68, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Trabajos con valor positivo:";
            // 
            // dgReporteCumplimiento
            // 
            this.dgReporteCumplimiento.AllowUserToAddRows = false;
            this.dgReporteCumplimiento.AllowUserToDeleteRows = false;
            this.dgReporteCumplimiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgReporteCumplimiento.Location = new System.Drawing.Point(23, 205);
            this.dgReporteCumplimiento.Name = "dgReporteCumplimiento";
            this.dgReporteCumplimiento.Size = new System.Drawing.Size(934, 753);
            this.dgReporteCumplimiento.TabIndex = 1;
            // 
            // lblEstadoColaborador
            // 
            this.lblEstadoColaborador.AutoSize = true;
            this.lblEstadoColaborador.Location = new System.Drawing.Point(221, 51);
            this.lblEstadoColaborador.Name = "lblEstadoColaborador";
            this.lblEstadoColaborador.Size = new System.Drawing.Size(15, 13);
            this.lblEstadoColaborador.TabIndex = 15;
            this.lblEstadoColaborador.Text = "%";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(87, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Estado de Colaborador:";
            // 
            // gbResultado
            // 
            this.gbResultado.Controls.Add(this.lblEstadoColaborador);
            this.gbResultado.Controls.Add(this.label4);
            this.gbResultado.Controls.Add(this.label8);
            this.gbResultado.Controls.Add(this.label5);
            this.gbResultado.Controls.Add(this.lblPositivo);
            this.gbResultado.Controls.Add(this.label9);
            this.gbResultado.Controls.Add(this.label7);
            this.gbResultado.Controls.Add(this.lblNegativo);
            this.gbResultado.Location = new System.Drawing.Point(23, 117);
            this.gbResultado.Name = "gbResultado";
            this.gbResultado.Size = new System.Drawing.Size(750, 82);
            this.gbResultado.TabIndex = 2;
            this.gbResultado.TabStop = false;
            this.gbResultado.Text = "Resultado";
            // 
            // FormReporteCumplimiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 537);
            this.Controls.Add(this.gbResultado);
            this.Controls.Add(this.dgReporteCumplimiento);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormReporteCumplimiento";
            this.Text = "Reporte de Cumplimiento";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgReporteCumplimiento)).EndInit();
            this.gbResultado.ResumeLayout(false);
            this.gbResultado.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFiltro;
        private System.Windows.Forms.DataGridView dgReporteCumplimiento;
        private System.Windows.Forms.DateTimePicker dtpF2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpF1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblNegativo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPositivo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.Label lblEstadoColaborador;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox gbResultado;
    }
}