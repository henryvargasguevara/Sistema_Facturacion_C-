﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo;
using ValidadorSES.dao;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormPrincipal : Form
    {
        public Usuario usuarioLogueado { get; set; }
        UsuarioDAO daouser = new UsuarioDAO();
        UtilUsuario utilUser = new UtilUsuario();

        public FormPrincipal()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_MENU_PRINCIPAL;
        }

        private void btnAsignacionColaborador_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormColaboradorRequerimiento formColaborador = new FormColaboradorRequerimiento();
            formColaborador.usuariologeado = usuarioLogueado;
            formColaborador.formPrincipal = formColaborador;
            formColaborador.mostrarPantalla();
            formColaborador.ShowDialog();
            this.Show();
        }
        
        private void btnMenuManUsers_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormMantenimientoUsuario formMantUsuarios = new FormMantenimientoUsuario();
            formMantUsuarios.usuariologeado = usuarioLogueado;
            formMantUsuarios.ShowDialog();
            this.Show();
        }
        
        private void btnMenuManReglas_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormReglaListado formReglaListado = new FormReglaListado();
            formReglaListado.usuarioLogueado = usuarioLogueado;
            formReglaListado.ShowDialog();
            this.Show();
        }

        private void btnMenuManObj_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormObjetoListado formListado = new FormObjetoListado();
            formListado.usuarioLogueado = usuarioLogueado;
            formListado.ShowDialog();
            this.Show();
        }

        private void btnMenuAsignReglas_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormReglaAsignacion formReglaAsignacion = new FormReglaAsignacion();
            formReglaAsignacion.ShowDialog();
            this.Show();
        }

        //segunda columna
        private void btnAsignacionRequerimiento_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAsignacionRequerimiento formAsignacion = new FormAsignacionRequerimiento();
            formAsignacion.usuariologeado = usuarioLogueado;
            formAsignacion.mostrarPantalla();
            formAsignacion.ShowDialog();
            this.Show();
        }

        private void btnGestionarRequerimiento_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormMantenimientoRequerimiento formRequerimiento = new FormMantenimientoRequerimiento();
            formRequerimiento.usuariologeado = usuarioLogueado;
            formRequerimiento.mostrarPantalla();
            formRequerimiento.ShowDialog();
            this.Show();
        }

        private void btnValidacionExpressFull_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTipoValidacion formTipoValidacion = new FormTipoValidacion();
            formTipoValidacion.ShowDialog();
            this.Show();
        }

        private void btn_Reportes_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormReportes reportes = new FormReportes();
            reportes.ShowDialog();
            this.Show();
        }

        private void btnBuscador_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormBuscador formBuscador = new FormBuscador();
            formBuscador.ShowDialog();
            this.Show();
        }

        private void lnkCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormLoginGeneral fgeneral = new FormLoginGeneral();
            this.Hide();
            fgeneral.ShowDialog();
            this.Close();
        }

      
    }
}
