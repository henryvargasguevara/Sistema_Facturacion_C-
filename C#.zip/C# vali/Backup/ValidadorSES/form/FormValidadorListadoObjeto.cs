﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.modelo.view;

namespace ValidadorSES.form
{
    public partial class FormValidadorListadoObjeto : Form
    {
        public const string TBL_OBJETO_TIPO = "Objeto";
        public const string TBL_OBJETO_NOMBRE = "Nombre";
        public const string TBL_OBJETO_PREFIJO = "Prefijo";
        public const string TBL_OBJETO_MNEMONICO = "Mnemónico";
        public const string TBL_OBJETO_DESCRIPCION = "Descripción";
        public const string TBL_OBJETO_AMPLIAR_DESCRIPCION = "ver más descripción";
        public const int TBL_OBJETO_POS_ABRIR_AMPLIAR_DESCRIPCION = 4;

        public FormValidadorListadoObjeto()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_VALIDADOR_LISTADO_OBJETO;

            mostrarTablaListadoObjeto();
        }
        
        private void mostrarTablaListadoObjeto() {
            List<ObjetoView> lista = new List<ObjetoView>();

            try
            {
                ObjetoDAO odao = new ObjetoDAO();
                lista = odao.getListaObjetoView();
            }catch(Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            llenarTabla(lista);
        }

        private void llenarTabla(List<ObjetoView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJETO_TIPO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJETO_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJETO_PREFIJO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJETO_MNEMONICO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJETO_DESCRIPCION));
            
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    ObjetoView ov = lista[j];
                    DataRow row = table.NewRow();
                    row[TBL_OBJETO_TIPO] = ov.clasificacion;
                    row[TBL_OBJETO_NOMBRE] = ov.nombre;
                    row[TBL_OBJETO_PREFIJO] = ov.prefijo;
                    row[TBL_OBJETO_MNEMONICO] = ov.mnemonico;
                    row[TBL_OBJETO_DESCRIPCION] = ov.descripcion;

                    table.Rows.Add(row);
                }
            }

            dataGridViewObjeto.Columns.Clear();
            DataView view = new DataView(table);

            dataGridViewObjeto.Visible = true;
            dataGridViewObjeto.RowHeadersVisible = false;
            dataGridViewObjeto.DataSource = view;
            
            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewObjeto.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "";
            buttonColumn.Text = "...";
            buttonColumn.Name = TBL_OBJETO_AMPLIAR_DESCRIPCION;
            buttonColumn.DisplayIndex = TBL_OBJETO_POS_ABRIR_AMPLIAR_DESCRIPCION;
            buttonColumn.UseColumnTextForButtonValue = true;
            buttonColumn.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);

            dataGridViewObjeto.Columns[TBL_OBJETO_TIPO].Width = 150;
            dataGridViewObjeto.Columns[TBL_OBJETO_NOMBRE].Width = 200;
            dataGridViewObjeto.Columns[TBL_OBJETO_PREFIJO].Width = 50;
            dataGridViewObjeto.Columns[TBL_OBJETO_MNEMONICO].Width = 140;
            dataGridViewObjeto.Columns[TBL_OBJETO_AMPLIAR_DESCRIPCION].Width = 50;
            dataGridViewObjeto.Columns[TBL_OBJETO_DESCRIPCION].Width = 900;
        }

        private void dataGridViewRegla_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewObjeto.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 0) //indice del boton amplicar descripcion
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewObjeto.CurrentCell.RowIndex;

                string texto = dataGridViewObjeto.Rows[filaSeleccionada].Cells[TBL_OBJETO_DESCRIPCION].Value.ToString();
                mostrarTexto(TBL_OBJETO_DESCRIPCION, texto);
            }
        }

        private void mostrarTexto(string titulo, string texto)
        {
            if (texto != null && texto != "")
            {
                string desConSalto = texto;
                desConSalto = desConSalto.Replace(": ", ": \n");
                desConSalto = desConSalto.Replace(". ", ". \n\n");
                MessageBox.Show(desConSalto, titulo, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
