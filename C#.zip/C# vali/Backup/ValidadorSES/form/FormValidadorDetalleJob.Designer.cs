﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;

namespace ValidadorSES.form
{
    partial class FormValidadorDetalleJob
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public void enviarMensaje() {
            MessageBox.Show("msg");
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormValidadorDetalleJob));
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewDetalleStage = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNroObservacion = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNroCorrectos = new System.Windows.Forms.TextBox();
            this.txtNroIncorrecto = new System.Windows.Forms.TextBox();
            this.txtTotalStage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNombreJob = new System.Windows.Forms.Label();
            this.txtRutaJob = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageStage = new System.Windows.Forms.TabPage();
            this.tabPageDocInterna = new System.Windows.Forms.TabPage();
            this.dataGridViewDetalleJob = new System.Windows.Forms.DataGridView();
            this.prgBarStage = new System.Windows.Forms.ProgressBar();
            this.prgBarDocInterna = new System.Windows.Forms.ProgressBar();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalleStage)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageStage.SuspendLayout();
            this.tabPageDocInterna.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalleJob)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre de Job:";
            // 
            // dataGridViewDetalleStage
            // 
            this.dataGridViewDetalleStage.AllowUserToAddRows = false;
            this.dataGridViewDetalleStage.AllowUserToDeleteRows = false;
            this.dataGridViewDetalleStage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDetalleStage.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewDetalleStage.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewDetalleStage.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewDetalleStage.Location = new System.Drawing.Point(15, 23);
            this.dataGridViewDetalleStage.Name = "dataGridViewDetalleStage";
            this.dataGridViewDetalleStage.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDetalleStage.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewDetalleStage.Size = new System.Drawing.Size(942, 324);
            this.dataGridViewDetalleStage.TabIndex = 2;
            this.dataGridViewDetalleStage.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewDetalleStage_CellFormatting);
            this.dataGridViewDetalleStage.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDetalleStage_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtNroObservacion);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtNroCorrectos);
            this.groupBox1.Controls.Add(this.txtNroIncorrecto);
            this.groupBox1.Controls.Add(this.txtTotalStage);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(1012, 132);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 187);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos";
            // 
            // txtNroObservacion
            // 
            this.txtNroObservacion.Enabled = false;
            this.txtNroObservacion.Location = new System.Drawing.Point(128, 138);
            this.txtNroObservacion.Name = "txtNroObservacion";
            this.txtNroObservacion.Size = new System.Drawing.Size(60, 20);
            this.txtNroObservacion.TabIndex = 9;
            this.txtNroObservacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Con observaciones:";
            // 
            // txtNroCorrectos
            // 
            this.txtNroCorrectos.Enabled = false;
            this.txtNroCorrectos.Location = new System.Drawing.Point(128, 72);
            this.txtNroCorrectos.Name = "txtNroCorrectos";
            this.txtNroCorrectos.Size = new System.Drawing.Size(60, 20);
            this.txtNroCorrectos.TabIndex = 6;
            this.txtNroCorrectos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNroIncorrecto
            // 
            this.txtNroIncorrecto.Enabled = false;
            this.txtNroIncorrecto.Location = new System.Drawing.Point(128, 104);
            this.txtNroIncorrecto.Name = "txtNroIncorrecto";
            this.txtNroIncorrecto.Size = new System.Drawing.Size(60, 20);
            this.txtNroIncorrecto.TabIndex = 5;
            this.txtNroIncorrecto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalStage
            // 
            this.txtTotalStage.Enabled = false;
            this.txtTotalStage.Location = new System.Drawing.Point(128, 40);
            this.txtTotalStage.Name = "txtTotalStage";
            this.txtTotalStage.Size = new System.Drawing.Size(60, 20);
            this.txtTotalStage.TabIndex = 4;
            this.txtTotalStage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Incorrectos:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Correctos:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Total Stage:";
            // 
            // lblNombreJob
            // 
            this.lblNombreJob.AutoSize = true;
            this.lblNombreJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreJob.Location = new System.Drawing.Point(125, 12);
            this.lblNombreJob.Name = "lblNombreJob";
            this.lblNombreJob.Size = new System.Drawing.Size(56, 29);
            this.lblNombreJob.TabIndex = 4;
            this.lblNombreJob.Text = "Job";
            // 
            // txtRutaJob
            // 
            this.txtRutaJob.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRutaJob.Location = new System.Drawing.Point(125, 50);
            this.txtRutaJob.Name = "txtRutaJob";
            this.txtRutaJob.ReadOnly = true;
            this.txtRutaJob.Size = new System.Drawing.Size(824, 20);
            this.txtRutaJob.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(51, 53);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Ruta de Job:";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPageStage);
            this.tabControl1.Controls.Add(this.tabPageDocInterna);
            this.tabControl1.Location = new System.Drawing.Point(12, 132);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(982, 389);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPageStage
            // 
            this.tabPageStage.Controls.Add(this.dataGridViewDetalleStage);
            this.tabPageStage.Location = new System.Drawing.Point(4, 22);
            this.tabPageStage.Name = "tabPageStage";
            this.tabPageStage.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStage.Size = new System.Drawing.Size(974, 363);
            this.tabPageStage.TabIndex = 0;
            this.tabPageStage.Text = "Validación de Stages";
            this.tabPageStage.UseVisualStyleBackColor = true;
            // 
            // tabPageDocInterna
            // 
            this.tabPageDocInterna.Controls.Add(this.dataGridViewDetalleJob);
            this.tabPageDocInterna.Location = new System.Drawing.Point(4, 22);
            this.tabPageDocInterna.Name = "tabPageDocInterna";
            this.tabPageDocInterna.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDocInterna.Size = new System.Drawing.Size(974, 363);
            this.tabPageDocInterna.TabIndex = 1;
            this.tabPageDocInterna.Text = "Validación de Documentación Interna y otros";
            this.tabPageDocInterna.UseVisualStyleBackColor = true;
            // 
            // dataGridViewDetalleJob
            // 
            this.dataGridViewDetalleJob.AllowUserToAddRows = false;
            this.dataGridViewDetalleJob.AllowUserToDeleteRows = false;
            this.dataGridViewDetalleJob.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDetalleJob.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewDetalleJob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewDetalleJob.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewDetalleJob.Location = new System.Drawing.Point(15, 23);
            this.dataGridViewDetalleJob.Name = "dataGridViewDetalleJob";
            this.dataGridViewDetalleJob.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDetalleJob.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewDetalleJob.Size = new System.Drawing.Size(942, 358);
            this.dataGridViewDetalleJob.TabIndex = 3;
            this.dataGridViewDetalleJob.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewDetalleJob_CellFormatting);
            this.dataGridViewDetalleJob.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDetalleJob_CellContentClick);
            // 
            // prgBarStage
            // 
            this.prgBarStage.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.prgBarStage.Location = new System.Drawing.Point(166, 78);
            this.prgBarStage.Name = "prgBarStage";
            this.prgBarStage.Size = new System.Drawing.Size(225, 30);
            this.prgBarStage.TabIndex = 11;
            // 
            // prgBarDocInterna
            // 
            this.prgBarDocInterna.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.prgBarDocInterna.Location = new System.Drawing.Point(636, 78);
            this.prgBarDocInterna.Name = "prgBarDocInterna";
            this.prgBarDocInterna.Size = new System.Drawing.Size(225, 30);
            this.prgBarDocInterna.TabIndex = 12;
            this.prgBarDocInterna.Tag = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(37, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "% Validación de Stages:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(449, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(181, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "% Validación de Doc. Interna y otros:";
            // 
            // FormValidadorDetalleJob
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1224, 533);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.prgBarDocInterna);
            this.Controls.Add(this.prgBarStage);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.txtRutaJob);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblNombreJob);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(1100, 300);
            this.Name = "FormValidadorDetalleJob";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detalle de Job";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormDetalleJob_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalleStage)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPageStage.ResumeLayout(false);
            this.tabPageDocInterna.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalleJob)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.DataGridView dataGridViewDetalleStage;
        public Label lblNombreJob;
        public TextBox txtNroCorrectos;
        public TextBox txtTotalStage;
        public TextBox txtNroIncorrecto;
        public TextBox txtRutaJob;
        private Label label7;
        public TextBox txtNroObservacion;
        private Label label5;
        private TabControl tabControl1;
        private TabPage tabPageStage;
        private TabPage tabPageDocInterna;
        public DataGridView dataGridViewDetalleJob;
        private ProgressBar prgBarStage;
        private ProgressBar prgBarDocInterna;
        private Label label6;
        private Label label8;
    }
}