﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormObjetoRegistroModificacion : Form
    {
        public Usuario usuarioLogueado { get; set; }

        public FormObjetoRegistroModificacion()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_REGISTRO_OBJETO;

            llenarComboEstado();
            llenarComboClasificacion();

            comboBoxClasificacionObjeto.SelectedIndex = 1; //Stage
            comboBoxEstado.SelectedIndex = 0; //ACTIVADO
        }

        private void btnAccion_Click(object sender, EventArgs e)
        {
            if (btnAccion.Text == "REGISTRAR")
            {
                Objeto obj = getObjetoValidado();

                if (obj != null)
                {
                    try
                    {
                        ObjetoDAO odao = new ObjetoDAO();

                        //validar duplicado
                        ObjetoView objDup = odao.getObjetoViewByCodigoObjeto(obj.codigoObjeto);
                        if (objDup != null)
                        {
                            string mensaje = "El objeto ya se encuentra registrado en la BD";
                            MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }else
                        {
                            odao.insertarObjeto(obj);
                            this.Hide();
                        }

                    }
                    catch (Exception)
                    {
                        string mensaje = "Ocurrió un error al registrar el objeto en la BD";
                        MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                Objeto obj = getObjetoValidado();

                if (obj != null)
                {
                    try
                    {
                        ObjetoDAO odao = new ObjetoDAO();
                        odao.actualizarObjeto(obj);
                        MessageBox.Show("El Objeto se actualizado correctamente", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                    }
                    catch (Exception)
                    {
                        string mensaje = "Ocurrió un error al actualizar el objeto en la BD";
                        MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (btnBorrar.Text == "BORRAR")
            {
                limpiarFormulario();
            }
            else {
                this.Hide();
            }
        }

        private void limpiarFormulario()
        {
            comboBoxClasificacionObjeto.Text = UtilForm.OPTION_SELECCIONAR;
            txtOLEType.Text = "";
            txtType.Text = "";
            txtPrefijo.Text = "";
            txtNombre.Text = "";
            txtMnemonico.Text = "";
            txtDescripcion.Text = "";
            comboBoxEstado.Text = UtilForm.OPTION_ACTIVO;
        }

        private Objeto getObjetoValidado()
        {
            txtOLEType.Text = txtOLEType.Text.Trim();
            txtType.Text = txtType.Text.Trim();
            txtPrefijo.Text = txtPrefijo.Text.Trim();
            txtNombre.Text = txtNombre.Text.Trim();
            txtMnemonico.Text = txtMnemonico.Text.Trim();
            txtDescripcion.Text = txtDescripcion.Text.Trim();

            string mensaje = "";
            Objeto obj = null;
            DetalleMaestro dmclas = (DetalleMaestro)comboBoxClasificacionObjeto.SelectedItem;
            string clasificacion = dmclas.valor_key;
            string oletype = txtOLEType.Text;
            string type = txtType.Text;
            string prefijo = txtPrefijo.Text;
            string nombre = txtNombre.Text;
            string mnemonico = txtMnemonico.Text;
            string descripcion = txtDescripcion.Text;
            DetalleMaestro dmest = (DetalleMaestro)comboBoxEstado.SelectedItem;
            string estado = dmest.valor_key;
            
            if (clasificacion == "0")
            {
                mensaje += "Debe seleccionar una clasificación de objeto válida" + "\n";
            }

            //validacion de Job
            if (clasificacion == ConstanteMaestro.COD_CLASF_OBJ_JOB)
            {
                if (type == "")
                {
                    mensaje += "Debe ingresar un JobType válido" + "\n";
                }
                if (nombre == "")
                {
                    mensaje += "Debe ingresar un nombre válido" + "\n";
                }
                if (descripcion == "")
                {
                    mensaje += "Debe ingresar una descripción válida" + "\n";
                }
            }


            //validacion de Stage
            if (clasificacion == ConstanteMaestro.COD_CLASF_OBJ_STAGE)
            {
                if (oletype == "")
                {
                    mensaje += "Debe ingresar un OLEType válido" + "\n";
                }
                if (type == "")
                {
                    mensaje += "Debe ingresar un StageType válido" + "\n";
                }
                if (prefijo == "")
                {
                    mensaje += "Debe ingresar un prefijo válido" + "\n";
                }
                if (nombre == "")
                {
                    mensaje += "Debe ingresar un nombre válido" + "\n";
                }
                if (mnemonico == "")
                {
                    mensaje += "Debe ingresar un mnemónico válido" + "\n";
                }
                if (descripcion == "")
                {
                    mensaje += "Debe ingresar una descripción válida" + "\n";
                }
            }


            //validacion de Routine
            if (clasificacion == ConstanteMaestro.COD_CLASF_OBJ_ROUTINE)
            {
                if (type == "")
                {
                    mensaje += "Debe ingresar un RoutineType válido" + "\n";
                }
                if (prefijo == "")
                {
                    mensaje += "Debe ingresar un prefijo válido" + "\n";
                }
                if (nombre == "")
                {
                    mensaje += "Debe ingresar un nombre válido" + "\n";
                }
                if (descripcion == "")
                {
                    mensaje += "Debe ingresar una descripción válida" + "\n";
                }
            }

            //validación de ParameterSet
            if (clasificacion == ConstanteMaestro.COD_CLASF_OBJ_PARAMETER)
            {
                if (prefijo == "")
                {
                    mensaje += "Debe ingresar un prefijo válido" + "\n";
                }
                if (nombre == "")
                {
                    mensaje += "Debe ingresar un nombre válido" + "\n";
                }
                if (mnemonico == "")
                {
                    mensaje += "Debe ingresar un mnemónico válido" + "\n";
                }
                if (descripcion == "")
                {
                    mensaje += "Debe ingresar una descripción válida" + "\n";
                }
            }

            //validación de Param de ParameterSet
            if (clasificacion == ConstanteMaestro.COD_CLASF_OBJ_PARAMETER_PARAM
                || clasificacion == ConstanteMaestro.COD_CLASF_OBJ_ARGUMENT)
            {
                if (nombre == "")
                {
                    mensaje += "Debe ingresar un nombre válido" + "\n";
                }
                if (descripcion == "")
                {
                    mensaje += "Debe ingresar una descripción válida" + "\n";
                }
            }

            //validar mensaje e insercion a BD
            if (mensaje != "") 
            {
                MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                obj = new Objeto();
                obj.codigoObjeto = oletype + "-" + type;
                obj.clasificacion = clasificacion;
                obj.oletype = oletype;
                obj.type = type;
                obj.prefijo = prefijo;
                obj.nombre = nombre;
                obj.mnemonico = mnemonico;
                obj.descripcion = descripcion;
                obj.estado = estado;

                obj.fechaCreacion = DateTime.Now;
                obj.usuarioCreador = usuarioLogueado.codigo_Usuario;
                obj.fechaModificacion = DateTime.Now;
                obj.usuarioModificador = usuarioLogueado.codigo_Usuario;
            }

            return obj;
        }

        public void cargarObjetoView(ObjetoView obj) {
            if (obj != null)
            {
                this.Text = ConstanteTituloForm.TITULO_EDICION_OBJETO;
                lblTitulo.Text = "Modificación de Objeto";
                btnAccion.Text = "MODIFICAR";
                btnBorrar.Text = "CANCELAR";

                comboBoxClasificacionObjeto.Text = obj.clasificacion;
                comboBoxClasificacionObjeto.Enabled = false;
                txtOLEType.Text = obj.oletype;
                txtOLEType.Enabled = false;
                txtType.Text = obj.type;
                txtType.Enabled = false;
                txtPrefijo.Text = obj.prefijo;
                txtNombre.Text = obj.nombre;
                txtMnemonico.Text = obj.mnemonico;
                txtDescripcion.Text = obj.descripcion;
                comboBoxEstado.Text = obj.estado;
            }
            else {
                this.Hide();
            }
        }

        private void comboBoxClasificacionObjeto_SelectedValueChanged(object sender, EventArgs e)
        {
            string val = comboBoxClasificacionObjeto.Text;

            lblOLEType.Visible = false;
            txtOLEType.Visible = false;
            lblType.Visible = false;
            txtType.Visible = false;
            lblPrefijo.Visible = false;
            txtPrefijo.Visible = false;
            lblNombre.Visible = true;
            txtNombre.Visible = true;
            lblMnemonico.Visible = false;
            txtMnemonico.Visible = false;
            lblDescripcion.Visible = true;
            txtDescripcion.Visible = true;
            lblEstado.Visible = true;
            comboBoxEstado.Visible = true;

            limpiarFormulario();

            switch(val){
                case ConstanteMaestro.DES_CLASF_OBJ_JOB:
                    lblType.Text = "  JobType:";
                    lblType.Visible = true;
                    txtType.Visible = true;

                    break;
                case ConstanteMaestro.DES_CLASF_OBJ_STAGE:
                    lblOLEType.Visible = true;
                    txtOLEType.Visible = true;

                    lblType.Text = " StageType:";
                    lblType.Visible = true;
                    txtType.Visible = true;

                    lblPrefijo.Visible = true;
                    txtPrefijo.Visible = true;

                    lblMnemonico.Visible = true;
                    txtMnemonico.Visible = true;
                    break;
                case ConstanteMaestro.DES_CLASF_OBJ_ROUTINE:
                    lblType.Text = "RoutineType:";
                    lblType.Visible = true;
                    txtType.Visible = true;

                    lblPrefijo.Visible = true;
                    txtPrefijo.Visible = true;
                    break;
                case ConstanteMaestro.DES_CLASF_OBJ_ARGUMENT:
                    break;
                case ConstanteMaestro.DES_CLASF_OBJ_PARAMETER:
                    lblOLEType.Visible = true;
                    txtOLEType.Visible = true;

                    lblPrefijo.Visible = true;
                    txtPrefijo.Visible = true;

                    lblMnemonico.Visible = true;
                    txtMnemonico.Visible = true;
                    break;
            }
        }

        private void llenarComboEstado()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            try
            {
                MaestroDAO mdao = new MaestroDAO();
                lista = mdao.getListaEstadoObjeto();
            }
            catch (Exception)
            {
                //string mensaje = "Ocurrió un error al registrar la regla en la BD";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            comboBoxEstado.DataSource = lista;
            comboBoxEstado.DisplayMember = "nombre";
            comboBoxEstado.ValueMember = "valor_key";
        }

        private void llenarComboClasificacion()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            try
            {
                MaestroDAO mdao = new MaestroDAO();
                lista = mdao.getListaClasificacion();
            }
            catch (Exception)
            {
                //string mensaje = "Ocurrió un error al registrar la regla en la BD";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            comboBoxClasificacionObjeto.DataSource = lista;
            comboBoxClasificacionObjeto.DisplayMember = "nombre";
            comboBoxClasificacionObjeto.ValueMember = "valor_key";
        }
    }
}
