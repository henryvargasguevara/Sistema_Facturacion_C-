﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.service;
using ValidadorSES.ValidadorGNX;

namespace ValidadorSES.form
{
    public partial class FormEscogerValidacion : Form
    {
        public int valor2;
        public string usuario2;
        public string admiGX2;
        public string admiDS2;
        public DateTime fecha2;
        public int valor
        {
            get { return valor2; }
            set { valor2 = value; }
        }
        public string usuario
        {
            get { return usuario2; }
            set { usuario2 = value; }
        }
        public string admiGX
        {
            get { return admiGX2; }
            set { admiGX2 = value; }
        }
        public string admiDS
        {
            get { return admiDS2; }
            set { admiDS2 = value; }
        }
        public DateTime fecha
        {
            get { return fecha2; }
            set { fecha2 = value; }
        }

        public FormEscogerValidacion()
        {
            InitializeComponent();
            // this.Text = ConstanteTituloForm.TITULO_APP_ABREV;            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (admiDS == "1")
            {
                FormPrincipal fPrincipal = new FormPrincipal();
                this.Hide();
                fPrincipal.ShowDialog();
                this.Close();
            }
            else
            {
                FormValidador fvalidador = new FormValidador();
                this.Hide();
                fvalidador.ShowDialog();
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //FormValidaSQL fvalidasql = new FormValidaSQL();
            //this.Hide();
            //fvalidasql.ShowDialog();
            //this.Close();
            int x = valor;

            if (x != 1)
            {
                ValidadorGNX.Formularios.Form1 Form1 = new ValidadorSES.ValidadorGNX.Formularios.Form1();
                //Form1.referencia = usuario;
                Form1.referencia = admiGX;
                this.Hide();
                Form1.ShowDialog();
                this.Close();
            }
            else
            {
                //if (dt.Rows[0][2].ToString().ToUpper() == "ADMINISTRADOR")
                if (admiGX == "1")
                {
                    string msj = "El sistema caduco el " + fecha.ToShortDateString() + "." + "\n" + "Actualize la fecha de vigencia.";
                    MessageBox.Show(msj, "Sistema Caducado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ValidadorGNX.Formularios.MantFechaVencimiento mantV = new ValidadorSES.ValidadorGNX.Formularios.MantFechaVencimiento();
                    this.Hide();
                    mantV.usuario = usuario;
                    mantV.ShowDialog();
                    this.Close();
                }
                else
                {
                    string msj = "El sistema caduco el " + fecha.ToShortDateString() + "." + "\n" + "Ponganse en contacto con el administrador.";
                    MessageBox.Show(msj, "Sistema Caducado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //ValidadorGNX.Formularios.Form1 loginGNX = new ValidadorSES.ValidadorGNX.Formularios.Form1();
            //this.Hide();
            //loginGNX.ShowDialog();
            //this.Close();
            int x = valor;

            if (x != 1)
            {
                ValidadorGNX.Formularios.Form1 Form1 = new ValidadorSES.ValidadorGNX.Formularios.Form1();
                //Form1.referencia = usuario;
                Form1.referencia = admiGX;
                this.Hide();
                Form1.ShowDialog();
                this.Close();
            }
            else
            {
                //if (dt.Rows[0][2].ToString().ToUpper() == "ADMINISTRADOR")
                if (admiGX == "1")
                {
                    string msj = "El sistema caduco el " + fecha.ToShortDateString() + "." + "\n" + "Actualize la fecha de vigencia.";
                    MessageBox.Show(msj, "Sistema Caducado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ValidadorGNX.Formularios.MantFechaVencimiento mantV = new ValidadorSES.ValidadorGNX.Formularios.MantFechaVencimiento();
                    this.Hide();
                    mantV.usuario = usuario;
                    mantV.ShowDialog();
                    this.Close();
                }
                else
                {
                    string msj = "El sistema caduco el " + fecha.ToShortDateString() + "." + "\n" + "Ponganse en contacto con el administrador.";
                    MessageBox.Show(msj, "Sistema Caducado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
        }

        private void FormEscogerValidacion_Load(object sender, EventArgs e)
        {

        }
    }
}
