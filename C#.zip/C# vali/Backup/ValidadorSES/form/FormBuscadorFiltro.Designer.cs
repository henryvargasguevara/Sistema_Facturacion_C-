﻿namespace ValidadorSES.form
{
    partial class FormBuscadorFiltro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBuscadorFiltro));
            this.label1 = new System.Windows.Forms.Label();
            this.checkedListBoxStage = new System.Windows.Forms.CheckedListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkedListBoxPropiedad = new System.Windows.Forms.CheckedListBox();
            this.btnGuardarFiltro = new System.Windows.Forms.Button();
            this.checkBoxTodosStage = new System.Windows.Forms.CheckBox();
            this.checkBoxNingunoStage = new System.Windows.Forms.CheckBox();
            this.checkBoxNingunoPropiedad = new System.Windows.Forms.CheckBox();
            this.checkBoxTodosPropiedad = new System.Windows.Forms.CheckBox();
            this.checkBoxNombreStage = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Stage:";
            // 
            // checkedListBoxStage
            // 
            this.checkedListBoxStage.CheckOnClick = true;
            this.checkedListBoxStage.FormattingEnabled = true;
            this.checkedListBoxStage.Location = new System.Drawing.Point(67, 43);
            this.checkedListBoxStage.Name = "checkedListBoxStage";
            this.checkedListBoxStage.Size = new System.Drawing.Size(168, 229);
            this.checkedListBoxStage.TabIndex = 1;
            this.checkedListBoxStage.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBoxStage_ItemCheck);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(279, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Propiedades:";
            // 
            // checkedListBoxPropiedad
            // 
            this.checkedListBoxPropiedad.CheckOnClick = true;
            this.checkedListBoxPropiedad.FormattingEnabled = true;
            this.checkedListBoxPropiedad.Location = new System.Drawing.Point(354, 65);
            this.checkedListBoxPropiedad.Name = "checkedListBoxPropiedad";
            this.checkedListBoxPropiedad.Size = new System.Drawing.Size(168, 199);
            this.checkedListBoxPropiedad.TabIndex = 3;
            this.checkedListBoxPropiedad.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBoxPropiedad_ItemCheck);
            // 
            // btnGuardarFiltro
            // 
            this.btnGuardarFiltro.Location = new System.Drawing.Point(221, 292);
            this.btnGuardarFiltro.Name = "btnGuardarFiltro";
            this.btnGuardarFiltro.Size = new System.Drawing.Size(117, 23);
            this.btnGuardarFiltro.TabIndex = 4;
            this.btnGuardarFiltro.Text = "Guardar Filtro";
            this.btnGuardarFiltro.UseVisualStyleBackColor = true;
            this.btnGuardarFiltro.Click += new System.EventHandler(this.btnGuardarFiltro_Click);
            // 
            // checkBoxTodosStage
            // 
            this.checkBoxTodosStage.AutoSize = true;
            this.checkBoxTodosStage.Checked = true;
            this.checkBoxTodosStage.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxTodosStage.Location = new System.Drawing.Point(67, 20);
            this.checkBoxTodosStage.Name = "checkBoxTodosStage";
            this.checkBoxTodosStage.Size = new System.Drawing.Size(56, 17);
            this.checkBoxTodosStage.TabIndex = 5;
            this.checkBoxTodosStage.Text = "Todos";
            this.checkBoxTodosStage.UseVisualStyleBackColor = true;
            this.checkBoxTodosStage.CheckedChanged += new System.EventHandler(this.checkBoxTodosStage_CheckedChanged);
            // 
            // checkBoxNingunoStage
            // 
            this.checkBoxNingunoStage.AutoSize = true;
            this.checkBoxNingunoStage.Location = new System.Drawing.Point(169, 20);
            this.checkBoxNingunoStage.Name = "checkBoxNingunoStage";
            this.checkBoxNingunoStage.Size = new System.Drawing.Size(66, 17);
            this.checkBoxNingunoStage.TabIndex = 6;
            this.checkBoxNingunoStage.Text = "Ninguno";
            this.checkBoxNingunoStage.UseVisualStyleBackColor = true;
            this.checkBoxNingunoStage.CheckedChanged += new System.EventHandler(this.checkBoxNingunoStage_CheckedChanged);
            // 
            // checkBoxNingunoPropiedad
            // 
            this.checkBoxNingunoPropiedad.AutoSize = true;
            this.checkBoxNingunoPropiedad.Location = new System.Drawing.Point(456, 19);
            this.checkBoxNingunoPropiedad.Name = "checkBoxNingunoPropiedad";
            this.checkBoxNingunoPropiedad.Size = new System.Drawing.Size(66, 17);
            this.checkBoxNingunoPropiedad.TabIndex = 8;
            this.checkBoxNingunoPropiedad.Text = "Ninguno";
            this.checkBoxNingunoPropiedad.UseVisualStyleBackColor = true;
            this.checkBoxNingunoPropiedad.CheckedChanged += new System.EventHandler(this.checkBoxNingunoPropiedad_CheckedChanged);
            // 
            // checkBoxTodosPropiedad
            // 
            this.checkBoxTodosPropiedad.AutoSize = true;
            this.checkBoxTodosPropiedad.Location = new System.Drawing.Point(354, 19);
            this.checkBoxTodosPropiedad.Name = "checkBoxTodosPropiedad";
            this.checkBoxTodosPropiedad.Size = new System.Drawing.Size(56, 17);
            this.checkBoxTodosPropiedad.TabIndex = 7;
            this.checkBoxTodosPropiedad.Text = "Todos";
            this.checkBoxTodosPropiedad.UseVisualStyleBackColor = true;
            this.checkBoxTodosPropiedad.CheckedChanged += new System.EventHandler(this.checkBoxTodosPropiedad_CheckedChanged);
            // 
            // checkBoxNombreStage
            // 
            this.checkBoxNombreStage.AutoSize = true;
            this.checkBoxNombreStage.Location = new System.Drawing.Point(354, 42);
            this.checkBoxNombreStage.Name = "checkBoxNombreStage";
            this.checkBoxNombreStage.Size = new System.Drawing.Size(92, 17);
            this.checkBoxNombreStage.TabIndex = 9;
            this.checkBoxNombreStage.Text = "Nombre stage";
            this.checkBoxNombreStage.UseVisualStyleBackColor = true;
            // 
            // FormBuscadorFiltro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 339);
            this.Controls.Add(this.checkBoxNombreStage);
            this.Controls.Add(this.checkBoxNingunoPropiedad);
            this.Controls.Add(this.checkBoxTodosPropiedad);
            this.Controls.Add(this.checkBoxNingunoStage);
            this.Controls.Add(this.checkBoxTodosStage);
            this.Controls.Add(this.btnGuardarFiltro);
            this.Controls.Add(this.checkedListBoxPropiedad);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkedListBoxStage);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormBuscadorFiltro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Filtro de Búsqueda";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormBuscadorFiltro_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox checkedListBoxStage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckedListBox checkedListBoxPropiedad;
        private System.Windows.Forms.Button btnGuardarFiltro;
        private System.Windows.Forms.CheckBox checkBoxTodosStage;
        private System.Windows.Forms.CheckBox checkBoxNingunoStage;
        private System.Windows.Forms.CheckBox checkBoxNingunoPropiedad;
        private System.Windows.Forms.CheckBox checkBoxTodosPropiedad;
        private System.Windows.Forms.CheckBox checkBoxNombreStage;
    }
}