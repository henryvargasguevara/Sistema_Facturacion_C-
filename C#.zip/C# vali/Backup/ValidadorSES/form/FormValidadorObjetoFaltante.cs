﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormValidadorObjetoFaltante : Form
    {
        public bool continuarValidacion { get; set; }
        public List<string> listaFaltanteJob { get; set; }
        public List<string> listaFaltanteRoutine { get; set; }
        public List<string> listaFaltanteVariableEntorno { get; set; }

        public FormValidadorObjetoFaltante()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_VALIDADOR_LISTADO_OBJETO_FALTANTE;

            continuarValidacion = false;
        }

        public void inicializarPantalla()
        {
            string msgJob = "";
            string msgRoutine = "";
            string msgVariableEntorno = "";

            if (listaFaltanteVariableEntorno != null ) 
            {
                msgVariableEntorno = UtilLista.getListaConcatenada(listaFaltanteVariableEntorno, "\r\n");
            }
            if (listaFaltanteJob != null)
            {
                msgJob = UtilLista.getListaConcatenada(listaFaltanteJob, "\r\n");
            }
            if (listaFaltanteRoutine != null)
            {
                msgRoutine = UtilLista.getListaConcatenada(listaFaltanteRoutine, "\r\n");
            }

            txtListaVariableEntorno.Text = msgVariableEntorno;
            txtListaJob.Text = msgJob;
            txtListaRoutine.Text = msgRoutine;
        }

        private void btnNO_Click(object sender, EventArgs e)
        {
            continuarValidacion = false;
            this.Hide();
        }

        private void btnSI_Click(object sender, EventArgs e)
        {
            continuarValidacion = true;
            this.Hide();
        }
    }
}
