﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormReglaRegistroModificacion : Form
    {
        public Usuario usuarioLogueado { get; set; }

        public FormReglaRegistroModificacion()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_REGISTRO_REGLA_VALIDACION;

            llenarComboTipoObjeto();
            llenarComboEstado();
            llenarComboEstadoFull();
            llenarComboEstadoExpress();
            comboBoxEstado.SelectedIndex = 0; //ACTIVADO
        }

        private void btnAccion_Click(object sender, EventArgs e)
        {
            if (btnAccion.Text == "REGISTRAR")
            {
                Regla regla = getReglaValidado();

                if (regla != null)
                {
                    try
                    {
                        ReglaDAO rdao = new ReglaDAO();
                        ReglaView reglaDup = rdao.getReglaViewByNombreAndTipo(regla.nombre, regla.tipoObjeto);
                        if (reglaDup != null)
                        {
                            string mensaje = "El nombre de la regla ya se encuentra registrado en la BD";
                            MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            rdao.insertarRegla(regla);
                            this.Hide();
                        }
                    }
                    catch (Exception)
                    {
                        string mensaje = "Ocurrió un error al registrar la regla en la BD";
                        MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                Regla regla = getReglaValidado();

                if (regla != null)
                {
                    try
                    {
                        ReglaDAO rdao = new ReglaDAO();
                        rdao.actualizarRegla(regla);
                        MessageBox.Show("Se actualizo correctamente la regla de validación","AVISO!",MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                    }
                    catch (Exception)
                    {
                        string mensaje = "Ocurrió un error al actualizar la regla en la BD";
                        MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (btnBorrar.Text == "BORRAR")
            {
                limpiarFormulario();
            }
            else {
                this.Hide();
            }
        }

        private void limpiarFormulario()
        {
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            comboBoxEstado.Text = UtilForm.OPTION_ACTIVO;
        }

        private Regla getReglaValidado()
        {
            string mensaje = "";
            Regla regla = null;

            txtNombre.Text = txtNombre.Text.Trim();
            txtDescripcion.Text = txtDescripcion.Text.Trim();
            txtSugerencia.Text = txtSugerencia.Text.Trim();

            int codigo = txtCodigo.Text == "" ? -1 : Convert.ToInt32(txtCodigo.Text);
            string nombre = txtNombre.Text;
            string descripcion = txtDescripcion.Text;
            string sugerencia = txtSugerencia.Text;
            DetalleMaestro dmTipoObj = (DetalleMaestro)comboBoxTipoObjeto.SelectedItem;
            string tipoObjeto = dmTipoObj.valor_key;
            DetalleMaestro dm = (DetalleMaestro)comboBoxEstado.SelectedItem;
            string estado = dm.valor_key;
            DetalleMaestro dmf = (DetalleMaestro)comboBoxFull.SelectedItem;
            string estadoFull = dmf.valor_key;
            DetalleMaestro dme = (DetalleMaestro)comboBoxExpress.SelectedItem;
            string estadoExpress = dme.valor_key;

            //validacion de Regla
            if (nombre == "")
            {
                mensaje += "Debe ingresar un nombre válido" + "\n";
            }
            if (descripcion == "")
            {
                mensaje += "Debe ingresar una descripción válida" + "\n";
            }


            //validar mensaje
            if (mensaje != "") 
            {
                MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                regla = new Regla();
                regla.codigoRegla = codigo;
                regla.nombre = nombre;
                regla.descripcion = descripcion;
                regla.sugerencia = sugerencia;
                regla.tipoObjeto = tipoObjeto;
                regla.estado = estado;
                regla.estadoFull = estadoFull;
                regla.estadoExpress = estadoExpress;

                regla.fechaCreacion = DateTime.Now;
                regla.usuarioCreador = usuarioLogueado.codigo_Usuario;

                regla.fechaModificacion = DateTime.Now;
                regla.usuarioModificador = usuarioLogueado.codigo_Usuario;
            }

            return regla;
        }

        public void cargarReglaView(ReglaView regla) {
            if (regla != null)
            {
                this.Text = "Modificación de Regla de Validación";
                lblTitulo.Text = "Modificación de Regla de Validación";
                btnAccion.Text = "MODIFICAR";
                btnBorrar.Text = "CANCELAR";

                txtCodigo.Text = Convert.ToString(regla.codigoRegla);
                txtNombre.Text = regla.nombre;
                txtDescripcion.Text = regla.descripcion;
                txtSugerencia.Text = regla.sugerencia;
                comboBoxTipoObjeto.Text = regla.tipoObjeto;
                comboBoxTipoObjeto.Enabled = false;
                comboBoxEstado.Text = regla.estado;
                comboBoxFull.Text = regla.estadoFull;
                comboBoxExpress.Text = regla.estadoExpress;
            }
            else {
                this.Hide();
            }
        }

        private void llenarComboTipoObjeto()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            try
            {
                MaestroDAO mdao = new MaestroDAO();
                lista = mdao.getListaClasificacion();
            }
            catch (Exception)
            {
                //string mensaje = "Ocurrió un error al registrar la regla en la BD";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            comboBoxTipoObjeto.DataSource = lista;
            comboBoxTipoObjeto.DisplayMember = "nombre";
            comboBoxTipoObjeto.ValueMember = "valor_key";
        }

        private void llenarComboEstado() 
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            try
            {
                MaestroDAO mdao = new MaestroDAO();
                lista = mdao.getListaEstadoRegla();
            }
            catch (Exception)
            {
                //string mensaje = "Ocurrió un error al registrar la regla en la BD";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            comboBoxEstado.DataSource = lista;
            comboBoxEstado.DisplayMember = "nombre";
            comboBoxEstado.ValueMember = "valor_key";
        }

        private void llenarComboEstadoFull()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            try
            {
                MaestroDAO mdao = new MaestroDAO();
                lista = mdao.getListaEstadoValidacionFull();
            }
            catch (Exception)
            {
            }

            comboBoxFull.DataSource = lista;
            comboBoxFull.DisplayMember = "nombre";
            comboBoxFull.ValueMember = "valor_key";
        }

        private void llenarComboEstadoExpress()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            try
            {
                MaestroDAO mdao = new MaestroDAO();
                lista = mdao.getListaEstadoValidacionExpress();
            }
            catch (Exception)
            {
            }

            comboBoxExpress.DataSource = lista;
            comboBoxExpress.DisplayMember = "nombre";
            comboBoxExpress.ValueMember = "valor_key";
        }
    }
}
