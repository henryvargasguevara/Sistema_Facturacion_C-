﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using System.Data.SqlClient;
using ValidadorSES.util;
using System.Data;

namespace ValidadorSES.dao
{
    class ReportesDAO
    {
        public List<ReporteCumplimientoView> getListaReportesCumplimiento()
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select u.codigo_Usuario,";
                sql += " u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " a.codigo_usuario_requerimiento,";
                sql += " r2.descripcion,";
                sql += " a.fecha_validacion,";
                sql += " r.fecha_entrega_trabajo,";
                sql += " a.estado_dsx,";
                sql += " case";
                sql += " when a.fecha_validacion > r.fecha_entrega_trabajo then 'No cumple' else 'Cumple'";
                sql += " end";
                sql += " FROM [dbo].[ARCHIVODSX] a";
                sql += " inner join [dbo].[ASIGNARREQUERIMIENTO] r";
                sql += " on r.codigo_usuario_requerimiento= a.codigo_usuario_requerimiento";
                sql += " inner join [dbo].[USUARIO] u";
                sql += " on u.codigo_Usuario= a.usuario_creador";
                sql += " inner join [dbo].[REQUERIMIENTO] r2";
                sql += " on r2.codigo=r.codigo_requerimiento";
                sql += " where a.estado_dsx='OK'";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                //cmd.Parameters.Add("@param", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(cod);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteCumplimientoView ov = new ReporteCumplimientoView();
                    ov.codigo = UtilSQL.getIntOrNull(reader, 0);
                    ov.usuario = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_Asignacion_Requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_Validacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_entrega = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado_dsx = UtilSQL.getStringOrNull(reader, 6);
                    ov.estado_Cumplimiento = UtilSQL.getStringOrNull(reader, 7);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public List<ReporteCumplimientoView> getListaFiltroCumplimiento(string b)
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select u.codigo_Usuario,";
                sql += " u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " a.codigo_usuario_requerimiento,";
                sql += " r2.descripcion,";
                sql += " a.fecha_validacion,";
                sql += " r.fecha_entrega_trabajo,";
                sql += " a.estado_dsx,";
                sql += " case";
                sql += " when a.fecha_validacion > r.fecha_entrega_trabajo then 'No cumple' else 'Cumple'";
                sql += " end";
                sql += " FROM [dbo].[ARCHIVODSX] a";
                sql += " inner join [dbo].[ASIGNARREQUERIMIENTO] r";
                sql += " on r.codigo_usuario_requerimiento= a.codigo_usuario_requerimiento";
                sql += " AND a.estado_dsx='OK'";
                sql += " inner join [dbo].[USUARIO] u";
                sql += " on u.codigo_Usuario= a.usuario_creador";
                sql += " inner join [dbo].[REQUERIMIENTO] r2";
                sql += " on r2.codigo=r.codigo_requerimiento";
                sql += " WHERE u.nombres_Usuario+' '+u.apellidos_usuario like '%'+ @param + '%'";
                sql += " or u.codigo_Usuario like '%'+ @param + '%'";
                sql += " or r2.descripcion like '%'+ @param + '%'";
                sql += " or a.codigo_usuario_requerimiento like '%'+ @param + '%'";
                sql += " or a.estado_dsx like '%'+ @param + '%'";
                sql += " or case when a.fecha_validacion > r.fecha_entrega_trabajo then 'No cumple' else 'Cumple' end like '%'+ @param + '%'";
               
                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = b;
                buscar = buscar.Replace("_", "\\_");
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteCumplimientoView ov = new ReporteCumplimientoView();
                    ov.codigo = UtilSQL.getIntOrNull(reader, 0);
                    ov.usuario = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_Asignacion_Requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_Validacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_entrega = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado_dsx = UtilSQL.getStringOrNull(reader, 6);
                    ov.estado_Cumplimiento = UtilSQL.getStringOrNull(reader, 7);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<ReporteCumplimientoView> getListaFiltroCumplimientoPorColaborador(int b)
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select u.codigo_Usuario,";
                sql += " u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " a.codigo_usuario_requerimiento,";
                sql += " r2.descripcion,";
                sql += " a.fecha_validacion,";
                sql += " r.fecha_entrega_trabajo,";
                sql += " a.estado_dsx,";
                sql += " case";
                sql += " when a.fecha_validacion > r.fecha_entrega_trabajo then 'No cumple' else 'Cumple'";
                sql += " end";
                sql += " FROM [dbo].[ARCHIVODSX] a";
                sql += " inner join [dbo].[ASIGNARREQUERIMIENTO] r";
                sql += " on r.codigo_usuario_requerimiento= a.codigo_usuario_requerimiento";
                sql += " AND a.estado_dsx='OK'";
                sql += " inner join [dbo].[USUARIO] u";
                sql += " on u.codigo_Usuario= a.usuario_creador";
                sql += " inner join [dbo].[REQUERIMIENTO] r2";
                sql += " on r2.codigo=r.codigo_requerimiento";
                sql += " WHERE u.codigo_Usuario = @param";
               
                SqlCommand cmd = new SqlCommand(sql, conexion);
               
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(b);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteCumplimientoView ov = new ReporteCumplimientoView();
                    ov.codigo = UtilSQL.getIntOrNull(reader, 0);
                    ov.usuario = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_Asignacion_Requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_Validacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_entrega = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado_dsx = UtilSQL.getStringOrNull(reader, 6);
                    ov.estado_Cumplimiento = UtilSQL.getStringOrNull(reader, 7);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<ReporteCumplimientoView> getListaFiltrofecha(DateTime f1, DateTime f2)
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "select u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " a.codigo_usuario_requerimiento,";
                sql += " a.fecha_validacion,";
                sql += " r.fecha_entrega_trabajo,";
                sql += " a.estado_dsx,";
                sql += " case";
                sql += " when a.fecha_validacion > r.fecha_entrega_trabajo then 'No cumple' else 'Cumple'";
                sql += " end";
                sql += " FROM [dbo].[ARCHIVODSX] a";
                sql += " inner join [dbo].[ASIGNARREQUERIMIENTO] r";
                sql += " on r.codigo_usuario_requerimiento= a.codigo_usuario_requerimiento";
                sql += " AND a.estado_dsx='OK'";
                sql += " inner join [dbo].[USUARIO] u";
                sql += " on u.codigo_Usuario= a.usuario_creador";
                sql += " WHERE a.fecha_validacion between @param and @param1";
                
                SqlCommand cmd = new SqlCommand(sql, conexion);
                
                cmd.Parameters.Add("@param", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(f1);
                cmd.Parameters.Add("@param1", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(f2);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteCumplimientoView ov = new ReporteCumplimientoView();
                    ov.usuario = UtilSQL.getStringOrNull(reader, 0);
                    ov.codigo_Asignacion_Requerimiento = UtilSQL.getStringOrNull(reader, 1);
                    ov.fecha_Validacion = UtilSQL.getStringDateTimeOrNull(reader, 2);
                    ov.fecha_entrega = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.estado_dsx = UtilSQL.getStringOrNull(reader, 4);
                    ov.estado_Cumplimiento = UtilSQL.getStringOrNull(reader, 5);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }


        public List<ReporteEfectividadView> getListaReportesEfectividad()
        {
            List<ReporteEfectividadView> lista = new List<ReporteEfectividadView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT a.codigo_usuario_requerimiento";
                       sql += " ,r.descripcion";
                       sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                       sql += " ,a.fecha_creacion";
                       sql += " ,a.estado_dsx";
                       sql += " ,num_job_seq + num_job_paralelo + num_job_server + num_rutina";
                       sql += " FROM dbo.ARCHIVODSX a";
                       sql += " inner join dbo.USUARIO u";
                       sql += " on u.codigo_Usuario = a.usuario_creador";
                       sql += " inner join dbo.ASIGNARREQUERIMIENTO ar";
                       sql += " on ar.codigo_usuario_requerimiento = a.codigo_usuario_requerimiento";
                       sql += " inner join dbo.REQUERIMIENTO r";
                       sql += " on r.codigo = ar.codigo_requerimiento;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                //cmd.Parameters.Add("@param", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(cod);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteEfectividadView ov = new ReporteEfectividadView();
                    ov.codigoAsignacion = UtilSQL.getStringOrNull(reader, 0);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 1);
                    ov.colaborador = UtilSQL.getStringOrNull(reader, 2);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.estadoDsx = UtilSQL.getStringOrNull(reader, 4);
                    ov.numJobValidado = UtilSQL.getIntOrNull(reader, 5);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }


        public List<ReporteEfectividadView> getListaFiltroEfectividad(string b)
        {
            List<ReporteEfectividadView> lista = new List<ReporteEfectividadView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT a.codigo_usuario_requerimiento";
                sql += " ,r.descripcion";
                sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                sql += " ,a.fecha_creacion";
                sql += " ,a.estado_dsx";
                sql += " ,num_job_seq + num_job_paralelo + num_job_server + num_rutina";
                sql += " FROM dbo.ARCHIVODSX a";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario = a.usuario_creador";
                sql += " inner join dbo.ASIGNARREQUERIMIENTO ar";
                sql += " on ar.codigo_usuario_requerimiento = a.codigo_usuario_requerimiento";
                sql += " inner join dbo.REQUERIMIENTO r";
                sql += " on r.codigo = ar.codigo_requerimiento";
                sql += " WHERE a.codigo_usuario_requerimiento like '%'+ @param + '%'";
                sql += " or r.descripcion like '%'+ @param + '%'";
                sql += " or u.nombres_Usuario+', '+u.apellidos_usuario like '%'+ @param + '%'";
                sql += " or a.estado_dsx like '%'+ @param + '%';";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = b;
                buscar = buscar.Replace("_", "\\_");
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteEfectividadView ov = new ReporteEfectividadView();
                    ov.codigoAsignacion = UtilSQL.getStringOrNull(reader, 0);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 1);
                    ov.colaborador = UtilSQL.getStringOrNull(reader, 2);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.estadoDsx = UtilSQL.getStringOrNull(reader, 4);
                    ov.numJobValidado = UtilSQL.getIntOrNull(reader, 5);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<ReporteEfectividadView> getListaFiltrofechaEfectividad(DateTime f1, DateTime f2)
        {
            List<ReporteEfectividadView> lista = new List<ReporteEfectividadView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT a.codigo_usuario_requerimiento";
                sql += " ,r.descripcion";
                sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                sql += " ,a.fecha_creacion";
                sql += " ,a.estado_dsx";
                sql += " ,num_job_seq + num_job_paralelo + num_job_server + num_rutina";
                sql += " FROM dbo.ARCHIVODSX a";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario = a.usuario_creador";
                sql += " inner join dbo.ASIGNARREQUERIMIENTO ar";
                sql += " on ar.codigo_usuario_requerimiento = a.codigo_usuario_requerimiento";
                sql += " inner join dbo.REQUERIMIENTO r";
                sql += " on r.codigo = ar.codigo_requerimiento";
                sql += " WHERE a.fecha_validacion between @param and @param1;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(f1);
                cmd.Parameters.Add("@param1", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(f2);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteEfectividadView ov = new ReporteEfectividadView();
                    ov.codigoAsignacion = UtilSQL.getStringOrNull(reader, 0);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 1);
                    ov.colaborador = UtilSQL.getStringOrNull(reader, 2);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.estadoDsx = UtilSQL.getStringOrNull(reader, 4);
                    ov.numJobValidado = UtilSQL.getIntOrNull(reader, 5);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public string getDescripcionRequerimiento(string codigo)
        {
            string descripcion = "";
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT r.descripcion";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO] a";
                sql += " INNER JOIN [dbo].REQUERIMIENTO r";
                sql += " ON r.codigo=a.codigo_requerimiento";
                sql += " WHERE a.codigo_usuario_requerimiento = @param ;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codigo);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    descripcion= UtilSQL.getStringOrNull(reader, 0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return descripcion;
        }

        public string getFechaEntrega(string codigo)
        {
            string fecha = "";
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT [fecha_entrega_trabajo]";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO]";
                sql += " WHERE codigo_usuario_requerimiento = @param;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codigo);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    fecha = UtilSQL.getStringDateTimeOrNull(reader, 0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return fecha;
        }


        public bool getExisteRequerimiento(string codigo)
        {
            bool hay = false;
            string fecha = "";
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT [fecha_creacion]";
                sql += " FROM [dbo].[ARCHIVODSX]";
                sql += " WHERE [codigo_usuario_requerimiento] = @param;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codigo);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    fecha = UtilSQL.getStringDateTimeOrNull(reader, 0);
                    hay = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return hay;
        }


        public bool getFiltrarColaborador(int b)
        {
            bool hay = false;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select u.codigo_Usuario,";
                sql += " u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " a.codigo_usuario_requerimiento,";
                sql += " r2.descripcion,";
                sql += " a.fecha_validacion,";
                sql += " r.fecha_entrega_trabajo,";
                sql += " a.estado_dsx,";
                sql += " case";
                sql += " when a.fecha_validacion > r.fecha_entrega_trabajo then 'No cumple' else 'Cumple'";
                sql += " end";
                sql += " FROM [dbo].[ARCHIVODSX] a";
                sql += " inner join [dbo].[ASIGNARREQUERIMIENTO] r";
                sql += " on r.codigo_usuario_requerimiento= a.codigo_usuario_requerimiento";
                sql += " AND a.estado_dsx='OK'";
                sql += " inner join [dbo].[USUARIO] u";
                sql += " on u.codigo_Usuario= a.usuario_creador";
                sql += " inner join [dbo].[REQUERIMIENTO] r2";
                sql += " on r2.codigo=r.codigo_requerimiento";
                sql += " WHERE u.codigo_Usuario = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(b);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReporteCumplimientoView ov = new ReporteCumplimientoView();
                    ov.codigo = UtilSQL.getIntOrNull(reader, 0);
                    ov.usuario = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_Asignacion_Requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_Validacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_entrega = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado_dsx = UtilSQL.getStringOrNull(reader, 6);
                    ov.estado_Cumplimiento = UtilSQL.getStringOrNull(reader, 7);
                    hay = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return hay;
        }

    }
}
