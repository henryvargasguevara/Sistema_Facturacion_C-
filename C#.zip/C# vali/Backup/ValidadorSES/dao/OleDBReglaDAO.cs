﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using System.Data.OleDb;

namespace ValidadorSES.dao
{
    public class OleDBReglaDAO
    {
        public List<ObjetoView> getListaObjetoWithListaReglaByTipoObjeto(string tipoObjeto, string tipoValidacion)
        {
            List<ObjetoView> lista = new List<ObjetoView>();
            //SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            OleDbConnection conexion = ConexionOleDB.getOleDBConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT obj.[codigo_objeto]";
                sql += " ,obj.[OleType]";
                sql += " ,obj.[type_objeto]";
                sql += " ,obj.[nombre]";
                sql += " ,obj.[prefijo]";
                sql += " FROM [OBJETO] obj";
                sql += " WHERE obj.[estado] = '1' AND obj.clasificacion = @param";

                //SqlCommand commmand = new SqlCommand(sql, conexion);
                OleDbCommand commmand = new OleDbCommand(sql, conexion);

                //commmand.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipoObjeto);
                commmand.Parameters.Add("@param", OleDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipoObjeto);


                //SqlDataReader reader = commmand.ExecuteReader();
                OleDbDataReader reader = commmand.ExecuteReader();
                while (reader.Read())
                {
                    ObjetoView ov = new ObjetoView();
                    ov.codigoObjeto = UtilOleDB.getStringOrNullOle(reader, 0);
                    ov.oletype = UtilOleDB.getStringOrNullOle(reader, 1);
                    ov.type = UtilOleDB.getStringOrNullOle(reader, 2);
                    ov.nombre = UtilOleDB.getStringOrNullOle(reader, 3);
                    ov.prefijo = UtilOleDB.getStringOrNullOle(reader, 4);
                    ov.listaObjetoRegla = new List<ObjetoReglaView>();

                    lista.Add(ov);
                }

                reader.Close();

                for (int i = 0; i < lista.Count; i++)
                {
                    ObjetoView ov = lista[i];
                    List<ObjetoReglaView> listaRV = ov.listaObjetoRegla;

                    string sqlRegla = "SELECT reg.codigo_regla";
                    sqlRegla += " ,objReg.codigo_objeto_regla";
                    sqlRegla += " ,obj.codigo_objeto";
                    sqlRegla += " ,reg.nombre";
                    sqlRegla += " FROM (([OBJETO] obj";
                    sqlRegla += " INNER JOIN [OBJETO_REGLA] objReg";
                    sqlRegla += " ON obj.codigo_objeto = objReg.codigo_objeto)";
                    sqlRegla += " INNER JOIN REGLA reg";
                    sqlRegla += " ON objReg.codigo_regla = reg.codigo_regla)";
                    sqlRegla += " WHERE obj.[codigo_objeto] = @param and objReg.estado = '1' and reg.estado = '1'";
                    if (tipoValidacion == "E")
                    {
                        sqlRegla += " and reg.[estado_express] = 'S'";
                    }
                    else
                    {
                        sqlRegla += " and reg.[estado_full] = 'S'";
                    }

                    //SqlCommand cmdRegla = new SqlCommand(sqlRegla, conexion);
                    OleDbCommand cmdRegla = new OleDbCommand(sqlRegla, conexion);

                    //cmdRegla.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(ov.codigoObjeto);
                    cmdRegla.Parameters.Add("@param", OleDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(ov.codigoObjeto);

                    //SqlDataReader readerRegla = cmdRegla.ExecuteReader();
                    OleDbDataReader readerRegla = cmdRegla.ExecuteReader();

                    while (readerRegla.Read())
                    {

                        ObjetoReglaView orv = new ObjetoReglaView();
                        //orv.codigoRegla = UtilSQL.getIntOrNullOle(readerRegla, 0);
                        orv.codigoRegla = int.Parse(readerRegla["codigo_regla"].ToString());
                        orv.codigoObjetoRegla = UtilOleDB.getStringOrNullOle(readerRegla, 1);
                        orv.codigoObjeto = UtilOleDB.getStringOrNullOle(readerRegla, 2);
                        orv.nombreRegla = UtilOleDB.getStringOrNullOle(readerRegla, 3);

                        listaRV.Add(orv);


                    }

                    readerRegla.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

    }
}
