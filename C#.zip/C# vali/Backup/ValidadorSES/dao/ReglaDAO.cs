﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;

namespace ValidadorSES.dao
{
    public class ReglaDAO
    {
        public void insertarRegla(Regla regla)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[REGLA]";
                sql += "([nombre]";
                sql += ",[descripcion]";
                sql += ",[estado]";
                sql += ",[usuario_creador]";//5
                sql += ",[fecha_creacion]";
                sql += ",[usuario_modificador]";
                sql += ",[fecha_modificacion]";
                sql += ",[tipo_objeto]";
                sql += ",[estado_full]";
                sql += ",[estado_express]";
                sql += ",[sugerencia])";
                sql += "VALUES";
                sql += "(@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.nombre);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.descripcion);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estado);
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(regla.usuarioCreador);
                cmd.Parameters.Add("@param6", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(regla.fechaCreacion);
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(null);
                cmd.Parameters.Add("@param8", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(null);
                cmd.Parameters.Add("@param9", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.tipoObjeto);
                cmd.Parameters.Add("@param10", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estadoFull);
                cmd.Parameters.Add("@param11", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estadoExpress);
                cmd.Parameters.Add("@param12", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.sugerencia);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<ReglaView> getListaReglaView()
        {
            List<ReglaView> lista = new List<ReglaView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_regla]";
                sql += ",[nombre]";
                sql += ",[descripcion]";
                sql += ",det_est.nombre_Detalle_Maestro as [estado]";
                sql += ",usu_crea.nombres_Usuario + ' ' + usu_crea.apellidos_usuario  as [usuario_creador]";
                sql += ",reg.[fecha_creacion]";
                sql += ",usu_mod.nombres_Usuario + ' ' + usu_mod.apellidos_usuario  as [usuario_modificador]";
                sql += ",reg.[fecha_modificacion]";
                sql += ",det_est_full.nombre_Detalle_Maestro as [estado_full]";
                sql += ",det_est_express.nombre_Detalle_Maestro as [estado_express]";
                sql += ",det_tip_obj.nombre_Detalle_Maestro as [tipo_objeto]";
                sql += ",[sugerencia]";

                sql += " FROM [dbo].[REGLA] reg";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_crea";
                sql += " ON usu_crea.codigo_Usuario = reg.usuario_creador";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_mod";
                sql += " ON usu_mod.codigo_Usuario = reg.usuario_modificador";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est";
                sql += " ON det_est.codigo_Maestro = 6 AND reg.estado = det_est.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est_full";
                sql += " ON det_est_full.codigo_Maestro = 7 AND reg.estado_full = det_est_full.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est_express";
                sql += " ON det_est_express.codigo_Maestro = 8 AND reg.estado_express = det_est_express.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_tip_obj";
                sql += " ON det_tip_obj.codigo_Maestro = 1 AND reg.tipo_objeto = det_tip_obj.valor_key";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    ReglaView rv = new ReglaView();
                    rv.codigoRegla = UtilSQL.getIntOrNull(reader, 0);
                    rv.nombre = UtilSQL.getStringOrNull(reader, 1);
                    rv.descripcion = UtilSQL.getStringOrNull(reader, 2);
                    rv.estado = UtilSQL.getStringOrNull(reader, 3);
                    rv.usuarioCreador = UtilSQL.getStringOrNull(reader, 4);
                    rv.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    rv.usuarioModificador = UtilSQL.getStringOrNull(reader, 6);
                    rv.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 7);
                    rv.estadoFull = UtilSQL.getStringOrNull(reader, 8);
                    rv.estadoExpress = UtilSQL.getStringOrNull(reader, 9);
                    rv.tipoObjeto = UtilSQL.getStringOrNull(reader, 10);
                    rv.sugerencia = UtilSQL.getStringOrNull(reader, 11);

                    lista.Add(rv);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public ReglaView getReglaViewByCodigo(int codigo)
        {
            ReglaView rv = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT TOP 1[codigo_regla]";
                sql += ",[nombre]";
                sql += ",[descripcion]";
                sql += ",det_est.nombre_Detalle_Maestro as [estado]";
                sql += ",det_est_full.nombre_Detalle_Maestro as [estado_full]";
                sql += ",det_est_express.nombre_Detalle_Maestro as [estado_express]";
                sql += ",det_tip_obj.nombre_Detalle_Maestro as [tipo_objeto]";
                sql += ",[sugerencia]";
                
                sql += " FROM [dbo].[REGLA] reg";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est";
                sql += " ON det_est.codigo_Maestro = 6 AND reg.estado = det_est.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est_full";
                sql += " ON det_est_full.codigo_Maestro = 7 AND reg.estado_full = det_est_full.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est_express";
                sql += " ON det_est_express.codigo_Maestro = 8 AND reg.estado_express = det_est_express.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_tip_obj";
                sql += " ON det_tip_obj.codigo_Maestro = 1 AND reg.tipo_objeto = det_tip_obj.valor_key";

                sql += " WHERE [codigo_regla] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(codigo);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    rv = new ReglaView();
                    rv.codigoRegla = UtilSQL.getIntOrNull(reader, 0);
                    rv.nombre = UtilSQL.getStringOrNull(reader, 1);
                    rv.descripcion = UtilSQL.getStringOrNull(reader, 2);
                    rv.estado = UtilSQL.getStringOrNull(reader, 3);
                    rv.estadoFull = UtilSQL.getStringOrNull(reader, 4);
                    rv.estadoExpress = UtilSQL.getStringOrNull(reader, 5);
                    rv.tipoObjeto = UtilSQL.getStringOrNull(reader, 6);
                    rv.sugerencia = UtilSQL.getStringOrNull(reader, 7);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return rv;
        }

        public ReglaView getReglaViewByNombreAndTipo(string nombre, string tipo)
        {
            ReglaView rv = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT TOP 1[codigo_regla]";
                sql += ",[nombre]";
                sql += ",[descripcion]";
                sql += ",det_est.nombre_Detalle_Maestro as [estado]";
                sql += ",usu_crea.nombres_Usuario + ' ' + usu_crea.apellidos_usuario  as [usuario_creador]";
                sql += ",reg.[fecha_creacion]";
                sql += ",usu_mod.nombres_Usuario + ' ' + usu_mod.apellidos_usuario  as [usuario_modificador]";
                sql += ",reg.[fecha_modificacion]";
                sql += ",[sugerencia]";

                sql += " FROM [dbo].[REGLA] reg";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_crea";
                sql += " ON usu_crea.codigo_Usuario = reg.usuario_creador";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_mod";
                sql += " ON usu_mod.codigo_Usuario = reg.usuario_modificador";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est";
                sql += " ON det_est.codigo_Maestro = 6 AND reg.estado = det_est.valor_key";

                sql += " WHERE upper([nombre]) = @param1 and [tipo_objeto] = @param2";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = nombre.ToUpper();
                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(nombre);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipo);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    rv = new ReglaView();
                    rv.codigoRegla = UtilSQL.getIntOrNull(reader, 0);
                    rv.nombre = UtilSQL.getStringOrNull(reader, 1);
                    rv.descripcion = UtilSQL.getStringOrNull(reader, 2);
                    rv.estado = UtilSQL.getStringOrNull(reader, 3);
                    rv.usuarioCreador = UtilSQL.getStringOrNull(reader, 4);
                    rv.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    rv.usuarioModificador = UtilSQL.getStringOrNull(reader, 6);
                    rv.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 7);
                    rv.sugerencia = UtilSQL.getStringOrNull(reader, 8);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return rv;
        }

        public List<ReglaView> getListaReglaViewByKeyWord(string b)
        {
            List<ReglaView> lista = new List<ReglaView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_regla]";
                sql += ",[nombre]";
                sql += ",[descripcion]";
                sql += ",det_est.nombre_Detalle_Maestro as [estado]";
                sql += ",usu_crea.nombres_Usuario + ' ' + usu_crea.apellidos_usuario  as [usuario_creador]";
                sql += ",reg.[fecha_creacion]";
                sql += ",usu_mod.nombres_Usuario + ' ' + usu_mod.apellidos_usuario  as [usuario_modificador]";
                sql += ",reg.[fecha_modificacion]";
                sql += ",det_est_full.nombre_Detalle_Maestro as [estado_full]";
                sql += ",det_est_express.nombre_Detalle_Maestro as [estado_express]";
                sql += ",det_tip_obj.nombre_Detalle_Maestro as [tipo_objeto]";
                sql += ",[sugerencia]";

                sql += " FROM [dbo].[REGLA] reg";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_crea";
                sql += " ON usu_crea.codigo_Usuario = reg.usuario_creador";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_mod";
                sql += " ON usu_mod.codigo_Usuario = reg.usuario_modificador";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est";
                sql += " ON det_est.codigo_Maestro = 6 AND reg.estado = det_est.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est_full";
                sql += " ON det_est_full.codigo_Maestro = 7 AND reg.estado_full = det_est_full.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est_express";
                sql += " ON det_est_express.codigo_Maestro = 8 AND reg.estado_express = det_est_express.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_tip_obj";
                sql += " ON det_tip_obj.codigo_Maestro = 1 AND reg.tipo_objeto = det_tip_obj.valor_key";

                sql += " WHERE [codigo_regla] like '%'+ @param + '%'";
                sql += " or [nombre] like '%'+ @param + '%'";
                sql += " or [descripcion] like '%'+ @param + '%'";
                sql += " or [sugerencia] like '%'+ @param + '%'";
                sql += " or det_est.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " ESCAPE '\\'";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = b;
                buscar = buscar.Replace("_", "\\_");
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ReglaView rv = new ReglaView();
                    rv.codigoRegla = UtilSQL.getIntOrNull(reader, 0);
                    rv.nombre = UtilSQL.getStringOrNull(reader, 1);
                    rv.descripcion = UtilSQL.getStringOrNull(reader, 2);
                    rv.estado = UtilSQL.getStringOrNull(reader, 3);
                    rv.usuarioCreador = UtilSQL.getStringOrNull(reader, 4);
                    rv.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    rv.usuarioModificador = UtilSQL.getStringOrNull(reader, 6);
                    rv.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 7);
                    rv.estadoFull = UtilSQL.getStringOrNull(reader, 8);
                    rv.estadoExpress = UtilSQL.getStringOrNull(reader, 9);
                    rv.tipoObjeto = UtilSQL.getStringOrNull(reader, 10);
                    rv.sugerencia = UtilSQL.getStringOrNull(reader, 11);

                    lista.Add(rv);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public void actualizarRegla(Regla regla)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[REGLA] SET ";
                //sql += "[codigo_regla] = @param1";//1
                sql += "[nombre] = @param2";
                sql += ",[descripcion] = @param3";
                sql += ",[estado] = @param4";
                sql += ",[usuario_modificador] = @param7";
                sql += ",[fecha_modificacion] = @param8";
                sql += ",[estado_full] = @param9";
                sql += ",[estado_express] = @param10";
                sql += ",[sugerencia] = @param11";
                sql += " WHERE [codigo_regla] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.codigoRegla);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.nombre);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.descripcion);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estado);
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(regla.usuarioModificador);
                cmd.Parameters.Add("@param8", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(regla.fechaModificacion);
                cmd.Parameters.Add("@param9", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estadoFull);
                cmd.Parameters.Add("@param10", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estadoExpress);
                cmd.Parameters.Add("@param11", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.sugerencia);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void actualizarListaReglaExpress(List<Regla> listaRegla)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();


                for (int i = 0; i < listaRegla.Count; i++)
                {
                    Regla regla = listaRegla[i];
                    
                    string sql = "UPDATE [dbo].[REGLA] SET ";
                    //sql += "[codigo_regla] = @param1";//1
                    sql += " [estado_express] = @param2";
                    sql += ",[usuario_modificador] = @param3";
                    sql += ",[fecha_modificacion] = @param4";
                    sql += " WHERE [codigo_regla] = @param1";

                    SqlCommand cmd = new SqlCommand(sql, conexion);

                    cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.codigoRegla);
                    cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estadoExpress);
                    cmd.Parameters.Add("@param3", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(regla.usuarioModificador);
                    cmd.Parameters.Add("@param4", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(regla.fechaModificacion);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void actualizarListaReglaFull(List<Regla> listaRegla)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                for (int i = 0; i<listaRegla.Count; i++)
                {
                    Regla regla = listaRegla[i];

                    string sql = "UPDATE [dbo].[REGLA] SET ";
                    //sql += "[codigo_regla] = @param1";//1
                    sql += " [estado_full] = @param2";
                    sql += ",[usuario_modificador] = @param3";
                    sql += ",[fecha_modificacion] = @param4";
                    sql += " WHERE [codigo_regla] = @param1";

                    SqlCommand cmd = new SqlCommand(sql, conexion);

                    cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.codigoRegla);
                    cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(regla.estadoFull);
                    cmd.Parameters.Add("@param3", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(regla.usuarioModificador);
                    cmd.Parameters.Add("@param4", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(regla.fechaModificacion);

                    cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<ReglaView> getListaReglaViewSimpleByTipoObjeto(string tipo)
        {
            List<ReglaView> lista = new List<ReglaView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_regla]";
                sql += ",[nombre]";
                sql += ",[estado_full]";
                sql += ",[estado_express]";
                sql += " FROM [dbo].[REGLA]";
                sql += " WHERE [estado] = '1' AND [tipo_objeto] = @param";
                SqlCommand commmand = new SqlCommand(sql, conexion);
                commmand.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipo);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    ReglaView rv = new ReglaView();
                    rv.codigoRegla = UtilSQL.getIntOrNull(reader, 0);
                    rv.nombre = UtilSQL.getStringOrNull(reader, 1);
                    rv.estadoFull = UtilSQL.getStringOrNull(reader, 2);
                    rv.estadoExpress = UtilSQL.getStringOrNull(reader, 3);

                    lista.Add(rv);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<ReglaView> getListaReglaViewSimple()
        {
            List<ReglaView> lista = new List<ReglaView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_regla]";
                sql += ",[nombre]";
                sql += ",[estado_full]";
                sql += ",[estado_express]";
                sql += " FROM [dbo].[REGLA]";
                sql += " WHERE [estado] = '1' ";
                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    ReglaView rv = new ReglaView();
                    rv.codigoRegla = UtilSQL.getIntOrNull(reader, 0);
                    rv.nombre = UtilSQL.getStringOrNull(reader, 1);
                    rv.estadoFull = UtilSQL.getStringOrNull(reader, 2);
                    rv.estadoExpress = UtilSQL.getStringOrNull(reader, 3);

                    lista.Add(rv);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<ObjetoView> getListaObjetoWithListaReglaByTipoObjeto(string tipoObjeto, string tipoValidacion)
        {
            List<ObjetoView> lista = new List<ObjetoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            
            try
            {
                conexion.Open();
                string sql = "SELECT obj.[codigo_objeto]";
                sql += " ,obj.[OleType]";
                sql += " ,obj.[type_objeto]";
                sql += " ,obj.[nombre]";
                sql += " ,obj.[prefijo]";
                sql += " FROM [dbo].[OBJETO] obj";
                sql += " WHERE obj.[estado] = '1' AND obj.clasificacion = @param";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                commmand.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipoObjeto);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    ObjetoView ov = new ObjetoView();
                    ov.codigoObjeto = UtilSQL.getStringOrNull(reader, 0);
                    ov.oletype = UtilSQL.getStringOrNull(reader, 1);
                    ov.type = UtilSQL.getStringOrNull(reader, 2);
                    ov.nombre = UtilSQL.getStringOrNull(reader, 3);
                    ov.prefijo = UtilSQL.getStringOrNull(reader, 4);
                    ov.listaObjetoRegla = new List<ObjetoReglaView>();

                    lista.Add(ov);
                }

                reader.Close();

                for (int i = 0; i<lista.Count; i++) 
                {
                    ObjetoView ov = lista[i];
                    List<ObjetoReglaView> listaRV = ov.listaObjetoRegla;

                    string sqlRegla = "SELECT reg.codigo_regla";
                    sqlRegla += " ,objReg.codigo_objeto_regla";
                    sqlRegla += " ,obj.codigo_objeto";
                    sqlRegla += " ,reg.nombre";
                    sqlRegla += " FROM [dbo].[OBJETO] obj";
                    sqlRegla += " INNER JOIN [dbo].[OBJETO_REGLA] objReg";
                    sqlRegla += " ON obj.codigo_objeto = objReg.codigo_objeto and objReg.estado = '1'";
                    sqlRegla += " INNER JOIN [dbo].REGLA reg";
                    sqlRegla += " ON objReg.codigo_regla = reg.codigo_regla and reg.estado = '1'";
                    if (tipoValidacion == "E")
                    {
                        sqlRegla += " and reg.[estado_express] = 'S'";
                    }
                    else
                    {
                        sqlRegla += " and reg.[estado_full] = 'S'";
                    }
                    sqlRegla += " WHERE obj.[codigo_objeto] = @param";


                    SqlCommand cmdRegla = new SqlCommand(sqlRegla, conexion);
                    cmdRegla.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(ov.codigoObjeto);
                    SqlDataReader readerRegla = cmdRegla.ExecuteReader();

                    while (readerRegla.Read())
                    {
                        ObjetoReglaView orv = new ObjetoReglaView();
                        orv.codigoRegla = UtilSQL.getIntOrNull(readerRegla, 0);
                        orv.codigoObjetoRegla = UtilSQL.getStringOrNull(readerRegla, 1);
                        orv.codigoObjeto = UtilSQL.getStringOrNull(readerRegla, 2);
                        orv.nombreRegla = UtilSQL.getStringOrNull(readerRegla, 3);

                        listaRV.Add(orv);
                    }

                    readerRegla.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<ReglaView> getListaReglaViewByTipoValidacion(string tipoValidacion)
        {
            List<ReglaView> lista = new List<ReglaView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_regla]";
                sql += ",det_tip_obj.nombre_Detalle_Maestro as [tipo_objeto]";
                sql += ",[nombre]";
                sql += ",[descripcion]";
                sql += ",[sugerencia]";

                sql += " FROM [dbo].[REGLA] reg";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_tip_obj";
                sql += " ON det_tip_obj.codigo_Maestro = 1 AND reg.tipo_objeto = det_tip_obj.valor_key";
                sql += " WHERE reg.estado = '1' and";
                if (tipoValidacion == ConstanteMaestro.COD_TIP_VAL_EXPRESS)
                {
                    sql += " reg.estado_express = 'S' ";
                }
                else
                {
                    sql += " reg.estado_full = 'S' ";
                }

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    ReglaView rv = new ReglaView();
                    rv.codigoRegla = UtilSQL.getIntOrNull(reader, 0);
                    rv.tipoObjeto = UtilSQL.getStringOrNull(reader, 1); 
                    rv.nombre = UtilSQL.getStringOrNull(reader, 2);
                    rv.descripcion = UtilSQL.getStringOrNull(reader, 3);
                    rv.sugerencia = UtilSQL.getStringOrNull(reader, 4);

                    lista.Add(rv);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

    }
}
