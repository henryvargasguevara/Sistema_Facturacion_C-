﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using System.Data.OleDb;

namespace ValidadorSES.dao
{
    public class OleDBObjetoDAO
    {

        public List<string> getListaObjetoViewByOLEType()
        {
            List<string> lista = new List<string>();
            //SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            OleDbConnection conexion = ConexionOleDB.getOleDBConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [OleType]";
                sql += " FROM [OBJETO]";
                sql += " GROUP BY [OleType]";

                //    SqlCommand commmand = new SqlCommand(sql, conexion);
                //    SqlDataReader reader = commmand.ExecuteReader();
                OleDbCommand com = new OleDbCommand(sql, conexion);
                OleDbDataReader reader = com.ExecuteReader();

                while (reader.Read())
                {
                    //        lista.Add(UtilSQL.getStringOrNull(reader, 0));
                    lista.Add(UtilOleDB.getStringOrNullOle(reader, 0));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }
        public List<Objeto> getListaObjetoByJob()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_JOB);
        }

        public List<Objeto> getListaObjetoByStage()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_STAGE);
        }

        public List<Objeto> getListaObjetoByRoutine()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_ROUTINE);
        }

        public List<Objeto> getListaObjetoByArgument()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_ARGUMENT);
        }

        public List<Objeto> getListaObjetoByParameterSet()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_PARAMETER);
        }

        public List<Objeto> getListaObjetoByParam()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_PARAMETER_PARAM);
        }

        private List<Objeto> getListaObjetoByTipo(string tipoObjeto)
        {
            List<Objeto> lista = new List<Objeto>();
            //SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            OleDbConnection conexion = ConexionOleDB.getOleDBConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_objeto]";
                sql += ",[nombre]";
                sql += ",[OleType]";
                sql += ",[type_objeto]";
                sql += ",[prefijo]";
                sql += ",[mnemonico]";
                sql += " FROM [OBJETO]";
                sql += " WHERE [estado] = '1' and [clasificacion] = @param";

                //SqlCommand cmd = new SqlCommand(sql, conexion);
                OleDbCommand com = new OleDbCommand(sql, conexion);

                //cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipoObjeto);
                com.Parameters.Add("@param", OleDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipoObjeto);

                //SqlDataReader reader = cmd.ExecuteReader();
                OleDbDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Objeto obj = new Objeto();

                    obj.codigoObjeto = UtilOleDB.getStringOrNullOle(reader, 0);
                    obj.nombre = UtilOleDB.getStringOrNullOle(reader, 1);
                    obj.oletype = UtilOleDB.getStringOrNullOle(reader, 2);
                    obj.type = UtilOleDB.getStringOrNullOle(reader, 3);
                    obj.prefijo = UtilOleDB.getStringOrNullOle(reader, 4);
                    obj.mnemonico = UtilOleDB.getStringOrNullOle(reader, 5);

                    lista.Add(obj);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

    }
}
