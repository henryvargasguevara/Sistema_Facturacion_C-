﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;

namespace ValidadorSES.dao
{
    public class ObjetoDAO
    {
        public void insertarObjeto(Objeto obj) 
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[OBJETO]";
                sql += "([codigo_objeto]";//1
                sql += ",[type_objeto]";
                sql += ",[clasificacion]";
                sql += ",[nombre]";
                sql += ",[OleType]";
                sql += ",[prefijo]";//5
                sql += ",[estado]";
                sql += ",[descripcion]";
                sql += ",[mnemonico]";
                sql += ",[fecha_creacion]";
                sql += ",[fecha_modificacion]";//10
                sql += ",[usuario_creador]";
                sql += ",[usuario_modificador])";
                sql += "VALUES";
                sql += "(@param0";
                sql += ",@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param0", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.codigoObjeto);
                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.type);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.clasificacion);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.nombre);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.oletype);
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.prefijo);
                cmd.Parameters.Add("@param6", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.estado);
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.descripcion);
                cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.mnemonico);
                cmd.Parameters.Add("@param9", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(obj.fechaCreacion);
                cmd.Parameters.Add("@param10", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(null);
                cmd.Parameters.Add("@param11", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.usuarioCreador);
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(null);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<ObjetoView> getListaObjetoView() 
        {
            List<ObjetoView> lista = new List<ObjetoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_objeto]";
                sql += ",[type_objeto]";
                sql += ",det_clas.nombre_Detalle_Maestro as [clasificacion]";
                sql += ",[nombre]";
                sql += ",[OleType]";
                sql += ",[prefijo]";
                sql += ",det_est.nombre_Detalle_Maestro as [estado]";
                sql += ",[descripcion]";
                sql += ",[mnemonico]";
                sql += ",obj.[fecha_creacion]";
                sql += ",obj.[fecha_modificacion]";
                sql += ",usu_crea.nombres_Usuario + ' ' + usu_crea.apellidos_usuario  as [usuario_creador]";
                sql += ",usu_mod.nombres_Usuario + ' ' + usu_mod.apellidos_usuario  as [usuario_modificador]";

                sql += " FROM [dbo].[OBJETO] obj";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_crea";
                sql += " ON usu_crea.codigo_Usuario = obj.usuario_creador";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_mod";
                sql += " ON usu_mod.codigo_Usuario = obj.usuario_modificador";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_clas";
                sql += " ON det_clas.codigo_Maestro = 1 AND obj.[clasificacion] = det_clas.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est";
                sql += " ON det_est.codigo_Maestro = 4 AND obj.estado = det_est.valor_key";

                sql += " ORDER BY [clasificacion],[nombre]"; 

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    ObjetoView ov = new ObjetoView();
                    ov.codigoObjeto = UtilSQL.getStringOrNull(reader, 0);
                    ov.type = UtilSQL.getStringOrNull(reader, 1);
                    ov.clasificacion = UtilSQL.getStringOrNull(reader, 2);
                    ov.nombre = UtilSQL.getStringOrNull(reader, 3);
                    ov.oletype = UtilSQL.getStringOrNull(reader, 4);
                    ov.prefijo = UtilSQL.getStringOrNull(reader, 5);
                    ov.estado = UtilSQL.getStringOrNull(reader, 6);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 7);
                    ov.mnemonico = UtilSQL.getStringOrNull(reader, 8);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 9);
                    ov.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 10);
                    ov.usuarioCreador = UtilSQL.getStringOrNull(reader, 11);
                    ov.usuarioModificador = UtilSQL.getStringOrNull(reader, 12);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public ObjetoView getObjetoViewByCodigoObjeto(string codigoObjeto) 
        {
            ObjetoView ov = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT TOP 1 [codigo_objeto]";
                sql += ",[type_objeto]";
                sql += ",det_clas.nombre_Detalle_Maestro as [clasificacion]";
                sql += ",[nombre]";
                sql += ",[OleType]";
                sql += ",[prefijo]";
                sql += ",det_est.nombre_Detalle_Maestro as [estado]";
                sql += ",[descripcion]";
                sql += ",[mnemonico]";
                sql += ",obj.[fecha_creacion]";
                sql += ",obj.[fecha_modificacion]";
                sql += ",usu_crea.nombres_Usuario + ' ' + usu_crea.apellidos_usuario  as [usuario_creador]";
                sql += ",usu_mod.nombres_Usuario + ' ' + usu_mod.apellidos_usuario  as [usuario_modificador]";

                sql += " FROM [dbo].[OBJETO] obj";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_crea";
                sql += " ON usu_crea.codigo_Usuario = obj.usuario_creador";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_mod";
                sql += " ON usu_mod.codigo_Usuario = obj.usuario_modificador";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_clas";
                sql += " ON det_clas.codigo_Maestro = 1 AND obj.[clasificacion] = det_clas.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est";
                sql += " ON det_est.codigo_Maestro = 4 AND obj.estado = det_est.valor_key";

                sql += " WHERE [codigo_objeto] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = codigoObjeto.ToUpper();
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ov = new ObjetoView();
                    ov.codigoObjeto = UtilSQL.getStringOrNull(reader, 0);
                    ov.type = UtilSQL.getStringOrNull(reader, 1);
                    ov.clasificacion = UtilSQL.getStringOrNull(reader, 2);
                    ov.nombre = UtilSQL.getStringOrNull(reader, 3);
                    ov.oletype = UtilSQL.getStringOrNull(reader, 4);
                    ov.prefijo = UtilSQL.getStringOrNull(reader, 5);
                    ov.estado = UtilSQL.getStringOrNull(reader, 6);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 7);
                    ov.mnemonico = UtilSQL.getStringOrNull(reader, 8);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 9);
                    ov.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 10);
                    ov.usuarioCreador = UtilSQL.getStringOrNull(reader, 11);
                    ov.usuarioModificador = UtilSQL.getStringOrNull(reader, 12);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return ov;
        }

        public List<ObjetoView> getListaObjetoViewByKeyWord(string b)
        {
            List<ObjetoView> lista = new List<ObjetoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_objeto]";
                sql += ",[type_objeto]";
                sql += ",det_clas.nombre_Detalle_Maestro as [clasificacion]";
                sql += ",[nombre]";
                sql += ",[OleType]";
                sql += ",[prefijo]";
                sql += ",det_est.nombre_Detalle_Maestro as [estado]";
                sql += ",[descripcion]";
                sql += ",[mnemonico]";
                sql += ",obj.[fecha_creacion]";
                sql += ",obj.[fecha_modificacion]";
                sql += ",usu_crea.nombres_Usuario + ' ' + usu_crea.apellidos_usuario  as [usuario_creador]";
                sql += ",usu_mod.nombres_Usuario + ' ' + usu_mod.apellidos_usuario  as [usuario_modificador]";

                sql += " FROM [dbo].[OBJETO] obj";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_crea";
                sql += " ON usu_crea.codigo_Usuario = obj.usuario_creador";
                sql += " LEFT JOIN [dbo].[USUARIO] usu_mod";
                sql += " ON usu_mod.codigo_Usuario = obj.usuario_modificador";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_clas";
                sql += " ON det_clas.codigo_Maestro = 1 AND obj.[clasificacion] = det_clas.valor_key";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_est";
                sql += " ON det_est.codigo_Maestro = 4 AND obj.estado = det_est.valor_key";

                sql += " WHERE [type_objeto] like '%'+ @param + '%'";
                sql += " or [nombre] like '%'+ @param + '%'";
                sql += " or [OleType] like '%'+ @param + '%'";
                sql += " or [prefijo] like '%'+ @param + '%'";
                sql += " or [descripcion] like '%'+ @param + '%'";
                sql += " or [mnemonico] like '%'+ @param + '%'";
                sql += " ESCAPE '\\'";

                sql += " ORDER BY [clasificacion],[nombre]";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = b;
                buscar = buscar.Replace("_", "\\_");
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ObjetoView ov = new ObjetoView();
                    ov.codigoObjeto = UtilSQL.getStringOrNull(reader, 0);
                    ov.type = UtilSQL.getStringOrNull(reader, 1);
                    ov.clasificacion = UtilSQL.getStringOrNull(reader, 2);
                    ov.nombre = UtilSQL.getStringOrNull(reader, 3);
                    ov.oletype = UtilSQL.getStringOrNull(reader, 4);
                    ov.prefijo = UtilSQL.getStringOrNull(reader, 5);
                    ov.estado = UtilSQL.getStringOrNull(reader, 6);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 7);
                    ov.mnemonico = UtilSQL.getStringOrNull(reader, 8);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 9);
                    ov.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 10);
                    ov.usuarioCreador = UtilSQL.getStringOrNull(reader, 11);
                    ov.usuarioModificador = UtilSQL.getStringOrNull(reader, 12);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }
        
        public void actualizarObjeto(Objeto obj)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[OBJETO] SET ";
                //sql += "[type_objeto] = @param1";//1
                sql += "[clasificacion] = @param2";
                sql += ",[nombre] = @param3";
                //sql += ",[OleType] = @param4";
                sql += ",[prefijo] = @param5";//5
                sql += ",[estado] = @param6";
                sql += ",[descripcion] = @param7";
                sql += ",[mnemonico] = @param8";
                sql += ",[fecha_modificacion] = @param10";//10
                sql += ",[usuario_modificador] = @param12";
                sql += " WHERE [codigo_objeto] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.codigoObjeto);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.clasificacion);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.nombre);
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.prefijo);
                cmd.Parameters.Add("@param6", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.estado);
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.descripcion);
                cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.mnemonico);
                cmd.Parameters.Add("@param10", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(obj.fechaModificacion);
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.usuarioModificador);

                cmd.ExecuteNonQuery();

                if (obj.estado == "2")
                {
                    //actualizar lista de ObjetoRegla cuando es Inactivo, setear Deshabilitado
                    string sqlUpdate = "UPDATE [dbo].[OBJETO_REGLA] SET";
                    sqlUpdate += " [estado] = @param2";
                    sqlUpdate += ",[usuario_modificador] = @param3";
                    sqlUpdate += ",[fecha_modificacion] = @param4";
                    sqlUpdate += " WHERE [codigo_objeto] = @param1";

                    SqlCommand cmdUpdate = new SqlCommand(sqlUpdate, conexion);

                    cmdUpdate.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.codigoObjeto);
                    cmdUpdate.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull('3');
                    cmdUpdate.Parameters.Add("@param3", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.usuarioModificador);
                    cmdUpdate.Parameters.Add("@param4", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(obj.fechaModificacion);

                    cmdUpdate.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<ObjetoView> getListaObjetoViewSimple()
        {
            List<ObjetoView> lista = new List<ObjetoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_objeto]";
                sql += ",[type_objeto]";
                sql += ",det_clas.nombre_Detalle_Maestro as [clasificacion]";
                sql += ",[nombre]";

                sql += " FROM [dbo].[OBJETO] obj";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_clas";
                sql += " ON det_clas.codigo_Maestro = 1 AND obj.[clasificacion] = det_clas.valor_key";
                sql += " WHERE [estado] = '1'";
                sql += " ORDER BY [clasificacion],[nombre]"; 

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    ObjetoView ov = new ObjetoView();
                    ov.codigoObjeto = UtilSQL.getStringOrNull(reader, 0);
                    ov.type = UtilSQL.getStringOrNull(reader, 1);
                    ov.clasificacion = UtilSQL.getStringOrNull(reader, 2);
                    ov.nombre = UtilSQL.getStringOrNull(reader, 3);
                    ov.clasificacionAndType = ov.clasificacion + " | " + ov.nombre;

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<string> getListaObjetoViewByOLEType()
        {
            List<string> lista = new List<string>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [OleType]";
                sql += " FROM [dbo].[OBJETO]";
                sql += " GROUP BY [OleType]";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(UtilSQL.getStringOrNull(reader, 0));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<Objeto> getListaObjetoByJob() 
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_JOB);
        }

        public List<Objeto> getListaObjetoByStage()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_STAGE);
        }

        public List<Objeto> getListaObjetoByRoutine()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_ROUTINE);
        }

        public List<Objeto> getListaObjetoByArgument()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_ARGUMENT);
        }

        public List<Objeto> getListaObjetoByParameterSet()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_PARAMETER);
        }

        public List<Objeto> getListaObjetoByParam()
        {
            return getListaObjetoByTipo(ConstanteMaestro.COD_CLASF_OBJ_PARAMETER_PARAM);
        }

        private List<Objeto> getListaObjetoByTipo(string tipoObjeto)
        {
            List<Objeto> lista = new List<Objeto>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_objeto]";
                sql += ",[nombre]";
                sql += ",[OleType]";
                sql += ",[type_objeto]";
                sql += ",[prefijo]";
                sql += ",[mnemonico]";
                sql += " FROM [dbo].[OBJETO]";
                sql += " WHERE [estado] = '1' and [clasificacion] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipoObjeto);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Objeto obj = new Objeto();

                    obj.codigoObjeto = UtilSQL.getStringOrNull(reader, 0);
                    obj.nombre = UtilSQL.getStringOrNull(reader, 1);
                    obj.oletype = UtilSQL.getStringOrNull(reader, 2);
                    obj.type = UtilSQL.getStringOrNull(reader, 3);                    
                    obj.prefijo = UtilSQL.getStringOrNull(reader, 4);
                    obj.mnemonico = UtilSQL.getStringOrNull(reader, 5);

                    lista.Add(obj);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<Objeto> getListaObjetoStage()
        {
            List<Objeto> lista = new List<Objeto>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [nombre]";
                sql += " FROM [dbo].[OBJETO]";
                sql += " WHERE [estado] = '1' and [clasificacion] = @param";
                sql += " GROUP BY [nombre]";
                sql += " ORDER BY [nombre]";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(ConstanteMaestro.COD_CLASF_OBJ_STAGE);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Objeto obj = new Objeto();

                    obj.nombre = UtilSQL.getStringOrNull(reader, 0);

                    lista.Add(obj);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }
    }
}
