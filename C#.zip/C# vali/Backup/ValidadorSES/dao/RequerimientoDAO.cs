﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.dao;
using System.Data.SqlClient;
using System.Data;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.dao
{
    class RequerimientoDAO
    {

        public void insertarRequerimiento(Requerimiento requered)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[REQUERIMIENTO]";
                sql += "([codigo]";//1
                sql += ",[cliente]";
                sql += ",[num_pase]";
                sql += ",[descripcion]";
                sql += ",[fecha_inicio]";
                sql += ",[fecha_fin]";
                sql += ",[estado]";
                sql += ",[usuario_creador]";
                sql += ",[fecha_creacion]";
                sql += ",[usuario_modificador]";
                sql += ",[fecha_modificacion]";//11
                sql += ",[liderResponsable]";//12
                sql += ",[prioridad]";//13
                sql += ",[tipoValidacion]";//14
                sql += ",[tipoCargaJob])";//15
                sql += "VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ",@param13";
                sql += ",@param14";
                sql += ",@param15";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = requered.codigo;
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = requered.cliente;
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = requered.num_pase;
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = requered.descripcion;
                cmd.Parameters.Add("@param5", SqlDbType.DateTime).Value = requered.fecha_inicio;
                cmd.Parameters.Add("@param6", SqlDbType.DateTime).Value = requered.fecha_fin;
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = "1";
                cmd.Parameters.Add("@param8", SqlDbType.Int).Value = requered.usuario_creador;
                cmd.Parameters.Add("@param9", SqlDbType.DateTime).Value = requered.fecha_creacion;
                cmd.Parameters.Add("@param10", SqlDbType.Int).Value = DBNull.Value;
                cmd.Parameters.Add("@param11", SqlDbType.DateTime).Value = DBNull.Value;
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = requered.liderResponsable;
                cmd.Parameters.Add("@param13", SqlDbType.VarChar).Value = requered.prioridad;
                cmd.Parameters.Add("@param14", SqlDbType.VarChar).Value = requered.tipoValidacion;
                cmd.Parameters.Add("@param15", SqlDbType.VarChar).Value = requered.tipoCargaJob;

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<RequerimientoView> getListaRequerimientoView()
        {
            List<RequerimientoView> lista = new List<RequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select r.codigo,";
                sql += " d.nombre_Detalle_Maestro,";
                sql += " r.num_pase,";
                sql += " r.descripcion,";
                sql += " r.fecha_inicio,";
                sql += " r.fecha_fin,";
                sql += " d2.nombre_Detalle_Maestro,";
                sql += " u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " r.fecha_creacion,";
                sql += " u2.nombres_Usuario+' '+u2.apellidos_usuario,";
                sql += " r.fecha_modificacion,";
                sql += " u3.nombres_Usuario+' '+u3.apellidos_usuario,";
                sql += " d3.nombre_Detalle_Maestro,";
                sql += " d4.nombre_Detalle_Maestro,";
                sql += " d5.nombre_Detalle_Maestro";
                sql += " from dbo.REQUERIMIENTO r";
                sql += " inner join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key = r.cliente and d.codigo_Maestro =10";
                sql += " inner join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key = r.estado and d2.codigo_Maestro=5";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario = r.usuario_creador";
                sql += " left join dbo.USUARIO u2";
                sql += " on u2.codigo_Usuario = r.usuario_modificador";
                sql += " left join dbo.USUARIO u3";
                sql += " on u3.codigo_Usuario = r.liderResponsable";
                sql += " left join dbo.DETALLEMAESTRO d3";
                sql += " on d3.valor_key = r.prioridad and d3.codigo_Maestro = 11";
                sql += " left join dbo.DETALLEMAESTRO d4";
                sql += " on d4.valor_key = r.tipoValidacion and d4.codigo_Maestro = 13";
                sql += " left join dbo.DETALLEMAESTRO d5";
                sql += " on d5.valor_key = r.tipoCargaJob and d5.codigo_Maestro = 15";
                sql += " order by r.fecha_creacion desc";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    RequerimientoView ov = new RequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.cliente = UtilSQL.getStringOrNull(reader, 1);
                    ov.num_pase = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_inicio = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_fin = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado = UtilSQL.getStringOrNull(reader, 6);
                    ov.usuario_creador = UtilSQL.getStringOrNull(reader, 7);
                    ov.fecha_creacion = UtilSQL.getStringDateTimeOrNull(reader, 8);
                    ov.usuario_modificador = UtilSQL.getStringOrNull(reader, 9);
                    ov.fecha_modificacion = UtilSQL.getStringDateTimeOrNull(reader, 10);
                    ov.LiderResponsable = UtilSQL.getStringOrNull(reader, 11);
                    ov.prioridad = UtilSQL.getStringOrNull(reader, 12);
                    ov.tipoValidacion = UtilSQL.getStringOrNull(reader, 13);
                    ov.tipoCargaJob = UtilSQL.getStringOrNull(reader, 14);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public void actualizarRequerimiento(Requerimiento obj)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[REQUERIMIENTO] SET ";
                //sql += "[type_objeto] = @param1";//1
                sql += " [cliente] = @param2";
                sql += ",[num_pase] = @param3";
                sql += ",[descripcion]= @param4";
                sql += ",[fecha_inicio] = @param5";
                sql += ",[fecha_fin] = @param6";
                sql += ",[estado]= @param7";
                sql += ",[fecha_modificacion] = @param8";
                sql += ",[usuario_modificador]= @param9";
                sql += ",[liderResponsable] = @param10";
                sql += ",[prioridad]= @param11";
                sql += ",[tipoValidacion]= @param12";
                sql += ",[tipoCargaJob]= @param13";
                sql += " WHERE [codigo] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.codigo);
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.cliente);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.num_pase);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.descripcion);
                cmd.Parameters.Add("@param5", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(obj.fecha_inicio);
                cmd.Parameters.Add("@param6", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(obj.fecha_fin);
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.estado);
                cmd.Parameters.Add("@param8", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(obj.fecha_modificacion);
                cmd.Parameters.Add("@param9", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.usuario_modificador);
                cmd.Parameters.Add("@param10", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.liderResponsable);
                cmd.Parameters.Add("@param11", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.prioridad);
                cmd.Parameters.Add("@param12", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.tipoValidacion);
                cmd.Parameters.Add("@param13", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.tipoCargaJob);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<RequerimientoView> getBuscarRequerimiento( string cadena)
        {
            List<RequerimientoView> lista = new List<RequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select r.codigo,";
                sql += " d.nombre_Detalle_Maestro,";
                sql += " r.num_pase,";
                sql += " r.descripcion,";
                sql += " r.fecha_inicio,";
                sql += " r.fecha_fin,";
                sql += " d2.nombre_Detalle_Maestro,";
                sql += " u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " r.fecha_creacion,";
                sql += " u2.nombres_Usuario+' '+u2.apellidos_usuario,";
                sql += " r.fecha_modificacion,";
                sql += " u3.nombres_Usuario+' '+u3.apellidos_usuario,";
                sql += " d3.nombre_Detalle_Maestro,";
                sql += " d4.nombre_Detalle_Maestro,";
                sql += " d5.nombre_Detalle_Maestro";
                sql += " from dbo.REQUERIMIENTO r";
                sql += " inner join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key = r.cliente and d.codigo_Maestro =10";
                sql += " inner join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key = r.estado and d2.codigo_Maestro=5";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario = r.usuario_creador";
                sql += " left join dbo.USUARIO u2";
                sql += " on u2.codigo_Usuario = r.usuario_modificador";
                sql += " left join dbo.USUARIO u3";
                sql += " on u3.codigo_Usuario = r.liderResponsable";
                sql += " left join dbo.DETALLEMAESTRO d3";
                sql += "  on d3.valor_key = r.prioridad and d3.codigo_Maestro = 11";
                sql += " left join dbo.DETALLEMAESTRO d4";
                sql += " on d4.valor_key = r.tipoValidacion and d4.codigo_Maestro = 13";
                sql += " left join dbo.DETALLEMAESTRO d5";
                sql += " on d5.valor_key = r.tipoCargaJob and d5.codigo_Maestro = 15";
                sql += " WHERE r.codigo like '%'+ @param + '%'";
                sql += " or d.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " or r.num_pase like '%'+ @param + '%'";
                sql += " or r.descripcion like '%'+ @param + '%'";
                sql += " or d2.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " or d3.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " or d4.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " or d5.nombre_Detalle_Maestro like '%'+ @param + '%'";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = cadena;
                buscar = buscar.Replace("_", "\\_");
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();


                while (reader.Read())
                {
                    RequerimientoView ov = new RequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.cliente = UtilSQL.getStringOrNull(reader, 1);
                    ov.num_pase = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_inicio = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_fin = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado = UtilSQL.getStringOrNull(reader, 6);
                    ov.usuario_creador = UtilSQL.getStringOrNull(reader, 7);
                    ov.fecha_creacion = UtilSQL.getStringDateTimeOrNull(reader, 8);
                    ov.usuario_modificador = UtilSQL.getStringOrNull(reader, 9);
                    ov.fecha_modificacion = UtilSQL.getStringDateTimeOrNull(reader, 10);
                    ov.LiderResponsable = UtilSQL.getStringOrNull(reader, 11);
                    ov.prioridad = UtilSQL.getStringOrNull(reader, 12);
                    ov.tipoValidacion = UtilSQL.getStringOrNull(reader, 13);
                    ov.tipoCargaJob = UtilSQL.getStringOrNull(reader, 14);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }


        public List<RequerimientoView> getListaRequerimientoPorEstado()
        {
            List<RequerimientoView> lista = new List<RequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                 string sql = "select r.codigo,";
                        sql += " r.descripcion";
                        sql += " from dbo.REQUERIMIENTO r";
                        sql += " where estado = 1;";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    RequerimientoView ov = new RequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public void actualizarEstadoRequerimiento(String codReq)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[REQUERIMIENTO] SET ";
                sql += "[estado]= @param2";
                sql += " WHERE [codigo] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codReq);
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = 2;

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void actualizarRequerimientoByArchivoDSX(Requerimiento r)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[REQUERIMIENTO] set";
                sql += " estado = @param1";
                sql += " WHERE codigo = @param2";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(r.estado);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(r.codigo);

                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public RequerimientoView getRequerimientoByCodigo(string codReq)
        {
            RequerimientoView req = new RequerimientoView();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select r.codigo,";
                sql += " r.estado,";
                sql += " r.descripcion";
                sql += " FROM dbo.REQUERIMIENTO r";
                sql += " WHERE codigo = @param";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                commmand.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codReq);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    req = new RequerimientoView();
                    req.codigo = UtilSQL.getStringOrNull(reader, 0);
                    req.estado = UtilSQL.getStringOrNull(reader, 1);
                    req.descripcion = UtilSQL.getStringOrNull(reader, 2);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return req;
        }
    }
}
