﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace ValidadorSES.dao
{
    public class ConexionOleDB
    {
        public static OleDbConnection getOleDBConnection()
        {
            OleDbConnection conn = new OleDbConnection();

            conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data source= D:\BDVALIDADOR_DEV.mdb";

            return conn;
        }
    }
}
