﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;

namespace ValidadorSES.util
{
   public class Singleton
    {
        //propiedad de ejemplo ...
         public Usuario usuario { get; set; }
        //public string Nombre { get; set; }
        //propiedad estática donde se guarda la única instancia de la clase ...
        private static Singleton instance;

        //Constructor por defecto privado para que no se pueda instanciar a menos que se use el metodo de clase "GetInstance" ...
        private Singleton() { }
        //Idem anterior pero con parametro para instancia con valor "Nombre" ...
        private Singleton(Usuario usuario)
        {
            this.usuario= usuario;
        }

        //Metodo estático que devuelve una unica instancia de "Singleton" ...
        public static Singleton GetInstance()
        {
            if (instance == null)
            {
                instance = new Singleton();
            }
            return instance;
        }
        //Metodo estático "sobrecargado" que devuelve una única instancia de "Singleton" ...
        public static Singleton GetInstance(Usuario usuario)
        {
            if (instance == null)
            {
                instance = new Singleton(usuario);
            }
            return instance;
        }

    }
}
