﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.util
{
    class UtilDataStage
    {
        //public List<StageValidator> listaStageReglaValidacion { get; set; }
        //public List<string> listaOLEType { get; set; }
        //public List<RoutineValidator> listaRoutineValidation { get; set; }

        //ROUTINE

        public UtilDataStage()
        {
            //Lista de todos los OLEType que se el algoritmo reconocerá
            //listaOLEType = new List<string>();
            //listaOLEType.Add(OLETYPE_C_JOB_DEFN);
            //listaOLEType.Add(OLETYPE_C_CUSTOM_INPUT);
            //listaOLEType.Add(OLETYPE_C_TRX_INPUT);
            //listaOLEType.Add(OLETYPE_C_CUSTOM_OUTPUT);
            //listaOLEType.Add(OLETYPE_C_TRX_OUTPUT);
            //listaOLEType.Add(OLETYPE_C_CUSTOM_STAGE);
            //listaOLEType.Add(OLETYPE_C_TRANSFORMER_STAGE);

            //listaOLEType.Add(OLETYPE_CJS_ACTIVITY_INPUT);
            //listaOLEType.Add(OLETYPE_CJS_ACTIVITY_OUTPUT);
            //listaOLEType.Add(OLETYPE_CJS_USER_VAR_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_JOB_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_CONDITION);
            //listaOLEType.Add(OLETYPE_CJS_MAIL_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_ROUTINE_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_SEQUENCER);
            //listaOLEType.Add(OLETYPE_CJS_START_LOOP_ACTIVIY);
            //listaOLEType.Add(OLETYPE_CJS_TERMINATOR_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_WAIT_FILE_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_EXEC_CMD_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_END_LOOP_ACTIVITY);
            //listaOLEType.Add(OLETYPE_CJS_EXCEPTION_HANDLER);

            //Lista de todos los Routine
            //listaRoutineValidation = new List<RoutineValidator>();                        
            //listaRoutineValidation.Add(getRoutineValidator(TYPE_ROUTINE_SERVER, DES_ROUTINE_SERVER, PRE_ROUTINE_SERVER));
            //listaRoutineValidation.Add(getRoutineValidator(TYPE_ROUTINE_PARALLEL, DES_ROUTINE_PARALLEL, PRE_ROUTINE_PARALLEL));

            //Lista de todos los Stages
            //listaStageReglaValidacion = new List<StageValidator>();
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_INPUT, TIPO_LINK_INPUT_1, DES_LINK_INPUT_1, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_TRX_INPUT, TIPO_LINK_INPUT_2, DES_LINK_INPUT_2, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_OUTPUT, TIPO_LINK_OUTPUT_1, DES_LINK_OUTPUT_1, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_TRX_OUTPUT, TIPO_LINK_OUTPUT_2, DES_LINK_OUTPUT_2, PRE_LINK));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_INPUT, "", DES_LINK_INPUT_1, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_TRX_INPUT, "", DES_LINK_INPUT_2, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_OUTPUT, "", DES_LINK_OUTPUT_1, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_TRX_OUTPUT, "", DES_LINK_OUTPUT_2, PRE_LINK));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_DATA_SET, DES_DATA_SET, PRE_DATA_SET));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SEQUENTIAL_FILE, DES_SEQUENTIAL_FILE, PRE_SEQUENTIAL_FILE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COMPLEX_FLAT_FILE, DES_COMPLEX_FLAT_FILE, PRE_COMPLEX_FLAT_FILE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_EXTERNAL_SOURCE, DES_EXTERNAL_SOURCE, PRE_EXTERNAL_SOURCE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_EXTERNAL_TARGET, DES_EXTERNAL_TARGET, PRE_EXTERNAL_TARGET));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_FILE_SET, DES_FILE_SET, PRE_FILE_SET));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_LOOKUP_FILE_SET, DES_LOOKUP_FILE_SET, PRE_LOOKUP_FILE_SET));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SAS, DES_SAS, PRE_SAS));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_ZOSFILE, DES_ZOSFILE, PRE_ZOSFILE));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_DB2, DES_DB2, PRE_DB2));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_CLASSIC_FEDERATION, DES_CLASSIC_FEDERATION, PRE_CLASSIC_FEDERATION));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_DISTRIBUTED_TRANSACTION, DES_DISTRIBUTED_TRANSACTION, PRE_DISTRIBUTED_TRANSACTION));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SYBASE_ENTERPRISE, DES_SYBASE_ENTERPRISE, PRE_SYBASE_ENTERPRISE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_TERADATA_CONNECTOR, DES_TERADATA_CONNECTOR, PRE_TERADATA_CONNECTOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_DRS_CONNECTOR, DES_DRS_CONNECTOR, PRE_DRS_CONNECTOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_INFORMIX_ENTERPRISE, DES_INFORMIX_ENTERPRISE, PRE_INFORMIX_ENTERPRISE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_IWAY_ENTERPRISE, DES_IWAY_ENTERPRISE, PRE_IWAY_ENTERPRISE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_NETEZZA_CONNECTOR, DES_NETEZZA_CONNECTOR, PRE_NETEZZA_CONNECTOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_ODBC_CONNECTOR, DES_ODBC_CONNECTOR, PRE_ODBC_CONNECTOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_ORACLE_CONNECTOR, DES_ORACLE_CONNECTOR, PRE_ORACLE_CONNECTOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_REDBRICK_LOAD, DES_REDBRICK_LOAD, PRE_REDBRICK_LOAD));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_STORED_PROCEDURE, DES_STORED_PROCEDURE, PRE_STORED_PROCEDURE));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_DATA_RULES, DES_DATA_RULES, PRE_DATA_RULES));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_INVESTIGATE, DES_INVESTIGATE, PRE_INVESTIGATE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_MATCH_FREQUENCY, DES_MATCH_FREQUENCY, PRE_MATCH_FREQUENCY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_MNS, DES_MNS, PRE_MNS));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_STANDARDIZE, DES_STANDARDIZE, PRE_STANDARDIZE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SURVIVE, DES_SURVIVE, PRE_SURVIVE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SQA, DES_SQA, PRE_SQA));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COLUMN_GENERATOR, DES_COLUMN_GENERATOR, PRE_COLUMN_GENERATOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_HEAD, DES_HEAD, PRE_HEAD));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_PEEK, DES_PEEK, PRE_PEEK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_ROW_GENERATOR, DES_ROW_GENERATOR, PRE_ROW_GENERATOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_TAIL, DES_TAIL, PRE_TAIL));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_WRITE_RANGE_MAP, DES_WRITE_RANGE_MAP, PRE_WRITE_RANGE_MAP));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SAMPLE, DES_SAMPLE, PRE_SAMPLE));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_AGGREGATOR, DES_AGGREGATOR, PRE_AGGREGATOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COPY, DES_COPY, PRE_COPY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_FILTER, DES_FILTER, PRE_FILTER));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_FUNNEL, DES_FUNNEL, PRE_FUNNEL));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_JOIN, DES_JOIN, PRE_JOIN));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_LOOKUP, DES_LOOKUP, PRE_LOOKUP));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_MERGE, DES_MERGE, PRE_MERGE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_MODIFY, DES_MODIFY, PRE_MODIFY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_PIVOT_1, DES_PIVOT_1, PRE_PIVOT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_PIVOT_2, DES_PIVOT_2, PRE_PIVOT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_REMOVE_DUPLICATES, DES_REMOVE_DUPLICATES, PRE_REMOVE_DUPLICATES));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SORT, DES_SORT, PRE_SORT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SURROGATE_KEY_GENERATOR, DES_SURROGATE_KEY_GENERATOR, PRE_SURROGATE_KEY_GENERATOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SWITCH, DES_SWITCH, PRE_SWITCH));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_TRANSFORMER_STAGE, TIPO_TRANSFORMER, DES_TRANSFORMER, PRE_TRANSFORMER));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_BLOOMFILTER, DES_BLOOMFILTER, PRE_BLOOMFILTER));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_CHANGE_APPLY, DES_CHANGE_APPLY, PRE_CHANGE_APPLY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_CHANGE_CAPTURE, DES_CHANGE_CAPTURE, PRE_CHANGE_CAPTURE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_CHECKSUM, DES_CHECKSUM, PRE_CHECKSUM));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COMPARE, DES_COMPARE, PRE_COMPARE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COMPRESS, DES_COMPRESS, PRE_COMPRESS));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_DECOD, DES_DECOD, PRE_DECOD));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_DIFFERENCE, DES_DIFFERENCE, PRE_DIFFERENCE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_ENCODE, DES_ENCODE, PRE_ENCODE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_EXPAND, DES_EXPAND, PRE_EXPAND));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_EXTERNAL_FILTER, DES_EXTERNAL_FILTER, PRE_EXTERNAL_FILTER));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_FTP_ENTERPRISE, DES_FTP_ENTERPRISE, PRE_FTP_ENTERPRISE));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_GENERIC, DES_GENERIC, PRE_GENERIC));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SLOWLY_CHANGING_DIMENSION, DES_SLOWLY_CHANGING_DIMENSION, PRE_SLOWLY_CHANGING_DIMENSION));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_WAVE_GENERATOR, DES_WAVE_GENERATOR, PRE_WAVE_GENERATOR));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COLUMN_EXPORT, DES_COLUMN_EXPORT, PRE_COLUMN_EXPORT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COLUMN_IMPORT, DES_COLUMN_IMPORT, PRE_COLUMN_IMPORT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_COMBINE_RECORDS, DES_COMBINE_RECORDS, PRE_COMBINE_RECORDS));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_MAKE_SUBRECORD, DES_MAKE_SUBRECORD, PRE_MAKE_SUBRECORD));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_PROMOTE_SUBRECORD, DES_PROMOTE_SUBRECORD, PRE_PROMOTE_SUBRECORD));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SPLIT_SUBRECORD, DES_SPLIT_SUBRECORD, PRE_SPLIT_SUBRECORD));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_SPLIT_VECTOR, DES_SPLIT_VECTOR, PRE_SPLIT_VECTOR));

            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_CDC_TRANSACTION, DES_CDC_TRANSACTION, PRE_CDC_TRANSACTION));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_ISD_INPUT, DES_ISD_INPUT, PRE_ISD_INPUT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_ISD_OUTPUT, DES_ISD_OUTPUT, PRE_ISD_OUTPUT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_WEB_SERVICES_CLIENT, DES_WEB_SERVICES_CLIENT, PRE_WEB_SERVICES_CLIENT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_WEB_SERVICES_TRANSFORMER, DES_WEB_SERVICES_TRANSFORMER, PRE_WEB_SERVICES_TRANSFORMER));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_WEBSPHERE_MQ_CONNECTOR, DES_WEBSPHERE_MQ_CONNECTOR, PRE_WEBSPHERE_MQ_CONNECTOR));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_XML_INPUT, DES_XML_INPUT, PRE_XML_INPUT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_XML_OUTPUT, DES_XML_OUTPUT, PRE_XML_OUTPUT));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_C_CUSTOM_STAGE, TIPO_XML_TRANSFORMER, DES_XML_TRANSFORMER, PRE_XML_TRANSFORMER));

            ///***************************************JOBSECUENCIA************************************************/
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_ACTIVITY_INPUT, TIPO_CJS_ACTIVITY_INPUT, DES_LINK_INPUT_3, PRE_LINK));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_ACTIVITY_OUTPUT, TIPO_CJS_ACTIVITY_OUTPUT, DES_LINK_OUTPUT_3, PRE_LINK));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_USER_VAR_ACTIVITY, TIPO_USER_VAR_ACTIVITY, DES_USER_VAR_ACTIVITY, PRE_USER_VAR_ACTIVITY));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_JOB_ACTIVITY, TIPO_JOB_ACTIVITY, DES_JOB_ACTIVITY, PRE_JOB_ACTIVITY));//no tiene prefijo
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_CONDITION, TIPO_NESTED_CONDITION, DES_NESTED_CONDITION, PRE_NESTED_CONDITION));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_MAIL_ACTIVITY, TIPO_NOTIFICATION_ACTIVITY, DES_NOTIFICATION_ACTIVITY, PRE_NOTIFICATION_ACTIVITY));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_ROUTINE_ACTIVITY, TIPO_ROUTINE_ACTIVITY, DES_ROUTINE_ACTIVITY, PRE_ROUTINE_ACTIVITY));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_SEQUENCER, TIPO_SEQUENCER, DES_SEQUENCER, PRE_SEQUENCER));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_START_LOOP_ACTIVIY, TIPO_START_LOOP_ACTIVITY, DES_START_LOOP_ACTIVITY, PRE_START_LOOP_ACTIVITY));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_TERMINATOR_ACTIVITY, TIPO_TERMINATOR_ACTIVITY, DES_TERMINATOR_ACTIVITY, PRE_TERMINATOR_ACTIVITY));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_WAIT_FILE_ACTIVITY, TIPO_WAIT_FOR_FILE_ACTIVITY, DES_WAIT_FOR_FILE_ACTIVITY, PRE_WAIT_FOR_FILE_ACTIVITY));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_EXEC_CMD_ACTIVITY, TIPO_EXECUTE_COMMAND, DES_EXECUTE_COMMAND, PRE_EXECUTE_COMMAND));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_END_LOOP_ACTIVITY, TIPO_END_LOOP_ACTIVITY, DES_END_LOOP_ACTIVITY, PRE_END_LOOP_ACTIVITY));
            ////listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_EXCEPTION_HANDLER, TIPO_EXCEPTION_HANDLER, DES_EXCEPTION_HANDLER, PRE_EXCEPTION_HANDLER));
        
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_ACTIVITY_INPUT, "", DES_LINK_INPUT_3, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_ACTIVITY_OUTPUT, "", DES_LINK_OUTPUT_3, PRE_LINK));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_USER_VAR_ACTIVITY, TIPO_USER_VAR_ACTIVITY, DES_USER_VAR_ACTIVITY, PRE_USER_VAR_ACTIVITY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_JOB_ACTIVITY, "", DES_JOB_ACTIVITY, PRE_JOB_ACTIVITY));//no tiene prefijo
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_CONDITION, TIPO_NESTED_CONDITION, DES_NESTED_CONDITION, PRE_NESTED_CONDITION));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_MAIL_ACTIVITY, TIPO_NOTIFICATION_ACTIVITY, DES_NOTIFICATION_ACTIVITY, PRE_NOTIFICATION_ACTIVITY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_ROUTINE_ACTIVITY, "", DES_ROUTINE_ACTIVITY, PRE_ROUTINE_ACTIVITY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_SEQUENCER, TIPO_SEQUENCER, DES_SEQUENCER, PRE_SEQUENCER));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_START_LOOP_ACTIVIY, TIPO_START_LOOP_ACTIVITY, DES_START_LOOP_ACTIVITY, PRE_START_LOOP_ACTIVITY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_TERMINATOR_ACTIVITY, TIPO_TERMINATOR_ACTIVITY, DES_TERMINATOR_ACTIVITY, PRE_TERMINATOR_ACTIVITY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_WAIT_FILE_ACTIVITY, TIPO_WAIT_FOR_FILE_ACTIVITY, DES_WAIT_FOR_FILE_ACTIVITY, PRE_WAIT_FOR_FILE_ACTIVITY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_EXEC_CMD_ACTIVITY, TIPO_EXECUTE_COMMAND, DES_EXECUTE_COMMAND, PRE_EXECUTE_COMMAND));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_END_LOOP_ACTIVITY, TIPO_END_LOOP_ACTIVITY, DES_END_LOOP_ACTIVITY, PRE_END_LOOP_ACTIVITY));
            //listaStageReglaValidacion.Add(getStageValidator(OLETYPE_CJS_EXCEPTION_HANDLER, TIPO_EXCEPTION_HANDLER, DES_EXCEPTION_HANDLER, PRE_EXCEPTION_HANDLER));
        }

        public static bool tieneStageType(string cadena)
        {
            return cadena == "OLEType \"CCustomStage\"";
        }

        public static bool esCJobDefn(string cadena)
        {
            return cadena == "OLEType \"CJobDefn\"";
        }

        public static bool esOLETypeValido(List<string> listaOLEType, string cadena)
        {
            for (int i = 0; i < listaOLEType.Count; i++)
            {
                if (("OLEType \"" + listaOLEType[i] + "\"") == cadena)
                {
                    return true;
                }
            }
            return false;
        }

        public static Objeto getObjetoFromLista(List<Objeto> lista, string codigoObjeto)
        {
            Objeto obj = null;

            if(lista !=null && lista.Count >0)
            {
                for (int i = 0; i<lista.Count; i++)
                {
                    if(lista[i].codigoObjeto == codigoObjeto)
                    {
                        return lista[i];
                    }
                }
            }

            return obj;
        }


        public static LogStage getStageByIdentifier(string id, List<LogStage> listaStage)
        {
            if (id.Contains("|"))
            {
                string[] ids = id.Split('|');
                id = ids[0];
            }

            for (int i = 0; i < listaStage.Count; i++)
            {
                LogStage s = listaStage[i];
                if (s.identifierStage == id)
                {
                    return s;
                }
            }

            return null;
        }

        public static List<LogJob> getListaJobByCategory(string category, List<LogJob> listaJob)
        {
            List<LogJob> lista = new List<LogJob>();

            for (int i = 0; i < listaJob.Count; i++)
            {
                LogJob job = listaJob[i];
                if (job.category == category)
                {
                    lista.Add(job);
                }
            }

            return lista;
        }

        public static List<LogJob> getJobByStartIdentifier(string prefijoIdentifier, List<LogJob> listaJob)
        {
            List<LogJob> lista = new List<LogJob>();

            for (int i = 0; i < listaJob.Count; i++)
            {
                LogJob job = listaJob[i];
                if (job.identifierJob.StartsWith(prefijoIdentifier))
                {
                    lista.Add(job);
                }
            }

            return lista;
        }

        public static ObjetoView getObjetoViewFromLista(string codigoObjeto, List<ObjetoView> listaObjetoView) 
        {
            ObjetoView ov = null;

            if(listaObjetoView != null && listaObjetoView.Count >0)
            {
                for (int i = 0; i<listaObjetoView.Count; i++) 
                {
                    if (listaObjetoView[i].codigoObjeto == codigoObjeto)
                    {
                        return listaObjetoView[i];
                    }
                }
            }

            return ov;
        }

        public static bool existeParametroEnLista(LogObjetoParam param,List<LogObjetoParam> listaParamParalelo)
        {
            if (listaParamParalelo != null && listaParamParalelo.Count>0)
            {
                for (int i = 0; i<listaParamParalelo.Count; i++)
                {
                    if (listaParamParalelo[i].name == param.name)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        public static DateTime getDateExportacion(string date, string time) 
        {
            int anio = Convert.ToInt32(date.Substring(0, 4));
            int mes = Convert.ToInt32(date.Substring(5, 2));
            int dia = Convert.ToInt32(date.Substring(8, 2));

            int hora = Convert.ToInt32(time.Substring(0, 2));
            int minuto = Convert.ToInt32(time.Substring(3, 2));
            int segundo = Convert.ToInt32(time.Substring(6, 2));
            return new DateTime(anio, mes, dia, hora, minuto, segundo, DateTime.Now.Kind);
        }

        public static DateTime getFirstDate()
        {
            return new DateTime(1970, 1, 1, 0, 0, 0, DateTime.Now.Kind);
        }
        public static DateTime getLastDate()
        {
            return new DateTime(2080, 1, 1, 0, 0, 0, DateTime.Now.Kind);
        }

        public static Carpeta getCarpeta(string category, Carpeta raiz) 
        {
            Carpeta carpeta = null;
            List<string> listaNombre = new List<string>();
            List<string> listaTodosDirectorios = new List<string>();

            //obtener todos los directorios del category
            string[] arrayNombreCarpeta = category.Split(new string[] { "\\\\" }, StringSplitOptions.None);
            if (arrayNombreCarpeta != null && arrayNombreCarpeta.Length > 1)
            {
                string directoryConcatenado = "";
                for (int i = 1; i < arrayNombreCarpeta.Length; i++)
                {
                    string nombreCarpeta = "\\" + arrayNombreCarpeta[i];
                    directoryConcatenado +=  nombreCarpeta;
                    listaNombre.Add(arrayNombreCarpeta[i]);
                    listaTodosDirectorios.Add(directoryConcatenado);
                }
            }
            
            //agregar a la raiz todos los directorios
            //
            //listaTodosDirectorios:
            //
            //  0: \\Jobs
            //  1: \\Jobs\\5_OPERACIONAL_DEPOSITOS
            //  2: \\Jobs\\5_OPERACIONAL_DEPOSITOS\\ 01 PERSONA - OP_D_DEPOSPLABT_CTA
            //
            for (int j = 1; j < listaTodosDirectorios.Count; j++) 
            {
                carpeta = agregarCategoryToArbol(listaNombre[j], listaTodosDirectorios[j], listaTodosDirectorios[j - 1], raiz);
            }

            return carpeta; //la ultima carpeta es la del category inicial
        }

        private static Carpeta agregarCategoryToArbol(string nombre, string nombreFull, string padre, Carpeta raiz) 
        {
            Carpeta carpetaHijo = buscarCarpeta(nombreFull, raiz);
            if(carpetaHijo == null)
            {
                Carpeta carpetaPadre = buscarCarpeta(padre, raiz);
                return carpetaPadre.agregarHijo(nombre, nombreFull);
            }

            return carpetaHijo;
        }

        private static Carpeta buscarCarpeta(string buscar, Carpeta raiz) 
        {
            if(raiz.nombreFull == buscar)
            {
                return raiz;
            }

            for (int i = 0; i<raiz.listaCarpeta.Count; i++)
            {
                Carpeta c = buscarCarpeta(buscar, raiz.listaCarpeta[i]);
                if(c != null)
                {
                    return c;
                }
            }

            return null;
        }

        public static Carpeta getCarpetaByNombre(string nombre, List<Carpeta> lista) 
        {
            for (int i = 0; i<lista.Count; i++) 
            {
                if(lista[i].nombre == nombre)
                {
                    return lista[i];
                }
            }

            return null;
        }

        public static string getPrefijoFrecuencia(string nombreCarpeta) 
        {
            if(tienePrefijoFrecuencia(nombreCarpeta))
            {
                return nombreCarpeta.Substring(0,3);
            }

            return "";
        }

        public static string getPrefijoFrecuenciaStaging(string nombreCarpeta)  //JT
        {
            if (tienePrefijoFrecuencia(nombreCarpeta))
            {
                return nombreCarpeta.Substring(0, 3);
            }
            else
            {
                return nombreCarpeta;
            }
            //return "";
        }

        public static bool tienePrefijoFrecuencia(string carpeta) 
        {
            return carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_PC)
                || carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_ST)
                || carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_CM)
                || carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_CS)
                || carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_RP)
                || carpeta.StartsWith(ConstanteDataStage.PREF_PROC_DEL);
        }

        public static string getPrefijoProceso(string carpeta)
        {
            if(carpeta.StartsWith(ConstanteDataStage.PREF_PROC_LDM))
            {
                return ConstanteDataStage.PREF_PROC_LDM;
            }
            if(carpeta.StartsWith(ConstanteDataStage.PREF_PROC_LN))
            {
                return ConstanteDataStage.PREF_PROC_LN;
            }
            if(carpeta.StartsWith(ConstanteDataStage.PREF_PROC_STG))
            {
                return ConstanteDataStage.PREF_PROC_STG;
            }
            if (carpeta.StartsWith(ConstanteDataStage.PREF_PROC_DEL))
            {
                return ConstanteDataStage.PREF_PROC_DEL;
            }
            return "";
        }

        public static string getPrefijoProcesoStaging(string carpeta)
        {
            if (carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_CM))
            {
                return ConstanteDataStage.PREF_FREQ_CM;
            }
            if (carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_PC))
            {
                return ConstanteDataStage.PREF_FREQ_PC;
            }
            if (carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_CS))
            {
                return ConstanteDataStage.PREF_FREQ_CS;
            }
            if (carpeta.StartsWith(ConstanteDataStage.PREF_FREQ_RP))
            {
                return ConstanteDataStage.PREF_FREQ_RP;
            }
            return "";
        }

        public static bool tienePrefijoProceso(string carpeta) 
        {
            return carpeta.StartsWith(ConstanteDataStage.PREF_PROC_LDM)
                || carpeta.StartsWith(ConstanteDataStage.PREF_PROC_LN)
                || carpeta.StartsWith(ConstanteDataStage.PREF_PROC_STG)
                || carpeta.StartsWith(ConstanteDataStage.PREF_PROC_DEL);            
        }

        public static bool tienePrefijoProcesoStaging(string carpeta)
        {
            return carpeta.StartsWith(ConstanteDataStage.PREF_STAGING_DED)
                || carpeta.StartsWith(ConstanteDataStage.PREF_STAGING_DIF)
                || carpeta.StartsWith(ConstanteDataStage.PREF_STAGING_EST)
                || carpeta.StartsWith(ConstanteDataStage.PREF_STAGING_IA)
                || carpeta.StartsWith(ConstanteDataStage.PREF_STAGING_VDU);
        }
    }
}