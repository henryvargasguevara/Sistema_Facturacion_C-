﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    class UtilRequerimiento
    {

        public static string getCodigoEstadoReq(string clas)
        {

            string cod = "";
            switch (clas)
            {
                case "Pendiente":
                    cod = "1";
                    break;
                case "Asignado":
                    cod = "2";
                    break;
                case "Success":
                    cod = "3";
                    break;
                case "Rechazado":
                    cod = "4";
                    break;
            }
            return cod;
        }

        public static bool getValidarDia(int dia, int dia2, int mes, int mes2, int año, int año2)
        {
            if (año < año2) return true;
            else 
            {
                if (mes < mes2) return true;
                else
                {
                    if (dia <= dia2) return true;
                }
            }
            return false;
        }

        public static string getCodigoTipoValidacion(string clas)
        {

            string cod = "";
            switch (clas)
            {
                case "Express":
                    cod = "E";
                    break;
                case "Full":
                    cod = "F";
                    break;
            }
            return cod;
        }

        public static string getCodigoPrioridad(string clas)
        {

            string cod = "";
            switch (clas)
            {
                case "Baja":
                    cod = "1";
                    break;
                case "media":
                    cod = "2";
                    break;
                case "alta":
                    cod = "3";
                    break;
            }
            return cod;
        }

        public static int getCodigocliente(string clas)
        {

            int cod = 0;
            switch (clas)
            {
                case "ScotiaBank":
                    cod = 1;
                    break;
            }
            return cod;
        }

        public static int getCodigoEstadoAsigancion(string clas)
        {

            int cod = 0;
            switch (clas)
            {
                case "Pendiente":
                    cod = 1;
                    break;
                case "Derivado":
                    cod = 2;
                    break;
                case "Finalizado":
                    cod = 3;
                    break;
                case "Rechazado":
                    cod = 4;
                    break;
            }
            return cod;
        }
    
    }
}
