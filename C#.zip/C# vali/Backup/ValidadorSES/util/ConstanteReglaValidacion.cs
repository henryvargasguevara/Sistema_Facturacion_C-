﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    public class ConstanteReglaValidacion
    {
        public const int COD_REGLA_JOB_NOMENCLATURA = 100;
        public const int COD_REGLA_JOB_ESTRUCTURA_DOC_INT = 101;
        public const int COD_REGLA_JOB_DESCRIPCION_BREVE = 102;
        public const int COD_REGLA_JOB_DOC_INT_NOMBRE = 103;
        public const int COD_REGLA_JOB_DOC_INT_DESTINO = 104;
        public const int COD_REGLA_JOB_DOC_INT_FUENTES = 105;
        public const int COD_REGLA_JOB_DOC_INT_DEPENDENCIAS = 106;
        public const int COD_REGLA_JOB_DOC_INT_OBJETIVO = 107;
        public const int COD_REGLA_JOB_DOC_INT_VERSION = 108;
        public const int COD_REGLA_JOB_PARAMETRO_VALOR_PREDETERMINADO = 109;
        public const int COD_REGLA_JOB_OPCION_COMPILACION = 110;
        public const int COD_REGLA_JOB_ELIMINACION_DATA_SET = 111;
        public const int COD_REGLA_JOB_TRANSFORMER_STG = 112;  //JT
        public const int COD_REGLA_JOB_MAXIMO_CONECTORES = 113;  //JT

        public const int COD_REGLA_STAGE_NOMENCLATURA = 201;
        public const int COD_REGLA_STAGE_FILE_PARAM_DIRECTORIO = 210;
        public const int COD_REGLA_STAGE_FILE_EXISTENCIA = 211;
        public const int COD_REGLA_STAGE_FILE_EXTENSION = 212;
        public const int COD_REGLA_STAGE_FILE_NOMENCLATURA = 213;

        public const int COD_REGLA_STAGE_AGGREGATOR_METHOD = 218;

        public const int COD_REGLA_STAGE_TRA_NOMENCLATURA_STAGE_VARIABLES = 220;
        public const int COD_REGLA_STAGE_TRA_NOMENCLATURA_LOOP_VARIABLES = 221;

        public const int COD_REGLA_STAGE_DB2_BEFORE_AFTER_SQL = 231;
        public const int COD_REGLA_STAGE_DB2_KEEP_CONDUCTOR = 232;
        public const int COD_REGLA_STAGE_DB2_DELETE = 233;
        public const int COD_REGLA_STAGE_DB2_FUNCIONES_SQL_NO_PERMITIDAS = 234;
        public const int COD_REGLA_STAGE_DB2_FUNCIONES_SQL_OBS = 235;
        public const int COD_REGLA_STAGE_DB2_OPERADOR_SQL = 236;
        public const int COD_REGLA_STAGE_DB2_OPERADOR_DATASTAGE_ORCHESTRATE = 237;
        public const int COD_REGLA_STAGE_DB2_COMENTARIOS = 238;
        public const int COD_REGLA_STAGE_DB2_SELECT_FROM = 239;
        public const int COD_REGLA_STAGE_DB2_PARAM_SCHEMA_QUERY = 240;
        public const int COD_REGLA_STAGE_DB2_PARAM_CONEXION = 241;
        public const int COD_REGLA_STAGE_DB2_LIMITE_RESULTADO = 242;
        public const int COD_REGLA_STAGE_DB2_RECORD_COUNT = 243;    
        public const int COD_REGLA_STAGE_DB2_ARRAY_SIZE = 244; //JT
       // public const int COD_REGLA_STAGE_DB2_RECORD_COUNT_2 = 245; //JT
        public const int COD_REGLA_STAGE_DB2_PK_EN_DU = 245;  //JT
        public const int COD_REGLA_STAGE_DB2_LINAJE = 246; //JT
        public const int COD_REGLA_STAGE_DB2_LOCK_WAIT_MODE = 247; //JT

        public const int COD_REGLA_STAGE_JOBACTIVITY_NOMBRE_INTERNO = 250;
        public const int COD_REGLA_STAGE_DESENCADENANTE = 251;
        public const int COD_REGLA_STAGE_COINCIDENCIA_PARAMETROS = 252;
        public const int COD_REGLA_STAGE_JOBACTIVITY_ACCION_EJECUCION = 253;
        public const int COD_REGLA_STAGE_TERMINATORACTIVITY_DESCRIPCION = 255;
        public const int COD_REGLA_STAGE_NOTIFICATION_ACTIVITY_ASUNTO = 256; //JT

        public const int COD_REGLA_STAGE_VAR_USER_VARIABLES_ACTIVITY_EXPRESION_VARIABLE = 260;
        
        public const int COD_REGLA_ROUTINE_NOMENCLATURA = 301;
        public const int COD_REGLA_ROUTINE_DESCRIPCION = 302;
        public const int COD_REGLA_ROUTINE_DESCRIPCION_BREVE = 303;
        public const int COD_REGLA_ROUTINE_OBJETIVO = 304;

        public const int COD_REGLA_ARGUMENT_DESCRIPCION = 401;

        public const int COD_REGLA_PARAMETER_SET_NOMENCLATURA = 501;
        public const int COD_REGLA_PARAMETER_SET_DESCRIPCION = 502;
        public const int COD_REGLA_PARAMETER_SET_DESCRIPCION_BREVE = 503;        

    }
}

