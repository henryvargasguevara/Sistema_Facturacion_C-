﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    public class ConstanteTituloForm
    {
        public const string TITULO_APP = " - Sistema de Validación de Desarrollo DataStage 3.5";
        public const string TITULO_APP_ABREV = "Validador SES 3.5";
        public const string TITULO_ASIGNACION_REQUERIMIENTO = "Asignación de Requerimientos" + TITULO_APP;
        public const string TITULO_BUSCADOR = "Buscador" + TITULO_APP;
        public const string TITULO_COLABORADOR_REQUERIMIENTO = "Requerimientos asignados" + TITULO_APP;
        public const string TITULO_LOGIN = "Acceso" + TITULO_APP;
        public const string TITULO_MANTENIMIENTO_REQUERIMIENTO = "Mantenimiento de Requerimiento" + TITULO_APP;
        public const string TITULO_MANTENIMIENTO_REQUERIMIENTO_RECURSOS_ASIGNADOS = "Colaboradores asignados por requerimiento" + TITULO_APP;
        public const string TITULO_REQUERIMIENTO_LISTADO_DSX = "Listado de DSX validados" + TITULO_APP;
        public const string TITULO_MANTENIMIENTO_USUARIO = "Mantenimiento de Usuarios" + TITULO_APP;
        public const string TITULO_MANTENIMIENTO_OBJETO = "Mantenimiento de Objetos DataStage" + TITULO_APP;
        public const string TITULO_REGISTRO_OBJETO = "Registro de Objeto DataStage" + TITULO_APP;
        public const string TITULO_EDICION_OBJETO = "Modificación de Objeto" + TITULO_APP;
        public const string TITULO_MENU_PRINCIPAL = "Menú Principal" + TITULO_APP;
        public const string TITULO_CAMBIAR_CONTRASENIA = "Cambiar Contraseña" + TITULO_APP;
        public const string TITULO_REGISTRO_USUARIO = "Registro de Usuario" + TITULO_APP;
        public const string TITULO_ASIGNACION_REGLA_VALIDACION = "Asignación de Reglas de Validación" + TITULO_APP;
        public const string TITULO_MANTENIMIENTO_REGLA_VALIDACION = "Mantenimiento de Regla de Validación de Objeto DataStage" + TITULO_APP;
        public const string TITULO_REGISTRO_REGLA_VALIDACION = "Registro de Regla de Validación" + TITULO_APP;
        public const string TITULO_REPORTE_CUMPLIMIENTO = "Reporte de Cumplimiento" + TITULO_APP;
        public const string TITULO_REPORTES = "Reportes" + TITULO_APP;
        public const string TITULO_REPORTE_TASA_EFECTIVIDAD = "Reporte de Tasa de Efectividad" + TITULO_APP;
        public const string TITULO_ASIGNACION_REGLA_VALIDACION_POR_TIPO_VALIDACION = "Asignación de Reglas de Validación por Tipo de Validación" + TITULO_APP;
        public const string TITULO_VALIDADOR = "Validador de Objetos DataStage" + TITULO_APP;
        public const string TITULO_VALIDADOR_LISTADO_OBJETO = "Listado de Objetos DataStage" + TITULO_APP;
        public const string TITULO_VALIDADOR_LISTADO_REGLA = "Listado de Reglas de Validación de Objeto DataStage" + TITULO_APP;
        public const string TITULO_VALIDADOR_LISTADO_OBJETO_FALTANTE = "Objetos DataStage necesarios para validación" + TITULO_APP;
        public const string TITULO_VALIDADOR_CERRAR_VALIDACION = "Nota para cerrar validación con errores" + TITULO_APP;
    }
}
