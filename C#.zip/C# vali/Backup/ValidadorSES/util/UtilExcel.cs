﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using ValidadorSES.modelo;
 using ValidadorSES.form;

namespace ValidadorSES.util
{
    class UtilExcel
    {

        public static void exportarToExcelResultadoBusqueda(ResultadoBusqueda rb, SaveFileDialog save, string txtRutaDSX) 
        {
            string rutaDefecto = "D:";
            string nombre = "resultado_";
            if (UtilArchivo.esValidoArchivoDSX(txtRutaDSX))
            {
                rutaDefecto = Path.GetDirectoryName(txtRutaDSX);
                nombre = Path.GetFileNameWithoutExtension(txtRutaDSX) + "_RESULTADO_BUSQUEDA";
            }

            save.InitialDirectory = rutaDefecto;
            save.FileName = nombre;
            save.Title = "Guardar como archivo Excel";
            save.Filter = "Excel Files(2007)|*.xlsx|Excel Files(2003)|*.xls";

            if (save.ShowDialog() != DialogResult.Cancel)
            {
                Excel._Application app = new Excel.Application();
                Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);

                Excel._Worksheet sheetJob = (Excel._Worksheet)workbook.Worksheets[1];
                sheetJob.Name = "Búsqueda en JOB";

                //Job  ----------------------------------------------------------------------------
                Excel.Range erJob = null;
                //TBL_JOB_NOMBRE_JOB
                erJob = sheetJob.get_Range("A:A", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 50;
                //TBL_JOB_TIPO_JOB
                erJob = sheetJob.get_Range("B:B", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 15;
                //TBL_JOB_TIPO_STAGE
                erJob = sheetJob.get_Range("C:C", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 15;
                //TBL_JOB_NOMBRE_STAGE
                erJob = sheetJob.get_Range("D:D", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 50;
                //TBL_JOB_TIPO_FILTRO
                erJob = sheetJob.get_Range("E:E", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 20;
                //TBL_JOB_RESULTADO
                erJob = sheetJob.get_Range("F:F", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 100;
                //TBL_JOB_RUTA
                erJob = sheetJob.get_Range("G:G", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 50;

                sheetJob.Cells[1, 1] = FormBuscador.TBL_JOB_NOMBRE_JOB;
                sheetJob.Cells[1, 2] = FormBuscador.TBL_JOB_TIPO_JOB;
                sheetJob.Cells[1, 3] = FormBuscador.TBL_JOB_TIPO_STAGE;
                sheetJob.Cells[1, 4] = FormBuscador.TBL_JOB_NOMBRE_STAGE;
                sheetJob.Cells[1, 5] = FormBuscador.TBL_JOB_TIPO_FILTRO;
                sheetJob.Cells[1, 6] = FormBuscador.TBL_JOB_RESULTADO;
                sheetJob.Cells[1, 7] = FormBuscador.TBL_JOB_RUTA;

                List<ResultadoJob> listaJob = rb.listaJob;
                int filaJob = 2;
                for (int i = 0; i < listaJob.Count; i++)
                {
                    ResultadoJob job = listaJob[i];

                    for (int s = 0; s<job.listaStage.Count; s++)
                    {
                        ResultadoStage stage = job.listaStage[s];

                        for (int f = 0; f < stage.listaResultado.Count; f++)
                        {
                            ResultadoFiltro filtro = stage.listaResultado[f];

                            sheetJob.Cells[filaJob, 1] = job.nombreJob;
                            sheetJob.Cells[filaJob, 2] = job.tipoJob;
                            sheetJob.Cells[filaJob, 3] = stage.tipoStage;
                            sheetJob.Cells[filaJob, 4] = stage.nombreStage;
                            sheetJob.Cells[filaJob, 5] = filtro.descripcionFiltro;
                            sheetJob.Cells[filaJob, 6] = filtro.resultado;
                            sheetJob.Cells[filaJob, 7] = job.rutaJob;
                            filaJob++;
                        }
                    }
                }

                //mostrar activo a la primera Hoja
                sheetJob.Activate();

                app.ActiveWorkbook.SaveCopyAs(save.FileName.ToString());
                app.ActiveWorkbook.Saved = true;
                app.Quit();
            }
        }
        
        public static void exportarToExcelResultadoValidacion(LogDSX dsx, SaveFileDialog save, string txtRutaDSX)
        {
            string rutaDefecto = "D:";
            string nombre = "resultado_";
            if (UtilArchivo.esValidoArchivoDSX(txtRutaDSX))
            {
                rutaDefecto = Path.GetDirectoryName(txtRutaDSX);
                nombre = Path.GetFileNameWithoutExtension(txtRutaDSX) + "_RESULTADO_VALIDACION";
            }

            save.InitialDirectory = rutaDefecto;
            save.FileName = nombre;
            save.Title = "Guardar como archivo Excel";
            save.Filter = "Excel Files(2007)|*.xlsx|Excel Files(2003)|*.xls";

            if (save.ShowDialog() != DialogResult.Cancel)
            {
                Excel._Application app = new Excel.Application();
                Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Excel._Worksheet currentSheet1 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[1], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet2 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[2], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet3 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[3], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet4 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[4], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet5 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[5], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet6 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[6], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet7 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[7], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet8 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[8], Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet currentSheet9 = (Excel._Worksheet)app.Worksheets.Add((Excel._Worksheet)workbook.Worksheets[9], Type.Missing, Type.Missing, Type.Missing);

                Excel._Worksheet sheetJob = (Excel._Worksheet)workbook.Worksheets[1];
                sheetJob.Name = "Estadísticas de JOB";
                Excel._Worksheet sheetStage = (Excel._Worksheet)workbook.Worksheets[2];
                sheetStage.Name = "Detalle de JOB";
                Excel._Worksheet sheetRoutine = (Excel._Worksheet)workbook.Worksheets[3];
                sheetRoutine.Name = "Estadísticas de ROUTINE";
                Excel._Worksheet sheetArgument = (Excel._Worksheet)workbook.Worksheets[4];
                sheetArgument.Name = "Detalle de ROUTINE";
                Excel._Worksheet sheetParameterSet = (Excel._Worksheet)workbook.Worksheets[5];
                sheetParameterSet.Name = "Estadísticas de PARAMETER SET";
                Excel._Worksheet sheetParam = (Excel._Worksheet)workbook.Worksheets[6];
                sheetParam.Name = "Detalle de PARAMETER SET";

                //Job  ----------------------------------------------------------------------------
                Excel.Range erJob = null;
                //TBL_JOB_NOMBRE_JOB
                erJob = sheetJob.get_Range("A:A", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 50;
                //TBL_JOB_TIPO_JOB
                erJob = sheetJob.get_Range("B:B", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 15;
                //TBL_JOB_TOTAL_STAGES
                erJob = sheetJob.get_Range("C:C", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 10;
                //TBL_JOB_ESTADO
                Excel.Range erJobEstado = sheetJob.get_Range("D:D", System.Type.Missing);
                erJobEstado.EntireColumn.ColumnWidth = 10;
                //TBL_JOB_FECHA_EXPORTACION
                erJob = sheetJob.get_Range("E:E", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 20;
                //TBL_JOB_FECHA_MOD
                erJob = sheetJob.get_Range("F:F", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 20;
                //TBL_JOB_TOTAL_STAGES_CORRECTOS
                erJob = sheetJob.get_Range("G:G", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 10;
                //TBL_JOB_TOTAL_STAGES_ERRORES
                erJob = sheetJob.get_Range("H:H", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 10;
                //TBL_JOB_TOTAL_STAGES_OBSERVACIONES
                erJob = sheetJob.get_Range("I:I", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 10;
                //TBL_JOB_DESCRIPCION_VALIDACION
                erJob = sheetJob.get_Range("J:J", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 70;
                //TBL_JOB_RUTA
                erJob = sheetJob.get_Range("K:K", System.Type.Missing);
                erJob.EntireColumn.ColumnWidth = 50;

                sheetJob.Cells[1, 1] = FormValidador.TBL_JOB_NOMBRE_JOB;
                sheetJob.Cells[1, 2] = FormValidador.TBL_JOB_TIPO_JOB;
                sheetJob.Cells[1, 3] = FormValidador.TBL_JOB_TOTAL_STAGES;
                sheetJob.Cells[1, 4] = FormValidador.TBL_JOB_ESTADO;
                sheetJob.Cells[1, 5] = FormValidador.TBL_JOB_FECHA_EXPORTACION;
                sheetJob.Cells[1, 6] = FormValidador.TBL_JOB_FECHA_MOD;
                sheetJob.Cells[1, 7] = FormValidador.TBL_JOB_TOTAL_STAGES_CORRECTOS;
                sheetJob.Cells[1, 8] = FormValidador.TBL_JOB_TOTAL_STAGES_ERRORES;
                sheetJob.Cells[1, 9] = FormValidador.TBL_JOB_TOTAL_STAGES_OBSERVACIONES;
                sheetJob.Cells[1, 10] = FormValidador.TBL_JOB_DESCRIPCION_VALIDACION;
                sheetJob.Cells[1, 11] = FormValidador.TBL_JOB_RUTA;

                List<LogJob> listaJob = dsx.listaJob;
                int filaJob = 2;
                for (int i = 0; i < listaJob.Count; i++)
                {
                    LogJob job = listaJob[i];

                    sheetJob.Cells[filaJob, 1] = job.identifierJob;
                    sheetJob.Cells[filaJob, 2] = job.objeto.nombre;
                    sheetJob.Cells[filaJob, 3] = job.listaStage.Count;
                    sheetJob.Cells[filaJob, 4] = job.estadoJobDescripcion;
                    sheetJob.Cells[filaJob, 5] = dsx.header.fecha + " " + dsx.header.hora;
                    sheetJob.Cells[filaJob, 6] = job.dateModified + " " + job.timeModified;
                    sheetJob.Cells[filaJob, 7] = job.numStageCorrecto;
                    sheetJob.Cells[filaJob, 8] = job.numStageIncorrecto;
                    sheetJob.Cells[filaJob, 9] = job.numStageObservado;
                    sheetJob.Cells[filaJob, 10] = job.mensaje;
                    sheetJob.Cells[filaJob, 11] = job.category;
                    filaJob++;
                }

                //Stage  ----------------------------------------------------------------------------
                //TBL_JOB_NOMBRE_JOB
                Excel.Range erStageJobNombreJob = sheetStage.get_Range("A:A", System.Type.Missing);
                erStageJobNombreJob.EntireColumn.ColumnWidth = 50;
                //TBL_JOB_TIPO_JOB
                Excel.Range erStageJobTipoJob = sheetStage.get_Range("B:B", System.Type.Missing);
                erStageJobTipoJob.EntireColumn.ColumnWidth = 15;
                //TBL_STAGE_NOMBRE_STAGE
                Excel.Range erStageNombreStage = sheetStage.get_Range("C:C", System.Type.Missing);
                erStageNombreStage.EntireColumn.ColumnWidth = 50;
                //TBL_STAGE_TIPO_STAGE
                Excel.Range erStageTipoStage = sheetStage.get_Range("D:D", System.Type.Missing);
                erStageTipoStage.EntireColumn.ColumnWidth = 15;
                //TBL_STAGE_ESTADO
                Excel.Range erStageEstado = sheetStage.get_Range("E:E", System.Type.Missing);
                erStageEstado.EntireColumn.ColumnWidth = 15;
                //TBL_STAGE_DESCRIPCION_VALIDACION
                Excel.Range erStageDescripcion = sheetStage.get_Range("F:F", System.Type.Missing);
                erStageDescripcion.EntireColumn.ColumnWidth = 200;

                sheetStage.Cells[1, 1] = FormValidador.TBL_JOB_NOMBRE_JOB;
                sheetStage.Cells[1, 2] = FormValidador.TBL_JOB_TIPO_JOB;
                sheetStage.Cells[1, 3] = FormValidadorDetalleJob.TBL_STAGE_NOMBRE_STAGE;
                sheetStage.Cells[1, 4] = FormValidadorDetalleJob.TBL_STAGE_TIPO_STAGE;
                sheetStage.Cells[1, 5] = FormValidadorDetalleJob.TBL_STAGE_ESTADO;
                sheetStage.Cells[1, 6] = FormValidadorDetalleJob.TBL_STAGE_DESCRIPCION_VALIDACION;

                int filaStage = 2;
                for (int i = 0; i < listaJob.Count; i++)
                {
                    LogJob job = listaJob[i];
                    for (int j = 0; j < job.listaStage.Count; j++)
                    {
                        LogStage stage = job.listaStage[j];
                        if (stage.objeto != null)
                        {
                            sheetStage.Cells[filaStage, 1] = job.identifierJob;
                            sheetStage.Cells[filaStage, 2] = job.objeto.nombre;
                            sheetStage.Cells[filaStage, 3] = stage.nameStage;
                            sheetStage.Cells[filaStage, 4] = stage.objeto.nombre;
                            sheetStage.Cells[filaStage, 5] = stage.estadoStageDescripcion;
                            sheetStage.Cells[filaStage, 6] = stage.mensaje;

                            filaStage++;
                        }
                    }
                }

                //Routine  ----------------------------------------------------------------------------
                //TBL_ROUTINE_NOMBRE_ROUTINE
                Excel.Range erRoutineNombre = sheetRoutine.get_Range("A:A", System.Type.Missing);
                erRoutineNombre.EntireColumn.ColumnWidth = 50;
                //TBL_ROUTINE_TIPO_ROUTINE
                Excel.Range erRoutineTipo = sheetRoutine.get_Range("B:B", System.Type.Missing);
                erRoutineTipo.EntireColumn.ColumnWidth = 15;
                //TBL_ROUTINE_TOTAL_ARGUMENTOS
                Excel.Range erRoutineTotalArgumento = sheetRoutine.get_Range("C:C", System.Type.Missing);
                erRoutineTotalArgumento.EntireColumn.ColumnWidth = 15;
                //TBL_ROUTINE_ESTADO
                Excel.Range erRoutineEstado = sheetRoutine.get_Range("D:D", System.Type.Missing);
                erRoutineEstado.EntireColumn.ColumnWidth = 15;
                //TBL_ROUTINE_FECHA_EXPORTACION
                Excel.Range erRoutineFechaExportacion = sheetRoutine.get_Range("E:E", System.Type.Missing);
                erRoutineFechaExportacion.EntireColumn.ColumnWidth = 20;
                //TBL_ROUTINE_FECHA_MOD
                Excel.Range erRoutineFechaMod = sheetRoutine.get_Range("F:F", System.Type.Missing);
                erRoutineFechaMod.EntireColumn.ColumnWidth = 20;
                //TBL_ROUTINE_TOTAL_ARGUMENT_CORRECTOS
                Excel.Range erRoutineTotalCorrecto = sheetRoutine.get_Range("G:G", System.Type.Missing);
                erRoutineTotalCorrecto.EntireColumn.ColumnWidth = 10;
                //TBL_ROUTINE_TOTAL_ARGUMENT_ERRORES
                Excel.Range erRoutineTotalIncorrecto = sheetRoutine.get_Range("H:H", System.Type.Missing);
                erRoutineTotalIncorrecto.EntireColumn.ColumnWidth = 10;
                //TBL_ROUTINE_TOTAL_ARGUMENT_OBSERVACIONES
                Excel.Range erRoutineTotalObservaciones = sheetRoutine.get_Range("I:I", System.Type.Missing);
                erRoutineTotalObservaciones.EntireColumn.ColumnWidth = 10;
                //TBL_ROUTINE_DESCRIPCION_VALIDACION
                Excel.Range erRoutineDescripcionValidacion = sheetRoutine.get_Range("J:J", System.Type.Missing);
                erRoutineDescripcionValidacion.EntireColumn.ColumnWidth = 50;
                //TBL_ROUTINE_DESCRIPCION_VALIDACION
                Excel.Range erRoutineRuta = sheetRoutine.get_Range("K:K", System.Type.Missing);
                erRoutineRuta.EntireColumn.ColumnWidth = 50;

                sheetRoutine.Cells[1, 1] = FormValidador.TBL_ROUTINE_NOMBRE_ROUTINE;
                sheetRoutine.Cells[1, 2] = FormValidador.TBL_ROUTINE_TIPO_ROUTINE;
                sheetRoutine.Cells[1, 3] = FormValidador.TBL_ROUTINE_TOTAL_ARGUMENTOS;
                sheetRoutine.Cells[1, 4] = FormValidador.TBL_ROUTINE_ESTADO;
                sheetRoutine.Cells[1, 5] = FormValidador.TBL_ROUTINE_FECHA_EXPORTACION;
                sheetRoutine.Cells[1, 6] = FormValidador.TBL_ROUTINE_FECHA_MOD;
                sheetRoutine.Cells[1, 7] = FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_CORRECTOS;
                sheetRoutine.Cells[1, 8] = FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_ERRORES;
                sheetRoutine.Cells[1, 9] = FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_OBSERVACIONES;
                sheetRoutine.Cells[1, 10] = FormValidador.TBL_ROUTINE_DESCRIPCION_VALIDACION;
                sheetRoutine.Cells[1, 11] = FormValidador.TBL_ROUTINE_RUTA;

                List<LogRoutine> listaRoutine = dsx.listaRoutine;
                int filaRoutine = 2;
                for (int i = 0; i < listaRoutine.Count; i++)
                {
                    LogRoutine routine = listaRoutine[i];

                    sheetRoutine.Cells[filaRoutine, 1] = routine.identifier;
                    sheetRoutine.Cells[filaRoutine, 2] = routine.objeto.nombre;
                    sheetRoutine.Cells[filaRoutine, 3] = routine.listaArgumentoRoutine.Count;
                    sheetRoutine.Cells[filaRoutine, 4] = routine.estadoRutinaDescripcion;
                    sheetRoutine.Cells[filaRoutine, 5] = dsx.header.fecha + " " + dsx.header.hora;
                    sheetRoutine.Cells[filaRoutine, 6] = routine.timeModified + " " + routine.timeModified;
                    sheetRoutine.Cells[filaRoutine, 7] = routine.numArgCorrecto;
                    sheetRoutine.Cells[filaRoutine, 8] = routine.numArgIncorrecto;
                    sheetRoutine.Cells[filaRoutine, 9] = routine.numArgObservado;
                    sheetRoutine.Cells[filaRoutine, 10] = routine.mensaje;
                    sheetRoutine.Cells[filaRoutine, 11] = routine.category;
                    filaRoutine++;
                }

                //Argument  ----------------------------------------------------------------------------
                //TBL_ARGUMENT_NOMBRE_ROUTINE
                Excel.Range erArgumentNombreRoutine = sheetArgument.get_Range("A:A", System.Type.Missing);
                erArgumentNombreRoutine.EntireColumn.ColumnWidth = 50;
                //TBL_ARGUMENT_TIPO_ROUTINE
                Excel.Range erArgumentRoutineTipo = sheetArgument.get_Range("B:B", System.Type.Missing);
                erArgumentRoutineTipo.EntireColumn.ColumnWidth = 15;
                //TBL_ARGUMENT_NOMBRE
                Excel.Range erArgumentNombre = sheetArgument.get_Range("C:C", System.Type.Missing);
                erArgumentNombre.EntireColumn.ColumnWidth = 30;
                //TBL_ARGUMENT_DESCRIPCION
                Excel.Range erArgumentDescripcion = sheetArgument.get_Range("D:D", System.Type.Missing);
                erArgumentDescripcion.EntireColumn.ColumnWidth = 30;
                //TBL_ARGUMENT_ESTADO
                Excel.Range erArgumentEstado = sheetArgument.get_Range("E:E", System.Type.Missing);
                erArgumentEstado.EntireColumn.ColumnWidth = 15;
                //TBL_ARGUMENT_DESCRIPCION_VALIDACION
                Excel.Range erArgumentDescripcionValidacion = sheetArgument.get_Range("F:F", System.Type.Missing);
                erArgumentDescripcionValidacion.EntireColumn.ColumnWidth = 200;

                sheetArgument.Cells[1, 1] = FormValidadorDetalleRoutine.TBL_ARGUMENT_NOMBRE_ROUTINE;
                sheetArgument.Cells[1, 2] = FormValidadorDetalleRoutine.TBL_ARGUMENT_TIPO_ROUTINE;
                sheetArgument.Cells[1, 3] = FormValidadorDetalleRoutine.TBL_ARGUMENT_NOMBRE;
                sheetArgument.Cells[1, 4] = FormValidadorDetalleRoutine.TBL_ARGUMENT_DESCRIPCION;
                sheetArgument.Cells[1, 5] = FormValidadorDetalleRoutine.TBL_ARGUMENT_ESTADO;
                sheetArgument.Cells[1, 6] = FormValidadorDetalleRoutine.TBL_ARGUMENT_DESCRIPCION_VALIDACION;

                int filaArgument = 2;
                for (int i = 0; i < listaRoutine.Count; i++)
                {
                    LogRoutine routine = listaRoutine[i];
                    for (int r = 0; r<routine.listaArgumentoRoutine.Count; r++)
                    {
                        LogArgument arg = routine.listaArgumentoRoutine[r];
                        sheetArgument.Cells[filaArgument, 1] = routine.identifier;
                        sheetArgument.Cells[filaArgument, 2] = routine.objeto.nombre;
                        sheetArgument.Cells[filaArgument, 3] = arg.nameArgRoutine;
                        sheetArgument.Cells[filaArgument, 4] = arg.descArgRoutine;
                        sheetArgument.Cells[filaArgument, 5] = arg.estadoArgumentDescripcion;
                        sheetArgument.Cells[filaArgument, 6] = arg.mensaje;
                        filaArgument++;
                    }
                }
                
                //ParameterSet  ----------------------------------------------------------------------------
                Excel.Range erParameterSet = null;
                //TBL_PARAMETER_SET_NOMBRE
                erParameterSet = sheetParameterSet.get_Range("A:A", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 50;
                //TBL_PARAMETER_SET_TOTAL_PARAMETROS
                erParameterSet = sheetParameterSet.get_Range("B:B", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 15;
                //TBL_PARAMETER_SET_ESTADO
                erParameterSet = sheetParameterSet.get_Range("C:C", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 15;
                //TBL_PARAMETER_SET_FECHA_EXPORTACION
                erParameterSet = sheetParameterSet.get_Range("D:D", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 20;
                //TBL_PARAMETER_SET_FECHA_MOD
                erParameterSet = sheetParameterSet.get_Range("E:E", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 20;
                //TBL_PARAMETER_SET_TOTAL_PARAM_CORRECTOS
                erParameterSet = sheetParameterSet.get_Range("F:F", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 10;
                //TBL_PARAMETER_SET_TOTAL_PARAM_ERRORES
                erParameterSet = sheetParameterSet.get_Range("G:G", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 10;
                //TBL_PARAMETER_SET_TOTAL_PARAM_OBSERVACIONES
                erParameterSet = sheetParameterSet.get_Range("H:H", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 10;
                //TBL_PARAMETER_SET_DESCRIPCION_VALIDACION
                erParameterSet = sheetParameterSet.get_Range("I:I", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 50;
                //TBL_PARAMETER_SET_RUTA
                erParameterSet = sheetParameterSet.get_Range("J:J", System.Type.Missing);
                erParameterSet.EntireColumn.ColumnWidth = 50;

                sheetParameterSet.Cells[1, 1] = FormValidador.TBL_PARAMETER_SET_NOMBRE;
                sheetParameterSet.Cells[1, 2] = FormValidador.TBL_PARAMETER_SET_TOTAL_PARAMETROS;
                sheetParameterSet.Cells[1, 3] = FormValidador.TBL_PARAMETER_SET_ESTADO;
                sheetParameterSet.Cells[1, 4] = FormValidador.TBL_PARAMETER_SET_FECHA_EXPORTACION;
                sheetParameterSet.Cells[1, 5] = FormValidador.TBL_PARAMETER_SET_FECHA_MOD;
                sheetParameterSet.Cells[1, 6] = FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_CORRECTOS;
                sheetParameterSet.Cells[1, 7] = FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_ERRORES;
                sheetParameterSet.Cells[1, 8] = FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_OBSERVACIONES;
                sheetParameterSet.Cells[1, 9] = FormValidador.TBL_PARAMETER_SET_DESCRIPCION_VALIDACION;
                sheetParameterSet.Cells[1, 10] = FormValidador.TBL_PARAMETER_SET_RUTA;

                List<LogParameterSet> listaParameter = dsx.listaParameterSet;
                int filaParameter = 2;
                for (int i = 0; i < listaParameter.Count; i++)
                {
                    LogParameterSet parameter = listaParameter[i];

                    sheetParameterSet.Cells[filaParameter, 1] = parameter.identifierParameterSet;
                    sheetParameterSet.Cells[filaParameter, 2] = parameter.listaParam.Count;
                    sheetParameterSet.Cells[filaParameter, 3] = parameter.estadoParameterDescripcion;
                    sheetParameterSet.Cells[filaParameter, 4] = dsx.header.fecha + " " + dsx.header.hora;
                    sheetParameterSet.Cells[filaParameter, 5] = parameter.timeModified + " " + parameter.timeModified;
                    sheetParameterSet.Cells[filaParameter, 6] = parameter.numParamCorrecto;
                    sheetParameterSet.Cells[filaParameter, 7] = parameter.numParamIncorrecto;
                    sheetParameterSet.Cells[filaParameter, 8] = parameter.numParamObservado;
                    sheetParameterSet.Cells[filaParameter, 9] = parameter.mensaje;
                    sheetParameterSet.Cells[filaParameter, 10] = parameter.category;
                    filaParameter++;
                }


                //Parámetros del ParameterSet  ----------------------------------------------------------------------------
                Excel.Range erParam = null;
                //TBL_PARAMETER_SET_NOMBRE
                erParam = sheetParam.get_Range("A:A", System.Type.Missing);
                erParam.EntireColumn.ColumnWidth = 50;
                //TBL_PARAM_NOMBRE
                erParam = sheetParam.get_Range("B:B", System.Type.Missing);
                erParam.EntireColumn.ColumnWidth = 30;
                //TBL_PARAM_DESCRIPCION
                erParam = sheetParam.get_Range("C:C", System.Type.Missing);
                erParam.EntireColumn.ColumnWidth = 30;
                //TBL_PARAM_ESTADO
                erParam = sheetParam.get_Range("D:D", System.Type.Missing);
                erParam.EntireColumn.ColumnWidth = 15;
                //TBL_PARAM_DESCRIPCION_VALIDACION
                erParam = sheetParam.get_Range("E:E", System.Type.Missing);
                erParam.EntireColumn.ColumnWidth = 200;

                sheetParam.Cells[1, 1] = FormValidadorDetalleParameterSet.TBL_PARAM_NOMBRE_PARAMETER_SET;
                sheetParam.Cells[1, 2] = FormValidadorDetalleParameterSet.TBL_PARAM_NOMBRE;
                sheetParam.Cells[1, 3] = FormValidadorDetalleParameterSet.TBL_PARAM_DESCRIPCION;
                sheetParam.Cells[1, 4] = FormValidadorDetalleParameterSet.TBL_PARAM_ESTADO;
                sheetParam.Cells[1, 5] = FormValidadorDetalleParameterSet.TBL_PARAM_DESCRIPCION_VALIDACION;

                int filaParam = 2;
                for (int i = 0; i < listaParameter.Count; i++)
                {
                    LogParameterSet parameter = listaParameter[i];
                    for (int r = 0; r < parameter.listaParam.Count; r++)
                    {
                        LogParam param = parameter.listaParam[r];
                        sheetParam.Cells[filaParam, 1] = parameter.identifierParameterSet;
                        sheetParam.Cells[filaParam, 2] = param.name;
                        sheetParam.Cells[filaParam, 3] = param.textoAyuda;
                        sheetParam.Cells[filaParam, 4] = param.estadoParamDescripcion;
                        sheetParam.Cells[filaParam, 5] = param.mensaje;
                        filaParam++;
                    }
                }

                //mostrar activo a la primera Hoja
                sheetJob.Activate();

                app.ActiveWorkbook.SaveCopyAs(save.FileName.ToString());
                app.ActiveWorkbook.Saved = true;
                app.Quit();
            }
        }
    }
}
