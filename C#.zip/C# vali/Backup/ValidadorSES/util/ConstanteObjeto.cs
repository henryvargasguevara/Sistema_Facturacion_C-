﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    public class ConstanteObjeto
    {
        public const string COD_OBJ_ROUTINE_ACTIVITY = "CJSRoutineActivity-CRoutineActivity";
        // public const string COD_OBJ_TRANS = "CTransformerStage"; //JT
    }
}
