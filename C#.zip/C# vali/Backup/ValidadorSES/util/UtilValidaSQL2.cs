﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using ValidadorSES.modelo;

namespace ValidadorSES.util
{
    class UtilValidaSQL2
    {

    }
}
