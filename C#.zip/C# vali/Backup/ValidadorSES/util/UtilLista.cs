﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    class UtilLista
    {
        public static bool existeCadenaEnLista(string cadena, List<string> lista)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                if (cadena == lista[i])
                {
                    return true;
                }
            }
            return false;
        }

        public static bool existeCadenaEnListaUpperCase(string cadena, List<string> lista)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                if (cadena.ToUpper() == lista[i].ToUpper())
                {
                    return true;
                }
            }
            return false;
        }

        public static string getListaConcatenada(List<string> lista, string delimitador) 
        {
            string concatenado = "";
            for (int i = 0; i<lista.Count; i++)
            {
                if (i == (lista.Count - 1))
                {
                    concatenado += lista[i];
                }
                else {
                    concatenado += lista[i] + delimitador;
                }

            }
            return concatenado;
        }

        public static bool existeCadenaEnArreglo(string cadena, string[] lista)
        {
            for (int i = 0; i < lista.Length; i++)
            {
                if (cadena == lista[i])
                {
                    return true;
                }
            }
            return false;
        }
    }
}
