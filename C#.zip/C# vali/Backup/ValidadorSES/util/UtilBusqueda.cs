﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;

namespace ValidadorSES.util
{
    public class UtilBusqueda
    {
        public static FiltroBusqueda getFiltroByNombre(string nombre, List<FiltroBusqueda> lista) 
        {
            if(lista!=null)
            {
                for (int i = 0; i<lista.Count ; i++) 
                {
                    if (lista[i].stage == nombre)
                    {
                        return lista[i];
                    }
                }
            }

            return null;
        }


        public static bool encontradoStageFiltro(string nombreStage, List<FiltroBusqueda> listaFiltro)
        {
            if (listaFiltro != null)
            {
                for (int i = 0; i < listaFiltro.Count; i++)
                {
                    if (nombreStage == listaFiltro[i].stage)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        public static FiltroBusqueda getStageFiltro(string nombreStage, List<FiltroBusqueda> listaFiltro)
        {
            if (listaFiltro != null)
            {
                for (int i = 0; i < listaFiltro.Count; i++)
                {
                    if (nombreStage == listaFiltro[i].stage)
                    {
                        return listaFiltro[i];
                    }
                }
            }

            return null;
        }

        public static string getMensaje(List<List<string>> listaPropiedad) 
        {
            string mensaje = "";
            if(listaPropiedad != null || listaPropiedad.Count>0)
            {
                for (int i = 0; i<listaPropiedad.Count; i++)
                {
                    if(listaPropiedad[i].Count>0)
                    {
                        for (int j = 0; j<listaPropiedad[i].Count; j++) 
                        {
                            mensaje += listaPropiedad[i][j] + "\r\n";
                        }
                    }
                }
            }

            return mensaje;
        }

    }
}
