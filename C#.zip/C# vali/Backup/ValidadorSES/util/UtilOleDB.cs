﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace ValidadorSES.util
{
    public class UtilOleDB
    {
        public static string getStringOrNullOle(OleDbDataReader reader, int ordinal)
        {
            return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
        }

        public static int getIntOrNullOle(OleDbDataReader reader, int ordinal)
        {
            return reader.IsDBNull(ordinal) ? -1 : reader.GetInt32(ordinal);
        }
    }
}
