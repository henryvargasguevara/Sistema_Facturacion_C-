﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ValidadorSES.form;
using ValidadorSES.util;

namespace ValidadorSES
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (ConstanteSistema.TIPO_PANTALLA_INICIAL == ConstanteSistema.PANTALLA_INICIAL_LOGIN) 
            {
                Application.Run(new FormLogin());
            }
            if (ConstanteSistema.TIPO_PANTALLA_INICIAL == ConstanteSistema.PANTALLA_INICIAL_VALIDADOR)
            {
                //Application.Run(new FormEscogerValidacion());
                Application.Run(new FormLoginGeneral());
            }
            if (ConstanteSistema.TIPO_PANTALLA_INICIAL == ConstanteSistema.PANTALLA_INICIAL_BUSCADOR)
            {
                Application.Run(new FormBuscador());
            }
            //Application.Run(new FormLogin());
            //Application.Run(new FormPrincipal());
            //Application.Run(new FormValidador());
            //Application.Run(new FormObjetoListado());
            //Application.Run(new FormReglaListado());
            //Application.Run(new FormReglaAsignacion());
            //Application.Run(new FormMantenimientoRequerimientoRecursoAsignados());
        }
    }
}
