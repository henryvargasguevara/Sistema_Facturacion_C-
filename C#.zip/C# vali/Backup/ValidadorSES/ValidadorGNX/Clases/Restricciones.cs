﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ValidadorSES.ValidadorGNX.Clases
{
    public class Restricciones
    {
        //public static void ValidaRestricciones( ListBox Lista, string pLinea, string pResultado)
        public static string ValidaRestricciones( ListBox Lista, string pLinea)
        {
            string pResultado;
            string lPalabra;
            int indice;            //Indice para recorrer listado de palabras
            //int indice2;           //Indice para recorrer la cadena 
            int longitud;          //Longitud de la cadena
            //char Caracter;         //Caracter actual
            Boolean flagIniPalabra;
            string PalabraPrueba;
            string letras = "zxcvbnmasdfghjklñqwertyuiopQWERTYUIOPÑLKJHGFDSAZXCVBNM";
            longitud = pLinea.Length;
            flagIniPalabra = true;  //Flag que indica si se está iniciando una palabra.
            pResultado = "";
            //COMPROBAR ESTAR PARTE!!
            //for (indice2 = 0; indice2 < longitud; indice2++)
            //{
                //Caracter = Convert.ToChar(pLinea.Substring(indice2, 1));
                //se busca el primer caracter que sea una letra
                for (int i = 0; i < pLinea.Length; i++)
                {
                    //string at = pLinea[i].ToString();
                    if (letras.IndexOf(pLinea[i], 0) != -1)
                    {
                        if (flagIniPalabra)
                        {
                            flagIniPalabra = false; //actualizamos el flag para indicar que ya hemos revisado esta palabra
                            // Se copia la porción del renglon desde el inicio de la palabra a la variable PalabraPrueba
                            PalabraPrueba = pLinea.Substring(i).ToString().ToUpper().Trim();

                            int indexEs = PalabraPrueba.IndexOf(" ");
                            int indexIg = PalabraPrueba.IndexOf("=");
                            int indexComent = 0;
                            indexComent = pLinea.IndexOf("//");

                            if (indexEs != -1)
                            {
                                PalabraPrueba = PalabraPrueba.Substring(0, PalabraPrueba.IndexOf(" "));
                            }
                            else if (indexIg != -1)
                            {
                                PalabraPrueba = PalabraPrueba.Substring(0, PalabraPrueba.IndexOf("="));
                            }
                            else if (indexComent != -1)
                            {
                                PalabraPrueba = pLinea.Substring(indexComent);
                            }

                            //Recorremos la lista de palabras restrMOingidas
                            for (indice = 0; indice < Lista.Items.Count - 1; indice++)
                            {
                                lPalabra = Lista.Items[indice].ToString().Trim().ToUpper();

                                //Preguntamos si alguna de las palabras restringidas está coincide con el inicio del renglón.
                                if (PalabraPrueba.Replace("'", " ").Trim().Equals(lPalabra.Trim()))
                                {
                                    pResultado = lPalabra;
                                    return pResultado;
                                }
                            }


                        }
                    }
                    else
                    {
                        flagIniPalabra = true;
                    }
                }
                return pResultado;
            //}
        }

        //public static void ValidaFormatoConstante(string pLinea, string pResultado1)
        public static string ValidaFormatoConstante(string pLinea)
        {
           // int indice2;           //Indice para recorrer la cadena
            int longitud;          //Longitud de la cadena
            char Caracter = ' ';         //Caracter actual
            string PalabraPrueba;
            string Estado;
            int Posicion1;
            int Posicion2;
            //int numero;
            string letras = "zxcvbnmasdfghjklñqwertyuiopQWERTYUIOPÑLKJHGFDSAZXCVBNM";
            string numeros = "0123456789";
            longitud = pLinea.Length;
            Regex rgx = new Regex(@"^[0-9]");

            Estado = "INICIAL";
            PalabraPrueba = "";
            string pResultado1 = "";

            //for (indice2 = 0; indice2 < longitud; indice2++)
            //{
               // Caracter =Convert.ToChar(pLinea.Substring(indice2, 1).ToUpper());
                //se busca el primer caracter que sea una letra
                for (int i = 0; i < pLinea.Length; i++)
                {
                    Caracter = pLinea[i];
                    if (letras.IndexOf(pLinea[i], 0) != -1)
                    {                        
                        if (Estado == "INICIAL")
                        {
                            if (Caracter == 'O' || Caracter == 'U' || Caracter == 'D' || Caracter == 'C' || Caracter == 'G')
                            {
                                Estado = "POSUSER";
                                PalabraPrueba = PalabraPrueba + Caracter;
                            }
                            else 
                            {
                                Estado = "POSMAILNOM";
                                PalabraPrueba = PalabraPrueba + Caracter;
                            }
                        }
                        else if (Estado == "POSUSER")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAILNOM")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSNUMERO")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAIL")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                    }
                    else if (numeros.IndexOf(pLinea[i], 0) != -1)
                    {
                        if (Estado == "INICIAL")
                        {
                            Estado = "POSNUMERO";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSUSER")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSNUMERO")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAILNOM")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAIL")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else
                        {
                            Estado = "INICIAL";
                            PalabraPrueba = "";
                        }
                    }
                    else if(Caracter == '@')
                    {
                        if (Estado == "INICIAL")
                        {
                            Estado = "POSMAIL";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSUSER")
                        {
                            Estado = "POSMAIL";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSNUMERO")
                        {
                            Estado = "POSMAIL";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAILNOM")
                        {
                            Estado = "POSMAIL";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAIL")
                        {
                            Estado = "INICIAL";
                            PalabraPrueba = "";
                        }
                        else
                        {
                            Estado = "INICIAL";
                            PalabraPrueba = "";
                        }
                    }
                    else if (Caracter == '_')
                    {
                        if (Estado == "INICIAL")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSUSER")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSNUMERO")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAIL")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAILNOM")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else
                        {
                            Estado = "INICIAL";
                            PalabraPrueba = "";
                        }
                    }
                    else if (Caracter == '.')
                    {
                        if (Estado == "INICIAL")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSUSER")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSNUMERO")
                        {
                            Estado = "POSMAILNOM";
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAIL")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else if (Estado == "POSMAILNOM")
                        {
                            PalabraPrueba = PalabraPrueba + Caracter;
                        }
                        else
                        {
                            Estado = "INICIAL";
                            PalabraPrueba = "";
                        }
                    }
                    else 
                    {
                        if(Estado == "POSUSER")
                        {
                            if (PalabraPrueba.Length == 5 || PalabraPrueba.Length == 6)
                            {
                                pResultado1 = "Posible código de usuario : " + PalabraPrueba;
                                return pResultado1;
                            }
                            else
                            {
                                Estado = "INICIAL";
                                PalabraPrueba = "";
                            }
                        }
                        else if (Estado == "POSNUMERO")
                        {
                            if (PalabraPrueba.Length == 16)
                            {
                                pResultado1 = "Posible Tarjeta de Crédito : " + PalabraPrueba;
                                return pResultado1;
                            }
                            else if (PalabraPrueba.Length == 11)
                            {
                                pResultado1 = "Posible número de RUC : " + PalabraPrueba;
                                return pResultado1;
                            }
                            else if (PalabraPrueba.Length == 8)
                            {
                                //COMPROBAR ESTAR PARTE!!
                            }
                            else if (PalabraPrueba.Length == 14)
                            {
                                pResultado1 = "Posible Rubro : " + PalabraPrueba;
                                return pResultado1;
                            }
                            else
                            {
                                Estado = "INICIAL";
                                PalabraPrueba = "";
                            }
                        }
                        else if (Estado == "POSMAIL")
                        {
                            Posicion1 = PalabraPrueba.IndexOf("@");
                            Posicion2 = PalabraPrueba.LastIndexOf(".");
                            if (!PalabraPrueba.EndsWith("."))
                            {
                                if (Posicion2 > Posicion1)
                                {
                                    if (PalabraPrueba.StartsWith("@"))
                                    {
                                        pResultado1 = "Posible Dominio : " + PalabraPrueba;
                                        return pResultado1;
                                    }
                                    else
                                    {
                                        pResultado1 = "Posible Correo Electrónico : " + PalabraPrueba;
                                        return pResultado1;
                                    }
                                }
                                else
                                {
                                    Estado = "INICIAL";
                                    PalabraPrueba = "";
                                }
                            }
                        }
                        else
                        {
                            Estado = "INICIAL";
                            PalabraPrueba = "";
                        }
                    }
                }
           //}
                if (Estado == "POSNUMERO")
                {
                    if (PalabraPrueba.Length == 16)
                    {
                        pResultado1 = "Posible Tarjeta de Crédito : " + PalabraPrueba;
                        return pResultado1;
                    }
                    else if (PalabraPrueba.Length == 11)
                    {
                        pResultado1 = "Posible número de RUC : " + PalabraPrueba;
                        return pResultado1;
                    }
                    else if (PalabraPrueba.Length == 8)
                    {
                        //COMPROBAR ESTAR PARTE!!
                    }
                    else if (PalabraPrueba.Length == 14)
                    {
                        pResultado1 = "Posible Rubro : " + PalabraPrueba;
                        return pResultado1;
                    }
                }
                else if (Estado == "POSUSER")
                {
                    if (PalabraPrueba.Length == 5 || PalabraPrueba.Length == 6)
                    {
                        pResultado1 = "Posible código de usuario : " + PalabraPrueba;
                        return pResultado1;
                    }
                }
                else if (Estado == "POSMAIL")
                {
                    Posicion1 = PalabraPrueba.IndexOf("@");
                    Posicion2 = PalabraPrueba.LastIndexOf(".");

                    if (!PalabraPrueba.EndsWith("."))
                    {
                        if (Posicion2 > Posicion1)
                        {
                            if (PalabraPrueba.StartsWith("@"))
                            {
                                pResultado1 = "Posible Dominio : " + PalabraPrueba;
                                return pResultado1;
                            }
                            else
                            {
                                pResultado1 = "Posible Correo Electrónico : " + PalabraPrueba;
                                return pResultado1;
                            }
                        }
                    }
                }
                if (pResultado1 == "")
                {
                    //validar división entre cero
                    string linea2;
                    linea2 = pLinea;
                    if (linea2.Contains("/*"))
                    {
                        Posicion1 = linea2.IndexOf("/*");
                        //hay inicio de comentario en bloque
                        if (linea2.Contains("*/"))
                        {
                            //se encontro cierre de comentario.
                            Posicion2 = linea2.IndexOf("*/");
                            linea2 = linea2.Remove(Posicion1, Posicion2 - Posicion1 + 2);
                        }
                        else
                        {
                            //no hay cierre de comentario. Se borra hasta el final de la linea
                            linea2 = linea2.Remove(Posicion1);
                        }
                    }

                    if (linea2.Contains("//"))
                    {
                        Posicion1 = linea2.IndexOf("//");
                        linea2 = linea2.Remove(Posicion1);
                    }

                    while (linea2.Contains("'"))
                    {
                        Posicion1 = 0;
                        Posicion2 = 0;
                        Posicion1 = linea2.IndexOf("'");
                        Posicion2 = linea2.IndexOf("'", Posicion1 + 1);
                        if (Posicion2 > 0)
                        {
                            linea2 = linea2.Remove(Posicion1, Posicion2 - Posicion1 + 1);
                        }
                        else
                        {
                            break;
                        }
                    }

                    if (linea2.Contains("/"))
                    {
                        Posicion1 = linea2.IndexOf("/");
                        if (linea2.Length > 2)
                        {
                            if (linea2.Substring(Posicion1 - 1,2)!= "</")
                            {
                                linea2 = linea2.Substring(Posicion1 + 1).Trim();
                                if (linea2.Length > 0)
                                {
                                    Caracter =Convert.ToChar(linea2.Substring(0, 1).Trim());
                                    //if(numeros)
                                    if (!rgx.IsMatch(Caracter.ToString()))
                                    {
                                        pResultado1 = "Posible división entre cero : " + pLinea.Trim();
                                        return pResultado1;
                                    }
                                }
                            }
                        }
                    }
                }
                return pResultado1;
        }


    }
}
