﻿namespace ValidadorSES.ValidadorGNX.Formularios
{
    partial class rptDurezas2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rptDurezas = new Microsoft.Reporting.WinForms.ReportViewer();
            this.SuspendLayout();
            // 
            // rptDurezas
            // 
            this.rptDurezas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rptDurezas.Location = new System.Drawing.Point(0, 0);
            this.rptDurezas.Name = "rptDurezas";
            this.rptDurezas.Size = new System.Drawing.Size(696, 506);
            this.rptDurezas.TabIndex = 0;
            // 
            // rptDurezas2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 506);
            this.Controls.Add(this.rptDurezas);
            this.MaximizeBox = false;
            this.Name = "rptDurezas2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reporte de Validaciones Gx";
            this.Load += new System.EventHandler(this.rptDurezas2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public Microsoft.Reporting.WinForms.ReportViewer rptDurezas;

    }
}