﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ValidadorSES.ValidadorGNX.Formularios
{
    public partial class MantFechaVencimiento : Form
    {
        SqlConnection cnn = ValidadorGNX.Clases.Conexion.ConexionSQL();
        public string usuario;

        public MantFechaVencimiento()
        {
            InitializeComponent();
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            if (Validar())
            {               
                try
                {
                    DataTable dtFecha = new DataTable();
                    string fch = dtFchaVigencia.Value.ToString();
                    SqlConnection conexion = ValidadorGNX.Clases.Conexion.ConexionSQL();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conexion;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.SP_ins_FechaVig";                                        
                    cmd.Parameters.AddWithValue("@fecha", fch);
                    cmd.Parameters.AddWithValue("@comentario", txtComentario.Text);
                    cmd.Parameters.AddWithValue("@userreg", usuario);
                    conexion.Open();
                    cmd.ExecuteNonQuery();
                    recupearfechaUltVig();
                    MessageBox.Show("Se actualizo la fecha correctamente.", "Fecha Vigencia", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error en: " + ex.Message.ToString());                    
                }
            }
        }

        private void MantFechaVencimiento_Load(object sender, EventArgs e)
        {
            recupearfechaUltVig();            
        }

        private void recupearfechaUltVig()
        {
            txtComentario.Text = null;
            DataTable dtFecha = new DataTable();
            DataTable dt = new DataTable();
            SqlDataAdapter da;
            string sel = null;
            sel = "dbo.SP_Recuperar_FechaVig";
            da = new SqlDataAdapter(sel, cnn);
            da.Fill(dtFecha);
            if (dtFecha.Rows.Count != 0)
            {
                string fecha = dtFecha.Rows[0][0].ToString();
                txtFechaVigencia.Text = Convert.ToDateTime(fecha).ToString("d");
            }
            else
            {
                MessageBox.Show("No se encontro una fecha de vigencia configurada.", "Fecha Vigencia", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool Validar()
        {
            //string fch = dtFchaVigencia.Value.Year.ToString() + dtFchaVigencia.Value.Month.ToString("00") + dtFchaVigencia.Value.Day.ToString().PadLeft(2, "0");
            //string fch = dtFchaVigencia.Value.Year.ToString() + dtFchaVigencia.Value.Month.ToString("00") + dtFchaVigencia.Value.Day.ToString("00");
            //DateTime fch = dtFchaVigencia.Value.Year + dtFchaVigencia.Value.Month + dtFchaVigencia.Value.Day;
            DateTime fch = dtFchaVigencia.Value;
            //string fchActual = DateTime.Now.ToString();
            DateTime fchActual = DateTime.Now;
            bool flag = true;
            string mensaje = "";
            if (fch < fchActual)
            {
                mensaje += "\n" + "-Fecha de vigencia debe ser mayor a la fecha actual";
                flag = false;
            }

            if(txtComentario.Text.Trim() == "")
            {
                mensaje += "\n" + "-Ingrese un comentario";
                flag = false;
            }

            if (flag == false)
            {
                MessageBox.Show(mensaje, "Fecha Vigencia", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return flag;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
