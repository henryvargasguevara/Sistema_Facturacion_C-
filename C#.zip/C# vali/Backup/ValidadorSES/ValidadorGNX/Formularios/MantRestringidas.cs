﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ValidadorSES.ValidadorGNX.Formularios
{
    public partial class MantRestringidas : Form
    {
        SqlConnection cnn = ValidadorGNX.Clases.Conexion.ConexionSQL();

        public MantRestringidas()
        {
            InitializeComponent();
        }

        private void MantRestringidas_Load(object sender, EventArgs e)
        {
            cargarGrilla();
        }

        private void cargarGrilla()
        {
            string sel = "SELECT idRestringidas as Código,descripcion as Palabras FROM TB_RESTRINGIDAS";
            SqlDataAdapter da;
            DataTable dt = new DataTable();
            try
            {
                da = new SqlDataAdapter(sel, cnn);
                da.Fill(dt);
                DataGridView1.DataSource = dt;
                
            }
            catch(Exception)
            {                
                string msj = "ERROR";
                MessageBox.Show(msj);
            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            ValidadorGNX.Formularios.Form1 form1 = new ValidadorSES.ValidadorGNX.Formularios.Form1();
            this.Hide();
            form1.ShowDialog();
            this.Close();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if(txtRestringida.Text != "")
            {
                string restringida = txtRestringida.Text;
                SqlDataAdapter da;
                DataTable dt = new DataTable();
                string sel = "SELECT idRestringidas,descripcion from TB_RESTRINGIDAS WHERE descripcion=" + "'" + restringida + "'";
                try
                {
                    da = new SqlDataAdapter(sel,cnn);
                    da.Fill(dt);
                    if(dt.Rows.Count >0)
                    {
                        string msj = "Ya existe esta Palabra.";
                        MessageBox.Show(msj);
                    }
                    else
                    {
                        string insertar = "INSERT INTO TB_RESTRINGIDAS VALUES(" + "'" + restringida + "'" + ")";
                        da = new SqlDataAdapter(insertar, cnn);
                        da.Fill(dt);
                        string msj = "Registró exitosamente";
                        MessageBox.Show(msj);
                        cargarGrilla();
                    }
                }
                catch(Exception)
                {
                    string msj = "ERROR";
                    MessageBox.Show(msj);
                }
            }
            else
            {
                string msj = "Debe ingresar un valor";
                MessageBox.Show(msj);
            }
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int variable = 0;
                variable = Convert.ToInt32(DataGridView1[0, DataGridView1.CurrentRow.Index].Value);
                if (variable != 0)
                {
                    lblCodigo.Text = variable.ToString();
                    string variable1 = DataGridView1[1,DataGridView1.CurrentRow.Index].Value.ToString();
                    txtRestringida.Text = variable1;
                }
            }
            catch(Exception)
            {
                string msj = "Debe seleccionar un Item de la Lista";
                MessageBox.Show(msj);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            string valor = txtRestringida.Text;
            if(MessageBox.Show("Esta seguro de Eliminar el siguiente Item :" + valor.ToUpper() + "","¿Eliminar?",MessageBoxButtons.YesNo)== DialogResult.Yes)
            {
                int restringida = Convert.ToInt32(lblCodigo.Text);
                string eliminar = "DELETE FROM TB_RESTRINGIDAS WHERE idRestringidas =" + restringida.ToString() + "";
                SqlDataAdapter da;
                DataTable dt = new DataTable();
                try
                {
                    da = new SqlDataAdapter(eliminar,cnn);
                    da.Fill(dt);
                    string msj = "Se eliminó satisfactoriamente";
                    MessageBox.Show(msj);
                    cargarGrilla();
                }
                catch(Exception)
                {
                    string msj = "No se pudo completar la Transacción";
                    MessageBox.Show(msj);
                }
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtRestringida.Text = "";
            lblCodigo.Text = "";
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            string restringidas = txtRestringida.Text;
            int codigo = Convert.ToInt32(lblCodigo.Text);
            string actualizar = "UPDATE TB_RESTRINGIDAS SET descripcion=" + "'" + restringidas + "'" + " WHERE idRestringidas=" + codigo.ToString() + "";
            SqlDataAdapter da;
            DataTable dt = new DataTable();

            try
            {
                da = new SqlDataAdapter(actualizar,cnn);
                da.Fill(dt);
                string msj = "Registro Actualizado satisfactoriamente";
                MessageBox.Show(msj);
                cargarGrilla();
            }
            catch(Exception)
            {
                string msj  = "No se pudo completar la Transacción";
                MessageBox.Show(msj);
            }
        }
    }
}
