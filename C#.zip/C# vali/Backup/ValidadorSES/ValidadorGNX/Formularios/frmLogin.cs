﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ValidadorSES.ValidadorGNX.Formularios
{
    public partial class frmLogin : Form
    {
        SqlConnection cnn = ValidadorGNX.Clases.Conexion.ConexionSQL();
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuarioLog.Text.ToUpper();
            string clave = txtPassword.Text;
            //string sel = "SELECT logueo,contraseña,usuario FROM TB_USUARIOS where logueo '" + usuario.ToUpper + "'and contraseña=" + "'" + clave + "'" + "";
            string sel = "SELECT logueo,contraseña,usuario from TB_USUARIOS where logueo = '" + usuario.ToUpper().ToString() + "' and contraseña = '" + clave.ToString() + "'";
            DataTable dt = new DataTable();
            SqlDataAdapter da;
            //try
            //{
                da = new SqlDataAdapter(sel, cnn);
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    DataTable dtFecha = new DataTable();
                    sel = "dbo.SP_Recuperar_FechaVig";
                    da = new SqlDataAdapter(sel, cnn);
                    da.Fill(dtFecha);
                    if (dtFecha.Rows.Count != 0)
                    {
                        //DateTime fecha = Convert.ToDateTime(dtFecha.Rows[0].ToString());
                        DateTime fecha = Convert.ToDateTime(dtFecha.Rows[0][0].ToString());
                        fecha = Convert.ToDateTime(fecha.ToString("d"));
                        DateTime fechaActual = Convert.ToDateTime(DateTime.Now.ToString("d"));
                        int x = DateTime.Compare(fechaActual, fecha);
                        if (x != 1)
                        {
                            ValidadorGNX.Formularios.Form1 Form1 = new ValidadorSES.ValidadorGNX.Formularios.Form1();
                            Form1.referencia = usuario;
                            this.Hide();
                            Form1.ShowDialog();
                            this.Close();
                        }
                        else
                        {
                            if (dt.Rows[0][2].ToString().ToUpper() == "ADMINISTRADOR")
                            {
                                string msj = "El sistema caduco el " + fecha.ToShortDateString() + "." + "\n" + "Actualize la fecha de vigencia.";
                                MessageBox.Show(msj, "Sistema Caducado", MessageBoxButtons.OK, MessageBoxIcon.Information);                                
                                ValidadorGNX.Formularios.MantFechaVencimiento mantV = new MantFechaVencimiento();
                                this.Hide();
                                mantV.usuario = usuario;
                                mantV.ShowDialog();
                                this.Close();
                            }
                            else
                            {
                                string msj = "El sistema caduco el " + fecha.ToShortDateString() + "." + "\n" + "Ponganse en contacto con el administrador.";
                                MessageBox.Show(msj, "Sistema Caducado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();
                            }
                        }
                    }
                    else
                    {
                        ValidadorGNX.Formularios.Form1 Form1 = new ValidadorSES.ValidadorGNX.Formularios.Form1();
                        this.Hide();
                        Form1.ShowDialog();
                        this.Close();
                    }
                }
                else
                {
                    string msj = "USUARIO O PASSWORD INVALIDO";
                    MessageBox.Show(msj);
                }
            //}
            //catch (SqlException ex)
            //{
            //    string msj = null;
            //    if (ex.Number == 2)
            //    {
            //        msj = "Error en Conexion";
            //    }
            //    else
            //    {
            //        msj = ex.Message;
            //    }
            //    MessageBox.Show(msj);
            //}
            //catch (Exception)
            //{
            //    string msj = "Ocurrio un Error durante el Proceso de Login";
            //    MessageBox.Show(msj);
            //}
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            this.txtUsuarioLog.Focus();
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                btnIngresar_Click(null,null);
            }
        }
    }
}
