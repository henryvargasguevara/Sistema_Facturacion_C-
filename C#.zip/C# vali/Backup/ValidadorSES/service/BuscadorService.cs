﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using ValidadorSES.util;

namespace ValidadorSES.service
{
    public class BuscadorService
    {
        public static ResultadoBusqueda getResultadoBusquedaByNombreStage(string keyword, LogDSX dsx,
            bool busquedaExacta, bool omitirMayMin, List<FiltroBusqueda> listaFiltro, bool filtroByNombreStage) 
        {
            ResultadoBusqueda rb = new ResultadoBusqueda();

            List<LogJob> listaJob = dsx.listaJob;
            for (int i = 0; i<listaJob.Count; i++) 
            {
                LogJob job = listaJob[i];
                List<LogStage> listaStage = job.listaStage;
                
                ResultadoJob rjob = new ResultadoJob();
                rjob.job = job;
                rjob.nombreJob = job.identifierJob;
                rjob.tipoJob = job.objeto.nombre;
                rjob.rutaJob = job.category;
              
                for (int s = 0; s<listaStage.Count; s++) 
                {
                    LogStage stage = listaStage[s];
                    
                    ResultadoStage rstage = new ResultadoStage();
                    rstage.stage = stage;
                    rstage.tipoStage = stage.objeto.nombre;
                    rstage.nombreStage = stage.nameStage;
                    
                    //filtro por nombre de stage
                    if (filtroByNombreStage && encontroResultado(stage.nameStage, keyword, busquedaExacta, omitirMayMin))
                    {
                        ResultadoFiltro rf = new ResultadoFiltro();
                        rf.resultado = stage.nameStage;
                        rf.descripcionFiltro = ConstanteBusqueda.PROP_STAGE_NOMBRE;
                        rf.stage = rstage;

                        rstage.listaResultado.Add(rf);
                    }

                    //Los demás filtros por cada stage
                    if (UtilBusqueda.encontradoStageFiltro(stage.objeto.nombre, listaFiltro))
                    {
                        FiltroBusqueda fb = UtilBusqueda.getStageFiltro(stage.objeto.nombre, listaFiltro);
                        List<FiltroBusqueda> lfb = fb.listaFiltroPropiedad;

                        for (int f = 0; f < lfb.Count; f++)
                        {
                            if (fb.check)
                            {
                                switch (rstage.tipoStage)
                                {
                                    case ConstanteDataStage.DES_DB2:

                                        if (lfb[f].check && lfb[f].codigo == ConstanteBusqueda.PROP_STAGE_DB_TABLA)
                                        {
                                            for (int t = 0; t < stage.stageBaseDato.listaTabla.Count; t++)
                                            {
                                                if (encontroResultado(stage.stageBaseDato.listaTabla[t], keyword, busquedaExacta, omitirMayMin))
                                                {
                                                    //listaPropiedad.Add(stage.stageBaseDato.listaTabla[t]);

                                                    ResultadoFiltro rf = new ResultadoFiltro();
                                                    rf.resultado = stage.stageBaseDato.listaTabla[t];
                                                    rf.descripcionFiltro = ConstanteBusqueda.PROP_STAGE_DB_TABLA;
                                                    rf.stage = rstage;

                                                    rstage.listaResultado.Add(rf);
                                                }
                                            }
                                        }

                                        break;
                                    case ConstanteDataStage.DES_DATA_SET:

                                        if (lfb[f].check && lfb[f].codigo == ConstanteBusqueda.PROP_STAGE_ARCHIVO_FILE)
                                        {

                                            if (encontroResultado(stage.stageArchivo.fileName, keyword, busquedaExacta, omitirMayMin))
                                            {
                                                //listaPropiedad.Add(stage.stageArchivo.fileName);
                                                ResultadoFiltro rf = new ResultadoFiltro();
                                                rf.resultado = stage.stageArchivo.fileName;
                                                rf.descripcionFiltro = ConstanteBusqueda.PROP_STAGE_ARCHIVO_FILE;
                                                rf.stage = rstage;

                                                rstage.listaResultado.Add(rf);
                                            }
                                        }

                                        break;
                                    case ConstanteDataStage.DES_SEQUENTIAL_FILE:

                                        if (lfb[f].check && lfb[f].codigo == ConstanteBusqueda.PROP_STAGE_ARCHIVO_FILE)
                                        {
                                            if (encontroResultado(stage.stageArchivo.fileName, keyword, busquedaExacta, omitirMayMin))
                                            {
                                                //listaPropiedad.Add(stage.stageArchivo.fileName);
                                                ResultadoFiltro rf = new ResultadoFiltro();
                                                rf.resultado = stage.stageArchivo.fileName;
                                                rf.descripcionFiltro = ConstanteBusqueda.PROP_STAGE_ARCHIVO_FILE;
                                                rf.stage = rstage;

                                                rstage.listaResultado.Add(rf);
                                            }
                                        }

                                        break;
                                }
                            }

                            
                        }                      
                    }

                    if (rstage.listaResultado != null && rstage.listaResultado.Count>0)
                    {
                        rjob.listaStage.Add(rstage);
                    }
                }

                if (rjob.listaStage != null && rjob.listaStage.Count>0)
                {
                    rb.listaJob.Add(rjob);
                }
            }

            //generar TotalResultados
            generarTotalResultado(rb);

            return rb;        
        }

        private static void generarTotalResultado(ResultadoBusqueda rb)
        {
            int totalResultado = 0;
            int totalJob = 0;
            int totalStage = 0;
            int totalParameterSet = 0;
            int totalRoutine = 0;

            if(rb.listaJob!=null)
            {
                totalJob = rb.listaJob.Count;
                for (int j = 0; j < totalJob; j++)
                {
                    ResultadoJob rsJob = rb.listaJob[j];
                    int numStage = rsJob.listaStage.Count;
                    totalStage += numStage;
                    for (int s = 0; s < numStage; s++) 
                    {
                        ResultadoStage rsStage = rsJob.listaStage[s];
                        int numRes = rsStage.listaResultado.Count;
                        totalResultado += numRes;
                    }

                }
            }

            rb.totalResultado = totalResultado;
            rb.totalJob = totalJob;
            rb.totalStage = totalStage;
            rb.totalParameterSet = totalParameterSet;
            rb.totalRoutine = totalRoutine;
        }

        private static bool encontroResultado(string palabra, string keyword, bool busquedaExacta, bool omitirMayMin)
        {
            if (busquedaExacta)
            {
                if (omitirMayMin)
                {
                    return palabra.ToUpper() == keyword.ToUpper();
                }
                else 
                {
                    return palabra == keyword;
                }
            }
            else
            {
                if (omitirMayMin)
                {
                    return palabra.ToUpper().Contains(keyword.ToUpper());
                }
                else 
                {
                    return palabra.Contains(keyword);
                }
            }
        }

        public static List<FiltroBusqueda> getListaFiltroBusquedaStage() 
        {
            List<FiltroBusqueda> lista = new List<FiltroBusqueda>();

            ObjetoDAO odao = new ObjetoDAO();
            List<Objeto> listaStage = odao.getListaObjetoStage();

            List<FiltroBusqueda> lista1 = new List<FiltroBusqueda>();
            List<FiltroBusqueda> lista2 = new List<FiltroBusqueda>();
            
            for (int i = 0; i<listaStage.Count; i++) 
            {
                FiltroBusqueda filtroStage = new FiltroBusqueda();
                filtroStage.codigo = listaStage[i].nombre;
                filtroStage.stage = listaStage[i].nombre;
                filtroStage.check = true;

                switch (listaStage[i].nombre)
                {
                    case ConstanteDataStage.DES_DB2:

                        filtroStage.listaFiltroPropiedad = ConstanteBusqueda.getListaPropiedadesFiltroStageBD(filtroStage);                        
                        lista1.Add(filtroStage);

                        break;
                    case ConstanteDataStage.DES_DATA_SET:

                        filtroStage.listaFiltroPropiedad = ConstanteBusqueda.getListaPropiedadesFiltroStageArchivo(filtroStage);
                        lista1.Add(filtroStage);

                        break;
                    case ConstanteDataStage.DES_SEQUENTIAL_FILE:

                        filtroStage.listaFiltroPropiedad = ConstanteBusqueda.getListaPropiedadesFiltroStageArchivo(filtroStage);
                        lista1.Add(filtroStage);

                        break;
                    default:

                        lista2.Add(filtroStage);
                        
                        break;
                }
            }

            lista.AddRange(lista1);
            lista.AddRange(lista2);

            return lista;
        }

    }
}
