﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.service.proceso;
using ValidadorSES.util;
using ValidadorSES.service;

namespace ValidadorSES.service.validador
{
    class ValidadorStageDB2
    {        
        /**
         *  Validación
         **/
        public static string getValidacionDB2BeforeAfter(LogStage s)
        {
            string obs = "";

            if (s.stageBaseDato.beforeAfter == ConstanteDataStage.PROPIEDAD_DB2_BEFORE_AFTER_SI)
            {
                obs = ConstanteCadena.MSG_VAL_STAGE_DB2_BEFORE_AFTER;
            }

            return obs;
        }

        /**
         *  Validación
         **/
        public static string getValidacionDB2KeepConductorConnectionAlive(LogStage s)
        {
            string obs = "";

            if (s.stageBaseDato.keepConductorConnectionAlive == ConstanteDataStage.PROPIEDAD_DB2_KEEP_CONDUCTOR_CONNECTION_ALIVE_SI)
            {
                obs = ConstanteCadena.MSG_VAL_STAGE_DB2_KEEP_CONDUCTOR_CONNECTION_ALIVE;
            }

            return obs;
        }

        public static string getValidacionArraySize(LogStage s)
        {
            string obs = "";
            if (s.stageBaseDato.arraySize != ConstanteDataStage.PROPIEDAD_DB2_ARRAY_SIZE && s.stageBaseDato.arrayZizeModidy != ConstanteDataStage.PROPIEDAD_DB2_ARRAY_SIZE)
            {
                obs = ConstanteCadena.MSG_VAL_STAGE_DB2_ARRAY_SIZE;
            }
            return obs;
        }

        public static string getValidacionRecordCount(LogStage s)
        {
            string obs = "";

            if (s.stageBaseDato.recordCount != ConstanteDataStage.PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO && s.stageBaseDato.recordCountModidy != ConstanteDataStage.PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO)
            {
                obs = ConstanteCadena.MSG_VAL_STAGE_DB2_RECORD_COUNT_PERMITIDO;
            }
            return obs;
        }

        public static string getValidacionLockWaitMode(LogStage s)
        {
            string obs = "";

            if (s.stageBaseDato.LockWaitMode != ConstanteDataStage.PROPIEDAD_DB2_LOCKWAITMODE && s.stageBaseDato.LockWaitModeModify != ConstanteDataStage.PROPIEDAD_DB2_LOCKWAITMODE)
            {
                obs = ConstanteCadena.MSG_VAL_STAGE_DB2_LOCK_WAIT_MODE;
            }
            return obs;
        }

        public static string getValidacionDB2ProbandoPKenDU(LogStage s, List<LogJob> listaJobDSX)
        {
            bool acaDejo = s.job.probandoPKJob;
            bool acadejo2 = s.job.stageDB2DuJob;
            string viendo = s.job.vamosviendo;
            string obs = "";

            if (s.job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_DED) || s.job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_ST))
                {
                        if (acaDejo && acadejo2)
                        {
                            obs = "Se encuentra activado el check de PK en tabla DU " + ConstanteChk.BP1;                            
                        }
                        s.job.probandoPKJob = false;
                        s.job.stageDB2DuJob = false;                    
                }
            return obs;

        }



        /**
         *  Validación
         **/
        public static string getValidacionDB2SentenciaDelete(LogStage s, List<LogJob> listaJobDSX)
        {
            if (s.stageBaseDato.writeMode == ConstanteDataStage.PROPIEDAD_DB2_WRITE_MODE_DELETE)
            {
                //lógica de Procedimiento de eliminación especial de data
                if (s.job.identifierJob.StartsWith(ConstanteDataStage.PREF_JOB_DEL_WBTL_NOMBRE_TABLA))
                {
                    return getValidacionEliminacionEspecialData(s, listaJobDSX);
                    //  return getValidacionTransformerStg(s, listaJobDSX);            
                }

                return ConstanteCadena.MSG_VAL_STAGE_DB2_WRITE_MODE_DELETE;
            }

            if (s.stageBaseDato.writeMode == ConstanteDataStage.PROPIEDAD_DB2_WRITE_MODE_DELETE_THEN_INSERT)
            {
                return ConstanteCadena.MSG_VAL_STAGE_DB2_WRITE_MODE_DELETE_THEN_INSERT;
            }

            for (int i = 0; i < s.stageBaseDato.listaSQLValida.Count; i++)
            {
                if (s.stageBaseDato.listaSQLValida[i].ToUpper().Contains("DELETE"))
                {
                    return ConstanteCadena.MSG_VAL_STAGE_DB2_SENTENCIA_DELETE;
                }
            }

            return "";
        }

        private static string getValidacionTransformerStg(LogStage stage, List<LogJob> listaJobDSX)
        {
            string validacion = "";

            List<LogJob> jobStg = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_PROC_STG, listaJobDSX);

            if (jobStg.Count != 0)
            {
                validacion = "si hay jobs de stg";
            }
            else
            {
                validacion = "no hay";
            }

            return validacion;
        }



        private static string getValidacionEliminacionEspecialData(LogStage stage, List<LogJob> listaJobDSX) 
        {
            string validacion = "";

            List<LogJob> listaJobByCategory = UtilDataStage.getListaJobByCategory(stage.job.category, listaJobDSX);

            List<LogJob> jobDelRbtl = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_JOB_DEL_RBTL_NOMBRE_TABLA, listaJobByCategory);
            List<LogJob> jobDelWbtl = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_JOB_DEL_WBTL_NOMBRE_TABLA, listaJobByCategory);
            List<LogJob> jobSeqDel = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_JOB_SEQ_DEL_NOMBRE_TABLA, listaJobByCategory);

            //validacion de DEL_RBTL_NOMBRE_TABLA
            if (jobDelRbtl.Count == 0)
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_RBTL_NO_EXISTE);
            }
            else {
                if (jobDelRbtl.Count != 1)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_RBTL_MUCHOS);
                }
            }

            //validacion de DEL_WBTL_NOMBRE_TABLA
            if (jobDelWbtl.Count == 0)
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_WBTL_NO_EXISTE);
            }
            else
            {
                if (jobDelWbtl.Count == 1)
                {
                    if (stage.stageBaseDato.recordCount != ConstanteDataStage.PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO && stage.stageBaseDato.recordCountModidy != ConstanteDataStage.PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO )
                    {
                        validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_RECORD_COUNT_PERMITIDO);
                    }

                    if(stage.stageBaseDato.autoCommitMode != ConstanteDataStage.PROPIEDAD_DB2_AUTO_COMMIT_OFF)
                    {
                        validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_AUTO_COMMIT_OFF);
                    }
                }
                else
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_WBTL_MUCHOS);
                }
            }

            //validacion de SEQ_DEL_NOMBRE_TABLA
            if (jobSeqDel.Count == 0)
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_SEQ_DEL_NO_EXISTE);
            }
            else
            {
                if (jobSeqDel.Count != 1)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_SEQ_DEL_MUCHOS);
                }
            }

            return validacion;                
        }


        private static string getValidacionEliminacionEspecialDataProbando(LogStage stage, List<LogJob> listaJobDSX)
        {
            string validacion = "";

            List<LogJob> listaJobByCategory = UtilDataStage.getListaJobByCategory(stage.job.category, listaJobDSX);

          //  List<LogJob> jobDelRbtl = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_JOB_DEL_RBTL_NOMBRE_TABLA, listaJobByCategory);
          //  List<LogJob> jobDelWbtl = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_JOB_DEL_WBTL_NOMBRE_TABLA, listaJobByCategory);
          //  List<LogJob> jobSeqDel = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_JOB_SEQ_DEL_NOMBRE_TABLA, listaJobByCategory);
            List<LogJob> jobDED = UtilDataStage.getJobByStartIdentifier(ConstanteDataStage.PREF_STAGING_DED, listaJobByCategory);
            //validacion de DEL_RBTL_NOMBRE_TABLA
            if (jobDED.Count > 0)
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_RBTL_NO_EXISTE);

            }                       

            return validacion;
        }



        /**
         *  Validación
         **/
        public static string getValidacionDataStageOrchestrate(LogStage s)
        {
            for (int i = 0; i<s.stageBaseDato.listaSQLValida.Count; i++)
            {
                if (s.stageBaseDato.listaSQLValida[i].ToUpper().Contains("ORCHESTRATE."))
                {
                    return ConstanteCadena.MSG_VAL_STAGE_DB2_OPERADOR_ORCHESTRATE;
                }
            }

            return "";
        }


        //public static string getValidacionDB2Count2(LogStage s)
        //{
        //    //string aa = s.stageBaseDato.recordCount;
        //    //string bb = ConstanteDataStage.PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO;
        //    if (s.stageBaseDato.recordCount != ConstanteDataStage.PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO)                        
        //    {
        //        return ConstanteCadena.MSG_VAL_STAGE_DB2_RECORD_COUNT_PERMITIDO;
        //    }
        //    return "";
        //}



        
        /**
         *  Validación
         **/
        public static string getValidacionDB2Comentarios(LogStage s)
        {
            if(s.stageBaseDato.estaComentario)
            {
                return ConstanteCadena.MSG_VAL_STAGE_DB2_COMENTARIOS;
            }

            return "";
        }

        /**
         *  Validación
         **/
        public static string getValidacionDB2SelectAll(LogStage s)
        {
            if (s.stageBaseDato.listaSQLValida != null)
            {
                List<string> listaSQL = s.stageBaseDato.listaSQLValida;
                for (int i = 0; i < listaSQL.Count; i++)
                {
                    string cadenaValidaSQL = listaSQL[i];
                    if (cadenaValidaSQL.Contains("*"))
                    {
                        string[] arrayCadena = cadenaValidaSQL.Split('*');
                        if (arrayCadena != null && arrayCadena.Length > 0)
                        {
                            for (int j = 0; j < arrayCadena.Length; j++)
                            {
                                string select = arrayCadena[j].Trim().ToUpper();
                                if (select.EndsWith("SELECT"))
                                {
                                    return ConstanteCadena.MSG_VAL_STAGE_DB2_SELECT_ALL;
                                }
                            }
                        }
                    }
                }
            }
                return "";
            }
        
        
        /**
         *  Validación
         **/
        public static string getValidacionDB2ParametrizacionEsquema(LogStage s)
        {
            string validacion = "";
            if (s.stageBaseDato.listaTabla != null)
            {
                

                List<string> listaTabla = s.stageBaseDato.listaTabla;

                for (int i = 0; i < listaTabla.Count; i++)
                {
                    validacion = "";
                    string lineaTabla = listaTabla[i].Trim();

                    validacion = getValidacionPropiedadEsquemaParametrizada(lineaTabla,
                        ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_PARAMETER_SET_INCORRECTO,
                        ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_VARIABLE_INCORRECTO,
                        ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA,
                        ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_NO_EXISTE,
                        ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_TABLA_INCORRECTO);

                    if (validacion != "")
                    {
                        return validacion;
                    }
                }
            }
            return validacion;
        }

        public static string getValidacionDB2LimiteResultado(LogStage s) 
        {
            string validacion = "";
            
            for (int i = 0; i < s.stageBaseDato.listaSQLValida.Count; i++)
            {
                if (s.stageBaseDato.listaSQLValida[i].ToUpper().Contains("FETCH FIRST"))
                {
                    return ConstanteCadena.MSG_VAL_STAGE_DB2_LIMITE_RESULTADO;
                }
            }

            return validacion;
        }

        public static string getValidacionDB2ParametrizacionConexion(LogStage s)
        {
            string validacion = "";
            string validacionDatabase = getValidacionPropiedadParametrizada(s.stageBaseDato.database,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE_PARAMETER_SET_INCORRECTO,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE_VARIABLE_INCORRECTO,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE_NO_EXISTE);

            string validacionUsername = getValidacionPropiedadParametrizada(s.stageBaseDato.username,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME_PARAMETER_SET_INCORRECTO,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME_VARIABLE_INCORRECTO,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME_NO_EXISTE);

            string validacionPassword = getValidacionPropiedadParametrizada(s.stageBaseDato.password,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD_PARAMETER_SET_INCORRECTO,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD_VARIABLE_INCORRECTO,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD,
                    ConstanteCadena.MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD_NO_EXISTE);

            validacion = ValidadorService.agregarRespuesta(validacion, validacionDatabase);
            validacion = ValidadorService.agregarRespuesta(validacion, validacionUsername);
            validacion = ValidadorService.agregarRespuesta(validacion, validacionPassword);

            return validacion;
        }

        private static string getValidacionPropiedadEsquemaParametrizada(string parametro, string error01, string error02, string error03, string error04, string error05) 
        {
            string validacion = "";
            string lineaTabla = parametro.Trim();

            if (lineaTabla.Contains("#"))
            {
                string[] arreglo = lineaTabla.Split('.');
                if (arreglo.Length <= 3)
                {
                    if (arreglo.Length == 3)
                    {
                        //dos puntos
                        string parameterSet = arreglo[0];
                        string variable = arreglo[1];
                        string tabla = arreglo[2];

                        if (!parameterSet.StartsWith("#"))
                        {
                            validacion = error01;
                        }

                        if (!variable.StartsWith("$") && variable.EndsWith("#"))
                        {
                            validacion = error02;
                        }
                    }
                    else
                    {
                        if (arreglo.Length == 2)
                        {
                            //un punto
                            validacion = error03;
                        }
                        else
                        {
                            //no hay punto
                            validacion = error04;
                        }
                    }
                }
                else
                {
                    validacion = error05;
                }
            }
            else
            {
                validacion = error04;
            }

            return validacion;
        }
        private static string getValidacionPropiedadParametrizada(string parametro, string error01, string error02, string error03, string error04)
        {
            string validacion = "";

            if (parametro != null)
            {                
                string lineaTabla = parametro.Trim();

                if (lineaTabla.Contains("#"))   //#PARM_STG_DB2_CSF.$PARM_CSF_STG_DB2_USERNAME#
                {
                    string[] arreglo = lineaTabla.Split('.');
                    if (arreglo.Length <= 2)
                    {
                        if (arreglo.Length == 2) //#PARM_STG_DB2_CSF    $PARM_CSF_STG_DB2_USERNAME#
                        {
                            //dos puntos
                            string parameterSet = arreglo[0];
                            string variable = arreglo[1];

                            if (!parameterSet.StartsWith("#"))
                            {
                                validacion = error01;
                            }

                            if (!variable.StartsWith("$") && variable.EndsWith("#"))
                            {
                                validacion = error02;
                            }
                        }
                        else
                        {
                            if (arreglo.Length == 1)
                            {
                                //un punto
                                validacion = error03;
                            }
                        }
                    }
                    else
                    {
                        validacion = error03;
                    }
                }
                else
                {
                    validacion = error04;
                }
            }

            return validacion;
        }


        /**
         *  Validación
         **/
        public static string getValidacionDB2FuncionErrorSQL(LogStage s)
        {
            string validacion = "";
            List<string> listaSQL = s.stageBaseDato.listaSQLValida;

            for (int i = 0; i < listaSQL.Count; i++)
            {

                validacion = getValidacionContieneFuncionErrorSQL(listaSQL[i]);
                if (validacion != "")
                {
                    return validacion;
                }
            }

            return validacion;
        }

        public static string getValidacionDB2FuncionObsSQL(LogStage s)
        {
            string validacion = "";
            List<string> listaSQL = s.stageBaseDato.listaSQLValida;

            for (int i = 0; i < listaSQL.Count; i++)
            {

                validacion = getValidacionContieneFuncionObsSQL(listaSQL[i]);
                if (validacion != "")
                {
                    return validacion;
                }
            }

            return validacion;
        }

        /**
         *  Validación
         **/
        public static string getValidacionDB2OperadorSQL(LogStage s)
        {
            string validacion = "";
            List<string> listaSQL = s.stageBaseDato.listaSQLValida;

            for (int i = 0; i < listaSQL.Count; i++)
            {

                validacion = getValidacionContieneOperadorSQL(listaSQL[i]);
                if (validacion != "")
                {
                    return validacion;
                }
            }

            return validacion;            
        }

        private static string getValidacionContieneFuncionErrorSQL(string sql)
        {
            string msg = "";
            string SA = "";
            List<string> listaFunciones = new List<string>();
            listaFunciones.Add("CAST");
            listaFunciones.Add("TRIM");
            listaFunciones.Add("SMALLINT");
            listaFunciones.Add("TOCHAR");
            listaFunciones.Add("SUBSTRING");
            listaFunciones.Add("COALESCE");
            listaFunciones.Add("SUBSTR");
            //listaFunciones.Add("");

            string sqlValido = sql;
            sqlValido = sqlValido.Replace(" ", "");

            for (int i = 0; i < listaFunciones.Count; i++)
            {
                if (sqlValido.ToUpper().Contains(listaFunciones[i].ToUpper() + "("))
                {
                  //  return ConstanteCadena.MSG_VAL_STAGE_DB2_FUNCTION + " " + listaFunciones[i].ToUpper();
                    SA = ConstanteCadena.MSG_VAL_STAGE_DB2_FUNCTION + " " + listaFunciones[i].ToUpper();
                    return SA;
                }
            }

            return msg;
        }

        private static string getValidacionContieneFuncionObsSQL(string sql)
        {
            string msg = "";
            List<string> listaFunciones = new List<string>();
            listaFunciones.Add("MAX");
            listaFunciones.Add("MIN");
            //listaFunciones.Add("");

            string sqlValido = sql;
            sqlValido = sqlValido.Replace(" ", "");

            for (int i = 0; i < listaFunciones.Count; i++)
            {
                if (sqlValido.ToUpper().Contains(listaFunciones[i].ToUpper() + "("))
                {
                    return ConstanteCadena.MSG_VAL_STAGE_DB2_FUNCTION + " " + listaFunciones[i].ToUpper();
                }
            }

            return msg;
        }

        public static string getValidacionContieneOperadorSQL(string sql)
        {
            string msg = "";
            List<string> listaOperador = new List<string>();
            listaOperador.Add("JOIN");
            //listaFunciones.Add("");

            for (int i = 0; i < listaOperador.Count; i++)
            {
                if (sql.ToUpper().Contains((" " + listaOperador[i] + " ").ToUpper()))
                {
                    return ConstanteCadena.MSG_VAL_STAGE_DB2_OPERADOR + " " + listaOperador[i].ToUpper() + "[CHK 19]";
                }
            }

            return msg;
        }



    }
}
