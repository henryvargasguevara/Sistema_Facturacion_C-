﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.service.proceso;
using ValidadorSES.util;
using ValidadorSES.service;

namespace ValidadorSES.service.validador
{
    class ValidadorSQL
    {

        public static string getValidacionScriptSQLNoPermitido(string sql)
        {
            string msj = "";
            List<string> ListaNoPermitida = new List<string>();
            ListaNoPermitida.Add("GRANT");
            ListaNoPermitida.Add("DROP");
            ListaNoPermitida.Add("INSERT");
            ListaNoPermitida.Add("UPDATE");
            ListaNoPermitida.Add("DELETE");

            for (int i = 0; i < ListaNoPermitida.Count; i++)
            {
                if (sql.ToUpper().Contains(ListaNoPermitida[i].ToUpper()))
                {
                    //mensaje += "EL SCRIPT CONTIENE " + ListaNoPermitida[i].ToUpper();
                    return ConstanteCadena.MSG_VAL_STAGE_DB2_FUNCTION + " " + ListaNoPermitida[i].ToUpper() + "[CHK 19]";
                }
            }

            return msj;
        }


    }
}
