﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.service.proceso;
using ValidadorSES.util;
using ValidadorSES.service;

namespace ValidadorSES.service.validador
{
    class ValidadorStageAggregator
    {
        public static string getValidacionOpcionSort(LogStage s)
        {
            string obs = "";

            if (s.stageAggregator.method != ConstanteDataStage.PROPIEDAD_AGGREGATOR_METHOD)
            {
                obs = ConstanteCadena.MSG_VAL_STAGE_PROPIEDAD_METHOD;
            }
            return obs;
        }
    }
}
