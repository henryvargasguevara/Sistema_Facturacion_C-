﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.service;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.service.validador
{
    class ValidadorStageArchivo
    {
        public static string getValidacionExistenciaArchivo(LogStage stage)
        {
            //si el archivo contiene salto de linea, no validar
            if (stage.stageArchivo.fileName == UtilArchivo.VALUE_SALTO_LINEA)
            {
                return ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_SALTO_LINEA;
            }

            string obs = "";
            string archivoInternoStage = ValidadorStageArchivo.getArchivoSinExtension(stage.stageArchivo.fileName);

            if (archivoInternoStage == "")
            {
                obs = ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_INVALIDO;
            }

            return obs;
        }

        public static string getValidacionExtensionArchivo(LogStage stage)
        {
            string obs = "";
            string extension = null;

            //si el archivo contiene salto de linea, no validar
            if (stage.stageArchivo.fileName == UtilArchivo.VALUE_SALTO_LINEA)
            {
                return "";
            }

            if (stage.objeto.type == ConstanteDataStage.TIPO_DATA_SET)
            {
                extension = UtilArchivo.EXT_DATASET;
            }

            if (extension != null)
            {
                string ext = ValidadorStageArchivo.getExtension(stage.stageArchivo.fileName);
                if (ext.ToUpper() != extension.ToUpper())
                {
                    obs = ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_EXTENSION_INVALIDO;
                }
            }

            return obs;
        }

        public static string getValidacionNomenclaturaArchivo(LogStage stage)
        {
            //si el archivo contiene salto de linea, no validar
            if (stage.stageArchivo.fileName == UtilArchivo.VALUE_SALTO_LINEA)
            {
                return "";
            }

            string validacion = "";
            string prefijo = stage.objeto.prefijo;
            string propiedadArchivo = stage.stageArchivo.fileName;
            string nombreStage = stage.nameStage;

            string archivoInternoStage = ValidadorStageArchivo.getArchivoSinExtension(propiedadArchivo);

            string desErrorNomenclatura = ValidadorStage.getValidacionNomenclaturaStage(stage);
            if (desErrorNomenclatura == "") //Si la nomenclatura del stage Dataset es correcta se procede a validar el archivo interno
            {
                string nombreArchivo = archivoInternoStage;
                bool esValidoNombreArchivo = (nombreArchivo == nombreArchivo.ToUpper());

                //validación del nombre
                if (!esValidoNombreArchivo)
                {
                    validacion = "El nombre del archivo [" + nombreArchivo + "] contiene minúsculas";//ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_MINUSCULAS;
                }
                else
                {
                    string nombreStageSinPrefijo = nombreStage.Substring(prefijo.Length, nombreStage.Length - prefijo.Length);
                    if (nombreArchivo != nombreStageSinPrefijo)
                    {
                        validacion = "El nombre del archivo [" + nombreArchivo + "] no coincide con el stage [" + nombreStageSinPrefijo + "]";//ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_NOMBRE_INCORRECTO;
                    }
                }
            }

            return validacion;
        }


        public static string getValidacionArchivoParametrizacion(LogStage stage)
        {

            //si el archivo contiene salto de linea, no validar
            if (stage.stageArchivo.fileName == UtilArchivo.VALUE_SALTO_LINEA)
            {
                return "";
            }

            if (!esValidoParametroArchivo(stage.stageArchivo.fileName))
            {
                return ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_PARAMETRIZACION_DIRECTORIO;
            }

            return "";
        }

        public static string getArchivoSinExtension(string valueFile)
        {
            string archivoSinExtension = "";
            if (valueFile != null && esValidoParametroArchivo(valueFile))
            {
                string[] arreglo = valueFile.Split('#');
                if (arreglo != null && arreglo.Length > 0)
                {
                    archivoSinExtension = arreglo[arreglo.Length - 1];
                    if (archivoSinExtension.Contains("."))
                    {
                        int posPunto = archivoSinExtension.LastIndexOf(".");
                        string archivo = archivoSinExtension.Substring(0, posPunto);
                        string extension = getExtension(valueFile);
                        return archivo;
                    }
                }
            }
            return archivoSinExtension;
        }

        public static string getExtension(string valueFile)
        {
            string extension = "";
            if (valueFile != null && esValidoParametroArchivo(valueFile))
            {
                string[] arreglo = valueFile.Split('#');
                if (arreglo != null && arreglo.Length > 0)
                {
                    string archivo = arreglo[arreglo.Length - 1];
                    if (archivo.Contains("."))
                    {
                        int posPunto = archivo.LastIndexOf(".");
                        extension = archivo.Substring(posPunto, archivo.Length - posPunto);
                    }
                }
            }
            return extension;
        }
        private static bool esValidoParametroArchivo(string valueFile)
        {
            if (valueFile != null && valueFile.Trim() != "")
            {
                string[] arreglo = valueFile.Split('#'); //#PARM_PATH.$PATH_WORK#JOB_RV_SBP_VI_CUENTAS_EXCLUIDAS.txt

                if (arreglo.Length == 3)
                {
                    string parametro = arreglo[1]; //PARM_PATH.$PATH_WORK
                    string archivo = arreglo[2];   //JOB_RV_SBP_VI_CUENTAS_EXCLUIDAS.txt

                    string[] arregloParametro = parametro.Split('.');
                    if (arregloParametro.Length == 2)
                    {
                        string variable = arregloParametro[1];
                        if (variable.StartsWith("$")) //  && archivo.Length > 0
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        
                    //if (nombreArchivo.StartsWith(nombreStageSinPrefijo))
                    //{
                    //    //validación del sufijo
                    //    if (nombreArchivo.Length > nombreStageSinPrefijo.Length)
                    //    {
                    //        int posIniSuf = nombreStageSinPrefijo.Length;
                    //        int posFinSuf = nombreArchivo.Length - posIniSuf;
                    //        string sufijo = nombreArchivo.Substring(posIniSuf, posFinSuf).Trim();

                    //        if (sufijo.Length >= 1)
                    //        {
                    //            if (sufijo.StartsWith("_"))
                    //            {
                    //                if (sufijo.Length == 1)
                    //                {
                    //                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_SUFIJO_INVALIDO);
                    //                }
                    //                if (sufijo.StartsWith("__"))
                    //                {
                    //                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_SUFIJO_INVALIDO);
                    //                }
                    //            }
                    //            else
                    //            {
                    //                obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_NOMBRE_INCORRECTO);
                    //            }
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_NOMBRE_INCORRECTO);
                    //}

        ///**
        // *  Validación de dataset 
        // **/
        //public static string getValidacionDataset(Stage s, string desErrorNomenclatura)
        //{
        //    string obs = "";
        //    string archivoDataset = ValidadorStageArchivo.getArchivoSinExtension(s.propiedadDataset);

        //    //proceso
        //    if (archivoDataset == "")//existencia de archivo
        //    {
        //        obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_INVALIDO);
        //    }
        //    else
        //    {
        //        if (desErrorNomenclatura == "") //Si la nomenclatura del stage Dataset es correcta se procede a validar el archivo interno
        //        {
        //            string nombreArchivo = archivoDataset;
        //            bool esValidoNombreArchivo = (nombreArchivo == nombreArchivo.ToUpper());

        //            //validación del nombre
        //            if (!esValidoNombreArchivo)
        //            {
        //                obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_MINUSCULAS);
        //            }
        //            else
        //            {
        //                string prefijo = ConstanteDataStage.PRE_DATA_SET;
        //                string nombreStage = s.nombreStage.Substring(prefijo.Length, s.nombreStage.Length - prefijo.Length);

        //                if (nombreArchivo.StartsWith(nombreStage))
        //                {
        //                    //validación del sufijo
        //                    if (nombreArchivo.Length > nombreStage.Length)
        //                    {
        //                        int posIniSuf = nombreStage.Length;
        //                        int posFinSuf = nombreArchivo.Length - posIniSuf;
        //                        string sufijo = nombreArchivo.Substring(posIniSuf, posFinSuf).Trim();

        //                        if (sufijo.Length >= 1)
        //                        {

        //                            if (sufijo.StartsWith("_"))
        //                            {
        //                                if (sufijo.Length == 1)
        //                                {
        //                                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_SUFIJO_INVALIDO);
        //                                }
        //                                if (sufijo.StartsWith("__"))
        //                                {
        //                                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_SUFIJO_INVALIDO);
        //                                }
        //                            }
        //                            else
        //                            {
        //                                obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_NOMBRE_INCORRECTO);
        //                            }
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_ARCHIVO_NOMBRE_INCORRECTO);
        //                }
        //            }
        //        }
        //    }

        //    return obs;
        //}

        ///**
        // *  Validación de dataset, el nombre del archivo corresponde con el nombre del stage
        // **/
        //public static string getValidacionDataset(Stage s, string desErrorNomenclatura)
        //{
        //    string obs = "";
        //    string archivoDataset = ValidadorStageArchivo.getArchivoDataSet(s.propiedadDataset);

        //    //proceso
        //    if (archivoDataset == null || archivoDataset == "")//existencia de archivo
        //    {
        //        obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_DATASET_ARCHIVO_INVALIDO);
        //    }
        //    else
        //    {
        //        if (desErrorNomenclatura == "") //Si la nomenclatura del stage Dataset es correcta se procede a validar el archivo interno
        //        {
        //            int posIni = ConstanteDataStage.PRE_DATA_SET.Length;
        //            int posFin = s.nombreStage.Length - posIni;
        //            string nombreArchivo = ValidadorStageArchivo.getArchivoDataSet(s.propiedadDataset);//string nombreStageSinPrefijo = s.nombreStage.Substring(posIni, posFin);

        //            //validacion del nombre del archivo del dataset
        //            bool esValidoNombreArchivoDataset = true;

        //            //validación del prefijo
        //            if (nombreArchivo.StartsWith(ConstanteDataStage.PRE_DATA_SET))
        //            {
        //                string prefijo = ConstanteDataStage.PRE_DATA_SET;
        //                string despuesPrefijo = nombreArchivo.Substring(prefijo.Length, nombreArchivo.Length - prefijo.Length);
        //                esValidoNombreArchivoDataset = (despuesPrefijo == despuesPrefijo.ToUpper());
        //            }

        //            //validación del nombre
        //            if (!esValidoNombreArchivoDataset)
        //            {
        //                obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_DATASET_ARCHIVO_MINUSCULAS);
        //            }
        //            else
        //            {
        //                if (nombreArchivo.StartsWith(s.nombreStage))
        //                {
        //                    //validación del sufijo
        //                    if (nombreArchivo.Length > s.nombreStage.Length)
        //                    {
        //                        int posIniSuf = s.nombreStage.Length;
        //                        int posFinSuf = nombreArchivo.Length - posIniSuf;
        //                        string sufijo = nombreArchivo.Substring(posIniSuf, posFinSuf);

        //                        if (sufijo.Length >= 1)
        //                        {

        //                            if (sufijo.StartsWith("_"))
        //                            {
        //                                if (sufijo.Length == 1)
        //                                {
        //                                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_DATASET_ARCHIVO_SUFIJO_INVALIDO);
        //                                }
        //                                if (sufijo.StartsWith("__"))
        //                                {
        //                                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_DATASET_ARCHIVO_SUFIJO_INVALIDO);
        //                                }
        //                            }
        //                            else
        //                            {
        //                                obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_DATASET_NOMBRE_INCORRECTO);
        //                            }
        //                        }


        //                    }
        //                }
        //                else
        //                {
        //                    obs = ValidadorService.agregarObservacion(obs, ConstanteCadena.MSG_VAL_STAGE_DATASET_NOMBRE_INCORRECTO);
        //                }
        //            }
        //        }
        //    }

        //    return obs;
        //}
    }
}
