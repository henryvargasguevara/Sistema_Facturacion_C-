﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.util;
using ValidadorSES.service;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;

namespace ValidadorSES.service.validador
{
    class ValidadorStage
    {
        /**
         *  Validación de nomenclatura de los stages
         **/
        public static string getValidacionNomenclaturaStage(LogStage s)
        {
            string validacion = "";
            bool esValidoPrefijo = false;
            bool esValidoNombre = true;
            //bool tipoEncontrado = false;
            //int comienzaNumeros = 0;
            string nombre = s.nameStage;

            //proceso
            if (s.objeto.type == s.stageType)
            {
                //tipoEncontrado = true;
                string prefijo = s.objeto.prefijo;
                if (nombre.StartsWith(prefijo))
                {
                    esValidoPrefijo = true;
                    string despuesPrefijo = nombre.Substring(prefijo.Length, nombre.Length - prefijo.Length);
                    esValidoNombre = (despuesPrefijo == despuesPrefijo.ToUpper());
                    //comienzaNumeros = comienzaAlfabeto(despuesPrefijo);
                    //if (comienzaNumeros == 1)
                    //{
                    //    validacion = ValidadorService.agregarObservacion(validacion, ConstanteCadena.MSG_VAL_STAGE_NOMENCLATURA_COMIENZA_NUM);
                    //}
                }

                if (!esValidoPrefijo)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_NOMENCLATURA_PREFIJO + " [ " + prefijo + " ] " + ConstanteChk.CHK14);
                }

                if (!esValidoNombre)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_NOMENCLATURA_CONTIENE_MINUSCULA + ConstanteChk.CHK14);
                }

            }

            ////setear valores en el stage
            //if (tipoEncontrado)
            //{
            //    s.estadoNomenclatura = (esValidoPrefijo && esValidoNombre) ? "OK" : "NOTOK";
            //}
            //else
            //{
            //    s.estadoNomenclatura = "OK";
            //    s.stageType = ConstanteDataStage.TIPO_STAGE_NO_DEFINIDO;
            //    //s.descripcionTipoStage = ConstanteDataStage.DES_STAGE_NO_DEFINIDO;
            //}

            return validacion;
        }

        /**
         *  Validación de nomenclatura si NOMBRE comienza con numeros o guion bajo
         **/
        private static int comienzaAlfabeto(String cadena)
        {
            int result = -1;
            string numeros = "_0123456789";
            for (int i = 0; i < cadena.Length; i++)
            {
                if (numeros.IndexOf(cadena[0], 0) != -1)
                {
                    return result = 1;//encontro numero o _
                }
            }
            return result;
        }


        //Validacion de parametros entre el Stage JobActivity del job secuencial y job paralelo
        public static string getValidacionParamJobActivity(LogStage stageJA, LogJob job)//job del nombrestage
        {
            string validacion = "";
            if (job != null)
            {
                List<LogObjetoParam> listaParamJA = stageJA.stageJobActivity.listaParametroJobActivity;
                List<LogObjetoParam> listaParamJob = job.listaParamJob;

                string validacionParamJA = "";
                string validacionParamJob = "";

                for (int i = 0; i < listaParamJA.Count(); i++)
                {
                    if (!UtilDataStage.existeParametroEnLista(listaParamJA[i], listaParamJob))
                    {
                        validacionParamJA = ValidadorService.agregarRespuesta(validacionParamJA, listaParamJA[i].name);
                    }
                }
                if (validacionParamJA != "")
                {
                    validacionParamJA = "El JobActivity tiene los parámetros " + validacionParamJA;
                    validacionParamJA += " pero no se encuentra en el Job";

                    validacion = validacion + validacionParamJA;
                }


                for (int i = 0; i < listaParamJob.Count(); i++)
                {
                    if (!UtilDataStage.existeParametroEnLista(listaParamJob[i], listaParamJA))
                    {
                        validacionParamJob = ValidadorService.agregarRespuesta(validacionParamJob, listaParamJob[i].name);
                    }
                }
                if (validacionParamJob != "")
                {
                    if (validacion != "") {
                        validacion += ". ";
                    }
                    validacionParamJob = "El Job tiene los parámetros " + validacionParamJob;
                    validacionParamJob += " pero no se encuentran establecidas con valor en el JobActivity";

                    validacion = validacion + validacionParamJob;
                }
            }
            else 
            {
                validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_PARAM_NO_EXISTE_JOB; 
            }

            return validacion;
        }

        public static string getValidacionActionEjecucion(LogStage s) 
        {
            string validacion = "";

            if (s.stageJobActivity.executionType != null)
            {
                if (s.stageJobActivity.executionType != ConstanteDataStage.ACCION_EJECUCION_REESTABLECER_LUEGO_EJECUTAR)
                {
                    validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_ACCION_EJECUCION_NO_REESTABLECER_LUEGO_EJECUTAR;
                }
            }
            else 
            {
                validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_ACCION_EJECUCION_NO_EXISTE;
            }

            return validacion;
        }

        public static string getValidacionParamRoutine(LogStage s, LogRoutine rutina)
        {
            List<string> listaArgRoutine = new List<string>();
            List<LogObjetoParam> listaParamRoutine = new List<LogObjetoParam>();
            string msj = "";

            if (rutina != null)
            {
                for (int j = 0; j < rutina.listaArgumentoRoutine.Count; j++)
                {
                    listaArgRoutine.Add(rutina.listaArgumentoRoutine[j].nameArgRoutine);
                }

                listaParamRoutine = s.stageRoutineActivity.listaParametroRoutine;

                for (int i = 0; i < listaParamRoutine.Count; i++)
                {
                    LogObjetoParam param = listaParamRoutine[i];
                    if (param.description == "")
                    {
                        return msj = "el valor del parámetro es vacío";
                    }
                }

                if (listaParamRoutine.Count != listaArgRoutine.Count)
                {
                    msj = "La cantidad de los argumentos del stage no coinciden con los argumentos de la rutina";
                }
            }

            return msj;
        }

        public static string getNombreInternoJobActivity(LogStage stage)
        {
            return stage.stageJobActivity.jobName;
        }


        /**
         * Validacion del nombre interior del job (nombre del trabajo), con el nombre del stage
         */
        public static string getValidaNombreInternoJobActivity(LogStage stage, List<LogStage> listaStage)
        {
            string validacion = "";
            string aa = stage.stageJobActivity.jobName;

            if (stage.stageJobActivity.jobName != null)
            {
                string bb = stage.nameStage;                
                if (stage.stageJobActivity.jobName == null || stage.nameStage != stage.stageJobActivity.jobName)
                {
                    int numJobActivity = UtilObjeto.getTotalJobActivityByNombreTrabajo(listaStage, stage.stageJobActivity.jobName);

                    //validar sufijo
                    if (numJobActivity > 1)
                    {
                        string nombreStage = stage.nameStage;
                        string nombreTrabajo = stage.stageJobActivity.jobName;

                        if (nombreStage.StartsWith(nombreTrabajo))
                        {
                            //validación del sufijo
                            if (nombreStage.Length > nombreTrabajo.Length)
                            {
                                int posIniSuf = nombreTrabajo.Length;
                                int posFinSuf = nombreStage.Length - posIniSuf;
                                string sufijo = nombreStage.Substring(posIniSuf, posFinSuf).Trim();

                                if (sufijo.Length >= 1)
                                {
                                    if (sufijo.StartsWith("_"))
                                    {
                                        if (sufijo.Length == 1)
                                        {
                                            validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_SUFIJO_INVALIDO;
                                        }
                                        if (sufijo.StartsWith("__"))
                                        {
                                            validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_SUFIJO_INVALIDO;
                                        }
                                    }
                                    else
                                    {
                                        validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_SUFIJO_INCORRECTO;
                                    }
                                }
                            }
                        }
                        else
                        {
                            validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_NOMBRE_INCORRECTO;
                        }
                    }
                    else
                    {
                        validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_NOMBRE_INCORRECTO;
                    }
                }
            }
            else
            {
                validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_ERROR_REFERENCIA;
            }

            return validacion;
        }

        /**
        * Validacion del Desencadenante, si es condición contraria deberia terminar en un TerminatorActivity
        */
        public static string getValidarDesencadenante(LogStage stage, LogJob job)
        {
            string validacion = "";
            int numCorrecto = 0;
            int numCondContraria = 0;

            for (int i = 0; i < stage.listaStageOutput.Count; i++)
            {
                LogStage stageLinkOutput = stage.listaStageOutput[i];

                if (stageLinkOutput.oleType == ConstanteDataStage.OLETYPE_CJS_ACTIVITY_OUTPUT)
                {
                    string conditionLink = stageLinkOutput.conditionType;

                    //no es desencadenante de condicion contraria o correcto, mandar mensaje
                    if (conditionLink != ConstanteDataStage.DESENCADENANTE_CONDICION_CONTRARIA
                        && conditionLink != ConstanteDataStage.DESENCADENANTE_CORRECTO)
                    {
                        validacion = ValidadorService.agregarRespuesta(validacion, "El link " + stageLinkOutput.nameStage + " tiene un desencadenante distinto a Condición Contraria o Correcto");
                    }

                    //al menos debe existir condicion contraria
                    if (conditionLink == ConstanteDataStage.DESENCADENANTE_CONDICION_CONTRARIA)
                    {
                        numCondContraria++;

                        for (int j = 0; j < stageLinkOutput.listaStageOutput.Count; j++)
                        {
                            LogStage stageCondicionContraria = stageLinkOutput.listaStageOutput[j];

                            if (stageCondicionContraria.stageType != ConstanteDataStage.TIPO_TERMINATOR_ACTIVITY
                                && stageCondicionContraria.stageType != ConstanteDataStage.TIPO_NOTIFICATION_ACTIVITY)
                            {
                                validacion = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE;
                            }
                            else
                            {
                                if (stageCondicionContraria.stageType == ConstanteDataStage.TIPO_NOTIFICATION_ACTIVITY)
                                {
                                    validacion = getValidacionAfterNotificationActivity(stageCondicionContraria);
                                }

                                //terminó en un terminatorActivity
                            }
                        }                        
                    }

                    //al menos debe existir correcto
                    if (conditionLink == ConstanteDataStage.DESENCADENANTE_CORRECTO)
                    {
                        numCorrecto++;
                        //al menos un correcto
                    }
                }
            }

            if (numCorrecto ==0) 
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_NO_CONDICION_CONTRARIA);
            }

            if (numCondContraria == 0) 
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_CORRECTO);
            }

            return validacion;
        }

        private static string getValidacionAfterNotificationActivity(LogStage stage)
        {
            string validacion = "";

            if(stage.listaStageOutput.Count == 0)
            {
                return ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL_0_SALIDA;
            }

            if(stage.listaStageOutput.Count >1)
            {
                return ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL_N_SALIDA;
            }

            //si es mail, entonces debe terminar en un TerminatorActivity
            LogStage stageLinkOutput = stage.listaStageOutput[0];

            if (stageLinkOutput.oleType == ConstanteDataStage.OLETYPE_CJS_ACTIVITY_OUTPUT)
            {
                if(stageLinkOutput.listaStageOutput.Count == 0)
                {
                    return ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL_0_SALIDA;
                }

                if(stageLinkOutput.listaStageOutput.Count >1)
                {
                    return ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL_N_SALIDA;
                }

                LogStage stageTerminatorActivity = stageLinkOutput.listaStageOutput[0];
                if (stageTerminatorActivity.stageType != ConstanteDataStage.TIPO_TERMINATOR_ACTIVITY)
                {
                    return ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL;
                }
            }            
            
            return validacion;
        }

        /*
        * Validacion de descripcion Terminator Activity
        */
        public static string getValidarDescripcionTerminator(LogStage stage)
        {
            string result = "";
            string MensaFInal = "";
            string TextoRegis = "";
            string Descripcion = "";
            string nombreJobActivity = null;
            string nombreRutinaActivity = null;
            if (stage.stageTerminatorActivity.fullDescription
                || stage.stageTerminatorActivity.logText
                || stage.stageTerminatorActivity.finalMessage)
            {
                if (stage.stageTerminatorActivity.descFinalMessage != null)
                {
                    MensaFInal = stage.stageTerminatorActivity.descFinalMessage.ToUpper();
                }
                if (stage.stageTerminatorActivity.descLogText != null)
                {
                    TextoRegis = stage.stageTerminatorActivity.descLogText.ToUpper();
                }
                if (stage.stageTerminatorActivity.descFullDescription != null)
                {
                    Descripcion = stage.stageTerminatorActivity.descFullDescription.ToUpper();
                }
                
               // result = ConstanteCadena.MSG_VAL_STAGE_TERMINATOR_ACTIVITY_DESCRIPCION;

                string input = stage.inputPins;                
                for (int i = 0; i < stage.job.listaStage.Count; i++)
                {
                    LogStage s = stage.job.listaStage[i];
                    if (s.partner != null && s.partner.Contains(input))
                    {
                        string idBuscar = s.identifierStage;

                        for (int j = 0; j < stage.job.listaStage.Count; j++)
                        {
                            LogStage s2 = stage.job.listaStage[j];
                            if (s2.outputPins != null && s2.outputPins.Contains(idBuscar))
                            {
                                //tengo el job activity
                                if (s2.stageJobActivity.jobName != null)
                                {
                                    nombreJobActivity = s2.stageJobActivity.jobName;
                                }

                                if (s2.stageRoutineActivity.routineName != null)
                                {
                                    nombreRutinaActivity = s2.stageRoutineActivity.routineName.ToUpper();
                                }
                            }
                        }
                    }
                }

                if (nombreJobActivity != null)
                {
                    if (MensaFInal.Contains(nombreJobActivity) || MensaFInal == "")
                    {
                        if (TextoRegis.Contains(nombreJobActivity) || TextoRegis == "")
                        {
                            if (Descripcion.Contains(nombreJobActivity) || Descripcion == "")
                            {
                                result = "";
                            }
                            else
                            {
                                result = "La Descripción no hace referencia al Job " + ConstanteChk.CHK11;
                            }
                        }
                        else
                        {
                            result = "La Descripción no hace referencia al Job " + ConstanteChk.CHK11;
                        }
                    }
                    else 
                    {
                        result = "La Descripción no hace referencia al Job " + ConstanteChk.CHK11;
                    }
                }

                if (nombreRutinaActivity != null)
                {
                    if (MensaFInal.Contains(nombreRutinaActivity) || MensaFInal == "")
                    {
                        if (TextoRegis.Contains(nombreRutinaActivity) || TextoRegis == "")
                        {
                            if (Descripcion.Contains(nombreRutinaActivity) || Descripcion == "")
                            {
                                result = "";
                            }
                            else
                            {
                                result = "La Descripción no hace referencia a la rutina " + ConstanteChk.CHK11;
                            }
                        }
                        else
                        {
                            result = "La Descripción no hace referencia a la rutina " + ConstanteChk.CHK11;
                        }
                    }
                    else
                    {
                        result = "La Descripción no hace referencia a la rutina " + ConstanteChk.CHK11;
                    }
                }
            }
            return result;
        }

        public static string getValidarAsuntoNotificationActivity(LogStage stage)
        {
            string result = null;
            string input = stage.inputPins;
            string asunto = "";
            string nombreJobActivity = "";            
            string nombreSequencer = "";



            for (int i = 0; i < stage.job.listaStage.Count; i++)
            {
                LogStage s = stage.job.listaStage[i];

                if (stage.stageNotificationActivity.asunto != null)
                {
                    asunto = stage.stageNotificationActivity.asunto;
                }
                else
                {
                    asunto = null;
                }

                if (s.oleType == ConstanteDataStage.OLETYPE_CJS_SEQUENCER && s.outputPins == null)
                {
                    nombreSequencer = s.nameStage;
                }
                else
                {
                    nombreSequencer = null;
                }

                if (input != null)
                {
                    if (s.partner != null && s.partner.Contains(input))
                    {
                        string idBuscar = s.identifierStage;

                        for (int j = 0; j < stage.job.listaStage.Count; j++)
                        {
                            LogStage s2 = stage.job.listaStage[j];
                            if (s2.outputPins != null && s2.outputPins.Contains(idBuscar))
                            {
                                //tengo el job activity
                                if (s2.stageJobActivity.jobName != null)
                                {
                                    nombreJobActivity = s2.stageJobActivity.jobName;
                                }
                            }
                        }
                    }
                }
            }
            if (asunto != "Ejecución Correcta " + stage.job.identifierJob && asunto != "Ejecución Anómala " + stage.job.identifierJob)
            {
                if ((!asunto.StartsWith("Ejecución Correcta") && !asunto.Contains(nombreJobActivity)) || (!asunto.StartsWith("Ejecución Anómala") && !asunto.Contains(nombreJobActivity)))
                {
                    result = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_MAIL;
                }
                else
                {
                    result = "";
                }
            }
            else
            {
                result = "";
            }

            return result;
        }

        public static string getValidarRoutineInUserVariablesActivity(LogStage stage, List<ObjetoView> listaRoutineRegla) 
        {
            string validacion = "";
            
            //datos válidos
            List<string> funcionesPermitidas = ConstanteDataStage.getListaFuncionPermitida();
            List<string> listaPrefijo = new List<string>();
            if(listaRoutineRegla!=null)
            {
                for (int r = 0; r<listaRoutineRegla.Count; r++) 
                {
                    listaPrefijo.Add(listaRoutineRegla[r].prefijo);
                }
            }

            //validacion
            List<string> listaFuncionNoValida = new List<string>();
            for (int i = 0; i < stage.stageUserVarsActivity.listaParametroVariable.Count; i++) 
            {
                LogObjetoParam param = stage.stageUserVarsActivity.listaParametroVariable[i];

                List<string> listaFuncion = param.listaFuncion;

                for (int j = 0; j<listaFuncion.Count; j++)
                {
                    if (!UtilLista.existeCadenaEnListaUpperCase(listaFuncion[j], funcionesPermitidas))
                    {
                        if (!esValidoPrefijoRoutine(listaFuncion[j], listaPrefijo))
                        {
                            listaFuncionNoValida.Add(listaFuncion[j]);
                        }
                    }
                }
            
            }
            List<string> listaFuncionSinDup = listaFuncionNoValida.Distinct().ToList<string>();

            if(listaFuncionSinDup.Count>0)
            {
                validacion = ValidadorService.agregarRespuesta(validacion, "Nomenclatura de routines " + UtilLista.getListaConcatenada(listaFuncionSinDup, ",") + " no es correcto " + ConstanteChk.CHK14);
            }

            return validacion;
        }

        private static bool esValidoPrefijoRoutine(string nombreFuncion, List<string> listaPrefijo) 
        {
            for (int i = 0; i<listaPrefijo.Count; i++)
            {
                if (nombreFuncion.StartsWith(listaPrefijo[i]))
                {
                    return true;
                }
            }

            return false;
        }


        public static string getValidarTableDefinitionEnDb2(LogStage stage)
        {
            string result = "";
            string input = stage.inputPins;
            string output = stage.outputPins;
            string outputPins = null;
            string inputPins = null;
            string idBuscar = null;
            if (stage.stageType == ConstanteDataStage.TIPO_DB2 || stage.stageType == ConstanteDataStage.TIPO_ODBC)
            {
                outputPins = stage.outputPins;
                inputPins = stage.inputPins;
                idBuscar = stage.identifierStage;
            }
            for (int i = 0; i < stage.job.listaStage.Count; i++)
            {
                LogStage s = stage.job.listaStage[i];

                if (outputPins != null && s.identifierStage == outputPins)
                {
                    int TotalCamposOut = s.TotalColumnas;
                    int TotalTableDefOut = s.TotalTableDef;
                    
                    if (TotalCamposOut != TotalTableDefOut)
                    {
                        result = ConstanteCadena.MSG_VAL_STAGE_DB2_LINAJE;
                    }
                }

                if (input != null)
                {
                    if (s.partner != null && s.partner.Contains(input))
                    {
                        int TotalCamposInp = s.TotalColumnas;
                        int TotalTableDefInp = s.TotalTableDef;

                        if (TotalCamposInp != TotalTableDefInp)
                        {
                            result = ConstanteCadena.MSG_VAL_STAGE_DB2_LINAJE;
                        }
                    }
                }
            }
            return result;
        }
            
        

    }
}
