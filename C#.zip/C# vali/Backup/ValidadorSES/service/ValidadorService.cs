﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.service.validador;
using ValidadorSES.dao;
using ValidadorSES.util;
using System.Reflection;

namespace ValidadorSES.service
{
    class ValidadorService
    {        
        public ValidadorService()
        {
        }

        public static LogDSX getValidacionFromDSX(LogDSX dsx, List<VariableEntorno> listaVariableEntorno, LogDSX dsxAdicional)
        {
            List<ObjetoView> listaJobRegla = null;
            List<ObjetoView> listaStageRegla = null;
            List<ObjetoView> listaRoutineRegla = null;
            List<ObjetoView> listaArgumentRegla = null;
            List<ObjetoView> listaParameterRegla = null;

            if (ConstanteSistema.TIPO_VERSION_SISTEMA == ConstanteSistema.VERSION_SISTEMA_DATABASE)
            {
                ReglaDAO rdao = new ReglaDAO();
                listaJobRegla = rdao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_JOB, dsx.tipoValidacion);
                listaStageRegla = rdao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_STAGE, dsx.tipoValidacion);
                listaRoutineRegla = rdao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_ROUTINE, dsx.tipoValidacion);
                listaArgumentRegla = rdao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_ARGUMENT, dsx.tipoValidacion);
                listaParameterRegla = rdao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_PARAMETER, dsx.tipoValidacion);

                serializarValidadorService(listaJobRegla, "listaJobRegla");
                serializarValidadorService(listaStageRegla, "listaStageRegla");
                serializarValidadorService(listaRoutineRegla, "listaRoutineRegla");
                serializarValidadorService(listaArgumentRegla, "listaArgumentRegla");
                serializarValidadorService(listaParameterRegla, "listaParameterRegla");
            }
            else
            {
                listaJobRegla = desSerializarProcesoService("listaJobRegla");
                listaStageRegla = desSerializarProcesoService("listaStageRegla");
                listaRoutineRegla = desSerializarProcesoService("listaRoutineRegla");
                listaArgumentRegla = desSerializarProcesoService("listaArgumentRegla");
                listaParameterRegla = desSerializarProcesoService("listaParameterRegla");
                //OleDBReglaDAO oledao = new OleDBReglaDAO();
                //listaJobRegla = oledao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_JOB, dsx.tipoValidacion);
                //listaStageRegla = oledao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_STAGE, dsx.tipoValidacion);
                //listaRoutineRegla = oledao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_ROUTINE, dsx.tipoValidacion);
                //listaArgumentRegla = oledao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_ARGUMENT, dsx.tipoValidacion);
                //listaParameterRegla = oledao.getListaObjetoWithListaReglaByTipoObjeto(ConstanteMaestro.COD_CLASF_OBJ_PARAMETER, dsx.tipoValidacion);
            }

            //validacion Job y Stage
            ValidadorService.validarDSJOB(dsx, listaVariableEntorno, dsxAdicional, listaJobRegla, listaStageRegla, listaRoutineRegla);

            //validacion de Rutinas
            ValidadorService.validarDSROUTINES(dsx.listaRoutine, listaRoutineRegla, listaArgumentRegla);

            //validación de ParameterSet
            ValidadorService.validarDSPARAMETERSETS(dsx.listaParameterSet, listaParameterRegla);

            //generar los objetos faltantes
            ValidadorService.generarObjetoFaltante(dsx);

            //generar los total y contar los errores
            ValidadorService.generarTotalJob(dsx, dsx.listaJob);
            ValidadorService.generarTotalRoutine(dsx, dsx.listaRoutine);
            ValidadorService.generarTotalParameterSet(dsx, dsx.listaParameterSet);
            
            dsx.numJobSequence = UtilObjeto.getTotalJobSequence(dsx.listaJob, ConstanteDataStage.TYPE_JOB_SEQUENCE);
            dsx.numJobParallel = UtilObjeto.getTotalJobSequence(dsx.listaJob, ConstanteDataStage.TYPE_JOB_PARALLEL);
            dsx.numJobServer = UtilObjeto.getTotalJobSequence(dsx.listaJob, ConstanteDataStage.TYPE_JOB_SERVER);
            dsx.numRoutine = dsx.listaRoutine.Count;
            dsx.numParameterSet = dsx.listaParameterSet.Count;

            dsx.codigoEstado = dsx.codigoEstadoJob;

            if (dsx.codigoEstadoJob == ConstanteMaestro.COD_EST_VALIDACION_OK
                || dsx.codigoEstadoRoutine == ConstanteMaestro.COD_EST_VALIDACION_OK
                || dsx.codigoEstadoParameter == ConstanteMaestro.COD_EST_VALIDACION_OK)
            {
                dsx.codigoEstado = ConstanteMaestro.COD_EST_VALIDACION_OK;
            }
            if (dsx.codigoEstadoJob == ConstanteMaestro.COD_EST_VALIDACION_OBS
                || dsx.codigoEstadoRoutine == ConstanteMaestro.COD_EST_VALIDACION_OBS
                || dsx.codigoEstadoParameter == ConstanteMaestro.COD_EST_VALIDACION_OBS)
            {
                dsx.codigoEstado = ConstanteMaestro.COD_EST_VALIDACION_OBS;
            }
            if (dsx.codigoEstadoJob == ConstanteMaestro.COD_EST_VALIDACION_ERROR
                || dsx.codigoEstadoRoutine == ConstanteMaestro.COD_EST_VALIDACION_ERROR
                || dsx.codigoEstadoParameter == ConstanteMaestro.COD_EST_VALIDACION_ERROR)
            {
                dsx.codigoEstado = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
            }

            return dsx;
        }

        private static void serializarValidadorService(Object o, string nombre)
        {

            string dir = @"c:\db";
            string serializationFile = Path.Combine(dir, nombre + ".bin");

            //serialize
            using (Stream stream = File.Open(serializationFile, FileMode.Create))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                bformatter.Serialize(stream, o);
            }



            /**var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db." + nombre + ".bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                bformatter.Serialize(stream, o);
            }**/
        }

        private static List<ObjetoView> desSerializarProcesoService(string archivo)
        {
            List<ObjetoView> l = new List<ObjetoView>();

            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db." + archivo + ".bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                l = (List<ObjetoView>)bformatter.Deserialize(stream);
            }

            return  l;
        }

        public static void generarObjetoFaltante(LogDSX dsx) 
        {
            if (dsx.listaFaltanteJob.Count > 0
                || dsx.listaFaltanteRoutine.Count > 0
                || dsx.listaFaltanteVariableEntorno.Count > 0) 
            {
                dsx.esNecesarioArchivoAdicional = true;

                dsx.listaFaltanteJob = dsx.listaFaltanteJob.Distinct().ToList<string>();
                dsx.listaFaltanteRoutine = dsx.listaFaltanteRoutine.Distinct().ToList<string>();
                dsx.listaFaltanteVariableEntorno = dsx.listaFaltanteVariableEntorno.Distinct().ToList<string>();
            }
        }

        public static void guardarValidacionBD(LogDSX dsx) 
        {
            AsignacionReqDAO ardao = new AsignacionReqDAO();
            ValidacionDAO vdao = new ValidacionDAO();
            
            //insertar el DSX
            dsx.descripcion = "";
            dsx.fechaDSXExportacion = UtilDataStage.getDateExportacion(dsx.header.fecha, dsx.header.hora);
            int codigoDSX = vdao.insertarDSX(dsx);
            dsx.codigoDSX = codigoDSX;

            //actualizar Asignacion requerimiento

            string estadoAsigReq = "3"; //Finalizado
            string estadoValidacionAsigReq = "4";//Validado OK
            if(dsx.codigoEstado == "OBS")
            
            {
                estadoAsigReq = "2"; //No finalizado
                estadoValidacionAsigReq = "3"; //Validador OBS
            }
            if (dsx.codigoEstado == "ERROR")
            {
                estadoAsigReq = "2"; //No finalizado
                estadoValidacionAsigReq = "2";//Validado Not OK
            }

            AsignarRequerimiento ar = new AsignarRequerimiento();
            ar.estado = estadoAsigReq;
            ar.estadoValidacion = estadoValidacionAsigReq;
            ar.codigo_requerimiento = dsx.codigoUsuarioRequerimiento;

            ardao.actualizarAsigReqByArchivoDSX(ar);

            //Actualizar requerimiento
            actualizarEstadoRequerimiento(dsx.codigoRequerimiento);

            //insertar lista de Jobs
            for (int j = 0; j<dsx.listaJob.Count; j++)
            {
                LogJob job = dsx.listaJob[j];
                job.codigoJob = dsx.codigoDSX + "-" + job.identifierJob;
                job.fechaCreacion = DateTime.Now;
                job.usuarioCreador = dsx.usuarioCreador;

                vdao.insertarJob(job);

                for (int s = 0; s<job.listaStage.Count; s++)
                {
                    LogStage stage = job.listaStage[s];
                    stage.fechaCreacion = DateTime.Now;
                    stage.usuarioCreador = dsx.usuarioCreador;

                    vdao.insertarStage(stage);
                }

                for (int r = 0; r<job.listaValidacion.Count; r++) 
                {
                    LogObjetoValidacion resultadoValidacion = job.listaValidacion[r];

                    vdao.insertaResultadoValidacion(resultadoValidacion);
                }
            }

            //insertar lista de Routine
            for (int r = 0; r<dsx.listaRoutine.Count; r++)
            {
                LogRoutine routine = dsx.listaRoutine[r];
                routine.codigoRoutine = dsx.codigoDSX + "-" + routine.identifier;
                routine.fechaCreacion = DateTime.Now;
                routine.usuarioCreador = dsx.usuarioCreador;

                vdao.insertarRoutine(routine);

                for (int a = 0; a<routine.listaArgumentoRoutine.Count; a++)
                {
                    LogArgument argument = routine.listaArgumentoRoutine[a];
                    argument.fechaCreacion = DateTime.Now;
                    argument.usuarioCreador = dsx.usuarioCreador;

                    vdao.insertarArgument(argument);
                }
            }

            //insertar lista de ParameterSet
            for (int r = 0; r < dsx.listaParameterSet.Count; r++)
            {
                LogParameterSet parameter = dsx.listaParameterSet[r];
                parameter.codigoParameter = dsx.codigoDSX + "-" + parameter.identifierParameterSet;
                parameter.fechaCreacion = DateTime.Now;
                parameter.usuarioCreador = dsx.usuarioCreador;

                vdao.insertarParameterSet(parameter);

                for (int a = 0; a < parameter.listaParam.Count; a++)
                {
                    LogParam param = parameter.listaParam[a];
                    param.fechaCreacion = DateTime.Now;
                    param.usuarioCreador = dsx.usuarioCreador;

                    vdao.insertarParam(param);
                }
            }
        }

        public static void aniadirNotaToDSX(LogDSX dsx)
        {
            //actualizar la nota, pero no cambiar el estado de ok o obs
            ValidacionDAO vdao = new ValidacionDAO();            
            vdao.actualizarDSXNota(dsx);

            AsignarRequerimiento ar = new AsignarRequerimiento();
            ar.estado = ConstanteMaestro.COD_EST_ASIG_FINALIZADO_JUSTIFICACION;
            ar.estadoValidacion = ConstanteMaestro.COD_EST_EJEC_VALIDADO_OK_JUSTIFICACION;
            ar.codigo_requerimiento = dsx.codigoUsuarioRequerimiento;

            //actualizar el estado de validacion y el estado de la asignación
            AsignacionReqDAO ardao = new AsignacionReqDAO();
            ardao.actualizarAsigReqByArchivoDSX(ar);

            //actualizar el requerimiento
            actualizarEstadoRequerimiento(dsx.codigoRequerimiento);
        }

        public static void actualizarEstadoRequerimiento(string codigoReq) 
        {
            AsignacionReqDAO ardao = new AsignacionReqDAO();
            List<AsignarRequerimientoView> lista = ardao.getListaRequerimientoAsignadosPorRequerimiento(codigoReq);

            if(lista!=null && lista.Count>0)
            {
                string estadoReq = "1"; //Pendiente
                //si todos las asignaciones de requerimiento son 'Finalizado' 3  o 'Finalizado con Justificación' 5

                int totalPendiente = 0;
                int totalNoFinalizado = 0;
                int totalFinalizado = 0;
                int totalRechazado = 0;
                int totalFinalizadoJustificacion = 0;

                for (int i = 0; i<lista.Count; i++) 
                {
                    switch(lista[i].codigoEstado)
                    {
                        case ConstanteMaestro.COD_EST_ASIG_PENDIENTE:
                            totalPendiente++;
                            break;
                        case ConstanteMaestro.COD_EST_ASIG_NO_FINALIZADO:
                            totalNoFinalizado++;
                            break;
                        case ConstanteMaestro.COD_EST_ASIG_FINALIZADO:
                            totalFinalizado++;
                            break;
                        case ConstanteMaestro.COD_EST_ASIG_RECHAZADO:
                            totalRechazado++;
                            break;
                        case ConstanteMaestro.COD_EST_ASIG_FINALIZADO_JUSTIFICACION:
                            totalFinalizadoJustificacion++;
                            break;
                    }
                }

                if (totalNoFinalizado >0)
                {
                    estadoReq = "2";//asignado
                }

                if (totalFinalizado + totalFinalizadoJustificacion == lista.Count)
                {
                    estadoReq = "3";//Success
                }

                if (totalRechazado == lista.Count) 
                {
                    estadoReq = "4";//Rechazado
                }

                RequerimientoDAO rdao = new RequerimientoDAO();
                Requerimiento r = new Requerimiento();
                r.codigo = codigoReq;
                r.estado = estadoReq;

                rdao.actualizarRequerimientoByArchivoDSX(r);
            }
        }

        /*
         * Validación del Job:
         * 
         * Documentación interna
         * **/
        public static void validarJob(LogJob job, List<LogJob> listaJob, List<VariableEntorno> listaVariableEntorno, List<ObjetoView> listaJobRegla, LogDSX dsx)
        {
            string validacion = "";

            ObjetoView obj = UtilDataStage.getObjetoViewFromLista(job.objeto.codigoObjeto, listaJobRegla);
            for (int i = 0; i < obj.listaObjetoRegla.Count; i++)
            {
                int codigoRegla = obj.listaObjetoRegla[i].codigoRegla;

                switch (codigoRegla)
                {
                    case ConstanteReglaValidacion.COD_REGLA_JOB_NOMENCLATURA:

                        if (dsx.tipoCarga == ConstanteMaestro.COD_CARGA_BDS_ODS_OTROS)
                        {
                            //ERROR - Nomenclatura de Job Parallels ODS, BDS y otros
                            string desErrorNomODS_BDS_Otros = ValidadorJob.getValidacionNomenclaturaJobODS_BDS_OTROS(job);
                            validacion = agregarMensaje(validacion, desErrorNomODS_BDS_Otros);
                            job.listaValidacion.Add(new LogObjetoValidacion(desErrorNomODS_BDS_Otros, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorNomODS_BDS_Otros), obj.listaObjetoRegla[i], job));
                        }
                        else   
                        {
                            //ERROR - Nomenclatura de Job Parallels Staging
                            string desErrorNomStaging = ValidadorJob.getValidacionNomenclaturaJobStaging(job);
                            validacion = agregarMensaje(validacion, desErrorNomStaging);
                            job.listaValidacion.Add(new LogObjetoValidacion(desErrorNomStaging, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorNomStaging), obj.listaObjetoRegla[i], job));
                        }

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_DESCRIPCION_BREVE:

                        //ERROR - Descripción del Job
                        string desErrorDescripcion = ValidadorJob.getValidacionDescripcionBreve(job);
                        validacion = agregarMensaje(validacion, desErrorDescripcion);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorDescripcion, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorDescripcion), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_DOC_INT_NOMBRE:

                        //ERROR - Documentación Interna: Nombre
                        string desErrorNombreDescripcion = ValidadorJob.getValidacionJobDocumentacionNombreJob(job);
                        validacion = agregarMensaje(validacion, desErrorNombreDescripcion);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorNombreDescripcion, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorNombreDescripcion), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_DOC_INT_DESTINO:

                        //ERROR - Documentación Interna: Destinos
                        string desErrorDestino = ValidadorJob.getValidacionJobDocumentacionDestino(job, listaVariableEntorno, dsx);
                        validacion = validacion + desErrorDestino;
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorDestino, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorDestino), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_DOC_INT_FUENTES:

                        //ERROR - Documentación Interna: Fuentes
                        string desErrorFuente = ValidadorJob.getValidacionJobDocumentacionFuente(job, listaVariableEntorno, dsx);
                        validacion = validacion + desErrorFuente;
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorFuente, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorFuente), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_DOC_INT_DEPENDENCIAS:

                        //ERROR - Documentacion Interna: Dependientes
                        string desErrorDependientes = ValidadorJob.getValidacionJobDocumentacionDependencias(job);
                        validacion = agregarMensaje(validacion, desErrorDependientes);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorDependientes, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorDependientes), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_DOC_INT_OBJETIVO:

                        //ERROR - Documentación Interna: objetivo
                        string desErrorObjetivo = ValidadorJob.getValidacionObjetivo(job);
                        validacion = agregarMensaje(validacion, desErrorObjetivo);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorObjetivo, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorObjetivo), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_DOC_INT_VERSION:

                        //ERROR - Documentación Interna: Versión
                        string desErrorVersion = ValidadorJob.getValidacionVersion(job);
                        validacion = agregarMensaje(validacion, desErrorVersion);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorVersion, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorVersion), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_PARAMETRO_VALOR_PREDETERMINADO:

                        //ERROR - Valor predeterminado de parámetros
                        string desErrorParametroValorPredeterminado = ValidadorJob.getValidacionParametroValorPredeterminado(job);
                        validacion = agregarMensaje(validacion, desErrorParametroValorPredeterminado);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorParametroValorPredeterminado, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorParametroValorPredeterminado), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_OPCION_COMPILACION:

                        //ERROR - Punto de comprobación
                        string desErrorPuntoComprobacion = ValidadorJob.getValidacionJobPuntoComprobacion(job, listaJob);
                        validacion = agregarMensaje(validacion, desErrorPuntoComprobacion);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorPuntoComprobacion, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorPuntoComprobacion), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_ESTRUCTURA_DOC_INT:

                        //ERROR - Estructura de documentación interna
                        string desErrorEstructuraDocInt = ValidadorJob.getValidacionEstructuraDocumentacionInternaJob(job);
                        validacion = agregarMensaje(validacion, desErrorEstructuraDocInt);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorEstructuraDocInt, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorEstructuraDocInt), obj.listaObjetoRegla[i], job));

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_JOB_ELIMINACION_DATA_SET:

                        //ERROR - Eliminación de Datasets
                        string desErrorEliminacionDataset = ValidadorJob.getValidacionJobEliminacionDataset(job);
                        validacion = agregarMensaje(validacion, desErrorEliminacionDataset);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorEliminacionDataset, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorEliminacionDataset), obj.listaObjetoRegla[i], job));

                        break;

                    case ConstanteReglaValidacion.COD_REGLA_JOB_TRANSFORMER_STG:

                        //ERROR - Se encuentra Transformer en job STG
                        string desErrorTransformerStg = ValidadorJob.getValidacionJobTransEnStg(job);
                        validacion = agregarMensaje(validacion, desErrorTransformerStg);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorTransformerStg, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorTransformerStg), obj.listaObjetoRegla[i], job));
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_JOB_MAXIMO_CONECTORES:

                        //ERROR - Se encuentra Transformer en job STG
                        string desErrorMaximoConectores = ValidadorJob.getValidacionJobMaximoConectores(job);
                        validacion = agregarMensaje(validacion, desErrorMaximoConectores);
                        job.listaValidacion.Add(new LogObjetoValidacion(desErrorMaximoConectores, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorMaximoConectores), obj.listaObjetoRegla[i], job));
                        break;
                    
                }
            }
            
            job.mensaje = validacion;
        }

        /*
         * Validacion del stage
         * **/
        public static void validarStage(LogJob job, LogStage s, List<LogJob> listaJob, List<LogRoutine> listaRutinas,
            List<ObjetoView> listaStageRegla, List<ObjetoView> listaRoutineRegla, LogDSX dsx, LogDSX dsxAdicional)
        {

            string validacion = "";
            string validacionMsgError = "";
            string validacionMsgObs = "";

            string desObsDB2FuncionSQL = "";
            if (s.objeto != null)
            {
            ObjetoView obj = UtilDataStage.getObjetoViewFromLista(s.objeto.codigoObjeto, listaStageRegla);
            for (int i = 0; i < obj.listaObjetoRegla.Count; i++)
            {
                int codigoRegla = obj.listaObjetoRegla[i].codigoRegla;

                switch (codigoRegla)
                {
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_NOMENCLATURA:

                        //ERROR - Nomenclatura de stage
                        string desErrorNomenclatura = ValidadorStage.getValidacionNomenclaturaStage(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorNomenclatura);

                        break;
                    //SequentialFile, DataSet
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_FILE_PARAM_DIRECTORIO:

                        //ERROR - Parametrización del directorio
                        string desErrorParametrizacionDirectorio = ValidadorStageArchivo.getValidacionArchivoParametrizacion(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorParametrizacionDirectorio);
                        
                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_FILE_EXISTENCIA:

                        //ERROR - Existencia de propiedad filename
                        string desErrorExistenciaFilename = ValidadorStageArchivo.getValidacionExistenciaArchivo(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorExistenciaFilename);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_FILE_EXTENSION:

                        //ERROR - Extension de filename
                        string desErrorExtensionFilename = ValidadorStageArchivo.getValidacionExtensionArchivo(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorExtensionFilename);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_FILE_NOMENCLATURA:
                        
                        //ERROR - Propiedad archivo de Sequential File
                        string desErrorArchivo = ValidadorStageArchivo.getValidacionNomenclaturaArchivo(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorArchivo);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_AGGREGATOR_METHOD:

                        //ERROR - Propiedad method
                        string desErrorMethod = ValidadorStageAggregator.getValidacionOpcionSort(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorMethod);

                        break;
                    //Transformer
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_TRA_NOMENCLATURA_STAGE_VARIABLES:

                        //ERROR - Nomenclatura de las Stage variables incorrecto
                        string desErrorNomenclaturaStageVariableTransformer = ValidadorStageTransformer.getValidacionStageVariableTransformer(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorNomenclaturaStageVariableTransformer);
                        
                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_TRA_NOMENCLATURA_LOOP_VARIABLES:

                        //ERROR - Nomenclatura de los Loop variables incorrecto
                        string desErrorNomenclaturaLoopVariableTransformer = ValidadorStageTransformer.getValidacionLoopVariableTransformer(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorNomenclaturaLoopVariableTransformer);

                        break;
                    //DB2
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_BEFORE_AFTER_SQL:

                        //ERROR - Before/After SQL
                        string desErrorDB2BeforeAfter = ValidadorStageDB2.getValidacionDB2BeforeAfter(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDB2BeforeAfter);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_KEEP_CONDUCTOR:

                        //ERROR - KeepConductor
                        string desErrorDB2KeepConductorConnectionAlive = ValidadorStageDB2.getValidacionDB2KeepConductorConnectionAlive(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDB2KeepConductorConnectionAlive);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_DELETE:

                        //ERROR - Delete
                        string desErrorDB2Delete = ValidadorStageDB2.getValidacionDB2SentenciaDelete(s, listaJob);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDB2Delete);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_FUNCIONES_SQL_NO_PERMITIDAS:

                        //ERROR - Funciones de SQL
                        string desErrorDB2FuncionSQL = ValidadorStageDB2.getValidacionDB2FuncionErrorSQL(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDB2FuncionSQL);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_FUNCIONES_SQL_OBS:

                        //OBSERVACIÓN - Funciones de SQL
                        desObsDB2FuncionSQL = ValidadorStageDB2.getValidacionDB2FuncionObsSQL(s);
                        validacionMsgObs = agregarMensaje(validacionMsgObs, desObsDB2FuncionSQL);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_OPERADOR_SQL:

                        //ERROR - Operador de SQL
                        string desErrorDB2OperadorSQL = ValidadorStageDB2.getValidacionDB2OperadorSQL(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDB2OperadorSQL);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_OPERADOR_DATASTAGE_ORCHESTRATE:

                        //ERROR - ORCHESTRATE
                        string desErrorDataStageOrchestrate = ValidadorStageDB2.getValidacionDataStageOrchestrate(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDataStageOrchestrate);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_COMENTARIOS:

                        //ERROR - Comentarios en la query
                        string desErrorComentarios = ValidadorStageDB2.getValidacionDB2Comentarios(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorComentarios);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_SELECT_FROM:

                        //ERROR - Select *
                        string desErrorSelectAll = ValidadorStageDB2.getValidacionDB2SelectAll(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorSelectAll);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_PARAM_SCHEMA_QUERY:

                        //ERRROR - Parametrizacion del esquema en query
                        string desErrorParametrizacionEsquema = ValidadorStageDB2.getValidacionDB2ParametrizacionEsquema(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorParametrizacionEsquema);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_PARAM_CONEXION:

                        //ERRROR - Parametrizacion del esquema en query
                        string desErrorParametrizacionConexion= ValidadorStageDB2.getValidacionDB2ParametrizacionConexion(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorParametrizacionConexion);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_LIMITE_RESULTADO:

                        //ERRROR - Uso de limite de los resultado de la consulta SQL
                        string desErrorLimiteResultado = ValidadorStageDB2.getValidacionDB2LimiteResultado(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorLimiteResultado);

                        break;
                    //case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_RECORD_COUNT_2:

                    //    //ERROR - record count
                    //    string desErrorDB2RecordCount = ValidadorStageDB2.getValidacionRecordCount(s);
                    //    validacionMsgError = agregarMensaje(validacionMsgError, desErrorDB2RecordCount);

                    //    break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_ARRAY_SIZE:

                        //ERROR - Array Size
                        string desErrorDB2ArraySize = ValidadorStageDB2.getValidacionArraySize(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDB2ArraySize);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_RECORD_COUNT:
                        //ERRROR - No esta en valor predefinido 2000                        
                        string desErrorRecordCount = ValidadorStageDB2.getValidacionRecordCount(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorRecordCount);
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_PK_EN_DU:
                        //ERROR - Se encuentra PK en tablas DU (staging)
                        string desErrorPKenDU = ValidadorStageDB2.getValidacionDB2ProbandoPKenDU(s, listaJob);                        
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorPKenDU);
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_LINAJE:
                        //ERROR - No se encuentra todos los campos con linaje (DB2)
                        string desErrorLinaje = ValidadorStage.getValidarTableDefinitionEnDb2(s);  //, listaJob
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorLinaje);
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DB2_LOCK_WAIT_MODE:
                        //ERROR - No se encuentra todos los campos con linaje (DB2)
                        string desErrorLockWaitMode = ValidadorStageDB2.getValidacionLockWaitMode(s);  //, listaJob
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorLockWaitMode);
                        break;

                    //Job Activity
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_JOBACTIVITY_NOMBRE_INTERNO:

                        //ERROR - Propiedad Nombre Interno Job Activity
                        string desErrorNombreInteriorJobActivity = ValidadorStage.getValidaNombreInternoJobActivity(s, job.listaStage);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorNombreInteriorJobActivity);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_DESENCADENANTE:

                        //ERROR - Desencadenate de Job Activity
                        string desErrorDesencadenante = ValidadorStage.getValidarDesencadenante(s, job);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDesencadenante);

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_COINCIDENCIA_PARAMETROS:

                        if (s.oleType == ConstanteDataStage.OLETYPE_CJS_JOB_ACTIVITY)
                        {
                            //ERROR - Coincidencia de parametros
                            //**buscar si existe el Job en el DSX
                            LogJob dsJob = UtilObjeto.getJobByName(s.nameStage, listaJob);
                            //**si no existe buscar en el DSX adicional
                            if (dsJob == null)
                            {
                                dsJob = UtilObjeto.getJobByName(s.nameStage, dsxAdicional.listaJob);

                                if (dsJob == null)
                                {
                                    dsx.listaFaltanteJob.Add(s.nameStage);
                                }
                            }

                            string desErrorParametrosJobActivity = ValidadorStage.getValidacionParamJobActivity(s, dsJob);
                            validacionMsgError = agregarMensaje(validacionMsgError, desErrorParametrosJobActivity);
                        }
                        if (s.oleType == ConstanteDataStage.OLETYPE_CJS_ROUTINE_ACTIVITY)
                        {
                            //ERROR - Coincidencia de parametros
                            //**buscar si existe el Routine en el DSX
                            LogRoutine dsRoutine = UtilObjeto.getRoutineByName(s.stageRoutineActivity.routineName, listaRutinas);
                            //**si no existe buscar en el DSX adicional
                            if (dsRoutine == null)
                            {
                                dsRoutine = UtilObjeto.getRoutineByName(s.stageRoutineActivity.routineName, dsxAdicional.listaRoutine);

                                if (dsRoutine == null)
                                {
                                    dsx.listaFaltanteRoutine.Add(s.stageRoutineActivity.routineName);
                                }
                            }

                            string desErrorParametrosRoutineActivity = ValidadorStage.getValidacionParamRoutine(s, dsRoutine);
                            validacionMsgError = agregarMensaje(validacionMsgError, desErrorParametrosRoutineActivity);
                        }

                        break;
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_JOBACTIVITY_ACCION_EJECUCION:
                        
                        if (s.oleType == ConstanteDataStage.OLETYPE_CJS_JOB_ACTIVITY)
                        {
                            //ERROR - Acción de ejecución
                            string desErrorAcionEjecucion = ValidadorStage.getValidacionActionEjecucion(s);
                            validacionMsgError = agregarMensaje(validacionMsgError, desErrorAcionEjecucion);
                        }

                        break;
                    //Terminator Activity
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_TERMINATORACTIVITY_DESCRIPCION:

                        //ERROR - Descripcion del Terminator Activity
                        string desErrorDescripcionTerminator = ValidadorStage.getValidarDescripcionTerminator(s);
                        validacionMsgError = agregarMensaje(validacionMsgError, desErrorDescripcionTerminator);

                        break;
                    //User Variables Activity
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_VAR_USER_VARIABLES_ACTIVITY_EXPRESION_VARIABLE:

                    //ERROR - Uso de funciones rutina válidas
                    string desErrorUserVariableActivityExp = ValidadorStage.getValidarRoutineInUserVariablesActivity(s, listaRoutineRegla);
                    validacionMsgError = agregarMensaje(validacionMsgError, desErrorUserVariableActivityExp);

                    break;

                    //Notification Activity
                    case ConstanteReglaValidacion.COD_REGLA_STAGE_NOTIFICATION_ACTIVITY_ASUNTO:

                    //ERROR - Asunto Notification Activity
                    string desErrorAsuntoNotification = ValidadorStage.getValidarAsuntoNotificationActivity(s);
                    validacionMsgError = agregarMensaje(validacionMsgError, desErrorAsuntoNotification);

                    break;
                }
            }
            
            //agrupar los errores y observaciones



            //existencia de errores, no hay observaciones
            s.hayError = validacionMsgError != "";

            //existencia de observación
            s.hayObservacion = validacionMsgObs != "";

            //validacion = agregarMensaje(validacion, validacionMsgError);
            validacion = agregarMensaje(validacionMsgError, validacionMsgObs);

            s.mensaje = validacion;
        }
        }

        /*
         * Validacion de la rutina
         * **/
        public static void validarRoutine(LogRoutine rou, List<ObjetoView> listaRoutineRegla)
        {
            string validacion = "";
            string desErrorNomenclatura = "";

            ObjetoView obj = UtilDataStage.getObjetoViewFromLista(rou.objeto.codigoObjeto, listaRoutineRegla);
            for (int i = 0; i < obj.listaObjetoRegla.Count; i++)
            {
                int codigoRegla = obj.listaObjetoRegla[i].codigoRegla;

                switch (codigoRegla)
                {
                    case ConstanteReglaValidacion.COD_REGLA_ROUTINE_NOMENCLATURA:

                        //ERROR - Nomenclatura de stage
                        desErrorNomenclatura = ValidadorRoutine.getValidacionNomenclaturaRoutine(rou);
                        validacion = agregarMensaje(validacion, desErrorNomenclatura);                        
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_ROUTINE_DESCRIPCION:
                        //ERROR - Documentacion del Rutina                        
                        string desErrorDescripcion = ValidadorRoutine.getValidacionDescripcionVersion(rou);
                        validacion = agregarMensaje(validacion, desErrorDescripcion);
                        //rou.listaValidacion.Add(new LogObjetoValidacion(desErrorDescripcion, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorDescripcion), obj.listaObjetoRegla[i]));                        
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_ROUTINE_DESCRIPCION_BREVE:
                        //ERROR - Documentacion del Rutina                        
                        string desErrorDescripcionBreve = ValidadorRoutine.getValidacionDescripcionBreve(rou);
                        validacion = agregarMensaje(validacion, desErrorDescripcionBreve);                        
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_ROUTINE_OBJETIVO:
                        //ERROR - Documentacion del Rutina                        
                        string desErrorObjetivo = ValidadorRoutine.getValidacionDescripcionObjetivo(rou);
                        validacion = agregarMensaje(validacion, desErrorObjetivo);                        
                        break;
                }
            }
            
            //existencia de errores
            rou.hayError = false;
            
            if (desErrorNomenclatura != "") 
            {
                rou.hayError = true;
            }

            rou.mensaje = validacion;
        }

        /*
         * Validacion de los argumentos de la rutina
         * **/
        public static void validarArgument(LogArgument arg, List<ObjetoView> listaArgumentRegla)
        {
            string validacion = "";
            string desErrorDescripcionArgumento = "";

            ObjetoView obj = UtilDataStage.getObjetoViewFromLista(arg.objeto.codigoObjeto, listaArgumentRegla);
            for (int i = 0; i < obj.listaObjetoRegla.Count; i++)
            {
                int codigoRegla = obj.listaObjetoRegla[i].codigoRegla;

                switch (codigoRegla)
                {
                    case ConstanteReglaValidacion.COD_REGLA_ARGUMENT_DESCRIPCION:

                        //ERROR - Descripción del argumento
                        desErrorDescripcionArgumento = ValidadorRoutine.validarDescripcion(arg);
                        validacion = agregarMensaje(validacion, desErrorDescripcionArgumento);

                        break;
                }
            }

            //existencia de errores
            arg.hayError = false;
            if (desErrorDescripcionArgumento != "")
            {
                arg.hayError = true;
            }

            //existencia de observaciones
            arg.hayObservacion = false;

            arg.mensaje = validacion;
        }

        /*
         * Validacion de los ParameterSet
         * **/
        public static void validarParameterSet(LogParameterSet parameter, List<ObjetoView> listaParameterRegla) 
        {
            string validacion = "";

            ObjetoView obj = UtilDataStage.getObjetoViewFromLista(parameter.objeto.codigoObjeto, listaParameterRegla);
            for (int i = 0; i < obj.listaObjetoRegla.Count; i++)
            {
                int codigoRegla = obj.listaObjetoRegla[i].codigoRegla;

                switch (codigoRegla)
                {
                    case ConstanteReglaValidacion.COD_REGLA_PARAMETER_SET_NOMENCLATURA:

                        //ERROR - Descripción del ParameterSet
                        string desErrorNomenclatura = ValidadorParameterSet.getValidacionNomenclatura(parameter);
                        validacion = agregarMensaje(validacion, desErrorNomenclatura);
                        parameter.listaValidacion.Add(new LogObjetoValidacion(desErrorNomenclatura, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorNomenclatura), obj.listaObjetoRegla[i]));
                        break;
                    
                    case ConstanteReglaValidacion.COD_REGLA_PARAMETER_SET_DESCRIPCION:

                        //ERROR - Documentacion del ParameterSet
                        string desErrorDocumentacion = ValidadorParameterSet.getValidacionDocumentacion(parameter);
                        validacion = agregarMensaje(validacion, desErrorDocumentacion);
                        parameter.listaValidacion.Add(new LogObjetoValidacion(desErrorDocumentacion, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorDocumentacion), obj.listaObjetoRegla[i]));                        
                        break;

                    case ConstanteReglaValidacion.COD_REGLA_PARAMETER_SET_DESCRIPCION_BREVE:

                        //ERROR - Documentacion breve del ParameterSet
                        string desErrorDocumentacionBreve = ValidadorParameterSet.getValidacionDescripcionBrevePar(parameter);
                        validacion = agregarMensaje(validacion, desErrorDocumentacionBreve);
                        parameter.listaValidacion.Add(new LogObjetoValidacion(desErrorDocumentacionBreve, UtilValidacion.getEstadoValidacion(UtilValidacion.COD_VAL_NOTOK, desErrorDocumentacionBreve), obj.listaObjetoRegla[i]));
                        break;

                }
            }

            parameter.mensaje = validacion;
        }

        /*
         * Validacion de los parámetros del ParameterSet
         * **/
        public static void validarParametro(LogParam param)
        {
            string validacion = "";

            //existencia de errores
            param.hayError = false;

            //existencia de observaciones
            param.hayObservacion = false;

            param.mensaje = validacion;
        }

        //auxiliares
        public static string agregarMensaje(string mensaje, string linea)
        {
            if(linea == ""){
                return mensaje;
            }

            if (mensaje == "")
            {
                mensaje = linea + ". ";
            }
            else 
            { 
                mensaje += linea + ". ";
            }

            return mensaje;
        }

        public static string agregarRespuesta(string textoPrincipal, string detalle)
        {
            if (textoPrincipal == "")
            {
                textoPrincipal = detalle;
            }
            else
            {
                if (detalle != "")
                {
                    textoPrincipal += ", " + detalle;
                }
            }
            return textoPrincipal;
        }

        //

        private static void validarDSJOB(LogDSX dsx, List<VariableEntorno> listaVariableEntorno, LogDSX dsxAdicional,
            List<ObjetoView> listaJobRegla, List<ObjetoView> listaStageRegla, List<ObjetoView> listaRoutineRegla)
        {
            List<LogJob> listaJob = dsx.listaJob;
            List<LogRoutine> listaRutinas = dsx.listaRoutine;
            string tipoCarga = dsx.tipoCarga;

            //validacion
            if (listaJob != null && listaJob.Count > 0)
            {
                int totalJobs = listaJob.Count;
                for (int j = 0; j < totalJobs; j++) //comienza a iterar por cada job
                {
                    LogJob job = listaJob[j];
                    int totalStage = job.listaStage.Count;

                    ValidadorService.validarJob(job, listaJob, listaVariableEntorno, listaJobRegla, dsx);

                    for (int s = 0; s < totalStage; s++) //comienza a iterar por cada stage
                    {
                        LogStage stage = job.listaStage[s];
                        //realizar todas las validaciones
                        ValidadorService.validarStage(job, stage, listaJob, listaRutinas, listaStageRegla, listaRoutineRegla, dsx, dsxAdicional);
                    }
                }
            }
        }

        private static void validarDSROUTINES(List<LogRoutine> listaRutina, List<ObjetoView> listaRoutineRegla, List<ObjetoView> listaArgumentRegla)
        {
            if (listaRutina != null && listaRutina.Count > 0)
            {
                for (int i = 0; i < listaRutina.Count; i++)
                {
                    LogRoutine rou = listaRutina[i];
                    int totalArgument = rou.listaArgumentoRoutine.Count;

                    ValidadorService.validarRoutine(rou, listaRoutineRegla);

                    for (int a = 0; a < totalArgument; a++)
                    {
                        LogArgument arg = rou.listaArgumentoRoutine[a];
                        //realizar todas las validaciones
                        ValidadorService.validarArgument(arg,listaArgumentRegla);
                    }
                }
            }
        }

        private static void validarDSPARAMETERSETS(List<LogParameterSet> listaParameterSet, List<ObjetoView> listaParameterRegla) 
        {
            if (listaParameterSet != null && listaParameterSet.Count>0) 
            {
                for (int i = 0; i < listaParameterSet.Count; i++)
                {
                    LogParameterSet parameter = listaParameterSet[i];
                    int totalParam = parameter.listaParam.Count;

                    ValidadorService.validarParameterSet(parameter, listaParameterRegla);

                    for (int a = 0; a < totalParam; a++)
                    {
                        LogParam param = parameter.listaParam[a];
                        //realizar todas las validaciones
                        ValidadorService.validarParametro(param);
                    }
                }
            }
        }

        private static void generarTotalJob(LogDSX dsx,List<LogJob> listaJob)
        {
            string estadoTodoJob = ConstanteMaestro.COD_EST_VALIDACION_OK;
            int numJobCorrectos = 0;
            int numJobIncorrectos = 0;
            int numJobObservaciones = 0;

            //contar los errores
            if (listaJob != null && listaJob.Count > 0)
            {
                int totalJobs = listaJob.Count;
                for (int j = 0; j < totalJobs; j++) //comienza a iterar por cada job
                {
                    LogJob job = listaJob[j];
                    int nroCorrectos = 0;
                    int nroIncorrectos = 0;
                    int nroObservaciones = 0;

                    int totalStage = job.listaStage.Count;
                    for (int s = 0; s < totalStage; s++) //comienza a iterar por cada stage
                    {
                        LogStage stage = job.listaStage[s];

                        string estadoStage = ConstanteMaestro.DES_EST_VALIDACION_OK;
                        string estadoStageCodigo = ConstanteMaestro.COD_EST_VALIDACION_OK;

                        if (stage.hayError)
                        {
                            estadoStage = ConstanteMaestro.DES_EST_VALIDACION_ERROR;
                            estadoStageCodigo = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
                            nroIncorrectos++;
                        }
                        else
                        {
                            if (stage.hayObservacion)
                            {
                                estadoStage = ConstanteMaestro.DES_EST_VALIDACION_OBS;
                                estadoStageCodigo = ConstanteMaestro.COD_EST_VALIDACION_OBS;
                                nroObservaciones++;
                            }
                            else
                            {
                                nroCorrectos++;
                            }
                        }

                        stage.estadoStageDescripcion = estadoStage;
                        stage.estadoStageCodigo = estadoStageCodigo;
                    }

                    //nroCorrectos = totalStage - nroIncorrectos;

                    job.numStageCorrecto = nroCorrectos;
                    job.numStageIncorrecto = nroIncorrectos;
                    job.numStageObservado = nroObservaciones;

                    string estadoJob = ConstanteMaestro.DES_EST_VALIDACION_OK;
                    string estadoJobCodigo = ConstanteMaestro.COD_EST_VALIDACION_OK;

                    if (nroObservaciones > 0)
                    {
                        estadoJob = ConstanteMaestro.DES_EST_VALIDACION_OBS;
                        estadoJobCodigo = ConstanteMaestro.COD_EST_VALIDACION_OBS;
                    }

                    if (nroIncorrectos > 0 || (job.mensaje != null && job.mensaje != ""))
                    {
                        estadoJob = ConstanteMaestro.DES_EST_VALIDACION_ERROR;
                        estadoJobCodigo = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
                    }

                    job.estadoJobDescripcion = estadoJob;
                    job.estadoJobCodigo = estadoJobCodigo;

                    //contador
                    if (job.estadoJobCodigo == ConstanteMaestro.COD_EST_VALIDACION_OK)
                    {
                        numJobCorrectos++;
                    }
                    if (job.estadoJobCodigo == ConstanteMaestro.COD_EST_VALIDACION_ERROR)
                    {
                        numJobIncorrectos++;
                    }
                    if (job.estadoJobCodigo == ConstanteMaestro.COD_EST_VALIDACION_OBS)
                    {
                        numJobObservaciones++;
                    }
                }
            }

            if (numJobObservaciones > 0)
            {
                estadoTodoJob = ConstanteMaestro.COD_EST_VALIDACION_OBS;
            }
            if(numJobIncorrectos > 0)
            {
                estadoTodoJob = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
            }

            dsx.codigoEstadoJob = estadoTodoJob;
        }

        private static void generarTotalRoutine(LogDSX dsx,List<LogRoutine> listaRoutine)
        {
            string estadoTodoRoutine = ConstanteMaestro.COD_EST_VALIDACION_OK;
            int numRoutineCorrectos = 0;
            int numRoutineIncorrectos = 0;
            int numRoutineObservaciones = 0;

            //contar los errores
            if (listaRoutine != null && listaRoutine.Count > 0)
            {
                int totalRoutine = listaRoutine.Count;
                for (int j = 0; j < totalRoutine; j++)
                {
                    LogRoutine routine = listaRoutine[j];
                    int totalArgument = routine.listaArgumentoRoutine.Count;
                    int nroCorrectos = 0;
                    int nroIncorrectos = 0;
                    int nroObservaciones = 0;

                    for (int s = 0; s < totalArgument; s++)
                    {
                        LogArgument arg = routine.listaArgumentoRoutine[s];

                        string estadoArgument = ConstanteMaestro.DES_EST_VALIDACION_OK;
                        string estadoArgumentCodigo = ConstanteMaestro.COD_EST_VALIDACION_OK;
                        if (arg.hayError)
                        {
                            estadoArgument = ConstanteMaestro.DES_EST_VALIDACION_ERROR;
                            estadoArgumentCodigo = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
                            nroIncorrectos++;
                        }
                        else
                        {
                            if (arg.hayObservacion)
                            {
                                estadoArgument = ConstanteMaestro.DES_EST_VALIDACION_OBS;
                                estadoArgumentCodigo = ConstanteMaestro.COD_EST_VALIDACION_OBS;
                                nroObservaciones++;
                            }
                            else
                            {
                                nroCorrectos++;
                            }
                        }

                        arg.estadoArgumentDescripcion = estadoArgument;
                        arg.estadoArgumentCodigo = estadoArgumentCodigo;
                    }

                    //nroCorrectos = totalStage - nroIncorrectos;

                    routine.numArgCorrecto = nroCorrectos;
                    routine.numArgIncorrecto = nroIncorrectos;
                    routine.numArgObservado = nroObservaciones;

                    string estadoRoutine = ConstanteMaestro.DES_EST_VALIDACION_OK;
                    string estadoRoutineCodigo = ConstanteMaestro.COD_EST_VALIDACION_OK;
                    if (nroObservaciones > 0)
                    {
                        estadoRoutine = ConstanteMaestro.DES_EST_VALIDACION_OBS;
                        estadoRoutineCodigo = ConstanteMaestro.COD_EST_VALIDACION_OBS;
                    }

                    if (nroIncorrectos > 0 || (routine.mensaje != null && routine.mensaje != ""))
                    {
                        estadoRoutine = ConstanteMaestro.DES_EST_VALIDACION_ERROR;
                        estadoRoutineCodigo = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
                    }

                    routine.estadoRutinaDescripcion = estadoRoutine;
                    routine.estadoRutinaCodigo = estadoRoutineCodigo;


                    //contador
                    if (routine.estadoRutinaCodigo == ConstanteMaestro.COD_EST_VALIDACION_OK)
                    {
                        numRoutineCorrectos++;
                    }
                    if (routine.estadoRutinaCodigo == ConstanteMaestro.COD_EST_VALIDACION_ERROR)
                    {
                        numRoutineIncorrectos++;
                    }
                    if (routine.estadoRutinaCodigo == ConstanteMaestro.COD_EST_VALIDACION_OBS)
                    {
                        numRoutineObservaciones++;
                    }
                }
            }

            if (numRoutineObservaciones > 0)
            {
                estadoTodoRoutine = ConstanteMaestro.COD_EST_VALIDACION_OBS;
            }
            if (numRoutineIncorrectos > 0)
            {
                estadoTodoRoutine = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
            }

            dsx.codigoEstadoRoutine = estadoTodoRoutine;
        }

        private static void generarTotalParameterSet(LogDSX dsx, List<LogParameterSet> listaParameter)
        {
            string estadoTodoParameter = ConstanteMaestro.COD_EST_VALIDACION_OK;
            int numParameterCorrectos = 0;
            int numParameterIncorrectos = 0;
            int numParameterObservaciones = 0;

            //contar los errores
            if (listaParameter != null && listaParameter.Count > 0)
            {
                int totalParameter = listaParameter.Count;
                for (int j = 0; j < totalParameter; j++)
                {
                    LogParameterSet parameter = listaParameter[j];
                    int totalParametros = parameter.listaParam.Count;
                    int nroCorrectos = 0;
                    int nroIncorrectos = 0;
                    int nroObservaciones = 0;

                    for (int s = 0; s < totalParametros; s++)
                    {
                        LogParam param = parameter.listaParam[s];

                        string estadoParam = ConstanteMaestro.DES_EST_VALIDACION_OK;
                        string estadoParamCodigo = ConstanteMaestro.COD_EST_VALIDACION_OK;
                        if (param.hayError)
                        {
                            estadoParam = ConstanteMaestro.DES_EST_VALIDACION_ERROR;
                            estadoParamCodigo = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
                            nroIncorrectos++;
                        }
                        else
                        {
                            if (param.hayObservacion)
                            {
                                estadoParam = ConstanteMaestro.DES_EST_VALIDACION_OBS;
                                estadoParamCodigo = ConstanteMaestro.COD_EST_VALIDACION_OBS;
                                nroObservaciones++;
                            }
                            else
                            {
                                nroCorrectos++;
                            }
                        }

                        param.estadoParamDescripcion = estadoParam;
                        param.estadoParamCodigo = estadoParamCodigo;
                    }

                    nroCorrectos = totalParametros - nroIncorrectos;

                    parameter.numParamCorrecto = nroCorrectos;
                    parameter.numParamIncorrecto = nroIncorrectos;
                    parameter.numParamObservado = nroObservaciones;

                    string estadoParameter = ConstanteMaestro.DES_EST_VALIDACION_OK;
                    string estadoParameterCodigo = ConstanteMaestro.COD_EST_VALIDACION_OK;
                    if (nroObservaciones > 0)
                    {
                        estadoParameter = ConstanteMaestro.DES_EST_VALIDACION_OBS;
                        estadoParameterCodigo = ConstanteMaestro.COD_EST_VALIDACION_OBS;
                    }

                    if (nroIncorrectos > 0 || (parameter.mensaje != null && parameter.mensaje != ""))
                    {
                        estadoParameter = ConstanteMaestro.DES_EST_VALIDACION_ERROR;
                        estadoParameterCodigo = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
                    }

                    parameter.estadoParameterDescripcion = estadoParameter;
                    parameter.estadoParameterCodigo = estadoParameterCodigo;


                    //contador
                    if (parameter.estadoParameterCodigo == ConstanteMaestro.COD_EST_VALIDACION_OK)
                    {
                        numParameterCorrectos++;
                    }
                    if (parameter.estadoParameterCodigo == ConstanteMaestro.COD_EST_VALIDACION_ERROR)
                    {
                        numParameterIncorrectos++;
                    }
                    if (parameter.estadoParameterCodigo == ConstanteMaestro.COD_EST_VALIDACION_OBS)
                    {
                        numParameterObservaciones++;
                    }
                }
            }

            if (numParameterObservaciones > 0)
            {
                estadoTodoParameter = ConstanteMaestro.COD_EST_VALIDACION_OBS;
            }
            if (numParameterIncorrectos > 0)
            {
                estadoTodoParameter = ConstanteMaestro.COD_EST_VALIDACION_ERROR;
            }

            dsx.codigoEstadoParameter = estadoTodoParameter;
        }
    }
}
