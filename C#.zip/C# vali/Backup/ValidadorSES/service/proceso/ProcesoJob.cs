﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.util;
using ValidadorSES.modelo;

namespace ValidadorSES.service.proceso
{
    public class ProcesoJob
    {

        private const string CAMPO_APLICATIVO = "APLICATIVO";
        private const string CAMPO_NOMBRE = "NOMBRE";
        private const string CAMPO_DESTINO = "DESTINO";
        private const string CAMPO_DESTINOS = "DESTINOS";
        private const string CAMPO_FUENTE = "FUENTE";
        private const string CAMPO_FUENTES = "FUENTES";
        private const string CAMPO_DEPENDENCIAS = "DEPENDENCIAS";
        private const string CAMPO_DEPENDENCIA = "DEPENDENCIA";
        private const string CAMPO_OBJETIVO = "OBJETIVO";
        private const string CAMPO_REPROCESABLE = "REPROCESABLE";
        private const string CAMPO_SCHEDULER = "SCHEDULER";
        private const string CAMPO_VERSIONES = "VERSIONES";
        
        public static void setDocInterna(LogObjetoDocumentacionInterna docInt, string fullDescripcion) 
        {
            string[] arreglo = fullDescripcion.Split('\n');
            int cont = 0;
            int fin = arreglo.Length;
            bool esIniDestino = false;
            bool esFinDestino = false;
            bool esIniFuente = false;
            bool esFinFuente = false;
            bool esIniDependencia = false;
            bool esFinDependencia = false;
            bool esIniVersion = false;
            bool esFinVersion = false;

            //obtención de las fuentes y destinos a partir de la documentación del job
            while (cont < fin)
            {
                //DESTINO
                if (esIniDestino && !esFinDestino)
                {
                    string linea = arreglo[cont];
                    if (!esLineaCampo(linea))
                    {
                        string lineaValida = UtilProceso.getElementoLineaValido(linea);
                        if (lineaValida != "")
                        {
                            docInt.listaDestino.Add(lineaValida);
                        }
                    }
                    else
                    {
                        esFinDestino = true;
                    }
                }

                //FUENTES
                if (esIniFuente && !esFinFuente)
                {
                    string linea = arreglo[cont];
                    if (!esLineaCampo(linea))
                    {
                        string lineaValida = UtilProceso.getElementoLineaValido(linea);
                        if (lineaValida != "")
                        {
                            docInt.listaFuentes.Add(lineaValida);
                        }
                    }
                    else
                    {
                        esFinFuente = true;
                    }
                }

                //DEPENDENCIAS
                if (esIniDependencia && !esFinDependencia)
                {
                    string linea = arreglo[cont];
                    if (!esLineaCampo(linea))
                    {
                        string lineaValida = UtilProceso.getElementoLineaValido(linea);
                        if (lineaValida != "")
                        {
                            docInt.listaDependencias.Add(lineaValida);
                        }
                    }
                    else
                    {
                        esFinDependencia = true;
                    }
                }
                //VERSIONES
                if (esIniVersion && !esFinVersion)
                {
                    string linea = arreglo[cont];
                    if (!esLineaCampo(linea))
                    {
                        string lineaActual = UtilCadena.eliminarCaracteresInvalidos(arreglo[cont]).Trim();
                        if (lineaActual != "")
                        {
                            docInt.listaVersion.Add(lineaActual);
                        }
                    }
                    else 
                    {
                        esFinVersion = true;
                    }
                }

                //CAMPOS
                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_APLICATIVO))
                {                    
                    docInt.aplicativo = UtilProceso.getValorCampoLineaComienzaPalabra(arreglo[cont], CAMPO_APLICATIVO);
                    if (docInt.aplicativo != "")
                    {
                        docInt.tieneCampoAplicativo = true;

                        esFinDestino = true;
                        esFinFuente = true;
                        esFinDependencia = true;
                        esFinVersion = true;
                    }
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_NOMBRE))
                {
                    docInt.nombre = UtilProceso.getValorCampoLineaComienzaPalabra(arreglo[cont], CAMPO_NOMBRE);
                    docInt.tieneCampoNombre = true;

                    esFinDestino = true;
                    esFinFuente = true;
                    esFinDependencia = true;
                    esFinVersion = true;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_DESTINO)
                    || UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_DESTINOS))
                {
                    docInt.tieneCampoDestino = true;

                    esIniDestino = true;
                    esFinDestino = false;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_FUENTE)
                    || UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_FUENTES))
                {
                    docInt.tieneCampoFuentes = true;

                    esIniFuente = true;
                    esFinFuente = false;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_DEPENDENCIAS))
                {
                    docInt.tieneCampoDependencias = true;

                    esIniDependencia = true;
                    esFinDependencia = false;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_DEPENDENCIA))
                {
                    docInt.tieneCampoDependencias = true;

                    esIniDependencia = true;
                    esFinDependencia = false;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_OBJETIVO))
                {
                    docInt.objetivo = UtilProceso.getValorCampoLineaComienzaPalabra(arreglo[cont], CAMPO_OBJETIVO);
                    docInt.tieneCampoObjetivo = true;

                    esFinDestino = true;
                    esFinFuente = true;
                    esFinDependencia = true;
                    esFinVersion = true;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_REPROCESABLE))
                {
                    docInt.reprocesable = UtilProceso.getValorCampoLineaComienzaPalabra(arreglo[cont], CAMPO_REPROCESABLE);
                    docInt.tieneCampoReprocesable = true;

                    esFinDestino = true;
                    esFinFuente = true;
                    esFinDependencia = true;
                    esFinVersion = true;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_SCHEDULER))
                {
                    docInt.scheduler = UtilProceso.getValorCampoLineaComienzaPalabra(arreglo[cont], CAMPO_SCHEDULER);
                    docInt.tieneCampoScheduler = true;

                    esFinDestino = true;
                    esFinFuente = true;
                    esFinDependencia = true;
                    esFinVersion = true;
                }

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_VERSIONES))
                {
                    docInt.tieneCampoVersiones = true;

                    esIniVersion = true;
                    esFinVersion = false;
                }

                cont++;
            }
        }

        private static bool esLineaCampo(string linea)
        {
            return UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_APLICATIVO)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_NOMBRE)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_DESTINO)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_DESTINOS)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_FUENTE)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_FUENTES)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_DEPENDENCIAS)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_DEPENDENCIA)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_OBJETIVO)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_REPROCESABLE)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_SCHEDULER)
                || UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_VERSIONES);
        }



        //public static List<string> getDocIntListaDestino(string descripcion)
        //{
        //    string fullDescripcion = descripcion;
        //    fullDescripcion = UtilCadena.eliminarCaracteresInvalidos(fullDescripcion);

        //    List<string> listaDestinoDes = new List<string>();

        //    string[] arreglo = fullDescripcion.Split('\n');
        //    int cont = 0;
        //    int fin = arreglo.Length;

        //    //obtención de las fuentes y destinos a partir de la documentación del job
        //    while (cont < fin)
        //    {
        //        if (arreglo[cont].Trim().StartsWith("DESTINOS:") || arreglo[cont].Trim().StartsWith("DESTINO:"))
        //        {
        //            cont++;
        //            while (cont < fin - 1 && !arreglo[cont].Trim().StartsWith("OBJETIVO:")
        //                && !arreglo[cont].Trim().StartsWith("FUENTES:")
        //                && !arreglo[cont].Trim().StartsWith("FUENTE:"))
        //            {
        //                string linea = getElementoLineaValido(arreglo[cont]);
        //                if (linea != "")
        //                {
        //                    listaDestinoDes.Add(linea);
        //                }
        //                cont++;
        //            }
        //        }
        //        else
        //        {
        //            cont++;
        //        }
        //    }

        //    return listaDestinoDes;
        //}

        //public static List<string> getDocIntListaVersion(string descripcion)
        //{
        //    List<string> lastlista = new List<string>();
        //    List<string> newlista = new List<string>();

        //    string[] listaDescripcion = descripcion.Split('\n');
        //    string lineaActual = "";
        //    bool esLineaVersion = false;

        //    for (int i = 0; i < listaDescripcion.Count(); i++)
        //    {

        //        lineaActual = UtilCadena.eliminarCaracteresInvalidos(listaDescripcion[i]);
        //        if (lineaActual.Contains("VERSIONES:") || lineaActual.Contains("VERSION:") || lineaActual.Contains("VERSIÓN:"))
        //        {
        //            esLineaVersion = true;

        //        }
        //        if (esLineaVersion)
        //        {
        //            lineaActual = UtilCadena.replaceCaracteresInvalidos(listaDescripcion[i]);
        //            lineaActual = lineaActual.Trim();
        //            newlista.Add(lineaActual);
        //        }

        //    }

        //    for (int i = 0; i < newlista.Count(); i++)
        //    {
        //        if (newlista[i] != "")
        //        {
        //            lastlista.Add(newlista[i]);
        //        }
        //    }

        //    return lastlista;
        //}

        //public static List<string> getDocIntListaDependencias(string descripcion)
        //{
        //    string fullDescripcion = descripcion;
        //    fullDescripcion = UtilCadena.eliminarCaracteresInvalidos(fullDescripcion);
        //    List<string> listaDependientes = new List<string>();

        //    //obtener la lista de dependientes de la documentacion del job sequence
        //    string[] arreglo = descripcion.Split('\n');
        //    int cont = 0;
        //    int fin = arreglo.Length;

        //    while (cont < fin)
        //    {
        //        if (arreglo[cont].Trim().StartsWith("DEPENDENCIAS:"))
        //        {
        //            cont++;
        //            while (cont < fin && !arreglo[cont].Trim().StartsWith("OBJETIVO:")
        //                && !arreglo[cont].Trim().StartsWith("REPROCESABLE:")
        //                && !arreglo[cont].Trim().StartsWith("VERSIONES:")
        //                && !arreglo[cont].Trim().StartsWith("=+=+=+="))
        //            {
        //                string linea = getElementoLineaValido(arreglo[cont]);
        //                if (linea != "")
        //                {
        //                    listaDependientes.Add(linea);
        //                }
        //                cont++;
        //            }
        //        }
        //        else
        //        {
        //            cont++;
        //        }
        //    }

        //    return listaDependientes;
        //}

        //public static List<string> getDocIntListaFuentes(string descripcion)
        //{
        //    string fullDescripcion = descripcion;
        //    fullDescripcion = UtilCadena.eliminarCaracteresInvalidos(fullDescripcion);

        //    string[] arreglo = fullDescripcion.Split('\n');
        //    List<string> listaFuenteDes = new List<string>();
        //    int cont = 0;
        //    int fin = arreglo.Length;

        //    //obtención de las fuentes y destinos a partir de la documentación del job
        //    while (cont < fin)
        //    {
        //        if (arreglo[cont].Trim().StartsWith("FUENTES:") || arreglo[cont].Trim().StartsWith("FUENTE:"))
        //        {
        //            cont++;
        //            while (cont < fin && !arreglo[cont].Trim().StartsWith("DESTINOS:")
        //                && !arreglo[cont].Trim().StartsWith("DESTINO:")
        //                && !arreglo[cont].Trim().StartsWith("OBJETIVO:")
        //                && !arreglo[cont].Trim().StartsWith("OBJETIVOS:"))
        //            {
        //                string linea = getElementoLineaValido(arreglo[cont]);
        //                if (linea != "")
        //                {
        //                    listaFuenteDes.Add(linea);
        //                }
        //                cont++;
        //            }
        //        }
        //        else
        //        {
        //            cont++;
        //        }
        //    }

        //    return listaFuenteDes;
        //}

        //public static string getDocIntNombre(string descripcion)
        //{
        //    string fullDescripcion = UtilCadena.eliminarCaracteresInvalidos(descripcion);

        //    string[] arreglo = fullDescripcion.Split('\n');

        //    for (int i = 0; i < arreglo.Count(); i++)
        //    {
        //        //validación del nombre del Job en la documentación
        //        if (arreglo[i].StartsWith("NOMBRE"))
        //        {
        //            string[] cadena = arreglo[i].Split(':');
        //            if (cadena.Count() == 2)
        //            {
        //                return cadena[1].Trim();
        //            }
        //        }
        //    }

        //    return "";
        //}

    }
}
