﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.service.proceso
{
    public class ProcesoUserVarsActivity
    {

        public static List<LogObjetoParam> getListaParamUserVariableActivity(string parametroUserVariable)
        {
            List<LogObjetoParam> lista = new List<LogObjetoParam>();
            if (parametroUserVariable != null)
            {
                string[] arregloParmRoutine = parametroUserVariable.Split('\n');

                for (int i = 0; i < arregloParmRoutine.Length; i++)
                {
                    int next = i;
                    if (arregloParmRoutine[i].StartsWith("Name"))
                    {
                        next++;

                        LogObjetoParam param = new LogObjetoParam();
                        param.listaFuncion = new List<string>();
                        param.name = arregloParmRoutine[i].Substring(6, arregloParmRoutine[i].Length - 7);
                        
                        if (arregloParmRoutine[next].StartsWith("Description"))
                        {
                            param.description = arregloParmRoutine[next].Substring(13, arregloParmRoutine[next].Length - 14).Trim();
                            param.listaFuncion = getListaFuncionByDescripcion(param.description);
                        }

                        lista.Add(param);
                    }
                }
            }

            return lista;
        }

        private static List<string> getListaFuncionByDescripcion(string expresion) 
        {
            bool esFin = false;
            List<string> lista = new List<string>();

            List<Funcion> listaFuncionAtomica = new List<Funcion>();

            List<Funcion> listaFuncion = new List<Funcion>();

            if (esValidaExpresion(expresion))
            {
                int numParentesisIzq = UtilCadena.contarCaracter(expresion, '(');

                if (numParentesisIzq > 0)
                {
                    listaFuncion = getListaFuncionByExpresion(expresion);    
                }
            }

            for (int f = 0; f < listaFuncion.Count; f++)
            {
                Funcion factual = listaFuncion[f];
                listaFuncionAtomica.Add(factual);
                string token = factual.argumento;

                esFin = false;
                while (!esFin)
                {
                    if (esValidaExpresion(token))
                    {
                        int numParentesisIzq = UtilCadena.contarCaracter(token, '(');

                        if (numParentesisIzq > 0)
                        {
                            List<Funcion> listaFuncionTokenSub = getListaFuncionByExpresion(token);

                            for (int g = 0; g<listaFuncionTokenSub.Count; g++)
                            {
                                listaFuncion.Add(listaFuncionTokenSub[g]);
                            }
                        }

                        esFin = true;
                    }
                    else
                    {
                        esFin = true;
                    }
                }
            }

            for (int k = 0; k < listaFuncionAtomica.Count; k++)
            {
                string nombreFuncion = listaFuncionAtomica[k].nombre;
                nombreFuncion = getNameFuncionFiltrada(nombreFuncion);
                if (nombreFuncion.Trim() != "")
                {
                    lista.Add(nombreFuncion.Trim());
                }
            }

            return lista;
        }

        private static string getNameFuncionFiltrada(string name)
        {
            //TODO agregar más casos de prueba para cada operador + - * /

            string op1 = getNombreSinOperador(name, ':');
            if(op1 != "")
            {
                return op1;
            }

            string op2 = getNombreSinOperador(name, '+');
            if (op2 != "")
            {
                return op2;
            }

            string op3 = getNombreSinOperador(name, '-');
            if (op3 != "")
            {
                return op3;
            }

            string op4 = getNombreSinOperador(name, '*');
            if (op4 != "")
            {
                return op4;
            }

            string op5 = getNombreSinOperador(name, '/');
            if (op5 != "")
            {
                return op5;
            }

            return name;
        }

        private static string getNombreSinOperador(string name, char operador) {
            if (name.Contains(operador))
            {
                string[] arrayConcatenador = name.Split(operador);

                if (arrayConcatenador.Length > 0)
                {
                    return arrayConcatenador[arrayConcatenador.Length - 1];
                }
            }
            return "";
        }

        private static List<Funcion> getListaFuncionByExpresion(string expresion) 
        {
            List<Funcion> lista = new List<Funcion>();

            while(expresion!="")
            {
                int numParentesisIzq = UtilCadena.contarCaracter(expresion, '(');

                if (numParentesisIzq > 0)
                {
                    expresion = getToken(expresion, lista);
                }
                else 
                {
                    expresion = "";
                }
            }

            return lista;
        }

        private static string getToken(string cadena, List<Funcion> listaFuncion) 
        {            
            Funcion funcion = new Funcion();
            string nombre = "";
            string argumento = "";
            string cadenaRestante = "";

            char[] arrayChar = cadena.ToCharArray();
            int i = 0;
            int n = arrayChar.Length;

            int numParIzqArg = 0;
            int numParDerArg = 0;

            int posIniParIzq = 0;
            bool esFin = false;
            while(i<n && !esFin)
            {
                if (arrayChar[i] == '(')
                {
                    posIniParIzq = i;
                    esFin = true;
                }
                else 
                {
                    nombre += arrayChar[i];
                }
                
                i++;
            }

            i = posIniParIzq + 1;
            esFin = false;
            while(i<n && !esFin)
            {
                if (arrayChar[i] == '(')
                {
                    numParIzqArg++;
                }

                if (arrayChar[i] == ')')
                {
                    esFin = true;
                }

                i++;
            }

            i = posIniParIzq + 1;
            esFin = false;
            while (i < n && !esFin)
            {
                if (arrayChar[i] == ')')
                {
                    numParDerArg++;
                }

                if (numParDerArg <= numParIzqArg)
                {
                    argumento += arrayChar[i];
                }
                else 
                {
                    esFin = true;
                }
                
                i++;
            }
            

            funcion.nombre = nombre.Trim();
            funcion.argumento = argumento;

            listaFuncion.Add(funcion);

            cadenaRestante = cadena.Substring(i,cadena.Length - i);

            return cadenaRestante;
        }

        private static bool esValidaExpresion(string expresion) 
        {
            int numParentesisIzq = UtilCadena.contarCaracter(expresion, '(');
            int numParentesisDer = UtilCadena.contarCaracter(expresion, ')');

            return numParentesisIzq == numParentesisDer;
        }
    }
}
