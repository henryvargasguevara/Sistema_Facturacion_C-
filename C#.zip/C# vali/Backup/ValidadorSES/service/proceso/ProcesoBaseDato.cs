﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;

namespace ValidadorSES.service.proceso
{
    public class ProcesoBaseDato
    {
        public const string COMODIN_TABLA = "TTTTTTTTTT";

        public static string getBeforeAfter(string propiedad)
        {
            //NO: <BeforeAfter collapsed='1' type='bool'><![CDATA[0]]></BeforeAfter>
            //SI: <BeforeAfter modified='1' type='bool'><![CDATA[1]]>
            string iniPropiedad = "<BeforeAfter collapsed='1' type='bool'><![CDATA[";
            string finPropiedad = "]]></BeforeAfter>";
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getKeepConductorConnectionAlive(string propiedad)
        {
            string iniPropiedad = "<KeepConductorConnectionAlive modified='1' type='bool'><![CDATA[";
            string finPropiedad = "]]></KeepConductorConnectionAlive>";
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }        

        public static string getWriteMode(string propiedad)
        {
            string iniPropiedad = "<WriteMode modified='1' type='int'><![CDATA[";
            string finPropiedad = "]]></WriteMode>";
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getRecordCount(string propiedad)
        {
            string iniPropiedad = "<RecordCount type='int'><![CDATA[";
            string finPropiedad = "]]></RecordCount>";
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getRecordCountModify(string propiedad)  //JT
        {
            string iniPropiedad = "<RecordCount modified='1' type='int'><![CDATA[";
            string finPropiedad = "]]></RecordCount>";
            string aa = getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getArraySize(string propiedad)  //JT
        {
            string iniPropiedad = "<ArraySize type='int'><![CDATA[";
            string finPropiedad = "]]></ArraySize>";
            string aa = getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getArraySizeModify(string propiedad)  //JT
        {
            string iniPropiedad = "<ArraySize modified='1' type='int'><![CDATA[";
            string finPropiedad = "]]></ArraySize>";
            string aa = getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getLockWaitMode(string propiedad)  //JT
        {
            string iniPropiedad = "<LockWaitMode collapsed='1' type='int'><![CDATA[";
            string finPropiedad = "]]></LockWaitMode>";
            string aa = getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getLockWaitModeModify(string propiedad)  //JT
        {
            string iniPropiedad = "LockWaitMode collapsed='1' modified='1' type='int'><![CDATA[";
            string finPropiedad = "]]></LockWaitMode>";
            string aa = getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static string getAutoCommitMode(string propiedad)
        {
            string iniPropiedad = "<AutocommitMode type='int'><![CDATA[";
            string finPropiedad = "]]></AutocommitMode>";
            return getPropiedadDB(propiedad, iniPropiedad, finPropiedad);
        }

        public static void setearConexion(string propiedad, LogStageBaseDato db)
        { 
            string iniDatabase = "<Database modified='1' type='string'><![CDATA[";
            string finDatabase = "]]></Database>";
            db.database = getPropiedadDB(propiedad, iniDatabase, finDatabase);

            string iniUsername = "<Username modified='1' type='string'><![CDATA[";
            string finUsername = "]]></Username>";
            db.username = getPropiedadDB(propiedad, iniUsername, finUsername);

            string pass = "";
            string iniStatement = "<Password modified='1' type='string'><![CDATA[";
            string finStatement = "]]></Password>";
            pass = getPropiedadDB(propiedad, iniStatement, finStatement);
            db.protectedPassword = false;

            if (pass == "")
            {
                iniStatement = "<Password modified='1' type='protectedstring'><![CDATA[";
                finStatement = "]]></Password>";
                pass = getPropiedadDB(propiedad, iniStatement, finStatement);
                db.protectedPassword = true;
            }
            db.password = pass;
        }

        public static void setearConexionODBC(string propiedad, LogStageBaseDato db)
        {
            string iniDatabase = "<DataSource modified='1' type='string'><![CDATA[";
            string finDatabase = "]]></DataSource>";
            db.database = getPropiedadDB(propiedad, iniDatabase, finDatabase);

            string iniUsername = "<Username modified='1' type='string'><![CDATA[";
            string finUsername = "]]></Username>";
            db.username = getPropiedadDB(propiedad, iniUsername, finUsername);

            string pass = "";
            string iniStatement = "<Password modified='1' type='string'><![CDATA[";
            string finStatement = "]]></Password>";
            pass = getPropiedadDB(propiedad, iniStatement, finStatement);
            db.protectedPassword = false;

            if (pass == "")
            {
                iniStatement = "<Password modified='1' type='protectedstring'><![CDATA[";
                finStatement = "]]></Password>";
                pass = getPropiedadDB(propiedad, iniStatement, finStatement);
                db.protectedPassword = true;
            }
            db.password = pass;
        }

        public static bool estaComentario(List<string> listaSQL)
        {
            for (int i = 0; i < listaSQL.Count; i++)
            {
                if (listaSQL[i].Contains("--"))
                {
                    return true;
                }
            }
            return false;
        }

        public static List<string> getListaQueryValida(List<string> listaSQL)
        {
            List<string> listaValida = new List<string>();
            if (listaSQL!=null && listaSQL.Count>0)
            {
                for (int i = 0; i<listaSQL.Count; i++)
                {
                    string sqlValido = getCadenaSQL(listaSQL[i]);

                    if(sqlValido != "")
                    {
                        listaValida.Add(sqlValido);
                    }
                }
            }

            return listaValida;
        }

        public static List<string> getListaQuery(string xmlProperties)
        {
            //TODO chekar el caso del collapsed
            List<string> listaSQL = new List<string>();

            //validar el string tiene datos
            if (xmlProperties == null || xmlProperties.Trim().Length == 0)
            {
                return listaSQL;
            }

            //GENERATE SQL SI: <GenerateSQL modified='1' type='bool'><![CDATA[1]]></GenerateSQL>
            if (xmlProperties.Contains("<![CDATA[1]]></GenerateSQL>"))
            {
                //tabla con datos: <TableName modified='1' type='string'><![ ... ]]></TableName>
                //tabla sin datos: <TableName type='string'></TableName>
                string iniTableName = "<TableName modified='1' type='string'><![CDATA[";
                string finTableName = "]]></TableName>";
                agregarSQL(listaSQL, xmlProperties, iniTableName, finTableName, true);//se agrego comodin TABLE
            }

            //GENERATE SQL NO: <GenerateSQL modified='1' type='bool'><![CDATA[0]]></GenerateSQL>
            if (xmlProperties.Contains("<![CDATA[0]]></GenerateSQL>"))
            {
                string iniSQLSelect = "<SelectStatement modified='1' type='string'><![CDATA[";
                string finSQLSelect = "]]><ReadFromFileSelect";
                agregarSQL(listaSQL, xmlProperties, iniSQLSelect, finSQLSelect, false);


                string iniSQLInsert = "<InsertStatement modified='1' type='string'><![CDATA[";
                string finSQLInsert = "]]><Tables";
                agregarSQL(listaSQL, xmlProperties, iniSQLInsert, finSQLInsert, false);

                string iniSQLDelete = "<DeleteStatement modified='1' type='string'><![CDATA[";
                string finSQLDelete = "]]><Tables";
                agregarSQL(listaSQL, xmlProperties, iniSQLDelete, finSQLDelete, false);

                string iniSQLUpdate = "<UpdateStatement modified='1' type='string'><![CDATA[";
                string finSQLUpdate = "]]><Tables";
                agregarSQL(listaSQL, xmlProperties, iniSQLUpdate, finSQLUpdate, false);
            }

            //WRITE MODE User-defined SQL:
            //<UserDefinedSQL type='int'><![CDATA[1]]>
            //<Statements modified='1' type='string'><![CDATA[
            if (xmlProperties.Contains("<WriteMode"))
            {
                string iniStatement = "<Statements modified='1' type='string'><![CDATA[";
                string finStatement = "]]></Statements>";
                agregarSQL(listaSQL, xmlProperties, iniStatement, finStatement, false);
            }


            //BEFORE/AFTER SQL EN SI
            if (xmlProperties.Contains("<BeforeAfter modified='1' type='bool'><![CDATA[1]]>"))
            {
                string iniBefore = "<before modified='1' type='string'><![CDATA[";
                string finBefore = "]]><ReadFromFileBeforeSQL";
                agregarSQL(listaSQL, xmlProperties, iniBefore, finBefore, false);

                string iniAfter = "<after modified='1' type='string'><![CDATA[";
                string finAfter = "]]><ReadFromFileAfterSQL";
                agregarSQL(listaSQL, xmlProperties, iniAfter, finAfter, false);

                string iniBeforeNode = "<beforeNode modified='1' type='string'><![CDATA[";
                string finBeforeNode = "]]><ReadFromFileBeforeSQLNode";
                agregarSQL(listaSQL, xmlProperties, iniBeforeNode, finBeforeNode, false);

                string iniAfterNode = "<afterNode modified='1' type='string'><![CDATA[";
                string finAfterNode = "]]><ReadFromFileAfterSQLNode";
                agregarSQL(listaSQL, xmlProperties, iniAfterNode, finAfterNode, false);
            }


            return listaSQL;
        }


        public static List<string> getListaQueryODBC(string xmlProperties)
        {
            //TODO chekar el caso del collapsed
            List<string> listaSQL = new List<string>();

            //validar el string tiene datos
            if (xmlProperties == null || xmlProperties.Trim().Length == 0)
            {
                return listaSQL;
            }

            //GENERATE SQL SI: <GenerateSQL modified='1' type='bool'><![CDATA[1]]></GenerateSQL>
            if (xmlProperties.Contains("<![CDATA[1]]></GenerateSQL>"))
            {
                //tabla con datos: <TableName modified='1' type='string'><![ ... ]]></TableName>
                //tabla sin datos: <TableName type='string'></TableName>
                string iniTableName = "<TableName modified='1' type='string'><![CDATA[";
                string finTableName = "]]></TableName>";
                agregarSQL(listaSQL, xmlProperties, iniTableName, finTableName, true);//se agrego comodin TABLE
            }

            //GENERATE SQL NO: <GenerateSQL modified='1' type='bool'><![CDATA[0]]></GenerateSQL>
            if (xmlProperties.Contains("<![CDATA[0]]></GenerateSQL>"))
            {
                string iniSQLSelect = "<SelectStatement modified='1' type='string'><![CDATA[";
                string finSQLSelect = "]]><ReadStatementFromFile";
                agregarSQL(listaSQL, xmlProperties, iniSQLSelect, finSQLSelect, false);


                string iniSQLInsert = "<InsertStatement modified='1' type='string'><![CDATA[";
                string finSQLInsert = "]]><Tables";
                agregarSQL(listaSQL, xmlProperties, iniSQLInsert, finSQLInsert, false);

                string iniSQLDelete = "<DeleteStatement modified='1' type='string'><![CDATA[";
                string finSQLDelete = "]]><Tables";
                agregarSQL(listaSQL, xmlProperties, iniSQLDelete, finSQLDelete, false);

                string iniSQLUpdate = "<UpdateStatement modified='1' type='string'><![CDATA[";
                string finSQLUpdate = "]]><Tables";
                agregarSQL(listaSQL, xmlProperties, iniSQLUpdate, finSQLUpdate, false);
            }

            //WRITE MODE User-defined SQL:
            //<UserDefinedSQL type='int'><![CDATA[1]]>
            //<Statements modified='1' type='string'><![CDATA[
            if (xmlProperties.Contains("<WriteMode"))
            {
                string iniStatement = "<Statements modified='1' type='string'><![CDATA[";
                string finStatement = "]]></Statements>";
                agregarSQL(listaSQL, xmlProperties, iniStatement, finStatement, false);
            }


            //BEFORE/AFTER SQL EN SI
            if (xmlProperties.Contains("<BeforeAfter modified='1' type='bool'><![CDATA[1]]>"))
            {
                string iniBefore = "<before modified='1' type='string'><![CDATA[";
                string finBefore = "]]><ReadFromFileBeforeSQL";
                agregarSQL(listaSQL, xmlProperties, iniBefore, finBefore, false);

                string iniAfter = "<after modified='1' type='string'><![CDATA[";
                string finAfter = "]]><ReadFromFileAfterSQL";
                agregarSQL(listaSQL, xmlProperties, iniAfter, finAfter, false);

                string iniBeforeNode = "<beforeNode modified='1' type='string'><![CDATA[";
                string finBeforeNode = "]]><ReadFromFileBeforeSQLNode";
                agregarSQL(listaSQL, xmlProperties, iniBeforeNode, finBeforeNode, false);

                string iniAfterNode = "<afterNode modified='1' type='string'><![CDATA[";
                string finAfterNode = "]]><ReadFromFileAfterSQLNode";
                agregarSQL(listaSQL, xmlProperties, iniAfterNode, finAfterNode, false);
            }


            return listaSQL;
        }

        private static void agregarSQL(List<string> listaSQL, string xmlProperties, string iniSQL, string finSQL, bool agregarComodin)
        {
            //string iniSQL = strIni;//"<SelectStatement modified='1' type='string'><![CDATA[";
            //string finSQL = strFin;//"]]><ReadFromFileSelect";

            //caso 1: modified='1' type='string'
            if (xmlProperties.Contains(iniSQL))
            {
                //obtener subcadena
                int totalCadena = xmlProperties.Length;
                int iniSubcadena = xmlProperties.IndexOf(iniSQL);
                int tamanioSubcadena = totalCadena - iniSubcadena;
                string subcadena = xmlProperties.Substring(iniSubcadena, tamanioSubcadena);

                //obtener query
                int posIniSQL = subcadena.IndexOf(iniSQL) + iniSQL.Length;
                int posFinSQL = subcadena.IndexOf(finSQL);
                string sql = subcadena.Substring(posIniSQL, posFinSQL - posIniSQL);

                sql = formatearSQL(sql);
                if (agregarComodin)
                {
                    sql = COMODIN_TABLA + " " + sql;
                }
                listaSQL.Add(sql);
            }

            //caso 2: collapsed='1' modified='1'
            iniSQL = iniSQL.Replace("modified='1'", "collapsed='1' modified='1'");
            if (xmlProperties.Contains(iniSQL))
            {
                //obtener subcadena
                int totalCadena = xmlProperties.Length;
                int iniSubcadena = xmlProperties.IndexOf(iniSQL);
                int tamanioSubcadena = totalCadena - iniSubcadena;
                string subcadena = xmlProperties.Substring(iniSubcadena, tamanioSubcadena);

                //obtener query
                int posIniSQL = subcadena.IndexOf(iniSQL) + iniSQL.Length;
                int posFinSQL = subcadena.IndexOf(finSQL);
                string sql = subcadena.Substring(posIniSQL, posFinSQL - posIniSQL);

                sql = formatearSQL(sql);
                if (agregarComodin)
                {
                    sql = COMODIN_TABLA + " " + sql;
                }
                listaSQL.Add(sql);
            }
        }

        private static string getPropiedadDB(string xmlProperties, string iniSQLDB, string finSQL)
        {
            //string iniSQL = strIni;//"<SelectStatement modified='1' type='string'><![CDATA[";
            //string finSQL = strFin;//"]]><ReadFromFileSelect";

            //caso 1: modified='1' type='string'
            if (xmlProperties.Contains(iniSQLDB))
            {
                //obtener subcadena
                int totalCadena = xmlProperties.Length;
                int iniSubcadena = xmlProperties.IndexOf(iniSQLDB);
                int tamanioSubcadena = totalCadena - iniSubcadena;
                string subcadena = xmlProperties.Substring(iniSubcadena, tamanioSubcadena);

                //obtener query
                int posIniSQL = subcadena.IndexOf(iniSQLDB) + iniSQLDB.Length;
                int posFinSQL = subcadena.IndexOf(finSQL);
                string prop = subcadena.Substring(posIniSQL, posFinSQL - posIniSQL);

                return prop;
            }

            //caso 2: collapsed='1' modified='1'
            string iniSQL = iniSQLDB.Replace("modified='1'", "collapsed='1' modified='1'");
            if (xmlProperties.Contains(iniSQL))
            {
                //obtener subcadena
                int totalCadena = xmlProperties.Length;
                int iniSubcadena = xmlProperties.IndexOf(iniSQL);
                int tamanioSubcadena = totalCadena - iniSubcadena;
                string subcadena = xmlProperties.Substring(iniSubcadena, tamanioSubcadena);

                //obtener query
                int posIniSQL = subcadena.IndexOf(iniSQL) + iniSQL.Length;
                int posFinSQL = subcadena.IndexOf(finSQL);
                string prop = subcadena.Substring(posIniSQL, posFinSQL - posIniSQL);

                return prop;
            }

            //caso 3: 
            iniSQL = iniSQLDB.Replace("modified='1' ", "");
            if (xmlProperties.Contains(iniSQL))
            {
                //obtener subcadena
                int totalCadena = xmlProperties.Length;
                int iniSubcadena = xmlProperties.IndexOf(iniSQL);
                int tamanioSubcadena = totalCadena - iniSubcadena;
                string subcadena = xmlProperties.Substring(iniSubcadena, tamanioSubcadena);

                //obtener query
                int posIniSQL = subcadena.IndexOf(iniSQL) + iniSQL.Length;
                int posFinSQL = subcadena.IndexOf(finSQL);
                string prop = subcadena.Substring(posIniSQL, posFinSQL - posIniSQL);

                return prop;
            }

            return "";
        }

        private static string formatearSQL(string sql)
        {
            //\\(A) cadena de salto de linea
            //sql = sql.Replace("\\(A)", " ");
            return sql.Trim();
        }


        public static List<string> getListaTablaDB2(List<string> listaSQL)
        {
            List<string> l = new List<string>();

            try
            {
                string tabla = "";

                for (int i = 0; i < listaSQL.Count; i++)
                {
                    string query = listaSQL[i];
                    tabla = getTablaFromLinea(query);
                    if (tabla != "")
                    {
                        l.Add(tabla);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocurrió una excepción en getTablaDB2" + ex.ToString());
            }

            return l;
        }

        private static string getTablaFromLinea(string query)
        {
            string cadenaValidaSQL = query;

            if (cadenaValidaSQL.ToUpper().Contains((" JOIN ").ToUpper()))
            {
                return ""; //es un select inválido
            }

            //select
            if (cadenaValidaSQL.ToUpper().Contains("SELECT")) //SELECT
            {
                string[] arrayCadena = cadenaValidaSQL.ToUpper().Split(new string[] { "FROM" }, StringSplitOptions.None);
                if (arrayCadena != null && arrayCadena.Length >= 2)
                {
                    string parteDerecha = arrayCadena[1].ToUpper().Trim();

                    if (parteDerecha.Contains("WHERE"))
                    {
                        string[] arrayWhere = parteDerecha.ToUpper().Split(new string[] { "WHERE" }, StringSplitOptions.None);

                        return quitarAliasTabla(arrayWhere[0].Trim());
                    }
                    else
                    {
                        if (parteDerecha.Contains("GROUP BY"))
                        {
                            string[] arrayWhere = parteDerecha.ToUpper().Split(new string[] { "GROUP BY" }, StringSplitOptions.None);
                            return quitarAliasTabla(arrayWhere[0].Trim());
                        }
                        else 
                        {
                            if (parteDerecha.Contains("FETCH FIRST"))
                            {
                                string[] arrayFetchFirst = parteDerecha.ToUpper().Split(new string[] { "FETCH FIRST" }, StringSplitOptions.None);
                                return quitarAliasTabla(arrayFetchFirst[0].Trim());
                            }
                        }
                    }

                    return quitarAliasTabla(parteDerecha);
                }
            }

            //update
            if (cadenaValidaSQL.ToUpper().Contains("UPDATE"))
            {
                string[] arrayCadena = cadenaValidaSQL.ToUpper().Split(new string[] { "UPDATE" }, StringSplitOptions.None);
                if (arrayCadena != null && arrayCadena.Length >= 2)
                {
                    string parteDerecha = arrayCadena[1].ToUpper().Trim();
                    if (parteDerecha.Contains("SET"))
                    {
                        string[] arraySet = parteDerecha.ToUpper().Split(new string[] { "SET" }, StringSplitOptions.None);
                        return quitarAliasTabla(arraySet[0].Trim());
                    }
                }
            }

            //insert
            if (cadenaValidaSQL.ToUpper().Contains("INSERT"))
            {
                string[] arrayCadena = cadenaValidaSQL.ToUpper().Split(new string[] { "VALUES" }, StringSplitOptions.None);
                if (arrayCadena != null && arrayCadena.Length >= 2)
                {
                    string parteIzq = arrayCadena[0].ToUpper().Trim();
                    string parteInsertInto = parteIzq;
                    if (parteIzq.Contains("("))
                    {
                        string[] arrayPar = parteIzq.ToUpper().Split(new string[] { "(" }, StringSplitOptions.None);
                        parteInsertInto = arrayPar[0].Trim();
                    }

                    string[] arrayInsertInto = parteInsertInto.ToUpper().Split(new string[] { "INSERT INTO" }, StringSplitOptions.None);
                    return quitarAliasTabla(arrayInsertInto[1].Trim());
                }
            }

            //delete
            if (cadenaValidaSQL.ToUpper().Contains("DELETE"))
            {
                string[] arrayCadena = cadenaValidaSQL.ToUpper().Split(new string[] { "FROM" }, StringSplitOptions.None);
                if (arrayCadena != null && arrayCadena.Length >= 2)
                {
                    string parteDerecha = arrayCadena[1].ToUpper().Trim();
                    if (parteDerecha.Contains("WHERE"))
                    {
                        string[] arraySet = parteDerecha.ToUpper().Split(new string[] { "WHERE" }, StringSplitOptions.None);
                        return quitarAliasTabla(arraySet[0].Trim());
                    }

                    return quitarAliasTabla(parteDerecha);
                }
            }

            //comodin table
            if (cadenaValidaSQL.ToUpper().Contains(COMODIN_TABLA))
            {
                string[] arrayCadena = cadenaValidaSQL.ToUpper().Split(new string[] { COMODIN_TABLA }, StringSplitOptions.None);
                if (arrayCadena != null && arrayCadena.Length >= 2)
                {
                    string parteDerecha = arrayCadena[1].ToUpper().Trim();
                    return quitarAliasTabla(parteDerecha);
                }
            }

            return "";
        }

        private static string quitarAliasTabla(string lineaTabla) 
        {
            if (lineaTabla.ToUpper().Contains(" AS "))
            {
                string[] arrayAlias = lineaTabla.ToUpper().Split(new string[] { "AS" }, StringSplitOptions.None);
                return arrayAlias[0].Trim();
            }

            if (lineaTabla.Trim().Contains(" "))
            {
                string[] arrayAlias = lineaTabla.Trim().ToUpper().Split(' ');
                return arrayAlias[0].Trim();
            }

            return lineaTabla;
        }

        private static string getCadenaSQL(string sql)
        {
            string sqlFormateado = "";
            if (sql.Contains("\\(A)") || sql.Contains("\n")) //tiene enters
            {
                string[] arrayCadena;
                if (sql.Contains("\\(A)"))
                {
                    arrayCadena = sql.Split(new string[] { "\\(A)" }, StringSplitOptions.None);
                }
                else
                {
                    arrayCadena = sql.Split('\n');
                }

                if (arrayCadena != null && arrayCadena.Length > 0)
                {
                    for (int i = 0; i < arrayCadena.Length; i++)
                    {
                        string linea = arrayCadena[i].Trim();
                        linea = getCadenaSQLSinComentariosAndPuntoComa(linea);
                        if (linea != "")
                        {
                            linea += " ";
                            sqlFormateado += linea;
                        }
                    }
                }
            }
            else
            {
                //no tiene enters
                sqlFormateado = getCadenaSQLSinComentariosAndPuntoComa(sql);
            }

            sqlFormateado = sqlFormateado.Replace("\\(9)", "");

            return sqlFormateado.Trim();
        }

        private static string getCadenaSQLSinComentariosAndPuntoComa(string sql)
        {
            sql = sql.Replace(";", "");
            if (sql.Contains("--"))
            {
                int posIniComentario = sql.IndexOf("--");
                string consultaSQL = sql.Substring(0, posIniComentario);
                return consultaSQL.Trim();
            }
            return sql.Trim();
        }

    }
}
