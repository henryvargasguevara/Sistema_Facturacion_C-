﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Facturacion
{
    public partial class menuDinamico : System.Web.UI.Page
    {
        libreria lib = new libreria();
        DataTable tbOpciones = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            llenarMenu(Convert.ToInt32(Session["usuario"]));
        }

        private void llenarMenu(int idUsuario)
        {
            int nfila=0;
       
            tbOpciones = lib.menuPrincipal(idUsuario);
            foreach (DataRow fila in tbOpciones.Rows)
            {   if ((fila["nivel"]).ToString()=="1")
                {
                    //MenuItem menuItem=new MenuItem(tbOpciones.Rows[nfila][0].ToString(),tbOpciones.Rows[nfila][1].ToString(),String.Empty,tbOpciones.Rows[nfila][3].ToString());
                    MenuItem menuItem = new MenuItem(fila["opcion"].ToString(), fila["id_opcion"].ToString(), String.Empty, fila["linkpagina"].ToString());
                    menuMain.Items.Add(menuItem);
                    nfila = nfila + 1;
                    anadirHijo(menuItem);

                }
            
            }

        }

        /// <summary>
        /// la
        /// </summary>
        /// <param name="menuItem"></param>
        private void anadirHijo(MenuItem menuItem)
        {    
            foreach (DataRow fila in tbOpciones.Rows)
            {
                if (fila["nivel"].ToString()==menuItem.Value)
                {
                    MenuItem menuItemHijo = new MenuItem(fila[0].ToString(),fila[1].ToString(),String.Empty,fila[2].ToString());
                    menuItem.ChildItems.Add(menuItemHijo);
                }                  
            }

        }

        protected void menuMain_MenuItemClick(object sender, MenuEventArgs e)
        {
            

        }
    }
}