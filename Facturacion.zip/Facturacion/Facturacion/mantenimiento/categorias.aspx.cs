﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Facturacion.paginas
{
    public partial class categorias : System.Web.UI.Page
    {
        libreria lib = new libreria();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int codigo;
            codigo = lib.ingresarCategoria(txtdescripcion.Text.Trim());
            txtCodigo.Text = codigo.ToString();
        }
    }
}