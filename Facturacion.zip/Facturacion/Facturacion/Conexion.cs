﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Facturacion
{
    public class Conexion
    {   //cadena de conexion
        String cs_conexion = "Data Source = DESKTOP-JM0U47U\\SQLSERVER2008_R2;Initial Catalog=sistema_facturacion;User ID=sa;Password=1234";
        public SqlConnection cn = new SqlConnection();

        public Conexion()
        {
            cn.ConnectionString = cs_conexion;
        }

        public Boolean conectarse()
        {
            Boolean estado;
            try
            {
                cn.Open();
                estado = true;

            }
            catch (Exception e)
            {
                estado = false;
            }

            return estado;
        }

        public void Desconectar()
        {
            cn.Close();
        }

        public DataTable validarUsuario(String pusuario,String pclave)
        { //PERMITE TRAER LOS NOMBRES COMPLETOS DE LOS USUARIOS VALIDADOS
            DataTable tbdatos  = new DataTable();
            SqlDataAdapter adaptador;
            SqlCommand comando;

            conectarse();
            comando = new SqlCommand("validarUsuario",cn);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@pusuario",pusuario);
            comando.Parameters.AddWithValue("@pclave",pclave);

            try
            {
                adaptador = new SqlDataAdapter();
               
                adaptador.SelectCommand = comando;
                adaptador.Fill(tbdatos);
            }
            catch (Exception e)
            {
                
            }
            //tbdatos.Load(comando.ExecuteReader());
            //sdataGridView1.DataSource = dt;

            Desconectar();
            return tbdatos;
        }
    }
}