﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Facturacion
{
    public partial class Login : System.Web.UI.Page
    {
        
        Conexion libreria = new Conexion();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btningresar_Click(object sender, EventArgs e)
        {
            DataTable tabla = new DataTable();
            //CONECTAR A LA BASE DE DATOS
            //VERIFICAR SI EXISTE
            //REDIRECCIONAR

            tabla = libreria.validarUsuario(txtusuario.Text,txtpassword.Text);
            if (tabla.Rows.Count == 0)
            {
                //lbl_usuario_Visible = false;
                //lbl_login_mensaje.Visible = true;
                //lbl_login_mensaje.Text = "Error, combinacion de usuario y clave incorrecto";
                Response.Write("Usuario no Valido");

            }
            else
            {   //lbl_login_mensaje.Text = "Login correcto...";
                Session["usuario"] = tabla.Rows[0][0].ToString();
                Session["nombres"] = tabla.Rows[0][1].ToString();
                Response.Redirect("menuDinamico.aspx");
            }

        }
    }
}