﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Facturacion
{
    public partial class Login : System.Web.UI.Page
    {
        Conexion libreria = new Conexion();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btningresar_Click(object sender, EventArgs e)
        {
            //CONECTAR A LA BASE DE DATOS
            //VERIFICAR SI EXISTE
            //REDIRECCIONAR
            DataTable tabla;
            tabla = libreria.validarUsuario(txtusuario.Text,txtpassword.Text);
            if (tabla.Rows.Count == 0)
            {
                Response.Write("Usuario no Valido");

            }
            else
            {
                Response.Write("Usuario Valido");
            }

        }
    }
}