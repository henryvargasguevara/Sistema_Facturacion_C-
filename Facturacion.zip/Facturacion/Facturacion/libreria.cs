﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Facturacion
{
    public class libreria
    {  //cadena de conexion
        String cs_conexion = "Data Source = DESKTOP-JM0U47U\\SQLSERVER2008_R2;Initial Catalog=sistema_facturacion;User ID=sa;Password=1234";
        public SqlConnection cn = new SqlConnection();

        public libreria()
        {
            cn.ConnectionString = cs_conexion;
        }

        public Boolean conectarse()
        {
            Boolean estado;
            try
            {
                cn.Open();
                estado = true;

            }
            catch (Exception e)
            {
                estado = false;
            }

            return estado;
        }

        public void Desconectar()
        {
            cn.Close();
        }

        public DataTable validarUsuario(String pusuario, String pclave)
        { //PERMITE TRAER LOS NOMBRES COMPLETOS DE LOS USUARIOS VALIDADOS
            DataTable tbdatos = new DataTable();
            SqlDataAdapter adaptador;
            SqlCommand comando;

            conectarse();
            comando = new SqlCommand("validarUsuario", cn);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@pusuario", pusuario);
            comando.Parameters.AddWithValue("@pclave", pclave);

            try
            {
                adaptador = new SqlDataAdapter();

                adaptador.SelectCommand = comando;
                adaptador.Fill(tbdatos);
            }
            catch (Exception e)
            {

            }
            //tbdatos.Load(comando.ExecuteReader());
            //sdataGridView1.DataSource = dt;

            Desconectar();
            return tbdatos;
        }

        public DataTable menuPrincipal(int idUsuario)
        {
            DataTable tbdatos = new DataTable();
            SqlDataAdapter adaptador;
            SqlCommand comando;

            comando = new SqlCommand("sp_TraerMenuPrincipal", cn);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("idUsuario", idUsuario);

            try
            {
                adaptador = new SqlDataAdapter();

                adaptador.SelectCommand = comando;
                adaptador.Fill(tbdatos);
            }
            catch (Exception e)
            {

            }

            Desconectar();
            return tbdatos;
        }

        public String ingresarCliente(String ruc,String nombres, String direccion,
            String  email,String telefono)
        { //PERMITE 
            DataTable tbdatos = new DataTable();
            SqlDataAdapter adaptador;
            SqlCommand comando;
            String codigo_cliente;

            conectarse();
            comando = new SqlCommand("ingresarCliente", cn);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("RUC", ruc);
            comando.Parameters.AddWithValue("nombres", nombres);
            comando.Parameters.AddWithValue("direccion",direccion);
            comando.Parameters.AddWithValue("telefono",telefono);
            comando.Parameters.AddWithValue("email",email);

            try
            {
                //adaptador = new SqlDataAdapter();
                codigo_cliente =(String) comando.ExecuteScalar();
                //adaptador.SelectCommand = comando;
                //adaptador.Fill(tbdatos);
            }
            catch (Exception e)
            {
                codigo_cliente = e.ToString();
            }
            //tbdatos.Load(comando.ExecuteReader());
            //sdataGridView1.DataSource = dt;

            Desconectar();
            return codigo_cliente;
        }

        public int ingresarCategoria(String descripcion)
        { //PERMITE 
            DataTable tbdatos = new DataTable();
            SqlDataAdapter adaptador;
            SqlCommand comando;
             int id_categoria=0;

            conectarse();
            comando = new SqlCommand("ingresarCategoria", cn);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("descripcion", descripcion);
        

            try
            {
                //adaptador = new SqlDataAdapter();
                id_categoria = (int)comando.ExecuteScalar();
                //adaptador.SelectCommand = comando;
                //adaptador.Fill(tbdatos);
            }
            catch (Exception e)
            {
                
            }
            //tbdatos.Load(comando.ExecuteReader());
            //sdataGridView1.DataSource = dt;

            Desconectar();
            return id_categoria;
        }




    }
}