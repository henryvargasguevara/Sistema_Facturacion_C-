﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ValidadorSES.ValidadorGNX.Clases
{
    public class Conexion
    {
        public static SqlConnection ConexionSQL()
        {
            SqlConnection conn = new SqlConnection();
            //conn.ConnectionString = "data source = F-CHAVIN-WD\\SBP; initial Catalog=VALIDADORES-DESARROLLO;User Id=valuserses;Password=VALhG9sRdO";
            conn.ConnectionString = "data source = F-CHAVIN-WD\\SBP; initial Catalog=VALIDADORES-DESARROLLO;Integrated Security=SSPI";
            //conn.ConnectionString = "data source = S-CHAVIN-WDT\\SQL2016DESA; initial Catalog=VALIDADORES-DESARROLLO;Integrated Security=SSPI";
            //conn.ConnectionString = "data source = 10.237.98.95\\SQL2008R2,50205; initial Catalog=BDGENERADOR_COD;User Id=sa;Password=Agencia350";
            //conn.ConnectionString = "Persist Security Info=False;Integrated Security=SSPI;database=BDGENERADOR_COD;server=(local)";
            try
            {
                conn.Open();
            }
            catch (Exception)
            {
                //MessageBox.Show(ex.Message, "¡¡Fallo al conectar con la base de datos!!");
            }
            finally
            {
                conn.Close();
            }

            return conn;
        }
    }
}
