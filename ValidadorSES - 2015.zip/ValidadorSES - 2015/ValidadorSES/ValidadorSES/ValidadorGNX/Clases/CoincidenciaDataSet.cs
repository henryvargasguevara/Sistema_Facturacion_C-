﻿namespace ValidadorSES.ValidadorGNX.Clases {
    
    
    public partial class CoincidenciaDataSet {
    }
}
