﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace ValidadorSES.ValidadorGNX.Clases
{
    public class CoincidenciaBE
    {
        public string TipoObj { get; set; }
        public string NombreObj { get; set; }
        public string Palabra { get; set; }
        public string NroLinea { get; set; }
        public string Linea { get; set; }
        public int Contador { get; set; }
        public string Flag { get; set; }
        public string RutaImg { get; set; }
        //public Image ImgFlag { get; set; }
        //public string ImgFlag { get; set; }
        public Image ImgFlag { get; set; }
       // public string RutaImagenes { get; set; }

        public CoincidenciaBE()
        {
            this.TipoObj = "";
            this.NombreObj = "";
            this.Palabra = "";
            this.NroLinea = "";
            this.Linea = "";
            this.Contador = 0;
            this.Flag = "";
            this.RutaImg = "";            
            //this.RutaImagenes = "C:\\STAGING";
        }
    }
}
