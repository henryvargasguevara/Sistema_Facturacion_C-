﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using ValidadorSES.ValidadorGNX.Formularios;

namespace ValidadorSES.ValidadorGNX.Clases
{
    public class Procedimientos
    {

        public object ObtenerDatosUsuario(string codigo)
        {
            string NombreUsuario = "";
            SqlCommand comando = new SqlCommand("[USP_OBTENERDATOSUSUARIO]");
            comando.Parameters.Add("@URED",codigo);
            comando.Parameters.Add("@TIPODOC",4);
            return NombreUsuario;
        }

    }
}
