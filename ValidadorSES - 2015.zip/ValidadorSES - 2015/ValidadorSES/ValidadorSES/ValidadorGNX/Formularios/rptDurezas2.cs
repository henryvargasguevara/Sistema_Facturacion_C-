﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ValidadorSES.ValidadorGNX.Formularios
{
    public partial class rptDurezas2 : Form
    {
        public rptDurezas2()
        {
            InitializeComponent();
        }

        private void rptDurezas2_Load(object sender, EventArgs e)
        {
            rptDurezas.LocalReport.ReportPath = "rptGeneral.rdlc";
            rptDurezas.LocalReport.EnableExternalImages = true;
            this.rptDurezas.RefreshReport();
        }
    }
}
