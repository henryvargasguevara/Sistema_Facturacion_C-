﻿namespace ValidadorSES.ValidadorGNX.Formularios
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnMantenimientoVigencia = new System.Windows.Forms.Button();
            this.PnlAdministrador = new System.Windows.Forms.Panel();
            this.txtPalabra = new System.Windows.Forms.TextBox();
            this.chkMayusMinus = new System.Windows.Forms.CheckBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.chkPalabraCompleta = new System.Windows.Forms.CheckBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.lstBoxPalabras = new System.Windows.Forms.ListBox();
            this.chkMultiple = new System.Windows.Forms.CheckBox();
            this.ibtAgregar = new System.Windows.Forms.PictureBox();
            this.PictureBox9 = new System.Windows.Forms.PictureBox();
            this.PictureBox8 = new System.Windows.Forms.PictureBox();
            this.ibtQuitar = new System.Windows.Forms.PictureBox();
            this.lblRestricciones = new System.Windows.Forms.ListBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.pnlReporte = new System.Windows.Forms.Panel();
            this.lblNombreUsuarioSQL = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.bad = new System.Windows.Forms.PictureBox();
            this.warning = new System.Windows.Forms.PictureBox();
            this.good = new System.Windows.Forms.PictureBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.lblMsgCoin = new System.Windows.Forms.Label();
            this.lblTotalCoin1 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.lblFlagCoin = new System.Windows.Forms.Label();
            this.imgCoin = new System.Windows.Forms.PictureBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.lblTittle = new System.Windows.Forms.Label();
            this.gvCoincidencias = new System.Windows.Forms.DataGridView();
            this.ImgFlag = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaImagen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Linea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NroLinea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NroVeces = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Flag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TipoObj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NombreObj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Palabra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Label7 = new System.Windows.Forms.Label();
            this.gvResumen = new System.Windows.Forms.DataGridView();
            this.Objeto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Busqueda1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaPalabra1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Busqueda2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda3 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda4 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda5 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda6 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda7 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda8 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda9 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Busqueda10 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Estatico = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaEstatico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.formatosConstantes = new System.Windows.Forms.DataGridViewImageColumn();
            this.rutaFormatos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noUsadas = new System.Windows.Forms.DataGridViewImageColumn();
            this.rutaUsadas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Inutilizado = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaInutilizado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DefinedBy = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaDefinedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Where = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaWhere = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Documentacion = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaDocumentacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.llamada = new System.Windows.Forms.DataGridViewImageColumn();
            this.rutaCall = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.restringidas = new System.Windows.Forms.DataGridViewImageColumn();
            this.rutaRestringidas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ResultadoFinal = new System.Windows.Forms.DataGridViewImageColumn();
            this.RutaResultadoFinal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.final = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblBottom = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblFecHora = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.lblUsuarioTexto = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btnMantPalabras = new System.Windows.Forms.Button();
            this.ibtExportPDF = new System.Windows.Forms.PictureBox();
            this.ibtLimpiar = new System.Windows.Forms.PictureBox();
            this.ibtBuscarPorCarpeta = new System.Windows.Forms.PictureBox();
            this.ibtBuscar = new System.Windows.Forms.PictureBox();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.PnlAdministrador.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ibtAgregar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtQuitar)).BeginInit();
            this.pnlReporte.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.warning)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.good)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCoin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvCoincidencias)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvResumen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtExportPDF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtLimpiar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtBuscarPorCarpeta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMantenimientoVigencia
            // 
            this.btnMantenimientoVigencia.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnMantenimientoVigencia.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMantenimientoVigencia.ForeColor = System.Drawing.Color.White;
            this.btnMantenimientoVigencia.Location = new System.Drawing.Point(799, 217);
            this.btnMantenimientoVigencia.Name = "btnMantenimientoVigencia";
            this.btnMantenimientoVigencia.Size = new System.Drawing.Size(191, 26);
            this.btnMantenimientoVigencia.TabIndex = 99;
            this.btnMantenimientoVigencia.Text = "MANT. FECHA DE VENCIMIENTO";
            this.btnMantenimientoVigencia.UseVisualStyleBackColor = false;
            this.btnMantenimientoVigencia.Click += new System.EventHandler(this.btnMantenimientoVigencia_Click);
            // 
            // PnlAdministrador
            // 
            this.PnlAdministrador.Controls.Add(this.txtPalabra);
            this.PnlAdministrador.Controls.Add(this.chkMayusMinus);
            this.PnlAdministrador.Controls.Add(this.Label2);
            this.PnlAdministrador.Controls.Add(this.chkPalabraCompleta);
            this.PnlAdministrador.Controls.Add(this.Label8);
            this.PnlAdministrador.Controls.Add(this.lstBoxPalabras);
            this.PnlAdministrador.Controls.Add(this.chkMultiple);
            this.PnlAdministrador.Controls.Add(this.ibtAgregar);
            this.PnlAdministrador.Controls.Add(this.PictureBox9);
            this.PnlAdministrador.Controls.Add(this.PictureBox8);
            this.PnlAdministrador.Controls.Add(this.ibtQuitar);
            this.PnlAdministrador.Location = new System.Drawing.Point(40, 93);
            this.PnlAdministrador.Name = "PnlAdministrador";
            this.PnlAdministrador.Size = new System.Drawing.Size(740, 116);
            this.PnlAdministrador.TabIndex = 98;
            this.PnlAdministrador.Visible = false;
            // 
            // txtPalabra
            // 
            this.txtPalabra.Location = new System.Drawing.Point(269, 7);
            this.txtPalabra.Name = "txtPalabra";
            this.txtPalabra.Size = new System.Drawing.Size(199, 20);
            this.txtPalabra.TabIndex = 15;
            // 
            // chkMayusMinus
            // 
            this.chkMayusMinus.AutoSize = true;
            this.chkMayusMinus.Location = new System.Drawing.Point(272, 59);
            this.chkMayusMinus.Name = "chkMayusMinus";
            this.chkMayusMinus.Size = new System.Drawing.Size(187, 17);
            this.chkMayusMinus.TabIndex = 23;
            this.chkMayusMinus.Text = "Coincidir mayúsculas y minúsculas";
            this.chkMayusMinus.UseVisualStyleBackColor = true;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(186, 8);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(79, 16);
            this.Label2.TabIndex = 16;
            this.Label2.Text = "Busqueda :";
            // 
            // chkPalabraCompleta
            // 
            this.chkPalabraCompleta.AutoSize = true;
            this.chkPalabraCompleta.Location = new System.Drawing.Point(272, 76);
            this.chkPalabraCompleta.Name = "chkPalabraCompleta";
            this.chkPalabraCompleta.Size = new System.Drawing.Size(175, 17);
            this.chkPalabraCompleta.TabIndex = 24;
            this.chkPalabraCompleta.Text = "Búscar sólo palabras completas";
            this.chkPalabraCompleta.UseVisualStyleBackColor = true;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(186, 8);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(79, 16);
            this.Label8.TabIndex = 16;
            this.Label8.Text = "Busqueda :";
            // 
            // lstBoxPalabras
            // 
            this.lstBoxPalabras.FormattingEnabled = true;
            this.lstBoxPalabras.Location = new System.Drawing.Point(503, 7);
            this.lstBoxPalabras.Name = "lstBoxPalabras";
            this.lstBoxPalabras.Size = new System.Drawing.Size(199, 82);
            this.lstBoxPalabras.TabIndex = 31;
            this.lstBoxPalabras.Visible = false;
            // 
            // chkMultiple
            // 
            this.chkMultiple.AutoSize = true;
            this.chkMultiple.Location = new System.Drawing.Point(272, 42);
            this.chkMultiple.Name = "chkMultiple";
            this.chkMultiple.Size = new System.Drawing.Size(113, 17);
            this.chkMultiple.TabIndex = 76;
            this.chkMultiple.Text = "Búsqueda Múltiple";
            this.chkMultiple.UseVisualStyleBackColor = true;
            this.chkMultiple.CheckedChanged += new System.EventHandler(this.chkMultiple_CheckedChanged);
            // 
            // ibtAgregar
            // 
            this.ibtAgregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ibtAgregar.Image = ((System.Drawing.Image)(resources.GetObject("ibtAgregar.Image")));
            this.ibtAgregar.Location = new System.Drawing.Point(476, 7);
            this.ibtAgregar.Name = "ibtAgregar";
            this.ibtAgregar.Size = new System.Drawing.Size(14, 17);
            this.ibtAgregar.TabIndex = 74;
            this.ibtAgregar.TabStop = false;
            this.ibtAgregar.Visible = false;
            this.ibtAgregar.Click += new System.EventHandler(this.ibtAgregar_Click);
            // 
            // PictureBox9
            // 
            this.PictureBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox9.Image")));
            this.PictureBox9.Location = new System.Drawing.Point(708, 7);
            this.PictureBox9.Name = "PictureBox9";
            this.PictureBox9.Size = new System.Drawing.Size(14, 17);
            this.PictureBox9.TabIndex = 75;
            this.PictureBox9.TabStop = false;
            this.PictureBox9.Visible = false;
            this.PictureBox9.Click += new System.EventHandler(this.PictureBox9_Click_1);
            // 
            // PictureBox8
            // 
            this.PictureBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PictureBox8.Location = new System.Drawing.Point(476, 7);
            this.PictureBox8.Name = "PictureBox8";
            this.PictureBox8.Size = new System.Drawing.Size(14, 17);
            this.PictureBox8.TabIndex = 74;
            this.PictureBox8.TabStop = false;
            this.PictureBox8.Visible = false;
            // 
            // ibtQuitar
            // 
            this.ibtQuitar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ibtQuitar.Location = new System.Drawing.Point(708, 7);
            this.ibtQuitar.Name = "ibtQuitar";
            this.ibtQuitar.Size = new System.Drawing.Size(14, 17);
            this.ibtQuitar.TabIndex = 75;
            this.ibtQuitar.TabStop = false;
            this.ibtQuitar.Visible = false;
            // 
            // lblRestricciones
            // 
            this.lblRestricciones.FormattingEnabled = true;
            this.lblRestricciones.Location = new System.Drawing.Point(748, 9);
            this.lblRestricciones.Name = "lblRestricciones";
            this.lblRestricciones.Size = new System.Drawing.Size(94, 43);
            this.lblRestricciones.TabIndex = 96;
            this.lblRestricciones.Visible = false;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.Location = new System.Drawing.Point(933, 9);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(0, 16);
            this.Label21.TabIndex = 95;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(346, 65);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(311, 25);
            this.Label3.TabIndex = 94;
            this.Label3.Text = "VALIDADOR DE CÓDIGO Gx";
            // 
            // pnlReporte
            // 
            this.pnlReporte.AutoScroll = true;
            this.pnlReporte.BackColor = System.Drawing.Color.White;
            this.pnlReporte.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlReporte.Controls.Add(this.lblNombreUsuarioSQL);
            this.pnlReporte.Controls.Add(this.Label9);
            this.pnlReporte.Controls.Add(this.bad);
            this.pnlReporte.Controls.Add(this.warning);
            this.pnlReporte.Controls.Add(this.good);
            this.pnlReporte.Controls.Add(this.Label6);
            this.pnlReporte.Controls.Add(this.Label1);
            this.pnlReporte.Controls.Add(this.lblMsgCoin);
            this.pnlReporte.Controls.Add(this.lblTotalCoin1);
            this.pnlReporte.Controls.Add(this.Label4);
            this.pnlReporte.Controls.Add(this.lblFlagCoin);
            this.pnlReporte.Controls.Add(this.imgCoin);
            this.pnlReporte.Controls.Add(this.Label5);
            this.pnlReporte.Controls.Add(this.lblTittle);
            this.pnlReporte.Controls.Add(this.gvCoincidencias);
            this.pnlReporte.Controls.Add(this.Label7);
            this.pnlReporte.Controls.Add(this.gvResumen);
            this.pnlReporte.Controls.Add(this.lblBottom);
            this.pnlReporte.Controls.Add(this.lblFecha);
            this.pnlReporte.Controls.Add(this.lblFecHora);
            this.pnlReporte.Controls.Add(this.lblUsuario);
            this.pnlReporte.Controls.Add(this.lblUsuarioTexto);
            this.pnlReporte.Location = new System.Drawing.Point(4, 257);
            this.pnlReporte.Name = "pnlReporte";
            this.pnlReporte.Size = new System.Drawing.Size(1005, 349);
            this.pnlReporte.TabIndex = 92;
            this.pnlReporte.Visible = false;
            // 
            // lblNombreUsuarioSQL
            // 
            this.lblNombreUsuarioSQL.AutoSize = true;
            this.lblNombreUsuarioSQL.Location = new System.Drawing.Point(644, 66);
            this.lblNombreUsuarioSQL.Name = "lblNombreUsuarioSQL";
            this.lblNombreUsuarioSQL.Size = new System.Drawing.Size(130, 13);
            this.lblNombreUsuarioSQL.TabIndex = 102;
            this.lblNombreUsuarioSQL.Text = "NOMBRE DEL USUARIO";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(495, 66);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(122, 13);
            this.Label9.TabIndex = 101;
            this.Label9.Text = "Nombre del Usuario:";
            // 
            // bad
            // 
            this.bad.Image = ((System.Drawing.Image)(resources.GetObject("bad.Image")));
            this.bad.Location = new System.Drawing.Point(67, 112);
            this.bad.Name = "bad";
            this.bad.Size = new System.Drawing.Size(20, 18);
            this.bad.TabIndex = 100;
            this.bad.TabStop = false;
            // 
            // warning
            // 
            this.warning.ErrorImage = null;
            this.warning.Image = ((System.Drawing.Image)(resources.GetObject("warning.Image")));
            this.warning.Location = new System.Drawing.Point(67, 112);
            this.warning.Name = "warning";
            this.warning.Size = new System.Drawing.Size(20, 18);
            this.warning.TabIndex = 99;
            this.warning.TabStop = false;
            // 
            // good
            // 
            this.good.Image = ((System.Drawing.Image)(resources.GetObject("good.Image")));
            this.good.Location = new System.Drawing.Point(67, 112);
            this.good.Name = "good";
            this.good.Size = new System.Drawing.Size(20, 18);
            this.good.TabIndex = 95;
            this.good.TabStop = false;
            this.good.Visible = false;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(120, 66);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(216, 13);
            this.Label6.TabIndex = 88;
            this.Label6.Text = "Total de Coincidencias Encontradas:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.CausesValidation = false;
            this.Label1.Location = new System.Drawing.Point(28, 112);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(33, 13);
            this.Label1.TabIndex = 96;
            this.Label1.Text = "Good";
            this.Label1.Visible = false;
            // 
            // lblMsgCoin
            // 
            this.lblMsgCoin.AutoSize = true;
            this.lblMsgCoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgCoin.Location = new System.Drawing.Point(137, 369);
            this.lblMsgCoin.Name = "lblMsgCoin";
            this.lblMsgCoin.Size = new System.Drawing.Size(86, 13);
            this.lblMsgCoin.TabIndex = 90;
            this.lblMsgCoin.Text = "Coincidencias";
            // 
            // lblTotalCoin1
            // 
            this.lblTotalCoin1.AutoSize = true;
            this.lblTotalCoin1.Location = new System.Drawing.Point(353, 66);
            this.lblTotalCoin1.Name = "lblTotalCoin1";
            this.lblTotalCoin1.Size = new System.Drawing.Size(81, 13);
            this.lblTotalCoin1.TabIndex = 89;
            this.lblTotalCoin1.Text = "Nro. Total Coin.";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(90, 116);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(64, 13);
            this.Label4.TabIndex = 94;
            this.Label4.Text = "Resultado";
            // 
            // lblFlagCoin
            // 
            this.lblFlagCoin.AutoSize = true;
            this.lblFlagCoin.CausesValidation = false;
            this.lblFlagCoin.Location = new System.Drawing.Point(72, 369);
            this.lblFlagCoin.Name = "lblFlagCoin";
            this.lblFlagCoin.Size = new System.Drawing.Size(33, 13);
            this.lblFlagCoin.TabIndex = 92;
            this.lblFlagCoin.Text = "Good";
            this.lblFlagCoin.Visible = false;
            // 
            // imgCoin
            // 
            this.imgCoin.Location = new System.Drawing.Point(111, 369);
            this.imgCoin.Name = "imgCoin";
            this.imgCoin.Size = new System.Drawing.Size(20, 18);
            this.imgCoin.TabIndex = 91;
            this.imgCoin.TabStop = false;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(121, 95);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(141, 13);
            this.Label5.TabIndex = 93;
            this.Label5.Text = "Resumen de Búsqueda:";
            // 
            // lblTittle
            // 
            this.lblTittle.AutoSize = true;
            this.lblTittle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTittle.Location = new System.Drawing.Point(313, 14);
            this.lblTittle.Name = "lblTittle";
            this.lblTittle.Size = new System.Drawing.Size(352, 29);
            this.lblTittle.TabIndex = 86;
            this.lblTittle.Text = "Software Enterprise Services";
            // 
            // gvCoincidencias
            // 
            this.gvCoincidencias.AllowUserToAddRows = false;
            this.gvCoincidencias.AllowUserToDeleteRows = false;
            this.gvCoincidencias.AllowUserToResizeColumns = false;
            this.gvCoincidencias.AllowUserToResizeRows = false;
            this.gvCoincidencias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvCoincidencias.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ImgFlag,
            this.RutaImagen,
            this.Linea,
            this.NroLinea,
            this.NroVeces,
            this.Flag,
            this.TipoObj,
            this.NombreObj,
            this.Palabra});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gvCoincidencias.DefaultCellStyle = dataGridViewCellStyle5;
            this.gvCoincidencias.Location = new System.Drawing.Point(156, 391);
            this.gvCoincidencias.Name = "gvCoincidencias";
            this.gvCoincidencias.ReadOnly = true;
            this.gvCoincidencias.Size = new System.Drawing.Size(734, 361);
            this.gvCoincidencias.TabIndex = 85;
            // 
            // ImgFlag
            // 
            this.ImgFlag.DataPropertyName = "ImgFlag";
            this.ImgFlag.FillWeight = 20F;
            this.ImgFlag.HeaderText = " ";
            this.ImgFlag.Name = "ImgFlag";
            this.ImgFlag.ReadOnly = true;
            this.ImgFlag.Width = 20;
            // 
            // RutaImagen
            // 
            this.RutaImagen.DataPropertyName = "RutaImg";
            this.RutaImagen.HeaderText = "RutaImg";
            this.RutaImagen.Name = "RutaImagen";
            this.RutaImagen.ReadOnly = true;
            this.RutaImagen.Visible = false;
            // 
            // Linea
            // 
            this.Linea.DataPropertyName = "Linea";
            this.Linea.HeaderText = "Linea";
            this.Linea.Name = "Linea";
            this.Linea.ReadOnly = true;
            this.Linea.Width = 600;
            // 
            // NroLinea
            // 
            this.NroLinea.DataPropertyName = "NroLinea";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.NroLinea.DefaultCellStyle = dataGridViewCellStyle4;
            this.NroLinea.HeaderText = "NroLinea";
            this.NroLinea.Name = "NroLinea";
            this.NroLinea.ReadOnly = true;
            this.NroLinea.Width = 70;
            // 
            // NroVeces
            // 
            this.NroVeces.DataPropertyName = "NroVeces";
            this.NroVeces.HeaderText = "NroVeces";
            this.NroVeces.Name = "NroVeces";
            this.NroVeces.ReadOnly = true;
            this.NroVeces.Visible = false;
            this.NroVeces.Width = 70;
            // 
            // Flag
            // 
            this.Flag.DataPropertyName = "Flag";
            this.Flag.HeaderText = "Flag";
            this.Flag.Name = "Flag";
            this.Flag.ReadOnly = true;
            this.Flag.Visible = false;
            this.Flag.Width = 150;
            // 
            // TipoObj
            // 
            this.TipoObj.DataPropertyName = "TipoObj";
            this.TipoObj.HeaderText = "TipoObj";
            this.TipoObj.Name = "TipoObj";
            this.TipoObj.ReadOnly = true;
            this.TipoObj.Visible = false;
            // 
            // NombreObj
            // 
            this.NombreObj.DataPropertyName = "NombreObj";
            this.NombreObj.HeaderText = "NombreObj";
            this.NombreObj.Name = "NombreObj";
            this.NombreObj.ReadOnly = true;
            this.NombreObj.Visible = false;
            // 
            // Palabra
            // 
            this.Palabra.DataPropertyName = "Palabra";
            this.Palabra.HeaderText = "Palabra";
            this.Palabra.Name = "Palabra";
            this.Palabra.ReadOnly = true;
            this.Palabra.Visible = false;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(64, 341);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(129, 13);
            this.Label7.TabIndex = 87;
            this.Label7.Text = "Detalle de Búsqueda:";
            // 
            // gvResumen
            // 
            this.gvResumen.AllowUserToAddRows = false;
            this.gvResumen.AllowUserToDeleteRows = false;
            this.gvResumen.AllowUserToResizeColumns = false;
            this.gvResumen.AllowUserToResizeRows = false;
            this.gvResumen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvResumen.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Objeto,
            this.Busqueda1,
            this.RutaPalabra1,
            this.Busqueda2,
            this.Busqueda3,
            this.Busqueda4,
            this.Busqueda5,
            this.Busqueda6,
            this.Busqueda7,
            this.Busqueda8,
            this.Busqueda9,
            this.Busqueda10,
            this.Estatico,
            this.RutaEstatico,
            this.formatosConstantes,
            this.rutaFormatos,
            this.noUsadas,
            this.rutaUsadas,
            this.Inutilizado,
            this.RutaInutilizado,
            this.DefinedBy,
            this.RutaDefinedBy,
            this.Where,
            this.RutaWhere,
            this.Documentacion,
            this.RutaDocumentacion,
            this.llamada,
            this.rutaCall,
            this.restringidas,
            this.rutaRestringidas,
            this.ResultadoFinal,
            this.RutaResultadoFinal,
            this.final});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gvResumen.DefaultCellStyle = dataGridViewCellStyle6;
            this.gvResumen.Location = new System.Drawing.Point(7, 132);
            this.gvResumen.Name = "gvResumen";
            this.gvResumen.ReadOnly = true;
            this.gvResumen.Size = new System.Drawing.Size(977, 191);
            this.gvResumen.TabIndex = 84;
            // 
            // Objeto
            // 
            this.Objeto.HeaderText = "Objeto";
            this.Objeto.Name = "Objeto";
            this.Objeto.ReadOnly = true;
            this.Objeto.Width = 85;
            // 
            // Busqueda1
            // 
            this.Busqueda1.HeaderText = "Resultado de Búsqueda";
            this.Busqueda1.Name = "Busqueda1";
            this.Busqueda1.ReadOnly = true;
            this.Busqueda1.Width = 70;
            // 
            // RutaPalabra1
            // 
            this.RutaPalabra1.HeaderText = "RutaPalabra1";
            this.RutaPalabra1.Name = "RutaPalabra1";
            this.RutaPalabra1.ReadOnly = true;
            this.RutaPalabra1.Visible = false;
            // 
            // Busqueda2
            // 
            this.Busqueda2.HeaderText = "Busqueda2";
            this.Busqueda2.Name = "Busqueda2";
            this.Busqueda2.ReadOnly = true;
            this.Busqueda2.Visible = false;
            // 
            // Busqueda3
            // 
            this.Busqueda3.HeaderText = "Busqueda3";
            this.Busqueda3.Name = "Busqueda3";
            this.Busqueda3.ReadOnly = true;
            this.Busqueda3.Visible = false;
            // 
            // Busqueda4
            // 
            this.Busqueda4.HeaderText = "Busqueda4";
            this.Busqueda4.Name = "Busqueda4";
            this.Busqueda4.ReadOnly = true;
            this.Busqueda4.Visible = false;
            // 
            // Busqueda5
            // 
            this.Busqueda5.HeaderText = "Busqueda5";
            this.Busqueda5.Name = "Busqueda5";
            this.Busqueda5.ReadOnly = true;
            this.Busqueda5.Visible = false;
            // 
            // Busqueda6
            // 
            this.Busqueda6.HeaderText = "Busqueda6";
            this.Busqueda6.Name = "Busqueda6";
            this.Busqueda6.ReadOnly = true;
            this.Busqueda6.Visible = false;
            // 
            // Busqueda7
            // 
            this.Busqueda7.HeaderText = "Busqueda7";
            this.Busqueda7.Name = "Busqueda7";
            this.Busqueda7.ReadOnly = true;
            this.Busqueda7.Visible = false;
            // 
            // Busqueda8
            // 
            this.Busqueda8.HeaderText = "Busqueda8";
            this.Busqueda8.Name = "Busqueda8";
            this.Busqueda8.ReadOnly = true;
            this.Busqueda8.Visible = false;
            // 
            // Busqueda9
            // 
            this.Busqueda9.HeaderText = "Busqueda9";
            this.Busqueda9.Name = "Busqueda9";
            this.Busqueda9.ReadOnly = true;
            this.Busqueda9.Visible = false;
            // 
            // Busqueda10
            // 
            this.Busqueda10.HeaderText = "Busqueda10";
            this.Busqueda10.Name = "Busqueda10";
            this.Busqueda10.ReadOnly = true;
            this.Busqueda10.Visible = false;
            // 
            // Estatico
            // 
            this.Estatico.HeaderText = "Constantes en duro";
            this.Estatico.Name = "Estatico";
            this.Estatico.ReadOnly = true;
            this.Estatico.Width = 70;
            // 
            // RutaEstatico
            // 
            this.RutaEstatico.HeaderText = "RutaEstatico";
            this.RutaEstatico.Name = "RutaEstatico";
            this.RutaEstatico.ReadOnly = true;
            this.RutaEstatico.Visible = false;
            // 
            // formatosConstantes
            // 
            this.formatosConstantes.HeaderText = "Advertencias";
            this.formatosConstantes.Name = "formatosConstantes";
            this.formatosConstantes.ReadOnly = true;
            this.formatosConstantes.Width = 75;
            // 
            // rutaFormatos
            // 
            this.rutaFormatos.HeaderText = "rutaFormatos";
            this.rutaFormatos.Name = "rutaFormatos";
            this.rutaFormatos.ReadOnly = true;
            this.rutaFormatos.Visible = false;
            // 
            // noUsadas
            // 
            this.noUsadas.HeaderText = "Posibles Variables No Usadas";
            this.noUsadas.Name = "noUsadas";
            this.noUsadas.ReadOnly = true;
            this.noUsadas.Width = 75;
            // 
            // rutaUsadas
            // 
            this.rutaUsadas.HeaderText = "rutaUsadas";
            this.rutaUsadas.Name = "rutaUsadas";
            this.rutaUsadas.ReadOnly = true;
            this.rutaUsadas.Visible = false;
            // 
            // Inutilizado
            // 
            this.Inutilizado.HeaderText = "Variables No Utilizadas";
            this.Inutilizado.Name = "Inutilizado";
            this.Inutilizado.ReadOnly = true;
            this.Inutilizado.Width = 70;
            // 
            // RutaInutilizado
            // 
            this.RutaInutilizado.HeaderText = "RutaInutilizado";
            this.RutaInutilizado.Name = "RutaInutilizado";
            this.RutaInutilizado.ReadOnly = true;
            this.RutaInutilizado.Visible = false;
            // 
            // DefinedBy
            // 
            this.DefinedBy.HeaderText = "For Each sin Defined By";
            this.DefinedBy.Name = "DefinedBy";
            this.DefinedBy.ReadOnly = true;
            this.DefinedBy.Width = 70;
            // 
            // RutaDefinedBy
            // 
            this.RutaDefinedBy.HeaderText = "RutaDefinedBy";
            this.RutaDefinedBy.Name = "RutaDefinedBy";
            this.RutaDefinedBy.ReadOnly = true;
            this.RutaDefinedBy.Visible = false;
            // 
            // Where
            // 
            this.Where.HeaderText = "Errores en Where de For Each";
            this.Where.Name = "Where";
            this.Where.ReadOnly = true;
            this.Where.Width = 70;
            // 
            // RutaWhere
            // 
            this.RutaWhere.HeaderText = "RutaWhere";
            this.RutaWhere.Name = "RutaWhere";
            this.RutaWhere.ReadOnly = true;
            this.RutaWhere.Visible = false;
            // 
            // Documentacion
            // 
            this.Documentacion.HeaderText = "Documentacion";
            this.Documentacion.Name = "Documentacion";
            this.Documentacion.ReadOnly = true;
            // 
            // RutaDocumentacion
            // 
            this.RutaDocumentacion.HeaderText = "RutaDocumentacion";
            this.RutaDocumentacion.Name = "RutaDocumentacion";
            this.RutaDocumentacion.ReadOnly = true;
            this.RutaDocumentacion.Visible = false;
            // 
            // llamada
            // 
            this.llamada.HeaderText = "Errores en llamadas (Call)";
            this.llamada.Name = "llamada";
            this.llamada.ReadOnly = true;
            // 
            // rutaCall
            // 
            this.rutaCall.HeaderText = "rutaCall";
            this.rutaCall.Name = "rutaCall";
            this.rutaCall.ReadOnly = true;
            this.rutaCall.Visible = false;
            // 
            // restringidas
            // 
            this.restringidas.HeaderText = "Palabras Restringidas";
            this.restringidas.Name = "restringidas";
            this.restringidas.ReadOnly = true;
            this.restringidas.Width = 70;
            // 
            // rutaRestringidas
            // 
            this.rutaRestringidas.HeaderText = "rutaRestringidas";
            this.rutaRestringidas.Name = "rutaRestringidas";
            this.rutaRestringidas.ReadOnly = true;
            this.rutaRestringidas.Visible = false;
            // 
            // ResultadoFinal
            // 
            this.ResultadoFinal.HeaderText = "Resultado Final";
            this.ResultadoFinal.Name = "ResultadoFinal";
            this.ResultadoFinal.ReadOnly = true;
            this.ResultadoFinal.Width = 70;
            // 
            // RutaResultadoFinal
            // 
            this.RutaResultadoFinal.HeaderText = "RutaResultadoFinal";
            this.RutaResultadoFinal.Name = "RutaResultadoFinal";
            this.RutaResultadoFinal.ReadOnly = true;
            this.RutaResultadoFinal.Visible = false;
            // 
            // final
            // 
            this.final.HeaderText = "final";
            this.final.Name = "final";
            this.final.ReadOnly = true;
            this.final.Visible = false;
            // 
            // lblBottom
            // 
            this.lblBottom.AutoSize = true;
            this.lblBottom.Location = new System.Drawing.Point(468, 32439);
            this.lblBottom.Name = "lblBottom";
            this.lblBottom.Size = new System.Drawing.Size(19, 13);
            this.lblBottom.TabIndex = 77;
            this.lblBottom.Text = "    ";
            this.lblBottom.UseWaitCursor = true;
            this.lblBottom.Visible = false;
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(293, 48);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(47, 13);
            this.lblFecha.TabIndex = 97;
            this.lblFecha.Text = "lblFecha";
            // 
            // lblFecHora
            // 
            this.lblFecHora.AutoSize = true;
            this.lblFecHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecHora.Location = new System.Drawing.Point(121, 48);
            this.lblFecHora.Name = "lblFecHora";
            this.lblFecHora.Size = new System.Drawing.Size(165, 13);
            this.lblFecHora.TabIndex = 79;
            this.lblFecHora.Text = "Fecha y Hora de Ejecución:";
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuario.Location = new System.Drawing.Point(534, 48);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(54, 13);
            this.lblUsuario.TabIndex = 97;
            this.lblUsuario.Text = "Usuario:";
            // 
            // lblUsuarioTexto
            // 
            this.lblUsuarioTexto.AutoSize = true;
            this.lblUsuarioTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuarioTexto.Location = new System.Drawing.Point(644, 48);
            this.lblUsuarioTexto.Name = "lblUsuarioTexto";
            this.lblUsuarioTexto.Size = new System.Drawing.Size(92, 13);
            this.lblUsuarioTexto.TabIndex = 98;
            this.lblUsuarioTexto.Text = "USUARIOTEXTO";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(909, 12);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(70, 13);
            this.linkLabel1.TabIndex = 100;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Cerrar Sesión";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // btnMantPalabras
            // 
            this.btnMantPalabras.Image = ((System.Drawing.Image)(resources.GetObject("btnMantPalabras.Image")));
            this.btnMantPalabras.Location = new System.Drawing.Point(799, 188);
            this.btnMantPalabras.Name = "btnMantPalabras";
            this.btnMantPalabras.Size = new System.Drawing.Size(191, 26);
            this.btnMantPalabras.TabIndex = 97;
            this.btnMantPalabras.UseVisualStyleBackColor = true;
            this.btnMantPalabras.Click += new System.EventHandler(this.btnMantPalabras_Click);
            // 
            // ibtExportPDF
            // 
            this.ibtExportPDF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ibtExportPDF.Image = ((System.Drawing.Image)(resources.GetObject("ibtExportPDF.Image")));
            this.ibtExportPDF.Location = new System.Drawing.Point(819, 156);
            this.ibtExportPDF.Name = "ibtExportPDF";
            this.ibtExportPDF.Size = new System.Drawing.Size(145, 26);
            this.ibtExportPDF.TabIndex = 93;
            this.ibtExportPDF.TabStop = false;
            this.ibtExportPDF.Visible = false;
            this.ibtExportPDF.Click += new System.EventHandler(this.ibtExportPDF_Click);
            // 
            // ibtLimpiar
            // 
            this.ibtLimpiar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ibtLimpiar.Image = ((System.Drawing.Image)(resources.GetObject("ibtLimpiar.Image")));
            this.ibtLimpiar.Location = new System.Drawing.Point(819, 127);
            this.ibtLimpiar.Name = "ibtLimpiar";
            this.ibtLimpiar.Size = new System.Drawing.Size(145, 26);
            this.ibtLimpiar.TabIndex = 91;
            this.ibtLimpiar.TabStop = false;
            this.ibtLimpiar.Click += new System.EventHandler(this.ibtLimpiar_Click);
            // 
            // ibtBuscarPorCarpeta
            // 
            this.ibtBuscarPorCarpeta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ibtBuscarPorCarpeta.Image = ((System.Drawing.Image)(resources.GetObject("ibtBuscarPorCarpeta.Image")));
            this.ibtBuscarPorCarpeta.Location = new System.Drawing.Point(819, 98);
            this.ibtBuscarPorCarpeta.Name = "ibtBuscarPorCarpeta";
            this.ibtBuscarPorCarpeta.Size = new System.Drawing.Size(145, 26);
            this.ibtBuscarPorCarpeta.TabIndex = 90;
            this.ibtBuscarPorCarpeta.TabStop = false;
            this.ibtBuscarPorCarpeta.Click += new System.EventHandler(this.ibtBuscarPorCarpeta_Click);
            // 
            // ibtBuscar
            // 
            this.ibtBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ibtBuscar.Image = ((System.Drawing.Image)(resources.GetObject("ibtBuscar.Image")));
            this.ibtBuscar.Location = new System.Drawing.Point(819, 69);
            this.ibtBuscar.Name = "ibtBuscar";
            this.ibtBuscar.Size = new System.Drawing.Size(145, 26);
            this.ibtBuscar.TabIndex = 89;
            this.ibtBuscar.TabStop = false;
            this.ibtBuscar.Click += new System.EventHandler(this.ibtBuscar_Click);
            // 
            // Logo
            // 
            this.Logo.Image = ((System.Drawing.Image)(resources.GetObject("Logo.Image")));
            this.Logo.Location = new System.Drawing.Point(40, 9);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(265, 78);
            this.Logo.TabIndex = 88;
            this.Logo.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1004, 612);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.btnMantenimientoVigencia);
            this.Controls.Add(this.PnlAdministrador);
            this.Controls.Add(this.btnMantPalabras);
            this.Controls.Add(this.lblRestricciones);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.ibtExportPDF);
            this.Controls.Add(this.pnlReporte);
            this.Controls.Add(this.ibtLimpiar);
            this.Controls.Add(this.ibtBuscarPorCarpeta);
            this.Controls.Add(this.ibtBuscar);
            this.Controls.Add(this.Logo);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1020, 800);
            this.MinimumSize = new System.Drawing.Size(900, 600);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validador de Código Gx";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PnlAdministrador.ResumeLayout(false);
            this.PnlAdministrador.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ibtAgregar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtQuitar)).EndInit();
            this.pnlReporte.ResumeLayout(false);
            this.pnlReporte.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.warning)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.good)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCoin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvCoincidencias)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvResumen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtExportPDF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtLimpiar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtBuscarPorCarpeta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnMantenimientoVigencia;
        internal System.Windows.Forms.Panel PnlAdministrador;
        internal System.Windows.Forms.TextBox txtPalabra;
        internal System.Windows.Forms.CheckBox chkMayusMinus;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.CheckBox chkPalabraCompleta;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.ListBox lstBoxPalabras;
        internal System.Windows.Forms.CheckBox chkMultiple;
        internal System.Windows.Forms.PictureBox ibtAgregar;
        internal System.Windows.Forms.PictureBox PictureBox9;
        internal System.Windows.Forms.PictureBox PictureBox8;
        internal System.Windows.Forms.PictureBox ibtQuitar;
        internal System.Windows.Forms.Button btnMantPalabras;
        internal System.Windows.Forms.ListBox lblRestricciones;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.PictureBox ibtExportPDF;
        internal System.Windows.Forms.Panel pnlReporte;
        internal System.Windows.Forms.Label lblNombreUsuarioSQL;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.PictureBox bad;
        internal System.Windows.Forms.PictureBox warning;
        internal System.Windows.Forms.PictureBox good;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label lblMsgCoin;
        internal System.Windows.Forms.Label lblTotalCoin1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label lblFlagCoin;
        internal System.Windows.Forms.PictureBox imgCoin;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label lblTittle;
        internal System.Windows.Forms.DataGridView gvCoincidencias;
        internal System.Windows.Forms.DataGridViewImageColumn ImgFlag;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaImagen;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Linea;
        internal System.Windows.Forms.DataGridViewTextBoxColumn NroLinea;
        internal System.Windows.Forms.DataGridViewTextBoxColumn NroVeces;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Flag;
        internal System.Windows.Forms.DataGridViewTextBoxColumn TipoObj;
        internal System.Windows.Forms.DataGridViewTextBoxColumn NombreObj;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Palabra;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.DataGridView gvResumen;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Objeto;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda1;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaPalabra1;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda2;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda3;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda4;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda5;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda6;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda7;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda8;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda9;
        internal System.Windows.Forms.DataGridViewImageColumn Busqueda10;
        internal System.Windows.Forms.DataGridViewImageColumn Estatico;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaEstatico;
        internal System.Windows.Forms.DataGridViewImageColumn formatosConstantes;
        internal System.Windows.Forms.DataGridViewTextBoxColumn rutaFormatos;
        internal System.Windows.Forms.DataGridViewImageColumn noUsadas;
        internal System.Windows.Forms.DataGridViewTextBoxColumn rutaUsadas;
        internal System.Windows.Forms.DataGridViewImageColumn Inutilizado;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaInutilizado;
        internal System.Windows.Forms.DataGridViewImageColumn DefinedBy;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaDefinedBy;
        internal System.Windows.Forms.DataGridViewImageColumn Where;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaWhere;
        internal System.Windows.Forms.DataGridViewImageColumn Documentacion;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaDocumentacion;
        internal System.Windows.Forms.DataGridViewImageColumn llamada;
        internal System.Windows.Forms.DataGridViewTextBoxColumn rutaCall;
        internal System.Windows.Forms.DataGridViewImageColumn restringidas;
        internal System.Windows.Forms.DataGridViewTextBoxColumn rutaRestringidas;
        internal System.Windows.Forms.DataGridViewImageColumn ResultadoFinal;
        internal System.Windows.Forms.DataGridViewTextBoxColumn RutaResultadoFinal;
        internal System.Windows.Forms.DataGridViewTextBoxColumn final;
        internal System.Windows.Forms.Label lblBottom;
        internal System.Windows.Forms.Label lblFecha;
        internal System.Windows.Forms.Label lblFecHora;
        internal System.Windows.Forms.Label lblUsuario;
        internal System.Windows.Forms.Label lblUsuarioTexto;
        internal System.Windows.Forms.PictureBox ibtLimpiar;
        internal System.Windows.Forms.PictureBox ibtBuscarPorCarpeta;
        internal System.Windows.Forms.PictureBox ibtBuscar;
        internal System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.LinkLabel linkLabel1;

    }
}