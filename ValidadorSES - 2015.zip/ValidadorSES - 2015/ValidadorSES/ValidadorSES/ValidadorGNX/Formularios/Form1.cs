﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.ValidadorGNX.Clases;
using ValidadorSES;
using System.Collections;
using System.IO.Compression;
using Ionic.Zip;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;



namespace ValidadorSES.ValidadorGNX.Formularios
{
    public partial class Form1 : Form
    {
        SqlConnection cnn = ValidadorGNX.Clases.Conexion.ConexionSQL();
        public string valor;
        public string referencia
        {
            get { return valor; }
            set { valor = value; }
        }        
        
            #region "Variables Globales"

        //List<CoincidenciaBE> = new List[CoincidenciaBE] lstFormatosConstantes;
        List<CoincidenciaBE> lstFormatosConstantes = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstPalabrasRestringidas = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCallStaticos = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCallStaticosAux = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstWheresMalImplementados = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstWhereMalImplementadosAux = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstDocumentation = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstUsadas = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstDocumentationAux = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstSinDefinedByAux = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstSinDefinedBy = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstVariablesInutilizadasAux = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstVariablesInutilizadas = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstAsignacionEstaticaAux = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstAsignacionEstatica = new List<CoincidenciaBE>();

        List<CoincidenciaBE> lstResumen = new List<CoincidenciaBE>();

        List<CoincidenciaBE> lstCoincidenciaAux = new List<CoincidenciaBE>();
        public List<CoincidenciaBE> lstCoincidencia1 = new List<CoincidenciaBE>();              
        List<CoincidenciaBE> lstCoincidencia2 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia3 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia4 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia5 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia6 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia7 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia8 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia9 = new List<CoincidenciaBE>();
        List<CoincidenciaBE> lstCoincidencia10 = new List<CoincidenciaBE>();

        string palabra1 = "";
        string palabra2 = "";
        string palabra3 = "";
        string palabra4 = "";
        string palabra5 = "";
        string palabra6 = "";
        string palabra7 = "";
        string palabra8 = "";
        string palabra9 = "";
        string palabra10 = "";

        string OriginalLine = "";
        string Line = "";

        int contadorLineas = 0;
        int contadorTotal = 0;
        int contadorTotalAux = 0;
        int contadorTotalPalabra1 = 0;
        int contadorTotalPalabra2 = 0;
        int contadorTotalPalabra3 = 0;
        int contadorTotalPalabra4 = 0;
        int contadorTotalPalabra5 = 0;
        int contadorTotalPalabra6 = 0;
        int contadorTotalPalabra7 = 0;
        int contadorTotalPalabra8 = 0;
        int contadorTotalPalabra9 = 0;
        int contadorTotalPalabra10 = 0;
        int contadorDefinedBy = 0;

        int contadorUsadas = 0;
        int contadorWhere = 0;
        int contadorDocumentation = 0;
        int contadorCALL = 0;
        int contadorPalabrasRestringidas = 0;
        int contadorFormatosConstantes = 0;

        ObjetoGeneXusBE GenexusObject = new ObjetoGeneXusBE();
        CoincidenciaBE result = new CoincidenciaBE();

        ArrayList resultados = new ArrayList();

        string RutaFinal = "";
        int noResult = 0;


        #endregion

        public Form1()
        {
            InitializeComponent();
            cargaListBox();
        }
            
        //public List<CoincidenciaBE> lstConFe = new List<CoincidenciaBE>();

        #region "clear"

        private void ClearGlobalVariables()
        {
            //listas
            lstSinDefinedBy.Clear();
            lstVariablesInutilizadas.Clear();
            lstAsignacionEstatica.Clear();
            lstCoincidencia1.Clear();
            lstCoincidencia2.Clear();
            lstCoincidencia3.Clear();            
            lstCoincidencia4.Clear();
            lstCoincidencia5.Clear();
            lstCoincidencia6.Clear();
            lstCoincidencia7.Clear();
            lstCoincidencia8.Clear();
            lstCoincidencia9.Clear();
            lstCoincidencia10.Clear();
            lstWheresMalImplementados.Clear();
            lstDocumentation.Clear();
            lstUsadas.Clear();
            lstCallStaticos.Clear();
            lstPalabrasRestringidas.Clear();
            lstFormatosConstantes.Clear();
            Line = "";
            OriginalLine = "";

            //contadores
            contadorTotal = 0;
            contadorDefinedBy = 0;
            contadorTotalPalabra1 = 0;
            contadorTotalPalabra2 = 0;
            contadorTotalPalabra3 = 0;            
            contadorTotalPalabra4 = 0;
            contadorTotalPalabra5 = 0;
            contadorTotalPalabra6 = 0;
            contadorTotalPalabra7 = 0;
            contadorTotalPalabra8 = 0;
            contadorTotalPalabra9 = 0;
            contadorTotalPalabra10 = 0;
            contadorLineas = 0;            
            contadorWhere = 0;            
            contadorCALL = 0;            
            contadorDocumentation = 0;            
            contadorPalabrasRestringidas = 0;            
            contadorFormatosConstantes = 0;            
            contadorUsadas = 0;
            GenexusObject = new ObjetoGeneXusBE();
            result = new CoincidenciaBE();
        }

        private void ClearAuxLists()
        {
            lstCoincidenciaAux = new List<CoincidenciaBE>();
            lstSinDefinedByAux = new List<CoincidenciaBE>();                        
            lstAsignacionEstaticaAux = new List<CoincidenciaBE>();
            lstVariablesInutilizadasAux = new List<CoincidenciaBE>();

            lstWhereMalImplementadosAux = new List<CoincidenciaBE>();

            lstCallStaticosAux = new List<CoincidenciaBE>();
            lstDocumentationAux = new List<CoincidenciaBE>();
            
        }

        private void ClearGrids()
        {            
            List<CoincidenciaBE> lstClear = new List<CoincidenciaBE>();
            gvCoincidencias.DataSource = lstClear;                                   
        }

        #endregion


        #region "coincidencias"

        private CoincidenciaBE VerificaCoincidencia(string Linea, string Parametro, string Line)
        {
            CoincidenciaBE CoincidenciaBE = new CoincidenciaBE();
            int ContadorPalabras = 0;
            Boolean validator = false;
            string[] PalabrasLinea = Line.Split(' ');
            //string[] PalabrasLinea = Line.Split(Convert.ToChar(" "));

            if (Line.Contains(Parametro))
            {
                if (chkPalabraCompleta.Checked)
                {
                    //Verificamos si lo que se encontró fue una palabra o parte de una palabra
                    for (int i = 0; i < PalabrasLinea.Length; i++)
                    {
                        if (PalabrasLinea[i] != "")
                        {
                            //De ser una palabra, se cuenta como un match
                            if (PalabrasLinea[i] == Parametro)
                            {
                                ContadorPalabras = ContadorPalabras + 1;
                                validator = true;
                            }
                        }
                    }
                    if (validator)
                    {
                        CoincidenciaBE.NroLinea = Linea.ToString();
                        CoincidenciaBE.Contador = ContadorPalabras;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    ContadorPalabras = ContadorPalabras + 1;
                    CoincidenciaBE.NroLinea = Linea.ToString();
                    CoincidenciaBE.Contador = ContadorPalabras;
                }
                return CoincidenciaBE;
            }
            else
            {
                return null;
            }
        }

        private Boolean VerificaDefinedBy(string Linea, string TextCode)
        {
            int contador = 0;
            Boolean DefinedByValidator = false;
            //StreamReader CodeText = new StreamReader(TextCode);
            StringReader CodeText = new StringReader(TextCode);
            while (true)
            {
                string Line = CodeText.ReadLine();
                if (contador < Convert.ToInt32(Linea))
                {
                    contador = contador + 1;
                }
                if (contador == Convert.ToInt32(Linea))
                {
                    if (Line == null)
                    {
                        break;
                    }
                    if (Line.ToUpper().Contains("ENDFOR"))
                    {
                        DefinedByValidator = false;
                        break;
                    }
                    if (Line.ToUpper().Contains("DEFINED BY"))
                    {
                        string[] splitDefinedBy = Line.ToUpper().Split(' ');
                        for (int x = 0; x < splitDefinedBy.Length; x++)
                        {
                            if (x == 0)
                            {
                                if (splitDefinedBy[x] == "DEFINED")
                                {
                                    DefinedByValidator = true;
                                    break;
                                }
                            }
                            else
                            {
                                if (splitDefinedBy[x] == "DEFINED")
                                {
                                    DefinedByValidator = true;
                                    for (int y = 0; y < x - 1; y++)
                                    {
                                        if (splitDefinedBy[y] != "")
                                        {
                                            DefinedByValidator = false;
                                            break;
                                        }
                                    }
                                   // break;                                    
                                    goto finWhile;
                                }                                
                            }
                        }
                    }                    
                }                
            }
            finWhile:
            return DefinedByValidator;
        }

        private Boolean VerificaFor(string Line, string Codigo)
        {
            Boolean Forvalidador = false;
            if (Line.ToUpper().Contains("FOR EACH"))
            {
                if (!Line.ToUpper().Contains("LINE"))
                {
                    string[] splitFor = Line.ToUpper().Split(' ');
                    for (int x = 0; x < splitFor.Length; x++)
                    {
                        if (x == 0)
                        {
                            if (splitFor[x] == "FOR")
                            {
                                Forvalidador = true;
                            }
                        }
                        else
                        {
                            if (splitFor[x] == "FOR")
                            {
                                Forvalidador = true;
                                for (int y = 0; y < x - 1; y++)
                                {
                                    if (splitFor[y] != "")
                                    {
                                        Forvalidador = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return Forvalidador;
        }

        


        #endregion


        #region "Validar Wheres"

        private List<string> VerificaErroresWhere(string Linea)
        {
            List<string> List = new List<string>();
            for(int x = 0; x<Linea.Length;x++)
            {
                if(Line[x] == '=' || Linea[x] == '<' || Linea[x] == '>' || Linea[x].ToString() == "<=" || Linea[x].ToString() == "=>")
                {
                    Linea = Linea.Substring(x,Linea.Length-x);
                    Linea = Linea.Remove(0,1).Trim();
                    Linea = Linea.Trim();
                }
            }

            string x1 = Linea;
            //valido si inicia con comilla simple
            if (Linea.StartsWith("'"))
            {
                x1 = "WHERE = " + x1;
                List.Add(x1);
            }

            //valido si inicia con letra
            //string x2 = Linea;
            //if (System.Text.RegularExpressions.Regex.IsMatch(x2, "^[A-Za-z]"))
            //{
            //    x2 = "WHERE =" + x2;
            //    List.Add(x2);
            //}

            //valido si inicia con numeros
            string x3 = Linea;
            for (int x = 0; x < 9; x++)
            {
                if (Linea.StartsWith(x.ToString()))
                {
                    x3 = "WHERE = " + x3;
                    List.Add(x3);
                }
            }

            //valido si inicia con "&" y termina en ")"
            string x4 = Linea;
            if (Linea.StartsWith("&") && Linea.EndsWith(")"))
            {
                x4 = "WHERE = " + x4;
                List.Add(x4);
            }

            return List;
        }

        //    Private Function VerificaDentroCALL(ByVal Linea As String) As List(Of String)
        //    Dim list As New List(Of String)
        //    Dim mensaje As String = String.Empty
        //    Linea = Linea.ToUpper.Replace("CALL(", "")
        //    Dim lector() As String = Linea.Split(",")
        //    For Each elemento As String In lector
        //        If Not elemento.StartsWith("&") Then
        //            mensaje = "variable estatica en llamado CALL: " & elemento
        //            list.Add(mensaje)
        //        End If
        //    Next
        //    Return list
        //End Function

        private List<string> VerificaCALL(string Line, string Codigo)
        {
            //Boolean CallValidator = false;
            List<string> Listado1 = new List<string>();
            string valores = "";
            string longitud = "";
            int posicion1;
            string LineaOri;
            Line = Line.Trim();
            LineaOri = Line;

            if (Line.Contains("//"))
            {
                posicion1 = Line.LastIndexOf("//");
                Line = Line.Remove(posicion1);
            }

            if (Line.ToUpper().ToUpper().Contains("CALL("))
            {
                if (!Line.ToUpper().Contains("'MOVSTRN'"))
                {
                    Line = Line.ToUpper().Replace("CALL(", "").Trim();
                    longitud = Line.Length.ToString();
                    if (Line.IndexOf(")") != -1)
                    {
                        Line = Line.Remove(0, Line.IndexOf(")") + 1).Trim().ToString();
                        Line = Line.Replace(")", "").Trim();
                    }
                    Line = Line.Remove(0, Line.IndexOf(",") + 1).Trim();
                    Line = Line.Replace("\\", "").Trim();
                    string[] splitCAll = Line.ToUpper().Split(',');

                    foreach (string item in splitCAll)
                    {
                        item.Trim();
                        if (!item.Contains("&") && item != "")
                        {
                            if (item.Contains("\"\"") || item.Contains("'") || IsNumeric(item))
                            {
                                valores = LineaOri;
                                Listado1.Add(valores);
                            }
                        }
                    }

                }
            }
            return Listado1;
        }

        private List<string> VerificaWhere(string Line, string Codigo)
        {
            Boolean WhereValidator = false;
            List<string> listaux = new List<string>();
            int posicion1;
            if (Line.ToUpper().Contains("WHERE"))
            {
                if (Line.Contains("//"))
                {
                    posicion1 = Line.LastIndexOf("//");
                    Line = Line.Remove(posicion1);
                }
                string[] splitwhere = Line.ToUpper().Split(' ');
                for (int x = 0; x < splitwhere.Length; x++)
                {
                    if (x == 0)
                    {
                        if (splitwhere[x] == "WHERE")
                        {
                            WhereValidator = true;
                            break;
                        }
                    }
                    else
                    {
                        if (splitwhere[x] == "WHERE")
                        {
                            WhereValidator = true;
                            List<string> lista = new List<string>();
                            lista = this.VerificaErroresWhere(Line);
                            if (lista.Count > 0)
                            {
                                listaux = lista;
                            }
                        }
                    }
                }
            }
            return listaux;
        }

        private bool IsNumeric(string numero)
        {            
            Regex pattern = new Regex("[^0-9]");
            return !pattern.IsMatch(numero);            
        }

        #endregion


        #region "Validar si Documentation tiene todos los campos"

        void MetodoAuxiliarLectura(string Aux, Boolean flagSIS, Boolean flagSUBSIS, Boolean flagAut, Boolean flagDesc, Boolean flagFecCreac, Boolean flagProg)
        {
            List<string> lista = new List<string>();
          //  string variable = Aux.ToUpper();
            //string msj = "";
            Aux = Aux.Replace("BR>", "");
            int x = 0;
            if (Aux.Contains(":"))
            {
                x = Aux.IndexOf(":");
            }
            else
            {
                x = 0;
            }
            string var = "";
            if (x != 0)
            {
                var = Aux.Substring(0, Aux.IndexOf(":")).Trim().ToUpper();
            }
            else 
            {
                var = Aux.Trim().ToUpper();
            }
            switch (var)
            {
                case "SISTEMA":
                    flagSIS = true;
                    break;
                case "SUBSISTEMA":
                case "SUB_SISTEMA":
                case "SUB-SISTEMA":
                case "SUB SISTEMA":
                    flagSUBSIS = true;
                    break;
                case "PROGRAMA":
                case "NOMBRE":
                case "OBJETO":
                    flagProg = true;
                    break;
                case "DESCRIPCIÓN":
                case "DESCRIPCION":
                    flagDesc = true;
                    break;
                case "AUTOR":
                    flagAut = true;
                    break;
                case "FECHA CREACIÓN":
                case "FECHA CREACION":
                case "FECHA":
                case "FECHACREACIÓN":
                case "FECHACREACION":
                    flagFecCreac = true;
                    break;
            }
        }

        #endregion


        #region "Metodo para Verificar la lectura del TAG Documentación de un Programa Gx"

        private List<string> VerificarSISTEMA(string Linea)
        {
            Boolean flagSIS = false;
            Boolean flagSUBSIS = false;
            Boolean flagAut = false;
            Boolean flagDesc = false;
            Boolean flagFecCreac = false;
            Boolean flagProg = false;

            //'Logica para limpiar los campos de tags no necesarios del xml
            //'        Replace("</P> por " < BR > "")
            //'        For i = 0 To Len(Linea) - 1
            //'           char = Linea(i)
            //'               if char='<'
            //'                If subtr(Linea, i, 4) <> "<BR>" Then
            //'                    flgComentario = True
            //'                End If
            //'            End If
            //'            If flgcomentario = False Then
            //'                       Linea3 = linea3 + char
            //'            End If
            //'                   if char='>' and flgcomentario = true  
            //'                flgComentario = off
            //'            End If
            //'               end for

            string Linea2 = "";
            Boolean flagComentario = false;
            Linea.Replace("</P>", "<BR>");
            Linea = Linea.Replace("</FONT", "<BR");
            for (int x = 0; x < Linea.Length; x++)
            {
                string caracter = Linea[x].ToString();
                if (caracter == "<")
                {
                    if (Linea.Substring(x, 4) != "<BR>")
                    {
                        flagComentario = true;
                    }
                }
                if (!flagComentario)
                {
                    Linea2 = Linea2 + caracter;
                }
                if (caracter == ">" && flagComentario)
                {
                    flagComentario = false;
                }
            }

            List<string> lista = new List<string>();
            List<string> listaAux = new List<string>();
            string[] separador = { "<BR>" };
            Boolean validator;
            Linea2 = Linea2.Replace("*", "");
            Linea2 = Linea2.Replace("&nbsp;", "");
            string[] lector = Linea2.Split(separador,StringSplitOptions.None);
            int count = 0;
           // int count2 = 0;

            foreach (string item in lector)
            {
                string item2 = lector[count];
                count = count + 1;
                if (!item2.Equals(""))
                {
                    for(int x = 0; x<item.Length;x++)
                    {
                        if (item[x] == ':')
                        {
                            string aux;
                            string variable;
                            string variable2;
                            aux = item2;

                            aux = aux.Replace("BR>", "").Trim();
                            if (aux.ToString().Length > x)
                            {
                                aux = item2.ToString().Substring(0, x);
                            }
                            else
                            {
                                aux = item2.ToString();
                            }
                            variable = aux.Replace("BR>", "").ToUpper().Trim();
                            if (item2.ToString().Length > x)
                            {
                                item2 = item2.Substring(x, item2.Length - x);
                            }
                            else
                            {
                                item2 = item2.ToString();
                            }
                            variable2 = item2.ToString().Replace(":", "").Trim().ToUpper();

                            switch(variable)
                            {
                                case "AUTOR":
                                    if (!variable2.ToUpper().Contains("SES"))
                                    {
                                        string sms = "Falta etiqueta 'SES' en Nombre de Autor";
                                        lista.Add(sms);
                                    }
                                    break;
                                case "OBJETO":
                                case "PROGRAMA":
                                case "NOMBRE":
                                    Boolean correcto = variable2.ToUpper().StartsWith(GenexusObject.NombrePrograma.ToUpper());
                                    if (!correcto)
                                    {
                                        string sms = "Nombre de Programa NO coincide con Documentación";
                                        lista.Add(sms);
                                    }
                                    break;
                            }
                            item2 = item2.ToString().Replace("BR>", "");
                            item2 = item2.ToString().Replace(":", "").Trim();
                            int contador1 = 0;
                            if (item2 == "" || item2 == ".")
                            {
                                aux = aux + ": " + item2;
                                aux = aux.Replace("BR>", "");
                                lista.Add(aux);
                                validator = true;
                                contador1 += 1;
                            }
                            //MetodoAuxiliarLectura(aux, flagSIS, flagSUBSIS, flagAut, flagDesc, flagFecCreac, flagProg);

                            List<string> lista2 = new List<string>();
                            string variable3 = aux.ToUpper();
                            //string msj = "";
                            aux = aux.Replace("BR>", "");
                            int y = 0;
                            if (aux.Contains(":"))
                            {
                                y = aux.IndexOf(":");
                            }
                            else
                            {
                                y = 0;
                            }
                            string var = "";
                            if (y != 0)
                            {
                                var = aux.Substring(0, aux.IndexOf(":")).Trim().ToUpper();
                            }
                            else
                            {
                                var = aux.Trim().ToUpper();
                            }
                            switch (var)
                            {
                                case "SISTEMA":
                                    flagSIS = true;
                                    break;
                                case "SUBSISTEMA":
                                case "SUB_SISTEMA":
                                case "SUB-SISTEMA":
                                case "SUB SISTEMA":
                                    flagSUBSIS = true;
                                    break;
                                case "PROGRAMA":
                                case "NOMBRE":
                                case "OBJETO":
                                    flagProg = true;
                                    break;
                                case "DESCRIPCIÓN":
                                case "DESCRIPCION":
                                    flagDesc = true;
                                    break;
                                case "AUTOR":
                                    flagAut = true;
                                    break;
                                case "FECHA CREACIÓN":
                                case "FECHA CREACION":
                                case "FECHA":
                                case "FECHACREACIÓN":
                                case "FECHACREACION":
                                    flagFecCreac = true;
                                    break;
                            }



                        }
                    }
                }
            }
            string msj = "";
            if (!flagSIS)
            {
                msj = "Falta Sistema";
                lista.Add(msj);
            }
            if (!flagSUBSIS)
            {
                msj = "Falta SubSistema";
                lista.Add(msj);
            }
            if (!flagProg)
            {
                msj = "Falta Programa";
                lista.Add(msj);
            }
            if (!flagDesc)
            {
                msj = "Falta Descripción";
                lista.Add(msj);
            }
            if (!flagAut)
            {
                msj = "Falta Autor";
                lista.Add(msj);
            }
            if (!flagFecCreac)
            {
                msj = "Falta Fecha de Creación";
                lista.Add(msj);
            }
            return lista;
        }

        private List<EntidadCoincidencia> separoPrints(string LineaPrint)
        {
            List<EntidadCoincidencia> listado = new List<EntidadCoincidencia>();
            if (LineaPrint != "" && LineaPrint != null)
            {
                string[] arregloPrint = LineaPrint.Split('-');
                foreach (string item in arregloPrint)
                {
                    EntidadCoincidencia objEntidadConincidencia = new EntidadCoincidencia();
                    objEntidadConincidencia.Contador = 0;
                    objEntidadConincidencia.Nombre = "&" + item;
                    listado.Add(objEntidadConincidencia);
                }
            }
            return listado;
        }

        private void VerificaPrintVsSource(List<EntidadCoincidencia> LineaPrint, string Line)
        {
            foreach (EntidadCoincidencia Item in LineaPrint)
            {
                if (Line.ToLower().Contains(Item.Nombre.ToLower()) && Item.Nombre.ToLower() != "&")
                {
                    Item.Contador = Item.Contador + 1;
                }
            }
        }

        private void VerificarListas(string UsedArray, List<EntidadCoincidencia> LineaPrint, List<EntidadCoincidencia> listadoUsadas)
        {
            string concatenacion = "";
            List<string> sobrantePrint = new List<string>();
            string[] usadasArreglo = UsedArray.Split('-');
            //lo almaceno en un listado de la entidad EntidadCoincidencias
            foreach (string item in usadasArreglo)
            {
                EntidadCoincidencia objeto = new EntidadCoincidencia();
                objeto.Contador = 0;
                objeto.Nombre = item;
                listadoUsadas.Add(objeto);
            }
            //Concateno los datos de LineaPrint en una sola Linea
            foreach (EntidadCoincidencia Item in LineaPrint)
            {
                if (Item.Nombre.ToLower() != "&")
                {
                    concatenacion += Item.Nombre.ToLower().ToString() + "-";
                }
                else
                {
                    sobrantePrint.Add(Item.Nombre.ToLower().ToString());
                }
            }
            foreach (EntidadCoincidencia Item in listadoUsadas)
            {
                if (concatenacion.ToLower().Contains(Item.Nombre.ToLower()) && Item.Nombre.ToLower() != "&")
                {
                    Item.Contador = Item.Contador + 1;
                }
            }
        }

        private Boolean VerificaAsignacionEstatica(string Line)
        {
            Boolean validator = false;
            for (int x = 0; x < Line.Length; x++)
            {
                if (Line[x].ToString() == "=")
                {
                    Line = Line.Substring(x,Line.Length - x);
                    Line = Line.Remove(0, 1).Trim();
                    break;
                }
            }
            if (Line.StartsWith("'"))
            {
                validator = true;
            }
            for (int x = 0; x < 9; x++)
            {
                if (Line.StartsWith(x.ToString()))
                {
                    validator = true;
                }
            }
            return validator;
        }

        #endregion


        #region "Report"

        private void ShowReport()
        {
            ClearGrids();

            pnlReporte.Visible = true;
            CoincidenciaBE ruta = new CoincidenciaBE();
            //Coincidencias================================================================
            lblTotalCoin1.Text = contadorTotalAux.ToString();

            if (contadorTotalAux > 0)
            {
                lblMsgCoin.Text = "Se encontraron las siguientes coincidencias:";
                //imgCoin.Image = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //My.Resources.Flag_Bad; //aqui puse \\
                imgCoin.Image = Properties.Resources.Flag_Bad;
                lblFlagCoin.Text = "Bad";
            }
            else
            {
                lblMsgCoin.Text = "No se encontraron Coincidencias";
                //imgCoin.Image = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                imgCoin.Image = Properties.Resources.Flag_Good;
                lblFlagCoin.Text = "Good";
            }

            contadorTotalAux = 0;
            gvCoincidencias.DataSource = lstCoincidenciaAux;

            if (!chkPalabraCompleta.Checked)
            {
                gvCoincidencias.Columns["Contador"].Visible = false;
            }
            else
            {
                gvCoincidencias.Columns["Contador"].Visible = true;
            }

            GenerateResume();
            giveFormat();
            ibtExportPDF.Visible = true;
        }

        private void giveFormat()
        {
            if (gvCoincidencias.Rows.Count > 0)
            {
                foreach (DataGridViewRow Row in gvCoincidencias.Rows)
                {
                    string type = Row.Cells["Flag"].Value.ToString();
                    if (type == "HeaderRowTittleObject")
                    {
                        Row.DefaultCellStyle.BackColor = Color.FromArgb(48, 164, 221);
                        Row.Cells["ImgFlag"].Style.BackColor = Color.White;
                        Row.DefaultCellStyle.ForeColor = Color.White;
                    }
                    else if (type != "HeaderRowTittleObject" && type.StartsWith("HeaderRowTittle"))
                    {
                        Row.Cells["Linea"].Style.Padding = new Padding(20, 0, 0, 0);
                        Row.DefaultCellStyle.BackColor = Color.FromArgb(110, 191, 231);                        
                        Row.Cells["ImgFlag"].Style.BackColor = Color.White;
                        Row.DefaultCellStyle.ForeColor = Color.White;
                    }
                    else if (type.StartsWith("DataRow"))
                    {
                        Row.Cells["Linea"].Style.Padding = new Padding(20, 0, 0, 0);
                    }
                }
            }
        }

        #endregion

        #region "nose"

        private void chkMultiple_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMultiple.Checked)
            {
                ibtAgregar.Visible = true;
                lstBoxPalabras.Visible = true;
            }
            else
            {
                ibtAgregar.Visible = false;
                lstBoxPalabras.Visible = false;
            }

            ibtQuitar.Visible = false;
            PictureBox9.Visible = false;
            lstBoxPalabras.Items.Clear();
        }

        private void AsignarPalabras()
        {
            if (chkMultiple.Checked)
            {
                for (int i = 0; i < lstBoxPalabras.Items.Count; i++)
                {
                    string palabra = Convert.ToString(lstBoxPalabras.Items[i]);
                    if (!chkMayusMinus.Checked)
                    {
                        palabra = palabra.ToUpper();
                    }

                    switch (i)
                    {
                        case 0: palabra1 = palabra;
                            break;

                        case 1: palabra2 = palabra;
                            break;

                        case 2: palabra3 = palabra;
                            break;

                        case 3: palabra4 = palabra;
                            break;

                        case 4: palabra5 = palabra;
                            break;

                        case 5: palabra6 = palabra;
                            break;

                        case 6: palabra7 = palabra;
                            break;

                        case 7: palabra8 = palabra;
                            break;

                        case 8: palabra9 = palabra;
                            break;

                        case 9: palabra10 = palabra;
                            break;
                    }
                }
            }
            else
            {
                if (chkMayusMinus.Checked)
                {
                    palabra1 = txtPalabra.Text.Trim();
                }
                else
                {
                    palabra1 = txtPalabra.Text.Trim().ToUpper();
                }
            }
        }

        private void OrdernalstCoincidenciaAux()
        {
            //Nombre y Tipo de Objeto
            //lstCallStaticosAux = new List<CoincidenciaBE>();
            CoincidenciaBE ResultTitle = new CoincidenciaBE();
            ResultTitle.TipoObj = GenexusObject.TipoObjeto;
            ResultTitle.Flag = "HeaderRowTittleObject";
            ResultTitle.Linea = GenexusObject.NombrePrograma;
            ResultTitle.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
            ResultTitle.ImgFlag = Properties.Resources.Flag_None;
            //ResultTitle.ImgFlag = Image.FromFile(ResultTitle.RutaImagenes + "\\Flag_None.png"); //aqui puse \\            
            lstCoincidenciaAux.Add(ResultTitle);

            //Palabra1
            //Aumentamos Contadores
            foreach (CoincidenciaBE Item in lstCoincidencia1)
            {
                contadorTotalPalabra1 = contadorTotalPalabra1 + Item.Contador;
                contadorTotal = contadorTotal + Item.Contador;
            }

            //Nombre y Total de Palabra
            CoincidenciaBE Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittlePalabra1";
            Result.Linea = "La palabra \"" + palabra1 + "\" ha sido encontrada un total de " + contadorTotalPalabra1 + " veces:";
            if (contadorTotalPalabra1 > 0)
            {
                Result.ImgFlag = Properties.Resources.Flag_Warning;
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
            }
            else
            {
                Result.ImgFlag = Properties.Resources.Flag_Good;
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
            }

            if (contadorTotalPalabra1 > 0)
            {
                Result.RutaImg = "\\Flag_Warning.png";
            }
            else
            {
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);

            foreach (CoincidenciaBE Item in lstCoincidencia1)
            {
                lstCoincidenciaAux.Add(Item);
            }

            //Palabra2
            if (palabra2 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia2)
                {
                    contadorTotalPalabra2 = contadorTotalPalabra2 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra2";
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_None;
                Result.Linea = "La palabra \"" + palabra2 + "\" ha sido encontrada un total de " + contadorTotalPalabra2 + " veces:";
                if (contadorTotalPalabra2 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia2)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra3
            if (palabra3 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia3)
                {
                    contadorTotalPalabra3 = contadorTotalPalabra3 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra3";
                Result.Linea = "La palabra \"" + palabra3 + "\" ha sido encontrada un total de " + contadorTotalPalabra3 + " veces:";
                if (contadorTotalPalabra3 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia3)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra4
            if (palabra4 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia4)
                {
                    contadorTotalPalabra4 = contadorTotalPalabra4 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra4";
                Result.Linea = "La palabra \"" + palabra4 + "\" ha sido encontrada un total de " + contadorTotalPalabra4 + " veces:";
                if (contadorTotalPalabra4 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia4)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra5
            if (palabra5 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia5)
                {
                    contadorTotalPalabra5 = contadorTotalPalabra5 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra5";
                Result.Linea = "La palabra \"" + palabra5 + "\" ha sido encontrada un total de " + contadorTotalPalabra5 + " veces:";
                if (contadorTotalPalabra5 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia5)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra6
            if (palabra6 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia6)
                {
                    contadorTotalPalabra6 = contadorTotalPalabra6 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra6";
                Result.Linea = "La palabra \"" + palabra6 + "\" ha sido encontrada un total de " + contadorTotalPalabra6 + " veces:";
                if (contadorTotalPalabra6 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia6)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra7
            if (palabra7 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia7)
                {
                    contadorTotalPalabra7 = contadorTotalPalabra7 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra7";
                Result.Linea = "La palabra \"" + palabra7 + "\" ha sido encontrada un total de " + contadorTotalPalabra7 + " veces:";
                if (contadorTotalPalabra7 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia7)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra8
            if (palabra8 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia8)
                {
                    contadorTotalPalabra8 = contadorTotalPalabra8 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra8";
                Result.Linea = "La palabra \"" + palabra8 + "\" ha sido encontrada un total de " + contadorTotalPalabra8 + " veces:";
                if (contadorTotalPalabra8 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia8)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra9
            if (palabra9 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia9)
                {
                    contadorTotalPalabra9 = contadorTotalPalabra9 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra9";
                Result.Linea = "La palabra \"" + palabra9 + "\" ha sido encontrada un total de " + contadorTotalPalabra9 + " veces:";
                if (contadorTotalPalabra9 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia9)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            //Palabra10
            if (palabra10 != "")
            {
                foreach (CoincidenciaBE Item in lstCoincidencia10)
                {
                    contadorTotalPalabra10 = contadorTotalPalabra10 + Item.Contador;
                    contadorTotal = contadorTotal + Item.Contador;
                }
                //Nombre y Total de Palabra
                Result = new CoincidenciaBE();
                Result.Flag = "HeaderRowTittlePalabra10";
                Result.Linea = "La palabra \"" + palabra10 + "\" ha sido encontrada un total de " + contadorTotalPalabra10 + " veces:";
                if (contadorTotalPalabra10 > 0)
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");
                    Result.ImgFlag = Properties.Resources.Flag_Bad;
                }
                else
                {
                    //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png");
                    Result.ImgFlag = Properties.Resources.Flag_Good;
                }
                lstCoincidenciaAux.Add(Result);

                foreach (CoincidenciaBE Item in lstCoincidencia10)
                {
                    lstCoincidenciaAux.Add(Item);
                }
            }

            ResultTitle = new CoincidenciaBE();
            ResultTitle.Flag = "BlankDataRow";
            ResultTitle.Linea = "";
            ResultTitle.RutaImg = "\\Flag_None.png";
            ResultTitle.ImgFlag = Properties.Resources.Flag_None;
            //ResultTitle.ImgFlag = Image.FromFile(ResultTitle.RutaImagenes + "\\Flag_None.png"); //aqui puse \\            
            lstCoincidenciaAux.Add(ResultTitle);

            //DefinedBy==========================================================================
            foreach(CoincidenciaBE Item in lstSinDefinedBy)
            {
                contadorDefinedBy = contadorDefinedBy + 1;
            }

            //Nombre y Total de Palabra
            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleDefinedBy";
            Result.Linea = "Se encontraron un total de " + contadorDefinedBy + " loop \"\"For\"\" sin asignación de \"\"Defined By\"\":";
            if (contadorDefinedBy > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                Result.RutaImg = "\\Flag_Bad.png";
                Result.ImgFlag = Properties.Resources.Flag_Bad;
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.RutaImg = "\\Flag_Good.png";
                Result.ImgFlag = Properties.Resources.Flag_Good;
            }

            //if (contadorDefinedBy > 0)
            //{
            //    Result.RutaImg = "\\Flag_Bad.png";
            //}
            //else
            //{
            //    Result.RutaImg = "\\Flag_Good.png";
            //}
            lstCoincidenciaAux.Add(Result);

            foreach(CoincidenciaBE Item in lstSinDefinedBy)
            {
                lstCoincidenciaAux.Add(Item);
            }

            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            Result.ImgFlag = Properties.Resources.Flag_None;
            Result.RutaImg = "\\Flag_None.png";
            lstCoincidenciaAux.Add(Result);

            //Definiciones Where======================================================================
            foreach (CoincidenciaBE Item in lstWheresMalImplementados)
            {
                contadorWhere = contadorWhere + 1;
            }

            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleWhereException";
            Result.Linea = "Se encontraron un total de " + contadorWhere + " Clausulas \"\"Where\"\" con variables estaticas o con rutinas:";
            if (contadorWhere > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Bad;
                Result.RutaImg = "\\Flag_Bad.png";
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Good;
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);

            foreach(CoincidenciaBE Item in lstWheresMalImplementados)
            {
                lstCoincidenciaAux.Add(Item);
            }

            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            Result.RutaImg = "\\Flag_None.png";
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            lstCoincidenciaAux.Add(Result);

            //Definiciones en Documentación
            //=================================================================================================================================

            contadorDocumentation = 0;
            foreach(CoincidenciaBE Item in lstDocumentation)
            {
                contadorDocumentation = contadorDocumentation + 1;
            }

            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleDocumentation";
            Result.Linea = "Se encontraron un total de " + contadorDocumentation + " Datos incompletos en la Documentación:";

            if (contadorDocumentation > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png");  //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Bad;
                Result.RutaImg = "\\Flag_Bad.png";
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Good;
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);

            foreach (CoincidenciaBE Item in lstDocumentation)
            {
                lstCoincidenciaAux.Add(Item);
            }

            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            Result.RutaImg = "\\Flag_None.png";
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            lstCoincidenciaAux.Add(Result);

            //Definiciones Call's
            //=============================================================================================================
            contadorCALL = 0;
            foreach (CoincidenciaBE Item in lstCallStaticos)
            {
                contadorCALL = contadorCALL + 1;
            }

            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleCALL";
            Result.Linea = "Se encontraron un total de " + contadorCALL + " Datos incompletos en los Calls:";

            if (contadorCALL > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Bad;
                Result.RutaImg = "\\Flag_Bad.png";
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Good;
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);
            foreach (CoincidenciaBE item in lstCallStaticos)
            {
                lstCoincidenciaAux.Add(item);
            }
            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            Result.RutaImg = "\\Flag_None.png";
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            lstCoincidenciaAux.Add(Result);

            //Definiciones Palabras Restringidas
            //============================================================================================================
            contadorPalabrasRestringidas = 0;
            foreach (CoincidenciaBE Item in lstPalabrasRestringidas)
            {
                contadorPalabrasRestringidas = contadorPalabrasRestringidas + 1;
            }
            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleRestringidas";
            Result.Linea = "Se encontraron un total de " + contadorPalabrasRestringidas + " palabras RESTRINGIDAS";

            if (contadorPalabrasRestringidas > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Bad;
                Result.RutaImg = "\\Flag_Bad.png";
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Good;
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);
            foreach (CoincidenciaBE item in lstPalabrasRestringidas)
            {
                lstCoincidenciaAux.Add(item);
            }
            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            Result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            lstCoincidenciaAux.Add(Result);

            //Definiciones Formatos Constantes
            //================================================================================================================
            contadorFormatosConstantes = 0;
            foreach (CoincidenciaBE item in lstFormatosConstantes)
            {
                contadorFormatosConstantes = contadorFormatosConstantes + 1;
            }
            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleFormatosConstantes";
            Result.Linea = "Se encontraron un total de " + contadorFormatosConstantes + " Advertencias";
            if (contadorFormatosConstantes > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Warning;
                Result.RutaImg = "\\Flag_Warning.png";
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Good;
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);
            foreach (CoincidenciaBE item in lstFormatosConstantes)
            {
                lstCoincidenciaAux.Add(item);
            }
            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            Result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
            lstCoincidenciaAux.Add(Result);

            //Definiciones Usadas
            //================================================================================================
            contadorUsadas = 0;
            foreach (CoincidenciaBE item in lstUsadas)
            {
                contadorUsadas = contadorUsadas + 1;
            }
            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleVariablesUsadas";
            Result.Linea = "Se encontraron un total de " + contadorUsadas + "  variables inicializadas y no utilizadas";
            if (contadorUsadas > 0)
            {
                Result.ImgFlag = Properties.Resources.Flag_Warning;
              //  Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                Result.RutaImg = "\\Flag_Warning.png";
            }
            else
            {
                Result.ImgFlag = Properties.Resources.Flag_Good;
               // Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);
            foreach (CoincidenciaBE item in lstUsadas)
            {
                lstCoincidenciaAux.Add(item);
            }

            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            Result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            lstCoincidenciaAux.Add(Result);

            //Definiciones Estáticas
            //==========================================================================
            //Nombre y Total de Palabra
            Result = new CoincidenciaBE();
            Result.Palabra = "-";
            Result.Flag = "HeaderRowTittleStatic";
            Result.Linea = "Se encontraron un total de " + lstAsignacionEstatica.Count + " líneas con asignaciones estáticas:";
            if (lstAsignacionEstatica.Count > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Warning;
                Result.RutaImg = "\\Flag_Warning.png";
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Good;
                Result.RutaImg = "\\Flag_Good.png";
            }
            lstCoincidenciaAux.Add(Result);

            foreach (CoincidenciaBE item in lstAsignacionEstatica)
            {
                lstCoincidenciaAux.Add(item);
            }
            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.Linea = "";
            Result.RutaImg = "\\Flag_None.png";
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            lstCoincidenciaAux.Add(Result);

            //Variables Inutilizadas==========================================================================
            //Nombre y Total de Palabra 
            Result = new CoincidenciaBE();
            Result.Flag = "HeaderRowTittleInutilizadas";
            Result.Linea = "Se encontraron un total de " + lstVariablesInutilizadas.Count + " variables no utilizadas:";

            if (lstVariablesInutilizadas.Count > 0)
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Warning;
                Result.RutaImg = "\\Flag_Warning.png";
            }
            else
            {
                //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Result.ImgFlag = Properties.Resources.Flag_Good;
                Result.RutaImg = "\\Flag_Good.png"; 
            }
            lstCoincidenciaAux.Add(Result);
            foreach (CoincidenciaBE item in lstVariablesInutilizadas)
            {
                lstCoincidenciaAux.Add(item);
            }
            Result = new CoincidenciaBE();
            Result.Flag = "BlankDataRow";
            Result.ImgFlag = Properties.Resources.Flag_None;
            //Result.ImgFlag = Image.FromFile(Result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
            Result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
            lstCoincidenciaAux.Add(Result);

            contadorTotalAux = contadorTotalAux + contadorTotal;        
        }

        //private Boolean generarArchivo(string ruta)
        //{
            //Try
            //    Dim fileStream As New FileStream(ruta, FileMode.CreateNew)
            //    Dim streamWriter As New StreamWriter(fileStream)
            //    streamWriter.Write(txtResults.Text)
            //    streamWriter.Close()
            //    Return True
            //Catch ex As Exception
            //    Return False
            //End Try
        //}

        #endregion

        private void btnMantPalabras_Click(object sender, EventArgs e)
        {
            ValidadorGNX.Formularios.MantRestringidas FormRestringidas = new ValidadorSES.ValidadorGNX.Formularios.MantRestringidas();
            this.Hide();
            FormRestringidas.ShowDialog();
            this.Close();
        }

        private void btnMantenimientoVigencia_Click(object sender, EventArgs e)
        {
            ValidadorGNX.Formularios.MantFechaVencimiento FormVigencia = new ValidadorSES.ValidadorGNX.Formularios.MantFechaVencimiento();
           // this.Hide();
            FormVigencia.usuario = valor;
            FormVigencia.ShowDialog();
            //this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {                       
            string x;
            x = valor;            
            if (x == "1")
            {
                PnlAdministrador.Visible = true;
                btnMantenimientoVigencia.Visible = true;
                btnMantPalabras.Visible = true;
            }
            else
            {
                btnMantPalabras.Visible = false;
                btnMantenimientoVigencia.Visible = false;
            }
        }

        private void Extraer(string zipExtraer, string zipAlm)
        {
        
            using (ZipFile zipl = ZipFile.Read(zipExtraer))
            {
                foreach(ZipEntry e in zipl)
                {
                    e.Extract(zipAlm, ExtractExistingFileAction.OverwriteSilently);
                }
            }            

        }

        private void ibtBuscar_Click(object sender, EventArgs e)
        {
            //COMPROBAR ESTAR PARTE!!

            lblNombreUsuarioSQL.Text = "";

            lblUsuarioTexto.Text = Environment.UserName.ToString().ToUpper();

            if (chkMultiple.Checked)
            {
                if (lstBoxPalabras.Items.Count <= 0)
                {
                    if (txtPalabra.Text.Trim() == "")
                    {
                        MessageBox.Show("Ingrese Palabra a Buscar.", "Error");
                        return;
                    }
                }
            }

            resultados.Clear();
            
            //limpiamos las variables globales
            this.ClearGlobalVariables();
            string nombreArchivo = "";


            palabra1 = "";
            palabra2 = "";
            palabra3 = "";
            palabra4 = "";
            palabra5 = "";
            palabra6 = "";
            palabra7 = "";
            palabra8 = "";
            palabra9 = "";
            palabra10 = "";

            this.AsignarPalabras();

            OpenFileDialog ofd = new OpenFileDialog();
            OpenFileDialog ofd2 = new OpenFileDialog();

            string auxnombre = "";

            ofd.Filter = "Archivos XML;XPZ|*.xml;*.xpz";

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string sFileName = ofd.FileName;
                string ruta = "";
                int direccion = 0;
                int index = sFileName.IndexOf(".");
                string extencion = sFileName.Substring(sFileName.Length - 3, 3);
                if (extencion.ToUpper().Equals("XPZ"))
                {
                    string auxFile = sFileName.Substring(0, index);
                    string sfileName2 = auxFile + ".zip";
                    
                    nombreArchivo = Path.GetFileNameWithoutExtension(sFileName);
                    auxnombre = nombreArchivo;
                    direccion = sFileName.LastIndexOf(nombreArchivo);

                    ruta = sFileName.Substring(0, direccion);
                    string RutaDestino = ruta + nombreArchivo + ".zip";
                    //File.Move(nombreArchivo + ".zip", ruta);
                    //File.Delete(RutaDestino);

                    //File.Copy(sFileName, RutaDestino);
                    File.Move(sFileName, sfileName2);
                    
                    Extraer(sfileName2, ruta);
                    sfileName2 = ruta + nombreArchivo + "_1.xml";
                    RutaFinal = this.getNewFilePath(nombreArchivo, sfileName2);
                    GenexusObject = this.getObjectCode(sfileName2);

                    //Restaurar Extensiones xpz o xpw a archivos
                    //COMPROBAR ESTAR PARTE!! :/                                     
                    File.Move(ruta + nombreArchivo + ".zip",sFileName);                    
                    File.Delete(sfileName2);
                    
                }
                else
                {
                    GenexusObject = getObjectCode(sFileName);
                    nombreArchivo = GenexusObject.NombrePrograma;
                }
                //Eliminar temporal xml
                string ErrorString = GenexusObject.TipoError;
                if (ErrorString == "ErrorCodigo")
                {
                    MessageBox.Show("No se pudo hallar el código en el archivo \"" + auxnombre + ".xpz\"\".", "Error");
                    return;
                }
                else if (ErrorString == "ErrorReglas")
                {
                   // string msj = "errors";
                }
                else if (ErrorString == "ErrorVariables")
                {
                    MessageBox.Show("No se pudo hallar las variables en el archivo \"\"" + auxnombre + ".xpz\"\".", "Error");
                    return;
                }

                string Parametros = GenexusObject.Parametros;
                string Variables = GenexusObject.Variables;
                string Codigo = GenexusObject.Codigo;
                string CodDoc = GenexusObject.Documentation;
                string CodPrint = GenexusObject.PrintBlock;

                //Obtenemos las Variables sin contar las Variables usadas como Parámetros del Objeto GeneXus                
                string[] VariablesSinParm = getVariablesSinParm(Parametros, Variables);

                //Evaluamos si las variables son inutilizadas
                string used = "";
                //VerificaVariables(Codigo, VariablesSinParm, GenexusObject.TipoObjeto, GenexusObject.Nombre, used);
                used = VerificaVariables(Codigo, VariablesSinParm, GenexusObject.TipoObjeto, GenexusObject.Nombre);
                List<EntidadCoincidencia> listadoPrint = new List<EntidadCoincidencia>();
                //Leemos bloque printblock
                StringReader codigoPrint = new StringReader(CodPrint);
                StringReader codigoSource = new StringReader(Codigo);

                string LineaPrint = codigoPrint.ReadLine();
               // int lineasint;
                listadoPrint = separoPrints(LineaPrint);

                List<EntidadCoincidencia> listadoUsadas = new List<EntidadCoincidencia>();
                VerificarListas(used, listadoPrint, listadoUsadas);
                List<EntidadCoincidencia> listaAuxiliar = new List<EntidadCoincidencia>();
                foreach (EntidadCoincidencia item in listadoUsadas)
                {
                    if (item.Contador == 0)
                    {
                        listaAuxiliar.Add(item);
                    }
                }
                //Leemos Documentacion con StringReader
                StringReader CodigoAux = new StringReader(CodDoc);
                
                while (true)
                {
                    Line = CodigoAux.ReadLine();
                    List<string> listado = new List<string>();
                    if (Line != null)
                    {
                        //almaceno la linea original
                        OriginalLine = CodDoc;
                        if (!Line.StartsWith("//"))
                        {
                            //Evaluamos la seccion Documentation
                            Line = OriginalLine;
                            listado = VerificarSISTEMA(Line);
                            if (listado.Count > 0)
                            {
                                foreach (String item in listado)
                                {
                                    result = new CoincidenciaBE();
                                    result.Flag = "DataRowDocumentationException";
                                    result.NombreObj = GenexusObject.Nombre;
                                    result.NroLinea = contadorLineas.ToString();
                                    result.Linea = item.ToString();
                                    result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                                    result.ImgFlag = Properties.Resources.Flag_None;
                                    //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                    lstDocumentation.Add(result);
                                }
                            }
                        }
                        //                        break;
                    }
                    else
                    {
                        //'listado.Add("NO SE ENCONTRO DOCUMENTACION")
                        //'Result.RutaImg = "\\Flag_None.png"
                        //'lstDocumentation.Add(Result)
                    }
                    break;
                }
                //Utilizamos un StringReader para la lectura del código
                StringReader CodeText = new StringReader(Codigo);
                //Leemos el código línea por línea
                while (true)
                {
                    Line = CodeText.ReadLine();
                    if (Line != null)
                    {
                        OriginalLine = Line.Trim();
                        if (!chkMayusMinus.Checked)
                        {
                            Line = Line.ToUpper();
                        }
                        contadorLineas = contadorLineas + 1;
                        //Evaluamos si se realiza asignaciones estáticas
                        if (Line.Contains("=") && !Line.Trim().StartsWith("//"))
                        {
                            if(VerificaAsignacionEstatica(Line.Trim()))
                            {
                                CoincidenciaBE Estatica = new CoincidenciaBE();
                                Estatica.Flag = "DataRowEstatico";
                                Estatica.NombreObj = GenexusObject.Nombre;
                                Estatica.NroLinea = contadorLineas.ToString();
                                Estatica.Linea = OriginalLine;
                                Estatica.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                                Estatica.ImgFlag = Properties.Resources.Flag_None;
                                //Estatica.ImgFlag = Image.FromFile(Estatica.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                lstAsignacionEstatica.Add(Estatica);
                            }
                        }

                        //evaluamos si contiene variables estaticas en call
                        List<string> arregloCALL = new List<string>();
                        string valor = "";
                        arregloCALL = VerificaCALL(Line, Codigo);
                        if (arregloCALL.Count > 0)
                        {
                            foreach (string a in arregloCALL)
                            {
                                valor = a;
                                result = new CoincidenciaBE();
                                result.Flag = "DataRowCALLException";
                                result.NombreObj = GenexusObject.Nombre;
                                result.NroLinea = contadorLineas.ToString();
                                result.Linea = valor;
                                result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                                result.ImgFlag = Properties.Resources.Flag_None;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                lstCallStaticos.Add(result);
                            }
                        }

                        //Evaluamos si contiene palabras Restringidas
                        string pResultado = "";
                        List<string> listado1 = new List<string>();

                        pResultado = Restricciones.ValidaRestricciones(lblRestricciones, Line);
                        if (pResultado != "")
                        {
                            result = new CoincidenciaBE();
                            result.Flag = "DataRowRestringidasException";
                            result.NombreObj = GenexusObject.Nombre;
                            result.NroLinea = contadorLineas.ToString();
                            result.Linea = pResultado;
                            result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                            result.ImgFlag = Properties.Resources.Flag_None;
                            //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                            lstPalabrasRestringidas.Add(result);
                        }

                        //Verificamos formatos constantes
                        string pResultado1 = "";
                        pResultado1 = Restricciones.ValidaFormatoConstante(Line);
                        if (pResultado1 != "")
                        {
                            result = new CoincidenciaBE();
                            result.Flag = "DataRowFormatosConstantes";
                            result.NombreObj = GenexusObject.Nombre;
                            result.NroLinea = contadorLineas.ToString();
                            result.Linea = pResultado1;
                            //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                            result.ImgFlag = Properties.Resources.Flag_None;
                            result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                            lstFormatosConstantes.Add(result);
                        }

                        //Evaluamos si contiene un where 
                        List<string> arregloWhere = new List<string>();
                        arregloWhere = VerificaWhere(Line, Codigo);

                        if (arregloWhere.Count > 0)
                        {
                            result = new CoincidenciaBE();
                            result.Flag = "DataRowWhereException";
                            result.NombreObj = GenexusObject.Nombre;
                            result.NroLinea = contadorLineas.ToString();
                            result.Linea = OriginalLine;
                            result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                            result.ImgFlag = Properties.Resources.Flag_None;
                            //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                            lstWheresMalImplementados.Add(result);
                        }

                        //Evaluamos si contiene un loop For
                        if (VerificaFor(Line, Codigo))
                        {
                            //Evaluamis si el loop For contiene Defined By
                            Boolean DefinedBy = VerificaDefinedBy(contadorLineas.ToString(), Codigo);
                            //if (!VerificaDefinedBy(contadorLineas.ToString(), Codigo))
                            if (!DefinedBy)
                            {
                                result = new CoincidenciaBE();
                                result.Flag = "DataRowDefinedBy";
                                result.Linea = "Loop For Each sin Definición de Defined By";
                                result.NombreObj = GenexusObject.Nombre;
                                result.NroLinea = contadorLineas.ToString();
                                result.ImgFlag = Properties.Resources.Flag_None;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                                lstSinDefinedBy.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Primera Palabra
                        if (palabra1 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra1, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra1";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra1;
                                result.Linea = OriginalLine;
                                result.RutaImg = "\\Flag_None.png";
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia1.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Segunda Palabra
                        if (palabra2 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra2, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra2";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra2;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia2.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Tercera Palabra
                        if (palabra3 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra3, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra3";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra3;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia3.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Cuarta Palabra
                        if (palabra4 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra4, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra4";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra4;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia4.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Quinta Palabra
                        if (palabra5 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra5, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra5";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra5;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia5.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Sexta Palabra
                        if (palabra6 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra6, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra6";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra6;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia6.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Septima Palabra
                        if (palabra7 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra7, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra7";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra7;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia7.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Octava Palabra
                        if (palabra8 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra8, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra8";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra8;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia8.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Novena Palabra
                        if (palabra9 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra9, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra9";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra9;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia9.Add(result);
                            }
                        }

                        //Verificamos Coincidencias de la Decima Palabra
                        if (palabra10 != "")
                        {
                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra10, Line);

                            if (result != null)
                            {
                                result.Flag = "DataRowPalabra10";
                                result.NombreObj = GenexusObject.Nombre;
                                result.Palabra = palabra10;
                                result.Linea = OriginalLine;
                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                result.ImgFlag = Properties.Resources.Flag_None;
                                lstCoincidencia10.Add(result);
                            }
                        }

                    }
                    else
                    {
                        break;
                    }

                    foreach (EntidadCoincidencia item in listaAuxiliar)
                    {
                        if (item.Contador == 0)
                        {
                            if (Line.ToLower().Contains(item.Nombre.ToLower()))
                            {
                                item.ContadorAux = item.ContadorAux + 1;
                                item.LineaAux = contadorLineas;
                            }
                        }
                    }
                        
                }

                foreach(EntidadCoincidencia item in listaAuxiliar)
                {
                    if (item.ContadorAux == "1")
                    {
                        result = new CoincidenciaBE();
                        result.Flag = "DataRowListadoUsadasException";
                        result.NombreObj = GenexusObject.Nombre;
                        result.NroLinea = item.LineaAux.ToString();
                        result.Linea = item.Nombre;
                        //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                        result.ImgFlag = Properties.Resources.Flag_None;
                        result.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                        lstUsadas.Add(result);
                    }

                    if(item.Nombre.ToLower() != "&" && item.Nombre.ToLower() != "")
                    {
                        //'MessageBox.Show((Item.Nombre & " " & Item.Contador).ToString())
                    }
                }
                ClearAuxLists();
                OrdernalstCoincidenciaAux();
                ShowReport();
            }
            ofd.Dispose();
            CargarFechaEjecución();
        }

        private string getNewFilePath(string FileName, string FilePath)
        {
            DateTime fechaActual = DateTime.Today;
            string filtro = FileName + "_" + fechaActual.Day + fechaActual.Month + fechaActual.Year + "*";
            string ruta = "";
            string[] ArchivosDir;
            string directorio;

            if (FilePath.Substring(FilePath.Length - 4, 4).ToUpper() == ".XML")
            {
                directorio = Path.GetDirectoryName(FilePath);
                ruta = FilePath.Substring(0, FilePath.Length - 4);
            }
            else 
            {
                directorio = FilePath;
                //COMPROBAR ESTAR PARTE!! :/
                ruta = FilePath + "\\" + FileName; 
            }

            ArchivosDir = Directory.GetFiles(directorio, filtro);
            if (ArchivosDir.Length == 0)
            {
                ruta = ruta + "_" + fechaActual.Day + fechaActual.Month + fechaActual.Year + ".txt";
            }
            else 
            {
                ruta = ruta + "_" + fechaActual.Day + fechaActual.Month + fechaActual.Year + "(" + ArchivosDir.Length + 1 + ".txt";
            }

            return ruta;
        }

        private ObjetoGeneXusBE getObjectCode(string path)
        {
            int validator = -1;
            try
            {
                XmlDocument xDoc = new XmlDocument();
                xDoc.Load(path);
                XmlNode FatherNode = xDoc.ChildNodes[1];
                XmlNode DescriptionNode = ((XmlNodeList)FatherNode.SelectNodes("GXObject"))[0];
                XmlNodeList LayoutNodeList = xDoc.SelectNodes("ExportFile/GXObject");

                string Tipo = "";
                string FiltroCode = "";
                string FiltroRules = "";
                string FiltroVariables = "";
                string FiltroDocumentation = "";
                string FiltroForm = "";
                string FiltroForm2 = "";
                string filtroPrint = "";
                string nombrePrograma = "";
                
                switch(DescriptionNode.FirstChild.LocalName.Substring(0,1).ToUpper())
                {
                    case "P":
                        Tipo = "Procedure";
                        FiltroCode = "Procedure/Layout/Block/CodeBlock/Source";
                        FiltroRules = "Procedure/Rules";
                        FiltroDocumentation = "Procedure/Documentation/Source";
                        FiltroVariables = "Procedure/Variable";
                        filtroPrint = "Procedure/Layout/Block/Edit/Name";
                        nombrePrograma = "Procedure/Info/Name";
                        break;

                    case "W":
                        Tipo = "WorkPanel";
                        FiltroCode = "WorkPanel/Events";
                        FiltroRules = "WorkPanel/Rules";
                        FiltroDocumentation = "WorkPanel/Documentation/Source";
                        FiltroVariables = "WorkPanel/Variable";
                        FiltroForm = "WorkPanel/Form/Block/Edit";
                        FiltroForm2 = "WorkPanel/Form/Block/SubFile/Item/Name";
                        filtroPrint = "WorkPanel/Form/Block/Edit/Name";
                        nombrePrograma = "WorkPanel/Info/Name";
                        break;

                    case "R":
                        Tipo = "Reporte";
                        FiltroCode = "Report/Layout/Block/CodeBlock/Source";
                        FiltroRules = "Report/Rules";
                        FiltroDocumentation = "Report/Documentation/Source";
                        FiltroVariables = "Report/Variable";
                        filtroPrint = "Report/Layout/Block/Edit/Name";
                        nombrePrograma = "Report/Info/Name";
                        break;
                }

                GenexusObject.TipoObjeto = Tipo;

                XmlNodeList VariablesNodeList = LayoutNodeList[0].SelectNodes(FiltroVariables);
                string variables = "";

                //obtenemos las variables
                foreach (XmlNode Node in VariablesNodeList)
                {
                    variables = variables + Node.ChildNodes[1].InnerText + "-";
                }

                GenexusObject.Variables = variables.Substring(0, variables.Length - 1);

                ////////////////////////////////////////////////////////////////////////////
                //pasó
                validator = -2;
                ////////////////////////////////////////////////////////////////////////////
                //obtener nombre del programa
                XmlNodeList NombreProgramaXml = LayoutNodeList[0].SelectNodes(nombrePrograma);

                foreach(XmlNode Node in NombreProgramaXml)
                {
                    nombrePrograma = Node.ChildNodes[0].InnerText;
                }

                GenexusObject.NombrePrograma = DescriptionNode.FirstChild.LocalName.Substring(0, 1).ToUpper() + nombrePrograma;

                XmlNodeList CodeNodeList = LayoutNodeList[0].SelectNodes(FiltroCode);
                GenexusObject.Codigo = "";
                foreach (XmlElement item in CodeNodeList)
                {
                    if (CodeNodeList.Count > 0)
                    {
                        GenexusObject.Codigo += item.InnerText;
                    }
                }

                ////////////////////////////////////////////////////////////////////////////
                //pasó
                ////////////////////////////////////////////////////////////////////////////
                //documentacion
                validator = -4;
                XmlNodeList DocumentationNodeList = LayoutNodeList[0].SelectNodes(FiltroDocumentation);
                GenexusObject.Documentation = "";
                foreach(XmlElement item in DocumentationNodeList)
                {
                    if (DocumentationNodeList.Count > 0)
                    {
                        GenexusObject.Documentation += item.InnerText;
                    }
                }

                ////////////////////////////////////////////////////////////////////////////
                validator = -5;
                XmlNodeList PrintBlockNodeList = LayoutNodeList[0].SelectNodes(filtroPrint);
                GenexusObject.PrintBlock = "";
                foreach (XmlElement Item in PrintBlockNodeList)
                {
                    if (PrintBlockNodeList.Count > 0)
                    {
                        GenexusObject.PrintBlock += Item.InnerText + "-";
                    }
                }

                ////////////////////////////////////////////////////////////////////////////
                validator = -3;
                XmlNodeList RulesNodeList = LayoutNodeList[0].SelectNodes(FiltroRules);
                GenexusObject.Parametros = this.getParam(RulesNodeList[0].InnerText);

                return GenexusObject;

            }
            catch (Exception)
            {
                if (validator == -1)
                {
                    GenexusObject.TipoError = "ErrorVariables";
                }
                else if (validator == -2)
                {
                    GenexusObject.TipoError = "ErrorCodigo";
                }
                else if (validator == -3)
                {
                    GenexusObject.TipoError = "ErrorReglas";
                }
                else if (validator == -4)
                {
                    GenexusObject.TipoError = "ErrorDocumentacion";
                }
                else
                {
                    GenexusObject.TipoError = "Error en Print";
                }

                return GenexusObject;
            }

        }

        private string getParam(string Rules)
        {
            string parameters = "";
            Boolean flag = false;
            //StreamReader CodeText = new StreamReader(Rules, System.Text.Encoding.UTF8);

            //while (true)
            //{
                //string Line = CodeText.ReadLine().Trim();
            string Line = Rules;
                if (flag == false)
                {
                    for (int x = 0; x < Line.Length; x++)
                    {
                        string actualWord = Line.Substring(0, x);
                        if (actualWord.Trim().ToUpper() == "PARM(")
                        {
                            parameters = Line.Substring(x, Line.Length - x).Trim();
                            flag = true;
                        }
                    }
                }
                else
                {
                    parameters = parameters + Line.Trim();
                }

                if (Line.Contains(");"))
                {
                    parameters = parameters.Substring(0, parameters.Length - 2).Trim();
                    parameters = parameters.Substring(0, parameters.Length - 2).Trim();
                }
            //}
            string newParameters = "";
            string UnCaracter;

            for (int x = 0; x < parameters.Length; x++)
            {
                UnCaracter = parameters.Substring(x, 1);
                if (UnCaracter != " ")
                {
                    newParameters = newParameters + UnCaracter;
                }
            }

            return newParameters.Replace(",", "-");
        }

        private string[] getVariablesSinParm(string Parameters, string Variables)
        {
            //char DeliGuion = '-';
            string[] ParametersArray;
            if (Parameters != null)
            {
                ParametersArray = Parameters.Split('-');
            }
            else
            {
                ParametersArray = new string[] { "" };
            }
            string[] VariablesArray = Variables.Split('-');
            Variables = "";
            //COMPROBAR ESTAR PARTE!!
            string[] Variables2 = null;

            for (int x = 0; x < VariablesArray.Length; x++)
            {
                Boolean validator = true;
                if (ParametersArray.Length > 1)
                {
                    for (int y = 0; y < ParametersArray.Length; y++)
                    {
                      string parmAux = ParametersArray[y].ToString().Trim();
                      if (parmAux != "")
                      {
                          string parm = ParametersArray[y].Remove(0, 1).ToUpper();
                          if (VariablesArray[x].ToUpper() == parm)
                          {
                              validator = false;
                          }
                      }
                    }
                }
                if (validator == true)
                {
                    Variables = Variables + "&" + VariablesArray[x] + "-";
                }
            }

            Variables2 = Variables.Substring(0, Variables.Length).Split('-');            
            return Variables2; //Variables.Substring(0, Variables.Length).Split(DeliGuion).ToString();
        }

       // private void VerificaVariables(string Code, string[] Variables, string Tipo, string Nombre, string retorno)
        private string VerificaVariables(string Code, string[] Variables, string Tipo, string Nombre)
        {
            string retorno = "";
            CoincidenciaBE VariablesSinUso;
            Code = Code.ToLower();
            string Used = "";

            for (int x = 0; x < Variables.Length; x++)
            {
                VariablesSinUso = new CoincidenciaBE();
                VariablesSinUso.Flag = "DataRowInutilizada";
                VariablesSinUso.NombreObj = Nombre;
                VariablesSinUso.Linea = Variables[x];
                VariablesSinUso.RutaImg = "\\Flag_None.png";  //aqui puse C:\\STAGING
                //VariablesSinUso.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                VariablesSinUso.ImgFlag = Properties.Resources.Flag_None;
                if (!Code.Contains(Variables[x].ToLower().Trim()))
                {
                    string item = Variables[x];
                    string item2 = item.ToLower();

                    if (item2.ToString() == "&today")
                    {
                        Used = Used + Variables[x] + "-";
                    }
                    else if (item2.ToString() == "&pgmname")
                    {
                        Used = Used + Variables[x] + "-";
                    }
                    else if (item2.ToString() == "&pgmdesc")
                    {
                        Used = Used + Variables[x] + "-";
                    }
                    else if (item2.ToString() == "&time")
                    {
                        Used = Used + Variables[x] + "-";
                    }
                    else if (item2.ToString() == "&page")
                    {
                        Used = Used + Variables[x] + "-";
                    }
                    else if (item2.ToString() == "&line")
                    {
                        Used = Used + Variables[x] + "-";
                    }
                    else if (item2.ToString() == "&output")
                    {
                        Used = Used + Variables[x] + "-";
                    }
                    else
                    {
                        lstVariablesInutilizadas.Add(VariablesSinUso);
                    }
                }
                else
                {
                    Used = Used + Variables[x] + "-";
                    retorno = Used;                    
                }
            }
            char DeliGuion = '-';            
            if (Used.Length > 1)
            {               
                string[] UsedArray = Used.Substring(0,Used.Length).Split(DeliGuion);
                for (int x = 0; x < UsedArray.Length;x++ )
                {
                    VariablesSinUso = new CoincidenciaBE();
                    VariablesSinUso.Flag = "DataRowInutilizada";
                    VariablesSinUso.NombreObj = Nombre;
                    VariablesSinUso.Linea = UsedArray[x];
                    VariablesSinUso.RutaImg = "\\Flag_None.png";
                    VariablesSinUso.ImgFlag = Properties.Resources.Flag_None;
                    //VariablesSinUso.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                    string variable = UsedArray[x].ToString().ToLower();
                    int noComment = 0;
                    int comment = 0;

                    //StreamReader CodeText = new StreamReader(Code);
                    StringReader CodeText = new StringReader(Code);
                    while (true)
                    {
                        string Line = CodeText.ReadLine();
                        if (Line == null)
                        {
                            break;
                        }
                        Line = Line.Trim();

                        if (Line.Contains(variable))
                        {
                            if (Line.StartsWith("//"))
                            {
                                comment = comment + 1;
                            }
                            else
                            {
                                noComment = noComment + 1;
                            }
                        }
                    }
                    if (comment > 0 && noComment == 0)
                    {
                        lstVariablesInutilizadas.Add(VariablesSinUso);
                    }
                }
            }
            return retorno;
        }


        private void ibtAgregar_Click(object sender, EventArgs e)
        {
            string palabra = txtPalabra.Text.Trim();
            if(palabra == "")
            {
                MessageBox.Show("Ingrese Palabra a Agregar.", "Error");
            }
            else
            {
                if(lstBoxPalabras.Items.Count < 10)
                {
                    txtPalabra.Text = "";
                    lstBoxPalabras.Items.Add(palabra);
                    ibtQuitar.Visible = true;
                    PictureBox9.Visible = true;
                    if(lstBoxPalabras.Items.Count == 10)
                    {
                        ibtAgregar.Visible = false;
                    }
                }
            }
        }


        private void PictureBox9_Click_1(object sender, EventArgs e)
        {
            lstBoxPalabras.Items.Remove(lstBoxPalabras.SelectedItem);
            if (lstBoxPalabras.Items.Count == 0)
            {
                ibtAgregar.Visible = true;
                ibtQuitar.Visible = false;
                PictureBox9.Visible = false;
            }
        }

        private void ibtLimpiar_Click(object sender, EventArgs e)
        {
            ClearGrids();
            ClearAuxLists();
            ClearGlobalVariables();

            pnlReporte.Visible = false;
            ibtExportPDF.Visible = false;
            lblNombreUsuarioSQL.Text = "";
        }


        private void CargarFechaEjecución()
        {
            lblFecha.Text = DateTime.Now.Day + "/" + DateTime.Now.Month + "/" + DateTime.Now.Year + " " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second;
        }

        private void cargaListBox()
        {
            string sel = "SELECT descripcion FROM TB_RESTRINGIDAS";
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                da = new SqlDataAdapter(sel, cnn);
                da.Fill(dt);
                foreach (DataRow valor in dt.Rows)
                {
                    lblRestricciones.Items.Add(valor["descripcion"].ToString());
                }
            }
            catch(Exception)
            {

            }
        }

        public class EntidadCoincidencia
        {
            private string nombreField;
            public string Nombre
            {
                get
                {
                    return nombreField;
                }
                set
                {
                    nombreField = value;
                }
            }

            private int ContadorField;
            public int Contador
            {
                get
                {
                    return ContadorField;
                }
                set
                {
                    ContadorField = value;
                }
            }

            private string contador1Field;
            public string ContadorAux
            {
                get
                {
                    return contador1Field;
                }
                set
                {
                    contador1Field = value;
                }
            }

            private int linea1Field;
            public int LineaAux
            {
                get
                {
                    return linea1Field;
                }
                set
                {
                    linea1Field = value;
                }
            }  
        }

        private void ibtBuscarPorCarpeta_Click(object sender, EventArgs e)
        {
            //COMPROBAR ESTAR PARTE!!
            //lblNombreUsuarioSQL.Text = Conexion.

            if (chkMultiple.Checked)
            {
                if (lstBoxPalabras.Items.Count <= 0)
                {
                    MessageBox.Show("Ingrese Palabra a Buscar.", "Error");
                }
            }

            ClearAuxLists();
            AsignarPalabras();

            //Limpiamos variables globales
            ClearGlobalVariables();

            //Declaración de variables
            string SelectedPath = "";
            string[] XmlFiles;
            string nombreArchivo = "";

            //Variables para el StringReader
            string Codigo = "";
            string auxnombre = "";

            FolderBrowserDialog browFol = new FolderBrowserDialog();
            browFol.Description = "Seleccione carpeta...";
            browFol.ShowNewFolderButton = false;

            if (browFol.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                SelectedPath = browFol.SelectedPath;
                XmlFiles = Directory.GetFiles(SelectedPath, "*.*");
                //try
                //{
                    if (XmlFiles.Length > 0)
                    {
                        int i = 0;
                        foreach (string archivo in XmlFiles)
                        {
                            if (archivo.Substring(archivo.Length - 3, 3) == "xpz" || archivo.Substring(archivo.Length - 3, 3) == "xml")
                            {
                                i = i + 1;
                            }
                        }
                        if (i > 0)
                        {
                            RutaFinal = getNewFilePath(Path.GetFileName(SelectedPath), SelectedPath);

                            foreach (string archivo in XmlFiles)
                            {
                                Codigo = "";
                                ClearGlobalVariables();
                                if (archivo.Substring(archivo.Length - 3, 3).ToUpper().Equals("XPZ"))
                                {
                                    //Reinicializamos valores por cada documento evaluado
                                    nombreArchivo = Path.GetFileNameWithoutExtension(archivo);
                                    int index = archivo.IndexOf('.');
                                    string auxfile = archivo.Substring(0, index);
                                    string sFileName2 = auxfile + ".zip";
                                    nombreArchivo = Path.GetFileNameWithoutExtension(archivo);
                                    auxnombre = nombreArchivo;
                                    //File.Copy(archivo, nombreArchivo + ".zip");
                                    File.Move(archivo, sFileName2);
                                    int direccion = archivo.LastIndexOf(nombreArchivo);
                                    string ruta = archivo.Substring(0, direccion);
                                    Extraer(sFileName2, ruta);
                                    sFileName2 = ruta + nombreArchivo + "_1.xml";
                                    RutaFinal = getNewFilePath(nombreArchivo, sFileName2);
                                    GenexusObject = getObjectCode(sFileName2);
                                    //Restaurar Extensiones xpz a archivos
                                    //File.Copy(auxfile + ".zip", nombreArchivo + ".xpz");
                                    File.Move(ruta + nombreArchivo + ".zip", archivo);
                                    File.Delete(sFileName2);
                                }
                                else
                                {
                                    GenexusObject = getObjectCode(archivo);
                                }
                                nombreArchivo = GenexusObject.NombrePrograma;
                                string ErrorString = GenexusObject.TipoError;

                                if (ErrorString == "ErrorCodigo")
                                {
                                    MessageBox.Show("No se pudo hallar el código en el archivo \"\"" + auxnombre + ".xpz\"\".", "Error");
                                }
                                else if (ErrorString == "ErrorReglas")
                                {
                                    string msj = "errors";
                                }
                                else if (ErrorString == "ErrorVariables")
                                {
                                    MessageBox.Show("No se pudo hallar las variables en el archivo \"\"" + auxnombre + ".xpz\"\".", "Error");
                                    continue;
                                }

                                string Parametros = GenexusObject.Parametros;
                                string Variables = GenexusObject.Variables;
                                string CodDoc = GenexusObject.Documentation;
                                Codigo = GenexusObject.Codigo;
                                string CodPrint = GenexusObject.PrintBlock;
                                //Obtenemos las Variables sin contar las Variables usadas como Parámetros del Objeto GeneXus
                                string[] VariablesSinParm = getVariablesSinParm(Parametros, Variables);
                                //Evaluamos si las variables son inutilizadas
                                string used = "";
                                //VerificaVariables(Codigo, VariablesSinParm, GenexusObject.TipoObjeto, GenexusObject.Nombre, used);
                                used = VerificaVariables(Codigo, VariablesSinParm, GenexusObject.TipoObjeto, GenexusObject.Nombre);
                                List<EntidadCoincidencia> listadoPrint = new List<EntidadCoincidencia>();

                                //Leemos bloque printblock
                                StringReader codigoPrint = new StringReader(CodPrint);
                                StringReader codigoSource = new StringReader(Codigo);
                                string LineaPrint = codigoPrint.ReadLine();
                                int lineasint;
                                listadoPrint = separoPrints(LineaPrint);

                                List<EntidadCoincidencia> listadoUsadas = new List<EntidadCoincidencia>();
                                VerificarListas(used, listadoPrint, listadoUsadas);
                                List<EntidadCoincidencia> listaAuxiliar = new List<EntidadCoincidencia>();
                                foreach (EntidadCoincidencia item in listadoUsadas)
                                {
                                    if (item.Contador == 0)
                                    {
                                        listaAuxiliar.Add(item);
                                    }
                                }

                                //Leemos Documentacion con StringReader
                                //StreamReader CodigoAux = new StreamReader(CodDoc);
                                StringReader CodigoAux = new StringReader(CodDoc);
                                while (true)
                                {
                                    Line = CodigoAux.ReadLine();
                                    if (Line != null)
                                    {
                                        //almaceno la linea original
                                        OriginalLine = CodDoc;
                                        if (!Line.StartsWith("//"))
                                        {
                                            Line = OriginalLine;
                                            //Evaluamos la seccion Documentation
                                            List<string> listado = new List<string>();
                                            listado = VerificarSISTEMA(Line);
                                            if (listado.Count > 0)
                                            {
                                                foreach (string item in listado)
                                                {
                                                    result = new CoincidenciaBE();
                                                    result.Flag = "DataRowDocumentationException";
                                                    result.NombreObj = GenexusObject.Nombre;
                                                    result.NroLinea = contadorLineas.ToString();
                                                    result.Linea = item.ToString();
                                                    result.RutaImg = "\\Flag_None.png";
                                                    result.ImgFlag = Properties.Resources.Flag_None;
                                                   // result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                                    lstDocumentation.Add(result);
                                                }
                                            }
                                        }
                                    }
                                    break;
                                }

                                //Utilizamos un StringReader para la lectura del código
                                StringReader CodeText = new StringReader(Codigo);
                                //Leemos el código línea por línea
                                while (true)
                                {
                                    Line = CodeText.ReadLine();
                                    if (Line != null)
                                    {
                                        OriginalLine = Line.Trim();
                                        if (!chkMayusMinus.Checked)
                                        {
                                            Line = Line.ToUpper();
                                        }
                                        contadorLineas = contadorLineas + 1;
                                        //Evaluamos si se realiza asignaciones estáticas
                                        if (Line.Contains("=") && !Line.Trim().StartsWith("//"))
                                        {
                                            if (VerificaAsignacionEstatica(Line.Trim()))
                                            {
                                                CoincidenciaBE Estatica = new CoincidenciaBE();
                                                Estatica.Flag = "DataRowEstatico";
                                                Estatica.NombreObj = GenexusObject.Nombre;
                                                Estatica.NroLinea = contadorLineas.ToString();
                                                Estatica.Linea = OriginalLine;
                                                Estatica.RutaImg = "\\Flag_None.png";
                                                Estatica.ImgFlag = Properties.Resources.Flag_None;
                                                //Estatica.ImgFlag = Image.FromFile(Estatica.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                                lstAsignacionEstatica.Add(Estatica);
                                            }
                                        }

                                        //Evaluamos si contiene palabras Restringidas
                                        string pResultado = "";
                                        List<string> listado1 = new List<string>();

                                        pResultado =  Restricciones.ValidaRestricciones(lblRestricciones, Line);
                                        if (pResultado != "")
                                        {
                                            result = new CoincidenciaBE();
                                            result.Flag = "DataRowRestringidasException";
                                            result.NombreObj = GenexusObject.Nombre;
                                            result.NroLinea = contadorLineas.ToString();
                                            result.Linea = pResultado;
                                            result.RutaImg = "\\Flag_None.png";
                                            result.ImgFlag = Properties.Resources.Flag_None;
                                            //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                            lstPalabrasRestringidas.Add(result);
                                        }
                                        //Verificamos formatos constantes
                                        string pResultado1 = "";
                                        //Restricciones.ValidaFormatoConstante(Line, pResultado1);
                                        pResultado1 = Restricciones.ValidaFormatoConstante(Line);
                                        if (pResultado1 != "")
                                        {
                                            result = new CoincidenciaBE();
                                            result.Flag = "DataRowFormatosConstantes";
                                            result.NombreObj = GenexusObject.Nombre;
                                            result.NroLinea = contadorLineas.ToString();
                                            result.Linea = pResultado1;
                                            result.RutaImg = "\\Flag_None.png";
                                            lstFormatosConstantes.Add(result);
                                        }

                                        //Evaluamos si contiene valores estaticos en los CALLS
                                        List<string> arregloCALL = new List<string>();
                                        string valor = "";
                                        arregloCALL = VerificaCALL(Line, Codigo);
                                        if (arregloCALL.Count > 0)
                                        {
                                            foreach (string a in arregloCALL)
                                            {
                                                valor = a;
                                                result = new CoincidenciaBE();
                                                result.Flag = "DataRowCALLException";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.NroLinea = contadorLineas.ToString();
                                                result.Linea = valor;
                                                result.RutaImg = "\\Flag_None.png";
                                                result.ImgFlag = Properties.Resources.Flag_None;
                                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                                lstCallStaticos.Add(result);
                                            }
                                        }

                                        //Evaluamos si contiene un where 
                                        List<string> arregloWhere = new List<string>();
                                        arregloWhere = VerificaWhere(Line, Codigo);
                                        if (arregloWhere.Count > 0)
                                        {
                                            result = new CoincidenciaBE();
                                            result.Flag = "DataRowWhereException";
                                            result.NombreObj = GenexusObject.Nombre;
                                            result.NroLinea = contadorLineas.ToString();
                                            result.Linea = OriginalLine;
                                            result.RutaImg = "\\Flag_None.png";
                                            lstWheresMalImplementados.Add(result);
                                        }

                                        //Evaluamos si contiene un loop For
                                        if (VerificaFor(Line, Codigo))
                                        {
                                            //Evaluamis si el loop For contiene Defined By
                                            if (!VerificaDefinedBy(contadorLineas.ToString(), Codigo))
                                            {
                                                result = new CoincidenciaBE();
                                                result.Flag = "DataRowDefinedBy";
                                                result.Linea = "Loop For Each sin Definición de Defined By";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.NroLinea = contadorLineas.ToString();
                                                lstSinDefinedBy.Add(result);
                                            }
                                        }
                                        //Verificamos Coincidencias de la Primera Palabra
                                        if (palabra1 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra1, Line);
                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra1";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra1;
                                                result.Linea = OriginalLine;
                                                result.ImgFlag = Properties.Resources.Flag_None;
                                                //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                                lstCoincidencia1.Add(result);
                                            }
                                        }
                                        //Verificamos Coincidencias de la Segunda Palabra
                                        if (palabra2 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra2, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra2";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra2;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia2.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Tercera Palabra
                                        if (palabra3 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra3, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra3";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra3;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia3.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Cuarta Palabra
                                        if (palabra4 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra4, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra4";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra4;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia4.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Quinta Palabra
                                        if (palabra5 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra5, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra5";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra5;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia5.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Sexta Palabra
                                        if (palabra6 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra6, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra6";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra6;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia6.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Septima Palabra
                                        if (palabra7 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra7, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra7";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra7;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia7.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Octava Palabra
                                        if (palabra8 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra8, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra8";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra8;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia8.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Novena Palabra
                                        if (palabra9 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra9, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra9";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra9;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia9.Add(result);
                                            }
                                        }

                                        //Verificamos Coincidencias de la Decima Palabra
                                        if (palabra10 != "")
                                        {
                                            result = VerificaCoincidencia(contadorLineas.ToString(), palabra10, Line);

                                            if (result != null)
                                            {
                                                result.Flag = "DataRowPalabra10";
                                                result.NombreObj = GenexusObject.Nombre;
                                                result.Palabra = palabra10;
                                                result.Linea = OriginalLine;
                                                lstCoincidencia10.Add(result);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }

                                    foreach (EntidadCoincidencia Item in listaAuxiliar)
                                    {
                                        if (Item.Contador == 0)
                                        {
                                            if (Line.ToLower().Contains(Item.Nombre.ToLower()))
                                            {
                                                Item.ContadorAux = Item.ContadorAux + 1;
                                                Item.LineaAux = contadorLineas;
                                            }
                                        }
                                    }
                                }
                                foreach (EntidadCoincidencia item in listaAuxiliar)
                                {
                                    if (item.ContadorAux == "1")
                                    {
                                        result = new CoincidenciaBE();
                                        result.Flag = "DataRowListadoUsadasException";
                                        result.NombreObj = GenexusObject.Nombre;
                                        result.NroLinea = item.LineaAux.ToString();
                                        result.Linea = item.Nombre;
                                        result.RutaImg = "\\Flag_None.png";
                                        result.ImgFlag = Properties.Resources.Flag_None;
                                        //result.ImgFlag = Image.FromFile(result.RutaImagenes + "\\Flag_None.png"); //aqui puse \\
                                        lstUsadas.Add(result);
                                    }
                                }
                                OrdernalstCoincidenciaAux();
                            }
                            ShowReport();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo encontrar archivos con la extensión \"\"xpz\"\" en la carpeta seleccionada.", "Error.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se pudo encontrar archivos con la extensión \"\"xpz\"\" en la carpeta seleccionada.", "Error.");
                    }
                //}
                //catch (Exception)
                //{
                //    MessageBox.Show("Error al momento de validar", "Error.");
                //}
            }
            CargarFechaEjecución();
        }

        private void ibtExportPDF_Click(object sender, EventArgs e)
        {
            CoincidenciaDataSet.dtGeneralDataTable dtGeneral = new CoincidenciaDataSet.dtGeneralDataTable();
            CoincidenciaDataSet.dtDetalleDataTable dtDetalle = new CoincidenciaDataSet.dtDetalleDataTable();

            string exePath = Path.GetDirectoryName(Application.ExecutablePath);
            //string ruta = "C:\\STAGING";

            foreach (DataGridViewRow row in gvResumen.Rows)
            {
                dtGeneral.Rows.Add(row.Cells[0].Value, exePath + row.Cells[2].Value, exePath + row.Cells[13].Value, exePath + row.Cells[15].Value, exePath + row.Cells[17].Value, exePath + row.Cells[19].Value, exePath + row.Cells[21].Value, exePath + row.Cells[23].Value, exePath + row.Cells[25].Value, exePath + row.Cells[27].Value, exePath + row.Cells[29].Value, exePath + row.Cells[31].Value);
            }

            foreach (DataGridViewRow row in gvCoincidencias.Rows)
            {
                //dtDetalle.Rows.Add(exePath + row.Cells[9].Value, row.Cells[5].Value, row.Cells[4].Value, row.Cells[7].Value);                
                //dtDetalle.Rows.Add(ruta + row.Cells[8].Value, row.Cells[5].Value, row.Cells[4].Value, row.Cells[7].Value);
                dtDetalle.Rows.Add(exePath + row.Cells[8].Value, row.Cells[5].Value, row.Cells[4].Value, row.Cells[7].Value);
            }

            ReportDataSource dtGeneralReport = new ReportDataSource("CoincidenciaDataSet_dtGeneral", dtGeneral);
            ReportDataSource dtDetalleReport = new ReportDataSource("CoincidenciaDataSet_dtDetalle", dtDetalle);
            
            rptDurezas2 rpt2 = new rptDurezas2();
            rpt2.Show();

            string logoPath = exePath + "\\Logo.png";
            string ResultadoPath = "";

            if (noResult == 0)
            {
                ResultadoPath = exePath + "\\Flag_Good.png";
            }
            else
            {
                if (noResult == 1)
                {
                    ResultadoPath = exePath + "\\Flag_Warning.png";
                }
                else
                {
                    if (noResult == 2)
                    {
                        ResultadoPath = exePath + "\\Flag_Bad.png";
                    }
                }

            }

            ReportParameter[] Parametro = new ReportParameter[5];
            Parametro[0] = new ReportParameter("lblFecha",DateTime.Now.ToString("dd/MM/yyyy hh:mm"));
            Parametro[1] = new ReportParameter("lblMsgCoin", "wasa");
            Parametro[2] = new ReportParameter("logoPath", logoPath);
            Parametro[3] = new ReportParameter("lblUsuario", lblUsuarioTexto.Text);
            Parametro[4] = new ReportParameter("ResultPath", ResultadoPath);

            Directory.SetCurrentDirectory(exePath);
            rpt2.rptDurezas.LocalReport.EnableExternalImages = true;
            rpt2.rptDurezas.LocalReport.ReportPath = "rptGeneral.rdlc";
            rpt2.rptDurezas.LocalReport.SetParameters(Parametro);

            rpt2.rptDurezas.LocalReport.DataSources.Clear();
            rpt2.rptDurezas.LocalReport.DataSources.Add(dtGeneralReport);
            rpt2.rptDurezas.LocalReport.DataSources.Add(dtDetalleReport);

            rpt2.rptDurezas.RefreshReport();
        }

        private void GenerateResume()
        {
            CoincidenciaBE ruta = new CoincidenciaBE();
            noResult = 0;
            gvResumen.Rows.Clear();
            Boolean FlagAdd = false;
            string Objeto = "";
            //Image Palabra1 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
            Image Palabra1 = Properties.Resources.Flag_Good;
            string rutaPalabra1 = "\\Flag_Good.png";
            Image Palabra2 = Properties.Resources.Flag_Good;
            Image Palabra3 = Properties.Resources.Flag_Good;
            Image Palabra4 = Properties.Resources.Flag_Good;
            Image Palabra5 = Properties.Resources.Flag_Good;
            Image Palabra6 = Properties.Resources.Flag_Good;
            Image Palabra7 = Properties.Resources.Flag_Good;
            Image Palabra8 = Properties.Resources.Flag_Good;
            Image Palabra9 = Properties.Resources.Flag_Good;
            Image Palabra10 = Properties.Resources.Flag_Good;

            //Image Palabra2 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra3 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra4 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra5 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra6 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra7 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra8 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra9 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
            //Image Palabra10 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");

            for (int x = 0; x < gvCoincidencias.Rows.Count; x++)
            {
                //Image Estatico = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                Image Estatico = Properties.Resources.Flag_Good;
                string rutaEstatico = "\\Flag_Good.png";
                //Image Inutilizado = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image Inutilizado = Properties.Resources.Flag_Good;
                string rutaInutilizado = "\\Flag_Good.png";
                //Image DefinedBy = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image DefinedBy = Properties.Resources.Flag_Good;
                string rutaDefinedBy = "\\Flag_Good.png";
                //Image ResultadoFinal = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image ResultadoFinal = Properties.Resources.Flag_Good;
                string rutaResultadoFinal = "\\Flag_Good.png";
                //Image Where = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image Where = Properties.Resources.Flag_Good;
                string rutaWhere = "\\Flag_Good.png";
                //Image varCall = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image varCall = Properties.Resources.Flag_Good;
                string rutaLlamado = "\\Flag_Good.png";
                //Image Documentacion = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image Documentacion = Properties.Resources.Flag_Good;
                string rutaDocumentacion = "\\Flag_Good.png";
                //Image palabrasRestringidas = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image palabrasRestringidas = Properties.Resources.Flag_Good;
                string rutapalabrasRestringidas = "\\Flag_Good.png";
                //Image formatosConstantes = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image formatosConstantes = Properties.Resources.Flag_Good;
                string rutaformatosConstantes = "\\Flag_Good.png";
                //Image noUsadas = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png");
                Image noUsadas = Properties.Resources.Flag_Good;

                string rutaUsadas = "\\Flag_Good.png";
                FlagAdd = false;
                List<int> listaResultado = new List<int>();
                int FlagResultado = 0; //0 = verde ; 1 = amarillo ; 2 = rojo
                DataGridViewRow gvRow = gvCoincidencias.Rows[x];
                string type = gvRow.Cells["Flag"].Value.ToString();

                if(type == "HeaderRowTittleObject")
                {
                    FlagAdd = true;
                    Objeto = gvRow.Cells["Linea"].Value.ToString();

                    for(int y = x+ 1; y< gvCoincidencias.Rows.Count;y++)
                    {
                        string type2 = gvCoincidencias.Rows[y].Cells["Flag"].Value.ToString();

                        if(type2 == "HeaderRowTittleObject")
                        {
                            break;
                        }
                        if(type2 == "DataRowPalabra1")
                        {
                            //Palabra1 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                            Palabra1 = Properties.Resources.Flag_Warning;
                            rutaPalabra1 = "\\Flag_Warning.png";
                            FlagResultado = 1;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra2")
                        {
                            //Palabra2 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra2 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra3")
                        {
                            //Palabra3 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra3 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra4")
                        {
                            //Palabra4 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra4 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra5")
                        {
                            //Palabra5 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra5 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra6")
                        {
                            //Palabra6 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra6 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra7")
                        {
                            //Palabra7 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra7 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra8")
                        {
                            //Palabra8 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra8 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra9")
                        {
                            //Palabra9 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png");//aqui puse \\
                            Palabra9 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowPalabra10")
                        {
                            //Palabra10 = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Palabra10 = Properties.Resources.Flag_Bad;
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if (type2 == "DataRowEstatico")
                        {
                            //Estatico = Image.FromFile(ruta.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                            Estatico = Properties.Resources.Flag_Warning;
                            rutaEstatico = "\\Flag_Warning.png";
                            FlagResultado = 1;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowInutilizada")
                        {
                            //Inutilizado = Image.FromFile(ruta.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                            Inutilizado = Properties.Resources.Flag_Warning;
                            rutaInutilizado = "\\Flag_Warning.png";
                            FlagResultado = 1;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowDefinedBy")
                        {
                            //DefinedBy = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            DefinedBy = Properties.Resources.Flag_Bad;
                            rutaDefinedBy = "\\Flag_Bad.png";
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowWhereException")
                        {
                            //Where = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Where = Properties.Resources.Flag_Bad;
                            rutaWhere = "\\Flag_Bad.png";
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowDocumentationException")
                        {
                            //Documentacion = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            Documentacion = Properties.Resources.Flag_Bad;
                            rutaDocumentacion = "\\Flag_Bad.png";
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowCALLException")
                        {
                            //varCall = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                            varCall = Properties.Resources.Flag_Bad;
                            rutaLlamado = "\\Flag_Bad.png";
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowRestringidasException")
                        {
                            //palabrasRestringidas = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png");
                            palabrasRestringidas = Properties.Resources.Flag_Bad;
                            rutapalabrasRestringidas = "\\Flag_Bad.png";
                            FlagResultado = 2;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowFormatosConstantes")
                        {
                            //formatosConstantes = Image.FromFile(ruta.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                            formatosConstantes = Properties.Resources.Flag_Warning;
                            rutaformatosConstantes = "\\Flag_Warning.png";
                            FlagResultado = 1;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                        if(type2 == "DataRowListadoUsadasException")
                        {
                            //noUsadas = Image.FromFile(ruta.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                            noUsadas = Properties.Resources.Flag_Warning;
                            rutaUsadas = "\\Flag_Warning.png";
                            FlagResultado = 1;
                            listaResultado.Add(FlagResultado);
                            continue;
                        }
                    }
                }
                if(FlagAdd)
                {
                    int item = 0;
                    foreach(int Item1 in listaResultado)
                    {
                        if(Item1 == 2)
                        {
                            item = 2;
                            break;
                        }
                        if(Item1 == 1)
                        {
                            item = 1;
                            //break;
                        }
                        if(Item1 == 0 && item < 1)
                        {
                            item = 0;
                        }
                    }

                    if(item == 0)
                    {
                        //ResultadoFinal = Image.FromFile(ruta.RutaImagenes + "\\Flag_Good.png"); //aqui puse \\
                        ResultadoFinal = Properties.Resources.Flag_Good;
                        rutaResultadoFinal = "\\Flag_Good.png";                            
                    }
                    if(item == 1)
                    {
                        //ResultadoFinal = Image.FromFile(ruta.RutaImagenes + "\\Flag_Warning.png"); //aqui puse \\
                        ResultadoFinal = Properties.Resources.Flag_Warning;
                        rutaResultadoFinal = "\\Flag_Warning.png";
                        if(noResult < 1)
                        {
                            noResult = 1;
                        }
                    }
                    if(item == 2)
                    {
                        //ResultadoFinal = Image.FromFile(ruta.RutaImagenes + "\\Flag_Bad.png"); //aqui puse \\
                        ResultadoFinal = Properties.Resources.Flag_Bad;
                        rutaResultadoFinal = "\\Flag_Bad.png";
                        noResult = 2;
                    }

                    gvResumen.Rows.Add(new DataGridView());
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Objeto"].Value = Objeto;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda1"].Value = Palabra1;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["RutaPalabra1"].Value = rutaPalabra1;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda2"].Value = Palabra2;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda3"].Value = Palabra3;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda4"].Value = Palabra4;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda5"].Value = Palabra5;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda6"].Value = Palabra6;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda7"].Value = Palabra7;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda8"].Value = Palabra8;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda9"].Value = Palabra9;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Busqueda10"].Value = Palabra9;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Estatico"].Value = Estatico;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["RutaEstatico"].Value = rutaEstatico;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["formatosConstantes"].Value = formatosConstantes;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["rutaFormatos"].Value = rutaformatosConstantes;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["noUsadas"].Value = noUsadas;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["rutaUsadas"].Value = rutaUsadas;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Inutilizado"].Value = Inutilizado;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["RutaInutilizado"].Value = rutaInutilizado;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["DefinedBy"].Value = DefinedBy;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["RutaDefinedBy"].Value = rutaDefinedBy;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Where"].Value = Where;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["RutaWhere"].Value = rutaWhere;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["Documentacion"].Value = Documentacion;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["RutaDocumentacion"].Value = rutaDocumentacion;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["llamada"].Value = varCall;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["rutaCall"].Value = rutaLlamado;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["restringidas"].Value = palabrasRestringidas;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["rutaRestringidas"].Value = rutapalabrasRestringidas;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["ResultadoFinal"].Value = ResultadoFinal;
                    gvResumen.Rows[gvResumen.Rows.Count - 1].Cells["RutaResultadoFinal"].Value = rutaResultadoFinal;
                }
            }
            //MM
            if (noResult == 0)
            {
                good.Visible = true;
                bad.Visible = false;
                warning.Visible = false;
            }
            else 
            {
                if (noResult == 1)
                {
                    good.Visible = false;
                    bad.Visible = false;
                    warning.Visible = true;
                }
                else
                {
                    if (noResult == 2)
                    {
                        good.Visible = false;
                        bad.Visible = true;
                        warning.Visible = false;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
       
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            form.FormLoginGeneral fgeneral = new form.FormLoginGeneral();
            this.Hide();
            fgeneral.ShowDialog();
            this.Close();
        }


    }
}
