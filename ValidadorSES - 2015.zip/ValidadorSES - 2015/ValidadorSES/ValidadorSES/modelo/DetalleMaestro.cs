﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    class DetalleMaestro
    {
        public int codigo { get; set; }
        public Maestro codigo_maestro { get; set; }
        public string nombre { get; set; }
        public string valor_key { get; set; }
    }
}
