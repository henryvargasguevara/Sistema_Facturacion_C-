﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    class Requerimiento
    {
        public string codigo {get;set;}
        public int cliente {get;set;}
        public string num_pase {get;set;}
        public string descripcion {get;set;}
        public DateTime fecha_inicio {get;set;}
        public DateTime fecha_fin {get;set;}
        public string estado {get;set;}
        public int usuario_creador {get;set;}
        public DateTime fecha_creacion {get;set;}
        public int usuario_modificador {get;set;}
        public DateTime fecha_modificacion { get; set; }
        public int liderResponsable { get; set; }
        public string prioridad { get; set; }
        public string tipoValidacion { get; set; }
        public string tipoCargaJob { get; set; }
    }
}
