﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStageTerminatorActivity
    {
        public bool finalMessage { get; set; }
        public bool logText { get; set; }
        public bool fullDescription { get; set; }
        public string descFinalMessage { get; set; }
        public string descLogText { get; set; }
        public string descFullDescription { get; set; }        
        public string InputPins { get; set; }
        public string NombreJobActivity { get; set; }
    }
}
