﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStageJobActivity
    {
        public string jobName { get; set; }        
        public string executionType { get; set; }
        public List<LogObjetoParam> listaParametroJobActivity { get; set; }
    }
}
