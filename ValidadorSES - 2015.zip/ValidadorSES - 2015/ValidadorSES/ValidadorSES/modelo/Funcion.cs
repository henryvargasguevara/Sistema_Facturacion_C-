﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class Funcion
    {
        public string nombre { get; set; }
        public string argumento { get; set; }

        public Funcion() 
        {
            nombre = "";
            argumento = "";
        }
    }
}
