﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    class AsignarRequerimientoView
    {
        public string codigo { get; set; }
        public string codigo_usuario { get; set; }
        public string codigo_requerimiento { get; set; }
        public string fecha_asignacion { get; set; }
        public string fecha_creacion { get; set; }
        public string estado { get; set; }
        public string fullName { get; set; }
        public string estadoValidacion { get; set; }
        public string codigoEstado { get; set; }
        public string descripcionRequerimiento { get; set; }
        public string descripcionAndCodigoRequerimiento { get; set; }
        public string tipoValidacion { get; set; }
        public string tipoCargaJob { get; set; }
    }
}
