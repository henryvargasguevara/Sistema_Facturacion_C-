﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    class ReporteCumplimientoView
    {
        public int codigo { get; set; }
        public string usuario { get; set; }
        public string codigo_Asignacion_Requerimiento { get; set; }
        public string descripcion { get; set; }
        public string fecha_Validacion { get; set; }
        public string fecha_entrega { get; set; }
        public string estado_dsx { get; set; }
        public string estado_Cumplimiento { get; set; }
    }
}
