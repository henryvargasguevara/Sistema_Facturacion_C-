﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    class RequerimientoView
    {
        public string codigo { get; set; }
        public string cliente { get; set; }
        public string num_pase { get; set; }
        public string descripcion { get; set; }
        public string fecha_inicio { get; set; }
        public string fecha_fin { get; set; }
        public string estado { get; set; }
        public string usuario_creador { get; set; }
        public string fecha_creacion { get; set; }
        public string usuario_modificador { get; set; }
        public string fecha_modificacion { get; set; }
        public string LiderResponsable { get; set; }
        public string prioridad{ get; set; }
        public string tipoValidacion { get; set; }
        public string tipoCargaJob { get; set; }
    }
}
