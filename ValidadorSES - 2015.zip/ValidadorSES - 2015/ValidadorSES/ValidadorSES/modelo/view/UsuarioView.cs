﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo.view
{
    class UsuarioView
    {
        public int codigo { get; set; }
        public string nombres { get; set; }
        public string apellidos { get; set; }
        public string cargo { get; set; }
        public string lider { get; set; }
        public string estado { get; set; }
        public string usuario { get; set; }
        public string contraseña { get; set; }

        public string fechaCreacion { get; set; }
        public string usuarioCreador { get; set; }
        public string fechaModificacion { get; set; }
        public string usuarioModificador { get; set; }

        public string pregunta { get; set; }
        public string respuesta { get; set; } 
    }
}
