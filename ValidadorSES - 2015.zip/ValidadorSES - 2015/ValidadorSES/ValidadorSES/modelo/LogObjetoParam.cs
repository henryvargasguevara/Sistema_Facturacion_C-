﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogObjetoParam
    {
        public string name { get; set; }
        public string solicitud { get; set; } //Prompt
        public string valorPredeterminado { get; set; } //Default
        public string tipo { get; set; } //ParamType
        public string description { get; set; }
        public List<string> listaFuncion { get; set; }
        
        public LogObjetoParam() 
        {
            this.name = "";
            this.solicitud = "";
            this.valorPredeterminado = "";
            this.tipo = "";
            this.description = "";
        }
    }
}
