﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogStageUserVarsActivity
    {
        public List<LogObjetoParam> listaParametroVariable { get; set; }

        public LogStageUserVarsActivity() 
        {
            this.listaParametroVariable = new List<LogObjetoParam>();
        }
    }
}
