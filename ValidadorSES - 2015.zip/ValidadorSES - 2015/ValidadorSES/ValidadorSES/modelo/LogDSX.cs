﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogDSX
    {
        public LogHeader header { get; set; }
        public List<LogJob> listaJob { get; set; }
        public List<LogRoutine> listaRoutine { get; set; }
        public List<LogParameterSet> listaParameterSet { get; set; }
        public Carpeta carpetaRaizJob { get; set; }

        public int numJobServer { get; set; }
        public int numJobParallel { get; set; }
        public int numJobSequence { get; set; }
        public int numRoutine { get; set; }
        public int numParameterSet { get; set; }
        public DateTime fechaDSXExportacion { get; set; }
        public DateTime fechaDSXUltimaModificacion { get; set; }
        public DateTime fechaDSXValidacion { get; set; }
        public string descripcion { get; set; }
        public int codigoDSX { get; set; }
        public string codigoUsuarioRequerimiento { get; set; }
        public string codigoRequerimiento { get; set; }
        public string tipoValidacion { get; set; }
        public string tipoCarga { get; set; }
        public string codigoEstadoJob { get; set; }
        public string codigoEstadoRoutine { get; set; }
        public string codigoEstadoParameter { get; set; }
        public string codigoEstado { get; set; }
        public string nota { get; set; }
        public string cadenaFechaUltimaModificacion { get; set; }
        public string cadenaFechaValidacion { get; set; }
        public string cadenaFechaExportacion { get; set; }
        public string descripcionEstado { get; set; }
        
        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }
        public DateTime fechaModificacion { get; set; }
        public int usuarioModificador { get; set; }

        public bool esNecesarioArchivoAdicional { get; set; }
        public List<string> listaFaltanteJob { get; set; }
        public List<string> listaFaltanteRoutine { get; set; }
        public List<string> listaFaltanteVariableEntorno { get; set; }

        public LogDSX() 
        {
            this.carpetaRaizJob = new Carpeta();
            this.carpetaRaizJob.nombre = "Jobs";
            this.carpetaRaizJob.nombreFull = "\\Jobs";
            this.carpetaRaizJob.carpetaPadre = null;
            this.carpetaRaizJob.listaCarpeta = new List<Carpeta>();
            this.carpetaRaizJob.listaJob = new List<LogJob>();

            this.header = new LogHeader();
            this.listaJob = new List<LogJob>();
            this.listaRoutine = new List<LogRoutine>();
            this.listaParameterSet = new List<LogParameterSet>();

            this.esNecesarioArchivoAdicional = false;
            this.listaFaltanteJob = new List<string>();
            this.listaFaltanteRoutine = new List<string>();
            this.listaFaltanteVariableEntorno = new List<string>();
            this.nota = "";
        }
    }
}
