﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES
{
    public class VariableEntorno
    {
        public string nombre {get;set;}
        public string valor {get;set;}
    }
}
