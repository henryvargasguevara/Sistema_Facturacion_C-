﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class Conexion
    {
        public string datasource { get; set; }
        public string database { get; set; }
        public string user { get; set; }
        public string password { get; set; }

        public Conexion()
        {
            this.datasource = "";
            this.database = "";
            this.user = "";
            this.password = "";
        }
    }
}
