﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class ResultadoStage
    {
        public string tipoStage { get; set; }
        public string nombreStage { get; set; }
        public LogStage stage { get; set; }
        public List<ResultadoFiltro> listaResultado { get; set; }
        public List<List<string>> listaPropiedad { get; set; }

        public ResultadoStage()
        {
            this.tipoStage = "";
            this.nombreStage = "";
            this.listaPropiedad = new List<List<string>>();
            this.listaResultado = new List<ResultadoFiltro>();
        }
    }
}
