﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class ResultadoBusqueda
    {
        public List<ResultadoJob> listaJob;
        public List<FiltroBusqueda> listaFiltro;
        public int totalResultado { get; set; }
        public int totalJob { get; set; }
        public int totalStage { get; set; }
        public int totalParameterSet { get; set; }
        public int totalRoutine { get; set; }

        public ResultadoBusqueda() 
        {
            this.listaJob = new List<ResultadoJob>();
            this.listaFiltro = new List<FiltroBusqueda>();

            this.totalResultado = 0;
            this.totalJob = 0;
            this.totalStage = 0;
            this.totalParameterSet = 0;
            this.totalRoutine = 0;
        }
    }
}
