﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogParam
    {
        public string oleType { get; set; }
        public string paramType { get; set; }
        public string name { get; set; }
        public string solicitud { get; set; } //Prompt
        public string tipo { get; set; } //ParamType
        public string valorPredeterminado { get; set; } //Default
        public string textoAyuda { get; set; } //
        
        public string estadoParamDescripcion { get; set; }
        public string estadoParamCodigo { get; set; }
        public string mensaje { get; set; }
        public bool hayError { get; set; }
        public bool hayObservacion { get; set; }

        public Objeto objeto { get; set; }
        public LogParameterSet parameter { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }
    }
}
