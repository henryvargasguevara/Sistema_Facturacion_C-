﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class LogSql
    {
        public List<string> listatablas { get; set; }
        public List<string> listaFinal { get; set; }
        public List<string> listaEstado { get; set; }                 
        public LogSQL_2 logsql2 { get; set; }

        public LogSql()
        {
            logsql2 = new LogSQL_2();
        }
    }
    
}
