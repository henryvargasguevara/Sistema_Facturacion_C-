﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;

namespace ValidadorSES.modelo
{
    public class LogRoutine
    {
        public string oleType { get; set; }
        public string routineType { get; set; }

        public string identifier { get; set; }
        public string dateModified { get; set; }
        public string timeModified { get; set; }
        public string category { get; set; }
        public string shortDesc { get; set; }
        public string descripcion_routine { get; set; }
        public string codigoRoutine { get; set; }
        public string mensaje { get; set; }
        public string estadoRutinaDescripcion { get; set; }
        public string estadoRutinaCodigo { get; set; }
        public int numArgCorrecto { get; set; }
        public int numArgIncorrecto { get; set; }
        public int numArgObservado { get; set; }
        public bool hayError { get; set; }

        public LogDSX dsx { get; set; }
        public Objeto objeto { get; set; }
        public List<LogArgument> listaArgumentoRoutine { get; set; }

        public DateTime fechaCreacion { get; set; }
        public int usuarioCreador { get; set; }

        public LogRoutine() 
        {
            this.listaArgumentoRoutine = new List<LogArgument>();
            this.shortDesc = "";
            this.descripcion_routine = "";
        }
    }
}
