﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.modelo
{
    public class ResultadoFiltro
    {
        public string tipoFiltro { get; set; }
        public string descripcionFiltro { get; set; }
        public string resultado { get; set; }
        public ResultadoStage stage { get; set; }

        public ResultadoFiltro() 
        {
            this.tipoFiltro = "";
            this.descripcionFiltro = "";
            this.resultado = "";
        }
    }
}
