﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    class UtilArchivoDSX
    {
        // funciones de extracción de nombre
        //header
        public static string getDateModifiedObjeto(string linea)
        {
            return linea.Substring(14, linea.Length - 15);
        }
        public static string getTimeModifiedObjeto(string linea)
        {
            return linea.Substring(14, linea.Length - 15);
        }

        //job
        public static string getIdentifierObjeto(string linea)
        {
            return linea.Substring(12, linea.Length - 13);
        }

        public static string getDescriptionJob(string linea)
        {
            return linea.Substring(13, linea.Length - 14);
        }

        public static string getCategoryObjeto(string linea)
        {
            return linea.Substring(10, linea.Length - 11);
        }

        public static string getJobType(string linea)
        {
            return linea.Substring(9, linea.Length - 10);
        }

        public static string getCheckPadre(string linea)
        {
            return linea.Substring(19, linea.Length - 20);
        }

        //stage
        public static string getNombreStage(string linea)
        {
            return linea.Substring(6, linea.Length - 7);
        }

        public static string getExecutionTypeJobActivity(string linea)
        {
            return linea.Substring(15, linea.Length - 16);
        }

        public static string getNombreJobActivity(string linea)
        {
            return linea.Substring(9, linea.Length - 10);
        }

        public static string getOLETypeObjeto(string linea)
        {
            return linea.Substring(9, linea.Length - 10);
        }

        public static string getStageType(string linea)
        {
            return linea.Substring(11, linea.Length - 12);
        }

        public static string getInputPins(string linea)
        {
            return linea.Substring(11, linea.Length - 12);
        }

        public static string getOutputPins(string linea)
        {
            return linea.Substring(12, linea.Length - 13);
        }

        public static string getValueDataset(string linea)
        {
            if (linea == UtilArchivo.VALUE_SALTO_LINEA)
            {
                return UtilArchivo.VALUE_SALTO_LINEA;
            }

            return linea.Substring(7, linea.Length - 8);
        }

        public static string getValueFile(string linea, int tipo)
        {
            if (linea == UtilArchivo.VALUE_SALTO_LINEA)
            {
                return UtilArchivo.VALUE_SALTO_LINEA;
            }

            if (tipo == 2)
            {
                //Value "\(2)\(2)0\(1)\(3)file \(2)#PARM_CI_FTP_DMCONV.$SBP_DMCONV_FTP_FOLDER_SWITCH#QA_DMCONV_EXTENSION_EMPRESAS.txt\(2)0"
                return linea.Substring(33, linea.Length - (34 + 5));
            }
            // Value "\(2)\(2)0\(1)\(3)file\(2)#PARM_PATH.$PATH_WORK#JOB_RV_SBP_VI_CUENTAS_EXCLUIDAS.txt\(2)0"
            return linea.Substring(32, linea.Length - (33 + 5));
        }

        public static string getValorSource(string linea)
        {
            return linea.Substring(10, linea.Length - 11);
        }
        public static string getValorPartner(string linea)
        {
            return linea.Substring(9, linea.Length - 10);
        }
        public static string getValorConditionType(string linea)
        {
            return linea.Substring(15, linea.Length - 16);
        }
        public static string getNombreVariableTransformer(string linea)
        {
            //Name "..."
            return linea.Substring(6, linea.Length - 7);
        }

        //funciones para obtener datos de routine
        public static string getShortDescRoutine(string linea)
        {
            return linea.Substring(11, linea.Length - 12);
        }
        public static string getRoutineType(string linea)
        {
            //RoutineType "0"
            return linea.Substring(13, linea.Length - 14);
        }
        //funciones para obtener Argumentos de routine

        public static string getArgNameRoutine(string linea)
        {
            return linea.Substring(6, linea.Length - 7);
        }
        public static string getArgDescRoutine(string linea)
        {
            return linea.Substring(6, linea.Length - 7);
        }
        public static string getNombreRoutine(string linea)
        {
            return linea.Substring(13, linea.Length - 14);
        }

        //funciones para obtener datos Header
        public static string getHeaderDate(string linea)
        {
            return linea.Substring(6, linea.Length - 7);//Date "2016-10-28"   
        }

        public static string getHeaderTime(string linea)
        {
            return linea.Substring(6, linea.Length - 7);//Time "15.25.46" 
        }

        //funciones para obtener datos de SUBRECORD param
        public static string getParamName(string linea) 
        {
            return linea.Substring(6, linea.Length - 7);
        }
        public static string getParamPrompt(string linea)
        {
            return linea.Substring(8, linea.Length - 9);
        }
        public static string getParamDefault(string linea)
        {
            return linea.Substring(9, linea.Length - 10);
        }
        public static string getParamType(string linea)
        {
            return linea.Substring(11, linea.Length - 12);
        }

        //ParameterSet
        public static string getShortDesc(string linea)
        {
            return linea.Substring(11, linea.Length - 12);
        }

        //CAnnotation
        public static string getAnnotacionText(string linea)
        {
            return linea.Substring(16, linea.Length - 17);
        }
        public static string getAnnotationType(string linea)
        {
            return linea.Substring(16, linea.Length - 17);
        }

        //terminator

        //stage
        public static string getDesFinalMessage(string linea)
        {
            return linea.Substring(14, linea.Length - 15);
        }

        public static string getDesFullDesciption(string linea)
        {
            return linea.Substring(17, linea.Length - 18);
        }

        public static string getDesLogText(string linea)
        {
            return linea.Substring(9, linea.Length - 10);
        }

        // notification
        public static string getAsuntoMensaje(string linea)
        {
            return linea.Substring(9, linea.Length - 10);
        }
    }

    
}
