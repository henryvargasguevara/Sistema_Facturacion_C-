﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ValidadorSES.util
{
    class UtilForm
    {
        public const string OPTION_SELECCIONAR = "--Seleccionar--";
        public const string OPTION_ACTIVO = "ACTIVO";

        public static DataColumn getColumnString(string nombre){
            DataColumn column = new DataColumn();
            column = new DataColumn();
            column.DataType = System.Type.GetType("System.String");
            column.ColumnName = nombre;
            return column;
        }
    }
}
