﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace ValidadorSES.util
{
     class UtilSQL
    {
        public static Object getObjectOrSQLNull(Object obj) 
        {
            if (obj == null)
            {
                return DBNull.Value;
            }
            return obj;
        }

        public static int getIntOrNull(SqlDataReader reader, int ordinal)
        {
            return reader.IsDBNull(ordinal) ? -1 : reader.GetInt32(ordinal);
        }

        public static string getStringOrNull(SqlDataReader reader, int ordinal) 
        {
            return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
        }

        public static string getStringDateTimeOrNull(SqlDataReader reader, int ordinal)
        {
            return reader.IsDBNull(ordinal) ? null : reader.GetDateTime(ordinal).ToString();
        }
    }
}
