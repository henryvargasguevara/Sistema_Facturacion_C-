﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using ValidadorSES.modelo;

namespace ValidadorSES.util
{
    class UtilValidaSQL
    {        

        public static string lineasArchivoSql(string rutaArchivoSQL)
        {
            string path = rutaArchivoSQL;
            string text = null;
            string comentario = "-";
            string eliminaEspacio = null;
            string[] readtext = File.ReadAllLines(path);

            foreach (string s in readtext)
            {
                eliminaEspacio = s.Trim();
                if (eliminaEspacio.Length >= 1)
                {
                    if (eliminaEspacio.Substring(0, 1) != comentario)
                    {
                        text += eliminaEspacio + "\n";
                    }
                }
            }
            return text;
        }

        public static string verificar_grant(string archivosql)
        {
            string archivo = archivosql;
            string grant = "GRANT";
            string result = null;
            int result_grant = archivo.IndexOf(grant, StringComparison.CurrentCultureIgnoreCase);
            if (result_grant != -1)
            {
                result = "Se encontró permisos para usuarios " + ConstanteChk.CHK30;
            }
            else
            {
                result = "";
            }
            return result;
        }

        public static string verificar_insert(string archivosql)
        {
            string archivo = archivosql;
            string insert = "INSERT";
            string result = null;
            int result_insert = archivo.IndexOf(insert, StringComparison.CurrentCultureIgnoreCase);
            if (result_insert != -1)
            {
                result = "Se encontró sentencia insert " + ConstanteChk.CHK26;
            }
            else
            {
                result = "";
            }
            return result;
        }

        public static string verificar_update(string archivosql)
        {
            string archivo = archivosql;
            string update = "UPDATE";
            string result = null;
            int result_update = archivo.IndexOf(update, StringComparison.CurrentCultureIgnoreCase);
            if (result_update != -1)
            {
                result = "Se encontró sentencia UPDATE " +ConstanteChk.CHK26;
            }
            else
            {
                result = "";
            }
            return result;
        }

        public static string verificar_delete(string archivosql)
        {
            string archivo = archivosql;
            string delete = "DELETE";
            string result = null;
            int result_delete = archivo.IndexOf(delete, StringComparison.CurrentCultureIgnoreCase);
            if (result_delete != -1)
            {
                result = "Se encontró sentencia DELETE " + ConstanteChk.CHK26;
            }
            else
            {
                result = "";
            }
            return result;
        }

        public static string verificar_truncate(string archivosql)
        {
            string archivo = archivosql;
            string truncate = "TRUNCATE";
            string result = null;
            int result_truncate = archivo.IndexOf(truncate, StringComparison.CurrentCultureIgnoreCase);
            if (result_truncate != -1)
            {
                result = "Se encontró sentencia TRUNCATE " + ConstanteChk.CHK26;
            }
            else
            {
                result = "";
            }
            return result;            
        }

        public static string verificar_compress(string archivosql)
        {
            string path = archivosql;
            string comentario = "-";
            string create_table = "CREATE TABLE ";
            string compress = "COMPRESS YES";
            int conta_table = 0;
            int conta_compress = 0;

                string[] readtext = File.ReadAllLines(path);
                foreach (string s in readtext)
                {
                    if (s.Length >= 1)
                    {
                        if (s.Substring(0, 1) != comentario)
                        {
                            int resultado_table = s.IndexOf(create_table, StringComparison.CurrentCultureIgnoreCase);
                            if (resultado_table != -1) { conta_table = conta_table + 1; }
                            int resultado_compress = s.IndexOf(compress, StringComparison.CurrentCultureIgnoreCase);
                            if (resultado_compress != -1) { conta_compress = conta_compress + 1; }
                        }
                    }
                }
            string mensaje = "";
            if (conta_table > conta_compress)
            {
                mensaje = "Falta 1 ó más sentencias 'COMPRESS YES'" + ConstanteChk.CHK26 + "\n";
            }
            else if (conta_table < conta_compress)
            {
                mensaje = "Se encontró la sentencia 'COMPRESS YES' más de " + conta_table + " veces" + ConstanteChk.CHK26;
            }
            else
            {
                mensaje = "";
            }
            return mensaje ;
        }

        public static string verificar_logged(string archivosql)
        {
            string path = archivosql;
            string comentario = "-";
            string create_table = "CREATE TABLE ";
            string logged = "NOT LOGGED INITIALLY";
            int conta_table = 0;
            int conta_logged = 0;

            string[] readtext = File.ReadAllLines(path);
            foreach (string s in readtext)
            {
                if (s.Length >= 1)
                {
                    if (s.Substring(0, 1) != comentario)
                    {
                        int resultado_table = s.IndexOf(create_table, StringComparison.CurrentCultureIgnoreCase);
                        if (resultado_table != -1) { conta_table = conta_table + 1; }
                        int resultado_logged = s.IndexOf(logged, StringComparison.CurrentCultureIgnoreCase);
                        if (resultado_logged != -1) { conta_logged = conta_logged + 1; }
                    }
                }
            }
            string mensaje = "";
            if (conta_table > conta_logged)
            {
                mensaje = "Falta 1 ó más sentencias 'NOT LOGGED INITIALLY'" + ConstanteChk.CHK26 + "\n";
            }
            else if (conta_table < conta_logged)
            {
                mensaje = "Se encontró la sentencia 'NOT LOGGED INITIALLY' más de " + conta_table + " veces" + ConstanteChk.CHK26;
            }
            else
            {
                mensaje = "";
            }
            return mensaje;
        }

        public static string verificar_pk_tablas_du(string archivosql)
        {
            string archivo = archivosql;
            string constraint = "ADD CONSTRAINT DU_";
            string alter_table_du = "ALTER TABLE EDWSTG.DU";
            string result = null;
            int result_constraint = archivo.IndexOf(constraint, StringComparison.CurrentCultureIgnoreCase);
            int result_alter = archivo.IndexOf(alter_table_du, StringComparison.CurrentCultureIgnoreCase);
            if (result_constraint != -1 && result_alter != -1)
            {
                result = "Se encontró PK para tabla DU " + ConstanteChk.CHK28;
            }
            else
            {
                result = "";
            }
            return result;
        }

        public static LogSql probando_vamos(string archivo)
        {
            LogSql ad = new LogSql();
            string path = archivo;
            string text = null;
            string comentario = "CREATE TABLE";
            string[] readtext = File.ReadAllLines(path);
            char[] borrar = { '(','"' };
            string TABLA_IA = "IA_";
            string TABLA_CA = "CA_";
            string TABLA_DU = "DU_";
            string TABLA_MA = "MA_";
            string TABLA_HIST = "HIST_";
            string TABLA_ULT = "ULT_";
            string TABLA_DTEN = "DTEN_";
            string TABLA_TMP = "TMP_";            
            string TABLA_REF = "REF_";
            string TABLA_REL = "REL_";
            string TABLA_OP = "OP_";

            string FRECUENCIA_D  = "D";
            string FRECUENCIA_S  = "S";
            string FRECUENCIA_M  = "M";
            string FRECUENCIA_E  = "E";
            string FRECUENCIA_HD = "HD";
            string FRECUENCIA_HM = "HM";
            string FRECUENCIA_MD = "MD";
            string FRECUENCIA_MM = "MM";
            string FRECUENCIA_OD = "OD";
            string FRECUENCIA_OM = "OM";
            string FRECUENCIA_UD = "UD";
            string FRECUENCIA_UM = "UM";

            string words;
            string[] cortar;
            string nombreTabla;
            string[] cortar2;
            string nombreTabla_frecuencia;
            string resul = null;
            string estado = null;
            List<string> listafinal = new List<string>();
            List<string> listatablas = new List<string>();
            List<string> listaestado = new List<string>();
            foreach (string s in readtext)
            {
                if (s.Length >= 13)
                {                    
                    if (s.Substring(0, 13).ToUpper().Trim() == comentario)
                    {
                        words=string.Join("",s.Split(borrar));
                        cortar = words.Split('.');
                        nombreTabla = cortar[1].ToUpper();
                        cortar2 = nombreTabla.Split('_');
                        nombreTabla_frecuencia = cortar2[1].ToUpper();
                        listatablas.Add(nombreTabla);

                        if (nombreTabla.Length >= 40)
                        {
                            resul += "Longitud de nombre de tabla sobrepasa los 40 carácteres. " + ConstanteChk.BP1;
                        }

                        if (nombreTabla.StartsWith(TABLA_IA) || nombreTabla.StartsWith(TABLA_CA) || nombreTabla.StartsWith(TABLA_DU) ||
                            nombreTabla.StartsWith(TABLA_HIST) || nombreTabla.StartsWith(TABLA_MA) || nombreTabla.StartsWith(TABLA_ULT) ||
                            nombreTabla.StartsWith(TABLA_DTEN) || nombreTabla.StartsWith(TABLA_OP) || nombreTabla.StartsWith(TABLA_REF) ||
                            nombreTabla.StartsWith(TABLA_REL) || nombreTabla.StartsWith(TABLA_TMP))
                        {
                            resul += "";
                        }
                        else
                        {
                            resul += "Nombre de tabla no tiene prefijo válido. " + ConstanteChk.CHK29 + "\n";
                        }

                        if (nombreTabla_frecuencia == FRECUENCIA_D || nombreTabla_frecuencia == FRECUENCIA_E || nombreTabla_frecuencia == FRECUENCIA_HD ||
                            nombreTabla_frecuencia == FRECUENCIA_HM || nombreTabla_frecuencia == FRECUENCIA_M || nombreTabla_frecuencia == FRECUENCIA_S ||
                            nombreTabla_frecuencia == FRECUENCIA_UD || nombreTabla_frecuencia == FRECUENCIA_UM || nombreTabla_frecuencia == FRECUENCIA_OD ||
                            nombreTabla_frecuencia == FRECUENCIA_OM || nombreTabla_frecuencia == FRECUENCIA_MD || nombreTabla_frecuencia == FRECUENCIA_MM)
                        {
                            resul += "";
                        }
                        else
                        {
                            resul += "Periocidad de la tabla no es correcto. " + ConstanteChk.CHK29 + "\n";
                        }

                        text += nombreTabla + "\n";
                        listafinal.Add(resul);

                        if (resul == "")
                        {
                            estado = "OK";
                        }
                        else
                        {
                            estado = "NOTOK";
                        }

                        listaestado.Add(estado);
                        resul = null;
                        estado = null;
                    }
                    
                }                
            }
            ad.listaFinal = listafinal;
            ad.listatablas = listatablas;
            ad.listaEstado = listaestado;
            return ad;
        }
    }
}
/*ELIMINA ESPACIOS EN BLANCO Y PUNTOS(CUALQUIER CARACTERES QUE QUIERAS) 
//char[] limites = { ' ', '.' };
//string result = null;
//string text = archivo;
//string[] words = text.Split(limites);

//foreach (string s in words)
//{
//    result += s;
//}
//return result;*/

/* ENCUENTRA LA PRIMERA PALABRA DE UNA CADENA
 string [] palabras = cadena.Split();
 string var1 = palabras[0];
 return var1;
 */

