﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    public class ConstanteMaestro
    {
        //Maestro clasificacion objeto
        public const string DES_CLASF_OBJ_JOB = "Job";
        public const string DES_CLASF_OBJ_STAGE = "Stage";
        public const string DES_CLASF_OBJ_ROUTINE = "Routine";
        public const string DES_CLASF_OBJ_ARGUMENT = "Argument";
        public const string DES_CLASF_OBJ_PARAMETER = "ParameterSet";
        public const string DES_CLASF_OBJ_PARAMETER_PARAM = "Parámetro de ParameterSet";

        public const string COD_CLASF_OBJ_JOB = "1";
        public const string COD_CLASF_OBJ_STAGE = "2";
        public const string COD_CLASF_OBJ_ROUTINE = "3";
        public const string COD_CLASF_OBJ_ARGUMENT = "4";
        public const string COD_CLASF_OBJ_PARAMETER = "5";
        public const string COD_CLASF_OBJ_PARAMETER_PARAM = "6";

        //Maestro tipo de carga
        public const string COD_CARGA_STAGING = "STAGING";
        public const string COD_CARGA_SANDBOX = "SANDBOX";
        public const string COD_CARGA_BDS_ODS_OTROS = "ODS_DBS_OT";

        //Maestro estado validación
        public const string DES_EST_VALIDACION_OK = "OK";
        public const string COD_EST_VALIDACION_OK = "OK";

        public const string DES_EST_VALIDACION_ERROR = "NOTOK";
        public const string COD_EST_VALIDACION_ERROR = "ERROR";

        public const string DES_EST_VALIDACION_OBS = "OBS";
        public const string COD_EST_VALIDACION_OBS = "OBS";

        //Maestro tipo de Validación - 13
        public const string COD_TIP_VAL_EXPRESS = "E";
        public const string COD_TIP_VAL_FULL = "F";

        //Maestro estado de asignación - 12
        public const string COD_EST_ASIG_PENDIENTE = "1";
        public const string COD_EST_ASIG_NO_FINALIZADO = "2";
        public const string COD_EST_ASIG_FINALIZADO = "3";
        public const string COD_EST_ASIG_RECHAZADO = "4";
        public const string COD_EST_ASIG_FINALIZADO_JUSTIFICACION = "5";

        public const string DES_EST_ASIG_PENDIENTE = "Pendiente";
        public const string DES_EST_ASIG_NO_FINALIZADO = "No Finalizado";
        public const string DES_EST_ASIG_FINALIZADO = "Finalizado";
        public const string DES_EST_ASIG_RECHAZADO = "Rechazado";
        public const string DES_EST_ASIG_FINALIZADO_JUSTIFICACION = "Finalizado con Justificación";

        //Maestro estado de ejecución - 14
        public const string COD_EST_EJEC_NO_VALIDADO = "1";
        public const string COD_EST_EJEC_VALIDADO_NOT_OK = "2";
        public const string COD_EST_EJEC_VALIDADO_OBS = "3";
        public const string COD_EST_EJEC_VALIDADO_OK = "4";
        public const string COD_EST_EJEC_VALIDADO_OK_JUSTIFICACION = "5";

        //Maestro estado de requerimiento - 5
        public const string COD_EST_REQ_PENDIENTE = "1";
        public const string COD_EST_REQ_ASIGNADO = "2";
        public const string COD_EST_REQ_SUCCESS = "3";
        public const string COD_EST_REQ_RECHAZADO = "4";

        public const string DES_EST_REQ_PENDIENTE = "Pendiente";
        public const string DES_EST_REQ_ASIGNADO = "Asignado";
        public const string DES_EST_REQ_SUCCESS = "Success";
        public const string DES_EST_REQ_RECHAZADO = "Rechazado";

    }
}
