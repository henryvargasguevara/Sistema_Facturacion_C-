﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    class UtilCadena
    {
        public static string eliminarCaracteresInvalidos(string linea)
        {
            if (linea != null)
            {
                linea = linea.Replace("\\(9)", "");//tabs
            }
            return linea;
        }

        public static string replaceCaracteresInvalidos(string linea)
        {
            if (linea != null)
            {
                linea = linea.Replace("\\(9)", " ");//tabs
            }
            return linea;
        }

        public static int contarCaracter(string cadena, char caracter) 
        {
            int contador = 0;
            if(cadena !=null)
            {                
                char[] arrayChar = cadena.ToCharArray();
                for (int i = 0; i<arrayChar.Length; i++)
                {
                    if (caracter == arrayChar[i])
                    {
                        contador++;
                    }
                }
            }

            return contador;
        }
    }
}
