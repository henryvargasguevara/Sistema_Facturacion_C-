﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;

namespace ValidadorSES.util
{
    class UtilArchivo
    {

        public const string EXT_DATASET = ".DS";
        public const string EXT_ENV = ".ENV";
        public const string EXT_DSX = ".DSX";
        public const string EXT_SQL = ".SQL";
        public const string VALUE_SALTO_LINEA = "Value =+=+=+=";

        public static bool esValidoArchivoDSX(string ruta)
        {
            if (File.Exists(ruta))
            {
                string directorio = Path.GetDirectoryName(ruta);
                string extension = Path.GetExtension(ruta);
                return EXT_DSX.Equals(extension.ToUpper());
            }

            return false;
        }

        public static bool esValidoArchivoSQL(string ruta)
        {
            if (File.Exists(ruta))
            {
                string directorio = Path.GetDirectoryName(ruta);
                string extension = Path.GetExtension(ruta);
                return EXT_SQL.Equals(extension.ToUpper());
            }
            return false;
        }

        public static bool esValidoArchivoENV(string ruta)
        {
            if (File.Exists(ruta))
            {
                string directorio = Path.GetDirectoryName(ruta);
                string extension = Path.GetExtension(ruta);
                return EXT_ENV.Equals(extension.ToUpper());
            }

            return false;
        }

        public static int contarLineasArchivo(string rutaArchivoDSX)
        {
            int total = 0;

            if (UtilArchivo.esValidoArchivoDSX(rutaArchivoDSX))
            {
                StreamReader objLeer = new StreamReader(rutaArchivoDSX);
                String sLine = "";
                while (sLine != null)
                {
                    sLine = objLeer.ReadLine();
                    total = total + 1;
                }
            }

            return total;
        }
        
        public static void serializarObjeto(Object o, string nombre)
        {
            string dir = @"c:\db";
            string serializationFile = Path.Combine(dir, nombre + ".bin");

            //serialize
            using (Stream stream = File.Open(serializationFile, FileMode.Create))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                bformatter.Serialize(stream, o);
            }
        }

        public static List<string> desSerializarListaString(string nombreArchivo)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db." + nombreArchivo + ".bin";

            //deserialize
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                List<string> lista = (List<string>)bformatter.Deserialize(stream);
                return lista;
            }
        }
        
        public static List<Objeto> desSerializarListaObjeto(string nombreArchivo)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db." + nombreArchivo + ".bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                List<Objeto> lista = (List<Objeto>)bformatter.Deserialize(stream);
                return lista;
            }
        }

        public static List<ObjetoView> desSerializarListaObjetoView(string nombreArchivo)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db." + nombreArchivo + ".bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                List<ObjetoView> lista = (List<ObjetoView>)bformatter.Deserialize(stream);
                return lista;
            }
        }
    }
}
