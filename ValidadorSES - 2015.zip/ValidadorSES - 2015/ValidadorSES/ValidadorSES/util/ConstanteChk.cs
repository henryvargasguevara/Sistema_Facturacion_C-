﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    class ConstanteChk
    {
        public const string BP1 = "[BP1]";
        public const string CHK01 = "[CHK01]";
        public const string CHK02 = "[CHK02]";
        public const string CHK03 = "[CHK03]";
        public const string CHK04 = "[CHK04]";
        public const string CHK05 = "[CHK05]";
        public const string CHK06 = "[CHK06]";
        public const string CHK07 = "[CHK07]";
        public const string CHK08 = "[CHK08]";
        public const string CHK09 = "[CHK09]";
        public const string CHK10 = "[CHK10]";
        public const string CHK11 = "[CHK11]";
        public const string CHK12 = "[CHK12]";
        public const string CHK13 = "[CHK13]";
        public const string CHK14 = "[CHK14]";
        public const string CHK15 = "[CHK15]";
        public const string CHK16 = "[CHK16]";
        public const string CHK17 = "[CHK17]";
        public const string CHK18 = "[CHK18]";
        public const string CHK19 = "[CHK19]";
        public const string CHK20 = "[CHK20]";
        public const string CHK21 = "[CHK21]";
        public const string CHK22 = "[CHK22]";
        public const string CHK23 = "[CHK23]";
        public const string CHK24 = "[CHK24]";
        public const string CHK25 = "[CHK25]";
        public const string CHK26 = "[CHK26]";
        public const string CHK27 = "[CHK27]";
        public const string CHK28 = "[CHK28]";
        public const string CHK29 = "[CHK29]";
        public const string CHK30 = "[CHK30]";
        public const string CHK31 = "[CHK31]";
        public const string CHK32 = "[CHK32]";
        public const string CHK33 = "[CHK33]";
    }
}
