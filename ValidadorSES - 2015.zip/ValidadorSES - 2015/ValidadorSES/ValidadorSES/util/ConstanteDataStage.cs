﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    public class ConstanteDataStage
    {
        //Propiedades de DB2
        public const string PROPIEDAD_DB2_WRITE_MODE_DELETE = "2";
        public const string PROPIEDAD_DB2_WRITE_MODE_DELETE_THEN_INSERT = "5";
        public const string PROPIEDAD_DB2_KEEP_CONDUCTOR_CONNECTION_ALIVE_SI = "1";
        public const string PROPIEDAD_DB2_KEEP_CONDUCTOR_CONNECTION_ALIVE_NO = "0";        
        public const string PROPIEDAD_DB2_BEFORE_AFTER_SI = "1";
        public const string PROPIEDAD_DB2_BEFORE_AFTER_NO = "0";
        public const string PROPIEDAD_DB2_AUTO_COMMIT_ON = "1";
        public const string PROPIEDAD_DB2_AUTO_COMMIT_OFF = "0";
        public const string PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO = "2000";
        public const string PROPIEDAD_DB2_ARRAY_SIZE = "2000"; //JT
        public const string PROPIEDAD_DB2_LOCKWAITMODE = "1"; //JT
        public const string PROPIEDAD_DB2_PK_DU = "DSIsKey";  //JT

        //Propiedad de Aggregator
        public const string PROPIEDAD_AGGREGATOR_METHOD = "sort";

        //PREFIJO NOMENCLATURA JOBS
        public const string PREF_JOB_DEL_RBTL_NOMBRE_TABLA = "DEL_RBTL_";
        public const string PREF_JOB_DEL_WBTL_NOMBRE_TABLA = "DEL_WBTL_";
        public const string PREF_JOB_SEQ_DEL_NOMBRE_TABLA = "SEQ_DEL_";
        public const string PREF_JOB_RBTL_NOMBRE_TABLA = "DEL_RBTL";
        public const string PREF_JOB_WBTL_NOMBRE_TABLA = "DEL_WBTL";

        //PREFIJO frecuencias
        public const string PREF_FREQ_PC = "PC_";
        public const string PREF_FREQ_ST = "ST_";
        public const string PREF_FREQ_CM = "CM_";
        public const string PREF_FREQ_RP = "RP_";
        public const string PREF_FREQ_CS = "CS_";
        public const string PREF_FREQ_FTP = "FTP_";
        public const string PREF_PROC_DEL = "DEL_";   //JT DEL

        //PREFIJO jobs staging   
        public const string PREF_STAGING_IA = "IA_";
        public const string PREF_STAGING_DED = "DED_";
        public const string PREF_STAGING_DIF = "DIF_";
        public const string PREF_STAGING_EST = "EST_";
        public const string PREF_STAGING_VDU = "VDU_";
        public const string PREF_STAGING_FTP = "FTP_";
        public const string PREF_STAGING_PARS = "PARS_";
        public const string PREF_STAGING_QA = "QA_";
        public const string PREF_STAGING_ST = "ST_";

        //PREFIJO proceso
        public const string PREF_PROC_LDM = "LDM_";
        public const string PREF_PROC_LN = "LN_";
        public const string PREF_PROC_STG = "STG_";
        
                

        //DESENCADENANTE
        public const string DESENCADENANTE_CORRECTO = "2";
        public const string DESENCADENANTE_CONDICION_CONTRARIA = "1";

        //ACCION DE EJECUCION
        public const string ACCION_EJECUCION_EJECUTAR = "0"; //Ejecutar
        public const string ACCION_EJECUCION_REESTABLECER_LUEGO_EJECUTAR = "1"; //Reestablecer si es necesario y, a continuación, ejecutar
        public const string ACCION_EJECUCION_VALIDAR_SOLO = "2"; //Validar sólo
        public const string ACCION_EJECUCION_REESTABLECER_SOLO = "3"; //Reestablecer sólo

        //PARAMETRO 
        public const string PARAM_VALOR_PRED_DEFAULT = "(As pre-defined)";
        public const string PARAM_VALOR_PRED_PROJDEF = "$PROJDEF";

        //ROUTINE Eliminacion de Dataset
        public const string ROUTINE_DELETE_DATASET = "rtsDeleteAllDataSetArg";
        public const string ROUTINE_DELETE_DATASET_2 = "DATASET";  //JT
        public const string ROUTINE_DELETE_DATASET_3 = "REMOVE"; //JT
        public const string ROUTINE_DELETE_DATASET_4 = "DELETE"; //JT
        public const string ROUTINE_DELETE_DATASET_EMPIEZA = "rts";  //JT

        //-----------------------------------  ROUTINE  ----------------------------------------
        public const string OLETYPE_C_ROUTINE = "CRoutine";

        public const string TYPE_ROUTINE_SERVER = "0";
        public const string DES_ROUTINE_SERVER = "Server";
        public const string PRE_ROUTINE_SERVER = "rts";

        //public const string TYPE_ROUTINE_PARALLEL = "3";
        //public const string DES_ROUTINE_PARALLEL = "Parallel";
        //public const string PRE_ROUTINE_PARALLEL = "rtp";

        public const string TIPO_ROUTINE_NO_DEFINIDO = "ROUTINE NO DEFINIDO";
        public const string DES_ROUTINE_NO_DEFINIDO = "ROUTINE NO DEFINIDO";

        //-------------------------------   PARAMETER SET  ----------------------------------------
        public const string OLETYPE_C_PARAMETERSET = "CParameterSet";

        public const string TYPE_PARAMETERSET = "";
        //-------------------------------    PARAMETRO   ----------------------------------------
        public const string OLETYPE_C_PARAMETRO = "CParametro";

        public const string TYPE_PARAMETRO = "";

        //-----------------------------------  ROUTINE  ----------------------------------------
        public const string OLETYPE_C_ARGUMENT = "CArgument";


        //-----------------------------------  JOBS  ----------------------------------------
        public const string OLETYPE_C_JOB_DEFN = "CJobDefn";

        public const string DES_JOB_SERVER = "Server";
        public const string TYPE_JOB_SERVER = "0";

        public const string DES_JOB_SEQUENCE = "Sequence";
        public const string TYPE_JOB_SEQUENCE = "2";
        public const string PRE_JOB_SEQUENCE = "SEQ_";

        public const string DES_JOB_PARALLEL = "Parallel";
        public const string TYPE_JOB_PARALLEL = "3";


        //-----------------------------------  STAGE  ----------------------------------------
        //GENERAL
        public const string OLETYPE_C_CUSTOM_INPUT = "CCustomInput";
        public const string TIPO_LINK_INPUT_1 = "CCustomInput";// --SIN STAGETYPE
        public const string DES_LINK_INPUT_1 = "Link";

        public const string OLETYPE_C_TRX_INPUT = "CTrxInput";
        public const string TIPO_LINK_INPUT_2 = "CTrxInput";// --SIN STAGETYPE
        public const string DES_LINK_INPUT_2 = "Link";

        public const string OLETYPE_C_CUSTOM_OUTPUT = "CCustomOutput";
        public const string TIPO_LINK_OUTPUT_1 = "CCustomOutput";// --SIN STAGETYPE
        public const string DES_LINK_OUTPUT_1 = "Link";

        public const string OLETYPE_C_TRX_OUTPUT = "CTrxOutput";
        public const string TIPO_LINK_OUTPUT_2 = "CTrxOutput";// --SIN STAGETYPE
        public const string DES_LINK_OUTPUT_2 = "Link";

        public const string OLETYPE_CJS_ACTIVITY_INPUT = "CJSActivityInput";
        public const string TIPO_CJS_ACTIVITY_INPUT = "CJSActivityInput";// --SIN STAGETYPE
        public const string DES_LINK_INPUT_3 = "Link";

        public const string OLETYPE_CJS_ACTIVITY_OUTPUT = "CJSActivityOutput";
        public const string TIPO_CJS_ACTIVITY_OUTPUT = "CJSActivityOutput";// --SIN STAGETYPE
        public const string DES_LINK_OUTPUT_3 = "Link";

        public const string PRE_LINK = "lnk_";

        //ARCHIVOS
        public const string OLETYPE_C_CUSTOM_STAGE = "CCustomStage";

        public const string TIPO_COMPLEX_FLAT_FILE = "PxCFF";
        public const string DES_COMPLEX_FLAT_FILE = "Complex Flat File";
        public const string PRE_COMPLEX_FLAT_FILE = "cplx_";

        public const string TIPO_DATA_SET = "PxDataSet";
        public const string DES_DATA_SET = "Dataset";
        public const string PRE_DATA_SET = "ds_";

        public const string TIPO_EXTERNAL_SOURCE = "PxExternalSource";
        public const string DES_EXTERNAL_SOURCE = "External Source";
        public const string PRE_EXTERNAL_SOURCE = "exts_";

        public const string TIPO_EXTERNAL_TARGET = "PxExternalTarget";
        public const string DES_EXTERNAL_TARGET = "External Target";
        public const string PRE_EXTERNAL_TARGET = "extt_";

        public const string TIPO_FILE_SET = "PxFileSet";
        public const string DES_FILE_SET = "File Set";
        public const string PRE_FILE_SET = "fset_";

        public const string TIPO_LOOKUP_FILE_SET = "PxLookupFileSet";
        public const string DES_LOOKUP_FILE_SET = "Lookup File Set";
        public const string PRE_LOOKUP_FILE_SET = "lkf_";

        public const string TIPO_SAS = "PxSAS";
        public const string DES_SAS = "SAS";
        public const string PRE_SAS = "sas_";

        public const string TIPO_SEQUENTIAL_FILE = "PxSequentialFile";
        public const string DES_SEQUENTIAL_FILE = "Sequential File";
        public const string PRE_SEQUENTIAL_FILE = "seqf_";

        public const string TIPO_ZOSFILE = "PxzOSFile";
        public const string DES_ZOSFILE = "zOSFile";
        public const string PRE_ZOSFILE = "zosf_";

        //BASE DE DATOS
        public const string TIPO_CLASSIC_FEDERATION = "PXClassicFederation";
        public const string DES_CLASSIC_FEDERATION = "Classic Federation";
        public const string PRE_CLASSIC_FEDERATION = "clf_";

        public const string TIPO_DB2 = "DB2ConnectorPX";
        public const string TIPO_DB2_2 = "DB2Connector";
        public const string DES_DB2 = "DB2 conector";
        public const string PRE_DB2 = "db2_";

        public const string TIPO_UNS = "UnstructuredDataConnectorPX";
        public const string DES_UNS = "Unstructured Data";
        public const string PRE_UNS = "uns_";

        public const string TIPO_ODBC = "ODBCConnectorPX";
        public const string DES_ODBC = "ODBC conector";
        public const string PRE_ODBC = "odbc_";

        public const string TIPO_DISTRIBUTED_TRANSACTION = "DTStagePX";
        public const string DES_DISTRIBUTED_TRANSACTION = "Distributed Transaction";
        public const string PRE_DISTRIBUTED_TRANSACTION = "dit_";

        public const string TIPO_DRS_CONNECTOR = "DRSConnectorPX";
        public const string DES_DRS_CONNECTOR = "DRS_Connector";
        public const string PRE_DRS_CONNECTOR = "drs_";

        public const string TIPO_INFORMIX_ENTERPRISE = "PxInformixXPS";
        public const string DES_INFORMIX_ENTERPRISE = "Informix Enterprise";
        public const string PRE_INFORMIX_ENTERPRISE = "ixe_";

        public const string TIPO_IWAY_ENTERPRISE = "Pxiway";
        public const string DES_IWAY_ENTERPRISE = "iWay Enterprise";
        public const string PRE_IWAY_ENTERPRISE = "iwe_";

        public const string TIPO_NETEZZA_CONNECTOR = "NetezzaConnectorPX";
        public const string DES_NETEZZA_CONNECTOR = "Netezza Connector";
        public const string PRE_NETEZZA_CONNECTOR = "nzzc_";

        public const string TIPO_ODBC_CONNECTOR = "ODBCConnectorPX";
        public const string DES_ODBC_CONNECTOR = "ODBC Connector";
        public const string PRE_ODBC_CONNECTOR = "odbc_";

        public const string TIPO_ORACLE_CONNECTOR = "OracleConnectorPX";
        public const string DES_ORACLE_CONNECTOR = "Oracle Connector";
        public const string PRE_ORACLE_CONNECTOR = "ora_";

        public const string TIPO_REDBRICK_LOAD = "rdbloadPX";
        public const string DES_REDBRICK_LOAD = "RedBrick Load";
        public const string PRE_REDBRICK_LOAD = "rbl_";

        public const string TIPO_STORED_PROCEDURE = "STPPX";
        public const string DES_STORED_PROCEDURE = "Stored Procedure";
        public const string PRE_STORED_PROCEDURE = "stpr_";

        public const string TIPO_SYBASE_ENTERPRISE = "PxSybase";
        public const string DES_SYBASE_ENTERPRISE = "Sybase Enterprise";
        public const string PRE_SYBASE_ENTERPRISE = "sybe_";

        public const string TIPO_TERADATA_CONNECTOR = "TeradataConnectorPX";
        public const string DES_TERADATA_CONNECTOR = "Teradata Connector";
        public const string PRE_TERADATA_CONNECTOR = "tdc_";

        //CALIDAD DE DATOS
        public const string TIPO_DATA_RULES = "IADataRule";
        public const string DES_DATA_RULES = "Data Rules";
        public const string PRE_DATA_RULES = "dtr_";

        public const string TIPO_INVESTIGATE = "Investigate";
        public const string DES_INVESTIGATE = "Investigate";
        public const string PRE_INVESTIGATE = "inv_";

        public const string TIPO_MATCH_FREQUENCY = "MatchFrequency";
        public const string DES_MATCH_FREQUENCY = "Match Frequency";
        public const string PRE_MATCH_FREQUENCY = "mtf_";

        public const string TIPO_MNS = "MNS";
        public const string DES_MNS = "MNS";
        public const string PRE_MNS = "mns_";

        public const string TIPO_SQA = "SQA";
        public const string DES_SQA = "SQA";
        public const string PRE_SQA = "sqa_";

        public const string TIPO_STANDARDIZE = "Standardize";
        public const string DES_STANDARDIZE = "Standardize";
        public const string PRE_STANDARDIZE = "stz_";

        public const string TIPO_SURVIVE = "Survive";
        public const string DES_SURVIVE = "Survive";
        public const string PRE_SURVIVE = "svv_";

        //DESARROLLO y DEPURACION
        public const string TIPO_COLUMN_GENERATOR = "PxColumnGenerator";
        public const string DES_COLUMN_GENERATOR = "Column Generator";
        public const string PRE_COLUMN_GENERATOR = "col_";

        public const string TIPO_HEAD = "PxHead";
        public const string DES_HEAD = "Head";
        public const string PRE_HEAD = "hed_";

        public const string TIPO_PEEK = "PxPeek";
        public const string DES_PEEK = "Peek";
        public const string PRE_PEEK = "pek_";

        public const string TIPO_ROW_GENERATOR = "PxRowGenerator";
        public const string DES_ROW_GENERATOR = "Row Generator";
        public const string PRE_ROW_GENERATOR = "rog_";

        public const string TIPO_SAMPLE = "PxSample";
        public const string DES_SAMPLE = "Sample";
        public const string PRE_SAMPLE = "smp_";

        public const string TIPO_TAIL = "PxTail";
        public const string DES_TAIL = "Tail";
        public const string PRE_TAIL = "tal_";

        public const string TIPO_WRITE_RANGE_MAP = "PxWriteRangeMap";
        public const string DES_WRITE_RANGE_MAP = "Write Range Map";
        public const string PRE_WRITE_RANGE_MAP = "wrm_";

        //PROCESO
        public const string TIPO_AGGREGATOR = "PxAggregator";
        public const string DES_AGGREGATOR = "Aggregator";
        public const string PRE_AGGREGATOR = "agg_";

        public const string TIPO_BLOOMFILTER = "PxBLM";
        public const string DES_BLOOMFILTER = "Bloomfilter";
        public const string PRE_BLOOMFILTER = "bof_";

        public const string TIPO_CHANGE_APPLY = "PxChangeApply";
        public const string DES_CHANGE_APPLY = "Change Apply";
        public const string PRE_CHANGE_APPLY = "cha_";

        public const string TIPO_CHANGE_CAPTURE = "PxChangeCapture";
        public const string DES_CHANGE_CAPTURE = "Change Capture";
        public const string PRE_CHANGE_CAPTURE = "chg_";

        public const string TIPO_CHECKSUM = "PxChecksum";
        public const string DES_CHECKSUM = "Checksum";
        public const string PRE_CHECKSUM = "chs_";

        public const string TIPO_COMPARE = "PxCompare";
        public const string DES_COMPARE = "Compare";
        public const string PRE_COMPARE = "cmp_";

        public const string TIPO_COMPRESS = "PxCompress";
        public const string DES_COMPRESS = "Compress";
        public const string PRE_COMPRESS = "cms_";

        public const string TIPO_COPY = "PxCopy";
        public const string DES_COPY = "Copy";
        public const string PRE_COPY = "cpy_";

        public const string TIPO_DECOD = "PxDecode";
        public const string DES_DECOD = "Decod";
        public const string PRE_DECOD = "dcd_";

        public const string TIPO_DIFFERENCE = "PxDifference";
        public const string DES_DIFFERENCE = "Difference";
        public const string PRE_DIFFERENCE = "dif_";

        public const string TIPO_ENCODE = "PxEncode";
        public const string DES_ENCODE = "Encode";
        public const string PRE_ENCODE = "ecd_";

        public const string TIPO_EXPAND = "PxExpand";
        public const string DES_EXPAND = "Expand";
        public const string PRE_EXPAND = "exp_";

        public const string TIPO_EXTERNAL_FILTER = "PxExternalFilter";
        public const string DES_EXTERNAL_FILTER = "External Filter";
        public const string PRE_EXTERNAL_FILTER = "exf_";

        public const string TIPO_FILTER = "PxFilter";
        public const string DES_FILTER = "Filter";
        public const string PRE_FILTER = "fil_";

        public const string TIPO_FTP_ENTERPRISE = "PxFTP";
        public const string DES_FTP_ENTERPRISE = "FTP Enterprise";
        public const string PRE_FTP_ENTERPRISE = "ftp_";

        public const string TIPO_FUNNEL = "PxFunnel";
        public const string DES_FUNNEL = "Funnel";
        public const string PRE_FUNNEL = "fun_";

        public const string TIPO_GENERIC = "PxGeneric";
        public const string DES_GENERIC = "Generic";
        public const string PRE_GENERIC = "gnr_";

        public const string TIPO_JOIN = "PxJoin";
        public const string DES_JOIN = "Join";
        public const string PRE_JOIN = "jon_";

        public const string TIPO_LOOKUP = "PxLookup";
        public const string DES_LOOKUP = "Lookup";
        public const string PRE_LOOKUP = "lok_";

        public const string TIPO_MERGE = "PxMerge";
        public const string DES_MERGE = "Merge";
        public const string PRE_MERGE = "mrg_";

        public const string TIPO_MODIFY = "PxModify";
        public const string DES_MODIFY = "Modify";
        public const string PRE_MODIFY = "mdf_";

        public const string TIPO_PIVOT_1 = "PxPivot";
        public const string DES_PIVOT_1 = "Pivot";

        public const string TIPO_PIVOT_2 = "PivotPX";
        public const string DES_PIVOT_2 = "Pivot";
        public const string PRE_PIVOT = "pvt_";

        public const string TIPO_REMOVE_DUPLICATES = "PxRemDup";
        public const string DES_REMOVE_DUPLICATES = "Remove Duplicates";
        public const string PRE_REMOVE_DUPLICATES = "rmv_";

        public const string TIPO_SLOWLY_CHANGING_DIMENSION = "PxSCD";
        public const string DES_SLOWLY_CHANGING_DIMENSION = "Slowly Changing Dimension";
        public const string PRE_SLOWLY_CHANGING_DIMENSION = "scd_";

        public const string TIPO_SORT = "PxSort";
        public const string DES_SORT = "Sort";
        public const string PRE_SORT = "srt_";

        public const string TIPO_SURROGATE_KEY_GENERATOR = "PxSurrogateKeyGeneratorN";
        public const string DES_SURROGATE_KEY_GENERATOR = "Surrogate KeyGenerator ";
        public const string PRE_SURROGATE_KEY_GENERATOR = "skg_";

        public const string TIPO_SWITCH = "PxSwitch";
        public const string DES_SWITCH = "Switch";
        public const string PRE_SWITCH = "swc_";

        public const string OLETYPE_C_TRANSFORMER_STAGE = "CTransformerStage";
        public const string TIPO_TRANSFORMER = "CTransformerStage";
        public const string DES_TRANSFORMER = "Transformer";
        public const string PRE_TRANSFORMER = "tra_";

        public const string TIPO_WAVE_GENERATOR = "PxWaveGenerator";
        public const string DES_WAVE_GENERATOR = "Wave Generator";
        public const string PRE_WAVE_GENERATOR = "wvg_";

        //REEESTRUCTURACION
        public const string TIPO_COLUMN_EXPORT = "PxColumnExport";
        public const string DES_COLUMN_EXPORT = "Column Export";
        public const string PRE_COLUMN_EXPORT = "cex_";

        public const string TIPO_COLUMN_IMPORT = "PxColumnImport";
        public const string DES_COLUMN_IMPORT = "Column Import";
        public const string PRE_COLUMN_IMPORT = "cim_";

        public const string TIPO_COMBINE_RECORDS = "PxCombineRecords";
        public const string DES_COMBINE_RECORDS = "Combine Records";
        public const string PRE_COMBINE_RECORDS = "com_";

        public const string TIPO_MAKE_SUBRECORD = "PxMakeSubRec";
        public const string DES_MAKE_SUBRECORD = "Make Subrecord";
        public const string PRE_MAKE_SUBRECORD = "mks_";

        public const string TIPO_PROMOTE_SUBRECORD = "PxPromoteSubRec";
        public const string DES_PROMOTE_SUBRECORD = "Promote Subrecord";
        public const string PRE_PROMOTE_SUBRECORD = "pms_";

        public const string TIPO_SPLIT_SUBRECORD = "PxSplitSubRec";
        public const string DES_SPLIT_SUBRECORD = "Split Subrecord";
        public const string PRE_SPLIT_SUBRECORD = "sps_";

        public const string TIPO_SPLIT_VECTOR = "PxSplitVect";
        public const string DES_SPLIT_VECTOR = "Split Vector";
        public const string PRE_SPLIT_VECTOR = "spv_";

        //TIEMPO REAL 
        public const string TIPO_CDC_TRANSACTION = "CDCTStagePX";
        public const string DES_CDC_TRANSACTION = "CDC Transaction";
        public const string PRE_CDC_TRANSACTION = "cdc_";

        public const string TIPO_ISD_INPUT = "PxRTIInput";
        public const string DES_ISD_INPUT = "ISD Input";
        public const string PRE_ISD_INPUT = "isdi_";

        public const string TIPO_ISD_OUTPUT = "PxRTIOutput";
        public const string DES_ISD_OUTPUT = "ISD Output";
        public const string PRE_ISD_OUTPUT = "isdo_";

        public const string TIPO_WEB_SERVICES_CLIENT = "WSClientPX";
        public const string DES_WEB_SERVICES_CLIENT = "Web Services Client";
        public const string PRE_WEB_SERVICES_CLIENT = "wsc_";

        public const string TIPO_WEB_SERVICES_TRANSFORMER = "WSTransformerPX";
        public const string DES_WEB_SERVICES_TRANSFORMER = "Web Services Transformer";
        public const string PRE_WEB_SERVICES_TRANSFORMER = "wst_";

        public const string TIPO_WEBSPHERE_MQ_CONNECTOR = "WebSphereMQConnectorPX";
        public const string DES_WEBSPHERE_MQ_CONNECTOR = "WebSphere_MQ_Connector";
        public const string PRE_WEBSPHERE_MQ_CONNECTOR = "wmc_";

        public const string TIPO_XML_INPUT = "XMLInputPX";
        public const string DES_XML_INPUT = "XML Input";
        public const string PRE_XML_INPUT = "xmli_";

        public const string TIPO_XML_OUTPUT = "XMLOutputPX";
        public const string DES_XML_OUTPUT = "XML Output";
        public const string PRE_XML_OUTPUT = "xmlo_";

        public const string TIPO_XML_TRANSFORMER = "XMLTransformerPX";
        public const string DES_XML_TRANSFORMER = "XML Transformer";
        public const string PRE_XML_TRANSFORMER = "xmlt_";

        //SECUENCIA
        //--Documento
        public const string OLETYPE_CJS_END_LOOP_ACTIVITY = "CJSEndLoopActivity";
        public const string TIPO_END_LOOP_ACTIVITY = "CEndLoopActivity";
        public const string DES_END_LOOP_ACTIVITY = "EndLoopActivity";
        public const string PRE_END_LOOP_ACTIVITY = "acte_";

        public const string OLETYPE_CJS_EXCEPTION_HANDLER = "CJSExceptionHandler";
        public const string TIPO_EXCEPTION_HANDLER = "CExceptionHandler";
        public const string DES_EXCEPTION_HANDLER = "ExceptionHandler";
        public const string PRE_EXCEPTION_HANDLER = "exh_";

        public const string OLETYPE_CJS_EXEC_CMD_ACTIVITY = "CJSExecCmdActivity";
        public const string TIPO_EXECUTE_COMMAND = "CExecCommandActivity";
        public const string DES_EXECUTE_COMMAND = "ExecuteCommand";
        public const string PRE_EXECUTE_COMMAND = "exc_";

        public const string OLETYPE_CJS_JOB_ACTIVITY = "CJSJobActivity";
        public const string TIPO_JOB_ACTIVITY = "CJSJobActivity";//--SIN STAGETYPE Oletype CJSJobActivity 
        public const string DES_JOB_ACTIVITY = "JobActivity";        
        public const string PRE_JOB_ACTIVITY = "";// No tiene prefijo

        public const string OLETYPE_CJS_CONDITION = "CJSCondition";
        public const string TIPO_NESTED_CONDITION = "CCondition";
        public const string DES_NESTED_CONDITION = "NestedCondition";
        public const string PRE_NESTED_CONDITION = "nec_";

        public const string OLETYPE_CJS_MAIL_ACTIVITY = "CJSMailActivity";
        public const string TIPO_NOTIFICATION_ACTIVITY = "CNotificationActivity";
        public const string DES_NOTIFICATION_ACTIVITY = "NotificationActivity";
        public const string PRE_NOTIFICATION_ACTIVITY = "nact_";

        public const string OLETYPE_CJS_ROUTINE_ACTIVITY = "CJSRoutineActivity";
        public const string TIPO_ROUTINE_ACTIVITY = "CJSRoutineActivity";//--SIN STAGETYPE "CRoutineActivity";// Oletype CJSRoutineActivity
        public const string DES_ROUTINE_ACTIVITY = "RoutineActivity";
        public const string PRE_ROUTINE_ACTIVITY = "rta_";

        public const string OLETYPE_CJS_SEQUENCER = "CJSSequencer";
        public const string TIPO_SEQUENCER = "CSequencer";
        public const string DES_SEQUENCER = "Sequencer";
        public const string PRE_SEQUENCER = "seq_";

        public const string OLETYPE_CJS_START_LOOP_ACTIVIY = "CJSStartLoopActivity";
        public const string TIPO_START_LOOP_ACTIVITY = "CStartLoopActivity";
        public const string DES_START_LOOP_ACTIVITY = "StartLoopActivity";
        public const string PRE_START_LOOP_ACTIVITY = "acts_";

        public const string OLETYPE_CJS_TERMINATOR_ACTIVITY = "CJSTerminatorActivity";
        public const string TIPO_TERMINATOR_ACTIVITY = "CTerminatorActivity";
        public const string DES_TERMINATOR_ACTIVITY = "TerminatorActivity";
        public const string PRE_TERMINATOR_ACTIVITY = "err_";

        public const string OLETYPE_CJS_USER_VAR_ACTIVITY = "CJSUserVarsActivity";
        public const string TIPO_USER_VAR_ACTIVITY = "CUserVarsActivity";
        public const string DES_USER_VAR_ACTIVITY = "UserVarActivity";
        public const string PRE_USER_VAR_ACTIVITY = "var_";

        public const string OLETYPE_CJS_WAIT_FILE_ACTIVITY = "CJSWaitFileActivity";
        public const string TIPO_WAIT_FOR_FILE_ACTIVITY = "CWaitForFileActivity";
        public const string DES_WAIT_FOR_FILE_ACTIVITY = "WaitForFileActivity";
        public const string PRE_WAIT_FOR_FILE_ACTIVITY = "wfa_";

        public const string TIPO_STAGE_NO_DEFINIDO = "STAGE NO DEFINIDO";
        public const string DES_STAGE_NO_DEFINIDO = "STAGE NO DEFINIDO";


        public static List<string> getListaFuncionPermitida()
        {
            List<string> listaFuncionPermitida = new List<string>();

            //******************************* Transformrs ***********************************
            //Built-in
            //**Dates
            listaFuncionPermitida.Add("DATE.TAG");
            listaFuncionPermitida.Add("MONTH.FIRST");
            listaFuncionPermitida.Add("MONTH.LAST");
            listaFuncionPermitida.Add("MONTH.TAG");
            listaFuncionPermitida.Add("MONTH.TO.YEAR");
            listaFuncionPermitida.Add("QUARTER.FIRST");
            listaFuncionPermitida.Add("QUARTER.LAST");
            listaFuncionPermitida.Add("QUARTER.TAG");
            listaFuncionPermitida.Add("QUARTER.TO.YEAR");
            listaFuncionPermitida.Add("TAG.TO.DATE");
            listaFuncionPermitida.Add("TAG.TO.MONTH");
            listaFuncionPermitida.Add("TAG.TO.QUARTER");
            listaFuncionPermitida.Add("TAG.TO.WEEK");
            listaFuncionPermitida.Add("TAG.TO.YEAR");
            listaFuncionPermitida.Add("TIMESTAMP");
            listaFuncionPermitida.Add("TIMESTAMP.TO.DATE");
            listaFuncionPermitida.Add("TIMESTAMP.TO.TIME");
            listaFuncionPermitida.Add("WEEK.FIRST");
            listaFuncionPermitida.Add("WEEK.LAST");
            listaFuncionPermitida.Add("WEEK.TAG");
            listaFuncionPermitida.Add("YEAR.FIRST");
            listaFuncionPermitida.Add("YEAR.LAST");
            listaFuncionPermitida.Add("YEAR.TAG");
            //**Null
            listaFuncionPermitida.Add("NullToEmpty");
            listaFuncionPermitida.Add("NullToZero");
            //**Strings
            listaFuncionPermitida.Add("CAPITALS");
            listaFuncionPermitida.Add("DIGITS");
            listaFuncionPermitida.Add("LETTERS");

            //sdk
            //**Data Type
            listaFuncionPermitida.Add("DataTypeAsciiPic9");
            listaFuncionPermitida.Add("DataTypeAsciiPic9V9");
            listaFuncionPermitida.Add("DataTypeAsciiPic9V99");
            listaFuncionPermitida.Add("DataTypeAsciiPic9V999");
            listaFuncionPermitida.Add("DataTypeAsciiPic9V9999");
            listaFuncionPermitida.Add("DataTypeAsciiToEbcdic");
            listaFuncionPermitida.Add("DataTypeEbcdicPic9");
            listaFuncionPermitida.Add("DataTypeEbcdicPic9V9");
            listaFuncionPermitida.Add("DataTypeEbcdicPic9V99");
            listaFuncionPermitida.Add("DataTypeEbcdicPic9V999");
            listaFuncionPermitida.Add("DataTypeEbcdicPic9V9999");
            listaFuncionPermitida.Add("DataTypeEbcdicToAscii");
            listaFuncionPermitida.Add("DataTypePic9");
            listaFuncionPermitida.Add("DataTypePic9V9");
            listaFuncionPermitida.Add("DataTypePic9V99");
            listaFuncionPermitida.Add("DataTypePic9V999");
            listaFuncionPermitida.Add("DataTypePic9V9999");
            listaFuncionPermitida.Add("DataTypePicComp");
            listaFuncionPermitida.Add("DataTypePicComp1");
            listaFuncionPermitida.Add("DataTypePicComp2");
            listaFuncionPermitida.Add("DataTypePicComp3");
            listaFuncionPermitida.Add("DataTypePicComp3Unsigned");
            listaFuncionPermitida.Add("DataTypePicComp3UnsignedFast");
            listaFuncionPermitida.Add("DataTypePicComp3V9");
            listaFuncionPermitida.Add("DataTypePicComp3V99");
            listaFuncionPermitida.Add("DataTypePicComp3V9999");
            listaFuncionPermitida.Add("DataTypePicComp3V9999");
            listaFuncionPermitida.Add("DataTypePicCompUnsigned");
            listaFuncionPermitida.Add("DataTypePicS9");
            //**Date
            listaFuncionPermitida.Add("DateCurrentDateTime");
            listaFuncionPermitida.Add("DateCurrentGMTTime");
            listaFuncionPermitida.Add("DateCurrentSwatchTime");
            listaFuncionPermitida.Add("DateDaysSince1900ToTimeStamp");
            listaFuncionPermitida.Add("DateDaysSince1970ToTimeStamp");
            //**Date **Generic
            listaFuncionPermitida.Add("DateGenericDateDiff");
            listaFuncionPermitida.Add("DateGenericGetDay");
            listaFuncionPermitida.Add("DateGenericGetMonth");
            listaFuncionPermitida.Add("DateGenericGetTime");
            listaFuncionPermitida.Add("DateGenericGetTimeHour");
            listaFuncionPermitida.Add("DateGenericGetTimeMinute");
            listaFuncionPermitida.Add("DateGenericGetTimeSecond");
            listaFuncionPermitida.Add("DateGenericGetYear");
            listaFuncionPermitida.Add("DateGenericIsDate");
            listaFuncionPermitida.Add("DateGenericToDaysSince1900");
            listaFuncionPermitida.Add("DateGenericToDaysSince1970");
            listaFuncionPermitida.Add("DateGenericToDaysSinceToday");
            listaFuncionPermitida.Add("DateGenericToInfCLI");
            listaFuncionPermitida.Add("DateGenericToInfCLIWithTime");
            listaFuncionPermitida.Add("DateGenericToInternal");
            listaFuncionPermitida.Add("DateGenericToInternalWithTime");
            listaFuncionPermitida.Add("DateGenericToODBC");
            listaFuncionPermitida.Add("DateGenericToODBCWithTime");
            listaFuncionPermitida.Add("DateGenericToOraOCI");
            listaFuncionPermitida.Add("DateGenericToOraOCIWithTime");
            listaFuncionPermitida.Add("DateGenericToSybaseOC");
            listaFuncionPermitida.Add("DateGenericToSybaseOCWithTime");
            listaFuncionPermitida.Add("DateGenericToTimeStamp");
            //**Date **YearFirst
            listaFuncionPermitida.Add("DateYearFirstDiff");
            listaFuncionPermitida.Add("DateYearFirstGetDay");
            listaFuncionPermitida.Add("DateYearFirstGetMonth");
            listaFuncionPermitida.Add("DateYearFirstGetTime");
            listaFuncionPermitida.Add("DateYearFirstGetTimeHour");
            listaFuncionPermitida.Add("DateYearFirstGetTimeMinute");
            listaFuncionPermitida.Add("DateYearFirstGetTimeSecond");
            listaFuncionPermitida.Add("DateYearFirstGetYear");
            listaFuncionPermitida.Add("DateYearFirstIsDate");
            listaFuncionPermitida.Add("DateYearFirstToDaysSince1900");
            listaFuncionPermitida.Add("DateYearFirstToDaysSince1970");
            listaFuncionPermitida.Add("DateYearFirstToDaysSinceToday");
            listaFuncionPermitida.Add("DateYearFirstToInfCLI");
            listaFuncionPermitida.Add("DateYearFirstToInfCLIWithTime");
            listaFuncionPermitida.Add("DateYearFirstToInternal");
            listaFuncionPermitida.Add("DateYearFirstToInternalWithTime");
            listaFuncionPermitida.Add("DateYearFirstToODBC");
            listaFuncionPermitida.Add("DateYearFirstToODBCWithTime");
            listaFuncionPermitida.Add("DateYearFirstToOraOCI");
            listaFuncionPermitida.Add("DateYearFirstToOraOCIWithTime");
            listaFuncionPermitida.Add("DateYearFirstToSybaseOC");
            listaFuncionPermitida.Add("DateYearFirstToSybaseOCWithTime");
            listaFuncionPermitida.Add("DateYearFirstToTimeStamp");
            //**KeyMgt
            listaFuncionPermitida.Add("KeyMgtGetNextValue");
            listaFuncionPermitida.Add("keyMgtGetNextValueConcurrent");
            //**Measure ** Area
            listaFuncionPermitida.Add("MeasureAreaAcresToSqFeet");
            listaFuncionPermitida.Add("MeasureAreaAcresToSqMeters");
            listaFuncionPermitida.Add("MeasureAreaSqFeetToAcres");
            listaFuncionPermitida.Add("MeasureAreaSqFeetToSqInches");
            listaFuncionPermitida.Add("MeasureAreaSqFeetToSqMeters");
            listaFuncionPermitida.Add("MeasureAreaSqFeetToSqMiles");
            listaFuncionPermitida.Add("MeasureAreaSqFeetToSqYards");
            listaFuncionPermitida.Add("MeasureAreaSqInchesToSqFeet");
            listaFuncionPermitida.Add("MeasureAreaSqInchesToSqMeters");
            listaFuncionPermitida.Add("MeasureAreaMetersToAcres");
            listaFuncionPermitida.Add("MeasureAreaMetersToSqFeet");
            listaFuncionPermitida.Add("MeasureAreaMetersToSqInches");
            listaFuncionPermitida.Add("MeasureAreaMetersToSqMiles");
            listaFuncionPermitida.Add("MeasureAreaMetersToSqYards");
            listaFuncionPermitida.Add("MeasureAreaMilesToSqFeet");
            listaFuncionPermitida.Add("MeasureAreaMilesToSqKilometers");
            listaFuncionPermitida.Add("MeasureAreaSqYardsToSqFeet");
            listaFuncionPermitida.Add("MeasureAreaSqYardsToSqMeters");
            //**Measure ** Distance
            listaFuncionPermitida.Add("MeasureDistanceFeetToInches");
            listaFuncionPermitida.Add("MeasureDistanceFeetToMeters");
            listaFuncionPermitida.Add("MeasureDistanceFeetToMiles");
            listaFuncionPermitida.Add("MeasureDistanceFeetToYards");
            listaFuncionPermitida.Add("MeasureDistanceInchesToFeet");
            listaFuncionPermitida.Add("MeasureDistanceInchesToMeters");
            listaFuncionPermitida.Add("MeasureDistanceInchesToMiles");
            listaFuncionPermitida.Add("MeasureDistanceInchesToYards");
            listaFuncionPermitida.Add("MeasureDistanceMetersToFeet");
            listaFuncionPermitida.Add("MeasureDistanceMetersToInches");
            listaFuncionPermitida.Add("MeasureDistanceMetersToMiles");
            listaFuncionPermitida.Add("MeasureDistanceMetersToYards");
            listaFuncionPermitida.Add("MeasureDistanceMilesToFeet");
            listaFuncionPermitida.Add("MeasureDistanceMilesToInches");
            listaFuncionPermitida.Add("MeasureDistanceMilesToMeters");
            listaFuncionPermitida.Add("MeasureDistanceMilesToYards");
            listaFuncionPermitida.Add("MeasureDistanceYardsToFeet");
            listaFuncionPermitida.Add("MeasureDistanceYardsToInches");
            listaFuncionPermitida.Add("MeasureDistanceYardsToMeters");
            listaFuncionPermitida.Add("MeasureDistanceYardsToMiles");
            //**Measure **Temp
            listaFuncionPermitida.Add("MeasureTempCelsiusToFahrenheit");
            listaFuncionPermitida.Add("MeasureTempFahrenheitToCelsius");
            //**Measure **Time
            listaFuncionPermitida.Add("MeasureTimeDaysToSeconds");
            listaFuncionPermitida.Add("MeasureTimeHoursToSeconds");
            listaFuncionPermitida.Add("MeasureTimeIsLeapYear");
            listaFuncionPermitida.Add("MeasureTimeMinutesToSeconds");
            listaFuncionPermitida.Add("MeasureTimeSecondsToDays");
            listaFuncionPermitida.Add("MeasureTimeSecondsToHours");
            listaFuncionPermitida.Add("MeasureTimeSecondsToMinutes");
            listaFuncionPermitida.Add("MeasureTimeSecondsToWeeks");
            listaFuncionPermitida.Add("MeasureTimeSecondsToYears");
            listaFuncionPermitida.Add("MeasureTimeWeeksToSeconds");
            listaFuncionPermitida.Add("MeasureTimeYearsToSeconds");
            //**Measure **Volume
            listaFuncionPermitida.Add("MeasureVolumeBarrelsLiquidToCubicFeet");
            listaFuncionPermitida.Add("MeasureVolumeBarrelsLiquidToGallons");
            listaFuncionPermitida.Add("MeasureVolumeBarrelsLiquidToLiters");
            listaFuncionPermitida.Add("MeasureVolumeBarrelsPetroToCubicFeet");
            listaFuncionPermitida.Add("MeasureVolumeBarrelsPetroToGallons");
            listaFuncionPermitida.Add("MeasureVolumeBarrelsPetroToLiters");
            listaFuncionPermitida.Add("MeasureVolumeCubicFeetToBarrelsLiquid");
            listaFuncionPermitida.Add("MeasureVolumeCubicFeetToBarrelsPetro");
            listaFuncionPermitida.Add("MeasureVolumeCubicFeetToGallons");
            listaFuncionPermitida.Add("MeasureVolumeCubicFeetToImpGallons");
            listaFuncionPermitida.Add("MeasureVolumeCubicFeetToLiters");
            listaFuncionPermitida.Add("MeasureVolumeGallonsToBarrelsLiquid");
            listaFuncionPermitida.Add("MeasureVolumeGallonsToBarrelsPetro");
            listaFuncionPermitida.Add("MeasureVolumeGallonsToCubicFeet");
            listaFuncionPermitida.Add("MeasureVolumeGallonsToLiters");
            listaFuncionPermitida.Add("MeasureVolumeImpGallonsToCubicFeet");
            listaFuncionPermitida.Add("MeasureVolumeImpGallonsToLiters");
            listaFuncionPermitida.Add("MeasureVolumeLitersToBarrelsLiquid");
            listaFuncionPermitida.Add("MeasureVolumeLitersToBarrelsPetro");
            listaFuncionPermitida.Add("MeasureVolumeLitersToCubicFeet");
            listaFuncionPermitida.Add("MeasureVolumeLitersToGallons");
            listaFuncionPermitida.Add("MeasureVolumeLitersToImpGallons");
            //**Measure **Weight
            listaFuncionPermitida.Add("MeasureWeightGrainsToGrams");
            listaFuncionPermitida.Add("MeasureWeightGramsToGrains");
            listaFuncionPermitida.Add("MeasureWeightGramsToOunces");
            listaFuncionPermitida.Add("MeasureWeightGramsToPennyWeight");
            listaFuncionPermitida.Add("MeasureWeightGramsToPounds");
            listaFuncionPermitida.Add("MeasureWeightKilogramsToLongTons");
            listaFuncionPermitida.Add("MeasureWeightKilogramsToShortTons");
            listaFuncionPermitida.Add("MeasureWeightLongTonsToKilograms");
            listaFuncionPermitida.Add("MeasureWeightLongTonsToPounds");
            listaFuncionPermitida.Add("MeasureWeightOuncesToGrams");
            listaFuncionPermitida.Add("MeasureWeightPennyWeightToGrams");
            listaFuncionPermitida.Add("MeasureWeightPoundsToGrams");
            listaFuncionPermitida.Add("MeasureWeightPoundsToLongTons");
            listaFuncionPermitida.Add("MeasureWeightPoundsToShortTons");
            listaFuncionPermitida.Add("MeasureWeightShortTonsToKilograms");
            listaFuncionPermitida.Add("MeasureWeightTonsToPounds");
            //**Numeric
            listaFuncionPermitida.Add("NumericIsSigned");
            listaFuncionPermitida.Add("NumericRound0");
            listaFuncionPermitida.Add("NumericRound1");
            listaFuncionPermitida.Add("NumericRound2");
            listaFuncionPermitida.Add("NumericRound3");
            listaFuncionPermitida.Add("NumericRound4");
            //**RowPoc
            listaFuncionPermitida.Add("RowProcCompareWithPreviousValue");
            listaFuncionPermitida.Add("RowProcGetPreviousValue");
            listaFuncionPermitida.Add("RowProcRunningTotal");
            //**String
            listaFuncionPermitida.Add("StringDecode");
            listaFuncionPermitida.Add("StringIsSpace");
            listaFuncionPermitida.Add("StringLeftJust");
            listaFuncionPermitida.Add("StringRightJust");
            listaFuncionPermitida.Add("StringUpperFirst");
            //**Utility
            listaFuncionPermitida.Add("UtilityAbortToLog");
            listaFuncionPermitida.Add("UtilityGetRunJobInfo");
            listaFuncionPermitida.Add("UtilityHashLookup");
            listaFuncionPermitida.Add("UtilityMessageToLog");
            listaFuncionPermitida.Add("UtilityPrintColumnValueToLog");
            listaFuncionPermitida.Add("UtilityPrintHexValueToLog");
            listaFuncionPermitida.Add("UtilityRunJob");
            listaFuncionPermitida.Add("UtilityWarningToLog");


            //Conversión
            listaFuncionPermitida.Add("Ascii");
            listaFuncionPermitida.Add("Char");
            listaFuncionPermitida.Add("Checksum");
            listaFuncionPermitida.Add("CRC32");
            listaFuncionPermitida.Add("Dtx");
            listaFuncionPermitida.Add("Ebcdic");
            listaFuncionPermitida.Add("Iconv");
            listaFuncionPermitida.Add("Oconv");
            listaFuncionPermitida.Add("Seq");
            listaFuncionPermitida.Add("Soundex");
            listaFuncionPermitida.Add("UniChar");
            listaFuncionPermitida.Add("UniSeq");
            listaFuncionPermitida.Add("Xtd");
            //Date & Time
            listaFuncionPermitida.Add("Date");
            listaFuncionPermitida.Add("Time");
            listaFuncionPermitida.Add("TimeDate");
            //Lógica
            listaFuncionPermitida.Add("Not");
            //Matemática
            listaFuncionPermitida.Add("Abs");
            listaFuncionPermitida.Add("Acos");
            listaFuncionPermitida.Add("Asin");
            listaFuncionPermitida.Add("Atan");
            listaFuncionPermitida.Add("Cos");
            listaFuncionPermitida.Add("Cosh");
            listaFuncionPermitida.Add("Div");
            listaFuncionPermitida.Add("Exp");
            listaFuncionPermitida.Add("Ln");
            listaFuncionPermitida.Add("Mod");
            listaFuncionPermitida.Add("Neg");
            listaFuncionPermitida.Add("Pwr");
            listaFuncionPermitida.Add("Rnd");
            listaFuncionPermitida.Add("Sin");
            listaFuncionPermitida.Add("Sinh");
            listaFuncionPermitida.Add("Sqrt");
            listaFuncionPermitida.Add("Tan");
            listaFuncionPermitida.Add("Tanh");
            //Null Handling
            listaFuncionPermitida.Add("IsNull");
            //Número
            listaFuncionPermitida.Add("Fix");
            listaFuncionPermitida.Add("Int");
            listaFuncionPermitida.Add("Real");
            //Serie
            listaFuncionPermitida.Add("Alpha");
            listaFuncionPermitida.Add("Cats");
            listaFuncionPermitida.Add("Change");
            listaFuncionPermitida.Add("Compare");
            listaFuncionPermitida.Add("Convert");
            listaFuncionPermitida.Add("Count");
            listaFuncionPermitida.Add("Dcount");
            listaFuncionPermitida.Add("DownCase");
            listaFuncionPermitida.Add("DQuote");
            listaFuncionPermitida.Add("Ereplace");
            listaFuncionPermitida.Add("Exchange");
            listaFuncionPermitida.Add("Extract");
            listaFuncionPermitida.Add("Field");
            listaFuncionPermitida.Add("FieldStore");
            listaFuncionPermitida.Add("Fmt");
            listaFuncionPermitida.Add("FmtDP");
            listaFuncionPermitida.Add("Fold");
            listaFuncionPermitida.Add("FoldDP");
            listaFuncionPermitida.Add("Index");
            listaFuncionPermitida.Add("Left");
            listaFuncionPermitida.Add("Len");
            listaFuncionPermitida.Add("LenDP");
            listaFuncionPermitida.Add("MatchField");
            listaFuncionPermitida.Add("Num");
            listaFuncionPermitida.Add("Remove");
            listaFuncionPermitida.Add("Right");
            listaFuncionPermitida.Add("Space");
            listaFuncionPermitida.Add("Squote");
            listaFuncionPermitida.Add("Str");
            listaFuncionPermitida.Add("Substrings");
            listaFuncionPermitida.Add("Trim");
            listaFuncionPermitida.Add("TrimB");
            listaFuncionPermitida.Add("TrimF");
            listaFuncionPermitida.Add("UpCase");
            //Systema
            listaFuncionPermitida.Add("Status");

            return listaFuncionPermitida;
        }
    }
}
