﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;

namespace ValidadorSES.util
{
    public class ConstanteBusqueda
    {
        public const string PROP_STAGE_NOMBRE = "Nombre de Stage";

        public const string PROP_STAGE_DB_TABLA = "Tablas";
        public const string PROP_STAGE_ARCHIVO_FILE = "Nombre de archivo";

        public static List<FiltroBusqueda> getListaPropiedadesFiltroStageBD(FiltroBusqueda filtroPadre) 
        {
            List<FiltroBusqueda> lista = new List<FiltroBusqueda>();

            lista.Add(new FiltroBusqueda(PROP_STAGE_DB_TABLA, PROP_STAGE_DB_TABLA, true, filtroPadre));

            return lista;
        }

        public static List<FiltroBusqueda> getListaPropiedadesFiltroStageArchivo(FiltroBusqueda filtroPadre)
        {
            List<FiltroBusqueda> lista = new List<FiltroBusqueda>();

            lista.Add(new FiltroBusqueda(PROP_STAGE_ARCHIVO_FILE, PROP_STAGE_ARCHIVO_FILE, true, filtroPadre));

            return lista;
        }
    }
}
