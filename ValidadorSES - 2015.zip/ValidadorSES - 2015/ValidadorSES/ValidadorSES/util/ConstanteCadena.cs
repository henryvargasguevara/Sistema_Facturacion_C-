﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    class ConstanteCadena
    {        
        //mensajes

        //validacion interfaz de usuario
        public const string MSG_VAL_ARCHIVO_DSX = "Debe ingresar un archivo .dsx válido.";
        public const string MSG_VAL_ARCHIVO_DSX_ADICIONAL = "Debe ingresar un archivo adicional .dsx válido.";
        public const string MSG_VAL_REQUERIMIENTO = "Debe seleccionar un Requerimiento.";
        public const string MSG_VAL_ARCHIVO_ENV = "Debe ingresar un archivo .env válido.";
        public const string MSG_VAL_ARCHIVO_SQL = "Debe ingresar un arvhivo .sql válido."; //JT        
        public const string MSG_VAL_KEYWORD = "Debe ingresar una Palabra clave.";

        //validación del job public const string MSG_VAL_ = "";
        public const string MSG_VAL_JOB_DESCRIPCION = "No existe documentación interna del Job " + ConstanteChk.CHK07;
        public const string MSG_VAL_JOB_DESCRIPCION_BREVE = "No existe descripción breve del Job " + ConstanteChk.CHK07;
        public const string MSG_VAL_JOB_OBJETIVO = "No existe descripción del objetivo del Job " + ConstanteChk.CHK07;
        public const string MSG_VAL_JOB_PUNTO_COMPROBACION = "El Check de la malla padre no está marcado " + ConstanteChk.CHK12;
        public const string MSG_VAL_JOB_NOMBRE_NO_COINCIDE = "Nombre del Job y nombre de la documentación no coinciden " + ConstanteChk.CHK07;
        public const string MSG_VAL_JOB_NOMBRE_INCORRECTO = "Nombre del Job no se encuentra en la documentacion interna " + ConstanteChk.CHK07;
        public const string MSG_VAL_JOB_VERSION_NO_EXISTE = "Falta completar la version del job en la descripción interna " + ConstanteChk.CHK07;
        public const string MSG_VAL_JOB_TRANSFORMER = "Se encontró el stage Transformer en el Job " + ConstanteChk.BP1;

        public const string MSG_VAL_JOB_CONEXIONES = "Se encontraron más de 5 conectores (DB2/ODBC)" + ConstanteChk.BP1;
        public const string MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA = "El prefijo del nombre de la carpeta de Frecuencia de carga(PC, ST, CS, CM, RP, DEL) es incorrecto " + ConstanteChk.BP1;
        
        public const string MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA_NO_EXISTE = "No se encuentra carpeta de Frecuencia de carga (PC, ST, CS, CM, RP) " + ConstanteChk.BP1;
        public const string MSG_VAL_JOB_NOM_CARPETA_SUB_PRINCIPAL_PROCESO_ETL = "El prefijo del nombre de la carpeta es incorrecto " + ConstanteChk.BP1;
        public const string MSG_VAL_JOB_NOM_CARPETA_SUB_PRINCIPAL_PROCESO_ETL_2 = "El prefijo del nombre de la carpeta del Job no cumple la nomenclatura" + ConstanteChk.BP1;
        public const string MSG_VAL_JOB_NOM_INCORRECTO = "El nombre del Job es incorrecto " + ConstanteChk.BP1;
        public const string MSG_VAL_JOB_NOM_SUFIJO_INVALIDO = "El sufijo del nombre del Job es incorrecto" + ConstanteChk.BP1;

        public const string MSG_VAL_JOB_OPCION_COMPILACION_PUNTO_COMPROBACION_MALLA_PADRE = "El job no debe tener ACTIVADO el check de Punto de comprobación" + ConstanteChk.CHK12;
        public const string MSG_VAL_JOB_OPCION_COMPILACION_REGISTRAR_AVISO = "El job debe tener ACTIVADO el check de Registrar avisos " + ConstanteChk.BP1;
        public const string MSG_VAL_JOB_OPCION_COMPILACION_REGISTRAR_MENSAJE = "El job debe tener ACTIVADO el check de Registrar mensajes de informe " + ConstanteChk.BP1;

//        public const string MSG_VAL_JOB_ELIMINACION_DATASET = "No se encuentra routine " + ConstanteDataStage.ROUTINE_DELETE_DATASET+ " en el job";
        public const string MSG_VAL_JOB_ELIMINACION_DATASET = "No se encuentra routine de eliminación de Dataset en el job " + ConstanteChk.CHK08;
        public const string MSG_VAL_JOB_ELIMINACION_DATASET_EMPIZA = "La rutina no comienza con el prefijo [rts]." + ConstanteChk.CHK07;  //JT

        //validacion de los stage public const string MSG_VAL_STAGE_
        public const string MSG_VAL_STAGE_NOMENCLATURA_COMIENZA_NUM = "El nombre del Stage comienza con numeros " + ConstanteChk.CHK14;
        public const string MSG_VAL_STAGE_NOMENCLATURA_PREFIJO = "El nombre no comienza con el prefijo";
        public const string MSG_VAL_STAGE_NOMENCLATURA_CONTIENE_MINUSCULA = "El nombre del stage contiene minúsculas ";

        public const string MSG_VAL_STAGE_PROPIEDAD_METHOD = "La propiedad Method no se encuentra en [sort] " + ConstanteChk.CHK21;


        public const string MSG_VAL_STAGE_JOB_ACTIVITY_SUFIJO_INCORRECTO = "Nombre del stage incorrecto";
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_NOMBRE_INCORRECTO = "Nombre interno del JobActivity incorrecto";
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_ERROR_REFERENCIA = "No tiene Referencia a otro Job";
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE = "El desencadenante de la condicion contraria no esta enlazada a un TerminatorActivity " + ConstanteChk.CHK10;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_NO_CONDICION_CONTRARIA = "No se encontro desencadenante de tipo condición contraria " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_CORRECTO = "No se encontro desencadenante de tipo Correcto " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL = "La salida del NotificationActivity debe ser de tipo TerminatorActivity "+ ConstanteChk.CHK10;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL_0_SALIDA = "La salida del NotificationActivity no esta enlazado a un TerminatorActivity " + ConstanteChk.CHK10;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_MAIL_N_SALIDA = "La salida del NotificationActivity debe terminar en un stage de tipo TerminatorActivity " + ConstanteChk.CHK10;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DESENCADENANTE_NO_PERMITIDO = "Se encuentra tipo de desencadenante diferente a Condición contraria o Correcto " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_SUFIJO_INVALIDO = "El sufijo del JobActivity es inválido " ;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_PARAM = "Revisar los parámetros del Stage Activity con su respectivo Job paralelo";
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_PARAM_NO_EXISTE_JOB = "Es necesario exportar el Job para poder validar correctamente los parámetros";
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_DEPENDENCIA_DUPLI = "Se encontraron dependencias duplicadas en la documentación. " + ConstanteChk.CHK07;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_MAIL = "El asunto del NotificationActivity no sigue el formato establecido " + ConstanteChk.CHK13;

        public const string MSG_VAL_STAGE_JOB_ACTIVITY_ACCION_EJECUCION_NO_EXISTE = "No se encontró la propiedad Acción de Ejecución " + ConstanteChk.CHK12;
        public const string MSG_VAL_STAGE_JOB_ACTIVITY_ACCION_EJECUCION_NO_REESTABLECER_LUEGO_EJECUTAR = "La Acción de Ejecución no tiene seleccionada la opción Reestablecer si es necesario y, a continuación, ejecutar " + ConstanteChk.CHK12;

        public const string MSG_VAL_STAGE_TERMINATOR_ACTIVITY_DESCRIPCION = "Hay descripciones dentro del TerminatorActivity";

        public const string MSG_VAL_STAGE_TRANSFORMER_NOMENCLATURA_STAGE_VARIABLE = "Nomenclatura de los Stage variables incorrecto " + ConstanteChk.CHK14;
        public const string MSG_VAL_STAGE_TRANSFORMER_NOMENCLATURA_LOOP_VARIABLE = "Nomenclatura de los Loop variables incorrecto " + ConstanteChk.CHK14;

        public const string MSG_VAL_STAGE_ARCHIVO_PARAMETRIZACION_DIRECTORIO = "El directorio del archivo no se encuentra parametrizado " + ConstanteChk.CHK15;

        public const string MSG_VAL_STAGE_ARCHIVO_SALTO_LINEA = "El nombre del archivo tiene salto de linea " + ConstanteChk.CHK14;
        public const string MSG_VAL_STAGE_ARCHIVO_INVALIDO = "El nombre del archivo es inválido " + ConstanteChk.CHK14;
        public const string MSG_VAL_STAGE_ARCHIVO_EXTENSION_INVALIDO = "La extensión del archivo es inválido " + ConstanteChk.CHK14;
        public const string MSG_VAL_STAGE_ARCHIVO_MINUSCULAS = "El nombre del archivo contiene minúsculas " + ConstanteChk.CHK14;
        public const string MSG_VAL_STAGE_ARCHIVO_SUFIJO_INVALIDO = "El sufijo del archivo es inválido " + ConstanteChk.CHK14;
        //public const string MSG_VAL_STAGE_ARCHIVO_NOMBRE_INCORRECTO = "El nombre del archivo no coincide con el stage";

        public const string MSG_VAL_STAGE_DB2_BEFORE_AFTER = "La propiedad Before/After SQL está en SI " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_KEEP_CONDUCTOR_CONNECTION_ALIVE = "La propiedad KeepConductorConnectionAlive está en SI " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_OPERADOR_ORCHESTRATE = "Operador ORCHESTRATE " + ConstanteChk.CHK19;
        public const string MSG_VAL_STAGE_DB2_LIMITE_RESULTADO = "La Query contiene un FETCH FIRST " + ConstanteChk.CHK19;
        public const string MSG_VAL_STAGE_DB2_COMENTARIOS = "El Stage contiene comentarios de base de datos " + ConstanteChk.CHK20;
        public const string MSG_VAL_STAGE_DB2_SELECT_ALL = "La Query tiene un SELECT * " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_FUNCTION = "La Query contiene la función";
        public const string MSG_VAL_STAGE_DB2_OPERADOR = "La Query contiene el operador";
        public const string MSG_VAL_STAGE_DB2_LINAJE = "No todos los campos contemplan el Table Definition para el proceso de Linaje de Datos" + ConstanteChk.CHK32;

        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_TABLA_INCORRECTO = "El nombre de la tabla es incorrecta " + ConstanteChk.CHK14;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_NO_EXISTE = "No se halla esquema parametrizado perteneciente a la tabla " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA = "El esquema no se encuentra parametrizado correctamente " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_PARAMETER_SET_INCORRECTO = "El ParameterSet del esquema es incorrecto " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_ESQUEMA_VARIABLE_INCORRECTO = "La variable de entorno del esquema es incorrecta " + ConstanteChk.CHK15;

        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE_PARAMETER_SET_INCORRECTO = "El ParameterSet de la base de datos es incorrecto " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE_VARIABLE_INCORRECTO = "La variable de entorno de la base de datos es incorrecta " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE = "La base de datos no se encuentra parametrizada correctamente " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_DATABASE_NO_EXISTE = "No se halla base de datos parametrizada " + ConstanteChk.CHK15;

        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME_PARAMETER_SET_INCORRECTO = "El ParameterSet del username es incorrecto " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME_VARIABLE_INCORRECTO = "La variable de entorno del username es incorrecta " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME = "El username no se encuentra parametrizado correctamente " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_USERNAME_NO_EXISTE = "No se halla username parametrizado " + ConstanteChk.CHK15;

        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD_PARAMETER_SET_INCORRECTO = "El ParameterSet del password es incorrecto " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD_VARIABLE_INCORRECTO = "La variable de entorno del password es incorrecta " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD = "El password no se encuentra parametrizado correctamente " + ConstanteChk.CHK15;
        public const string MSG_VAL_STAGE_DB2_PARAMETRIZACION_PASSWORD_NO_EXISTE = "No se halla password parametrizado " + ConstanteChk.CHK15;

        public const string MSG_VAL_STAGE_ROUTINE_DESCRIPCION_NO_EXISTE = "Los parámetros de la rutina no tiene descripción " + ConstanteChk.CHK07;
        public const string MSG_VAL_STAGE_ROUTINE_ACTIVITY_DESENCADENANTE = "El desencadenante del RoutineActivity de condición contraria no esta enlazado a un TerminatorActivity " + ConstanteChk.CHK10;

        public const string MSG_VAL_STAGE_DB2_WRITE_MODE_DELETE = "La propiedad WriteMode tiene seleccionada la opción DELETE " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_WRITE_MODE_DELETE_THEN_INSERT = "La propiedad WriteMode tiene seleccionada la opción DELETE THEN INSERT " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_SENTENCIA_DELETE = "Sentencia Delete " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_RBTL_NO_EXISTE = "No se encuentra el job con el patrón DEL_RBTL_NOMBRE_TABLA " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_WBTL_NO_EXISTE = "No se encuentra el job con el patrón DEL_WBTL_NOMBRE_TABLA " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_SEQ_DEL_NO_EXISTE = "No se encuentra el job con el patrón SEQ_DEL_NOMBRE_TABLA " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_RBTL_MUCHOS = "Se encuentra más de un job con el patrón DEL_RBTL_NOMBRE_TABLA " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_DEL_WBTL_MUCHOS = "Se encuentra más de un job con el patrón DEL_WBTL_NOMBRE_TABLA " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_ELIMINACION_DATA_ERROR_JOB_SEQ_DEL_MUCHOS = "Se encuentra más de un job con el patrón SEQ_DEL_NOMBRE_TABLA " + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_RECORD_COUNT_PERMITIDO = "La propiedad Record Count no tiene el valor de " + ConstanteDataStage.PROPIEDAD_DB2_RECORD_COUNT_PERMITIDO + ConstanteChk.BP1;
        public const string MSG_VAL_STAGE_DB2_LOCK_WAIT_MODE = "La propiedad LockWaitMode no se encuentra en [Use the look timeout database configuration parameter] " + ConstanteChk.BP1; //JT
        public const string MSG_VAL_STAGE_DB2_ARRAY_SIZE = "La propiedad Array Size no tiene el valor de " + ConstanteDataStage.PROPIEDAD_DB2_ARRAY_SIZE + ConstanteChk.BP1; //JT
        public const string MSG_VAL_STAGE_DB2_AUTO_COMMIT_OFF = "La propiedad AutoCommitMode no tiene seleccionada la opción OFF " + ConstanteChk.BP1;
        
        //validacion de las rutinas
        public const string MSG_VAL_ARGUMENT_DESCRIPCION_NO_EXISTE = "El argumento no tiene descripción " + ConstanteChk.CHK07;

        public const string MSG_VAL_ROUTINE_NOMENCLATURA_PREFIJO = "El nombre no comienza con el prefijo";
        public const string MSG_VAL_ROUTINE_NOMENCLATURA_NOMBRE = "El nombre contiene caracteres no permitidos";

        public const string MSG_VAL_PARAMETER_SET_NOMENCLATURA_PREFIJO = "El nombre no comienza con el prefijo";
        public const string MSG_VAL_PARAMETER_SET_NOMENCLATURA_CONTIENE_MINUSCULA = "El nombre del ParameterSet contiene minúsculas" + ConstanteChk.CHK07;
    }
}

