﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.dao;

namespace ValidadorSES.util
{
    class UtilUsuario
    {
        public const int COD_LIDER_AREA = 1;
        public const int COD_LIDER_GRUPO = 2;
        public const int COD_COLABORADOR_BI = 3;

        public const string OPTION_USU_LIDER_AREA = "Lider de Area";
        public const string OPTION_USU_LIDER_GRUPO = "Lider de Grupo";
        public const string OPTION_COLABORADOR_BI = "Colaborador BI";


        public const string VALUE_OPTION_USU_LIDER_AREA = "1";
        public const string VALUE_OPTION_USU_LIDER_GRUPO = "2";
        public const string VALUE_OPTION_COLABORADOR_BI = "3";

        public const string OPTION_USU_ESTADO_HABILITADO = "Habilitado";
        public const string OPTION_USU_ESTADO_INHABILITADO = "Inhabilitado";


        public const int VALUE_OPTION_USU_ESTADO_HABILITADO = 1;
        public const int VALUE_OPTION_USU_ESTADO_INHABILITADO = 2;

        public static string getDescripcionPorCodigoUsuario(int cod)
        {
            string des = "";
            switch (cod)
            {
                case COD_LIDER_AREA:
                    des = OPTION_USU_LIDER_AREA;
                    break;
                case COD_LIDER_GRUPO:
                    des = OPTION_USU_LIDER_GRUPO;
                    break;
                case COD_COLABORADOR_BI:
                    des = OPTION_COLABORADOR_BI;
                    break;
            }
            return des;
        }

        public static string getDescripcionEstadoUsuario(int cod)
        {
            string des = "";
            switch (cod)
            {
                case VALUE_OPTION_USU_ESTADO_HABILITADO:
                    des = OPTION_USU_ESTADO_HABILITADO;
                    break;
                case VALUE_OPTION_USU_ESTADO_INHABILITADO:
                    des = OPTION_USU_ESTADO_INHABILITADO;
                    break;
            }
            return des;
        }

        public static int getCodigoCargoUsuario(string clas)
        {

            int cod = 0;
            switch (clas)
            {
                case "Lider de Area":
                    cod = COD_LIDER_AREA;
                    break;
                case "Lider de Grupo":
                    cod = COD_LIDER_GRUPO;
                    break;
                case "Colaborador BI":
                    cod = COD_COLABORADOR_BI;
                    break;
            }
            return cod;
        }

        public static string getCodigoEstadoUsuario(string clas)
        {
            
            string cod = "";
            switch (clas)
            {
                case "Habilitado":
                    cod = "1";
                    break;
                case "Inhabilitado":
                    cod = "2";
                    break;
            }
            return cod;
        }

        public static string getCodigoPreguntaSecreta(string clas)
                {
                    
                    string cod = "";
                    switch (clas)
                    {
                        case "Nombre de tu mascota":
                            cod = "1";
                            break;
                        case "Deporte favorito":
                            cod = "2";
                            break;
                        case "comida favorita":
                            cod = "3";
                            break;
                        case "Artista o grupo favorito":
                            cod = "4";
                            break;
                        case "Color de tu preferencia":
                            cod = "5";
                            break;
                    }
                    return cod;
                }
       
        public static string getDescripcionCodigoCargoUsuario(int cod)
        {
            string des = "";
            switch (cod)
            {
                case COD_LIDER_AREA:
                    des = OPTION_USU_LIDER_AREA;
                    break;
                case COD_LIDER_GRUPO:
                    des = OPTION_USU_LIDER_GRUPO;
                    break;
                case COD_COLABORADOR_BI:
                    des = OPTION_COLABORADOR_BI;
                    break;
            }
            return des;
        }

    }
}
