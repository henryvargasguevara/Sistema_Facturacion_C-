﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    public class ConstanteSistema
    {
        //CONFIGURACION DEL SISTEMA
        public const int TIPO_VERSION_SISTEMA = 1;  //poner 3 para agregar nuevas validaciones sino 1
        public const int TIPO_CONEXION = 2;
        public const int TIPO_USO_DATA_MAESTRO = 1;
        public const int TIPO_PANTALLA_INICIAL = 3; //poner 1 para agregar nuevas validaciones sino 3

        //CODIGOS
        public const int VERSION_SISTEMA_STANDALONE = 1;
        public const int VERSION_SISTEMA_DATABASE = 2;

        public const int CONEXION_PROPERTIES = 1;
        public const int CONEXION_CONSTANTE = 2;

        public const int USO_DATA_MAESTRO_BASE_DATO = 1;
        public const int USO_DATA_MAESTRO_ARCHIVO = 2;

        public const int PANTALLA_INICIAL_LOGIN = 1;
        public const int PANTALLA_INICIAL_VALIDADOR = 2;
        public const int PANTALLA_INICIAL_BUSCADOR = 3;
    }
}
