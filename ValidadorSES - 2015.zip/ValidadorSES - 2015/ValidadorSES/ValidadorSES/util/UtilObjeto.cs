﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;

namespace ValidadorSES.util
{
    public class UtilObjeto
    {
        public static LogJob getJobByName(string name, List<LogJob> listaJob)
        {
            for (int i = 0; i < listaJob.Count; i++)
            {
                LogJob j = listaJob[i];
                if (j.identifierJob == name)
                {
                    return j;
                }

            }
            return null;
        }

        public static LogRoutine getRoutineByName(string name, List<LogRoutine> listaRoutine)
        {
            for (int i = 0; i < listaRoutine.Count; i++)
            {
                LogRoutine j = listaRoutine[i];
                if (j.identifier == name)
                {
                    return j;
                }

            }
            return null;
        }

        public static LogParameterSet getParameterSetByName(string name, List<LogParameterSet> listaParameter)
        {
            for (int i = 0; i < listaParameter.Count; i++)
            {
                LogParameterSet j = listaParameter[i];
                if (j.identifierParameterSet == name)
                {
                    return j;
                }

            }
            return null;
        }

        public static int getTotalJobSequence(List<LogJob> listaJob, string type)
        {
            int num = 0;

            if (listaJob != null && listaJob.Count > 0)
            {
                int totalJobs = listaJob.Count;
                for (int j = 0; j < totalJobs; j++) //comienza a iterar por cada job
                {
                    if (listaJob[j].jobType == type)
                    {
                        num++;
                    }
                }
            }

            return num;
        }

        public static int getTotalJobActivityByNombreTrabajo(List<LogStage> listaStage, string nombreTrabajo) {
            int total = 0;

            for (int i = 0; i < listaStage.Count; i++) 
            {
                LogStage s = listaStage[i];

                if (s.oleType == ConstanteDataStage.OLETYPE_CJS_JOB_ACTIVITY
                    && s.stageJobActivity != null
                    && s.stageJobActivity.jobName == nombreTrabajo)
                {
                    total = total + 1;
                }                
            }

            return total;
        }

        public static int getCodigoEstado(string estado) 
        {
            int cod = 0; //INACTIVO

            switch (estado)
            {
                case "ACTIVO":
                    cod = 1;
                    break;
                case "INACTIVO":
                    cod = 2;
                    break;
            }

            return cod;

        }

        public static string getDescripcionCodigoEstado(int cod)
        {
            string des = ""; //INACTIVO

            switch(cod){
                case 1:
                    des = "ACTIVO";
                    break;
                case 2:
                    des = "INACTIVO";
                    break;
            }

            return des;

        }

        public static string getCodigoClasificacionObjeto(string clas) 
        {
            string cod = "0";
            switch(clas){
                case ConstanteMaestro.DES_CLASF_OBJ_JOB:
                    cod = ConstanteMaestro.COD_CLASF_OBJ_JOB;
                    break;
                case ConstanteMaestro.DES_CLASF_OBJ_STAGE:
                    cod = ConstanteMaestro.COD_CLASF_OBJ_STAGE;
                    break;
                case ConstanteMaestro.DES_CLASF_OBJ_ROUTINE:
                    cod = ConstanteMaestro.COD_CLASF_OBJ_ROUTINE;
                    break;
                case ConstanteMaestro.DES_CLASF_OBJ_ARGUMENT:
                    cod = ConstanteMaestro.COD_CLASF_OBJ_ARGUMENT;
                    break;
            }
            return cod;
        }

        public static string getDescripcionCodigoClasificacionObjeto(string cod)
        {
            string des = "";
            switch (cod)
            {
                case ConstanteMaestro.COD_CLASF_OBJ_JOB:
                    des = ConstanteMaestro.DES_CLASF_OBJ_JOB;
                    break;
                case ConstanteMaestro.COD_CLASF_OBJ_STAGE:
                    des = ConstanteMaestro.DES_CLASF_OBJ_STAGE;
                    break;
                case ConstanteMaestro.COD_CLASF_OBJ_ROUTINE:
                    des = ConstanteMaestro.DES_CLASF_OBJ_ROUTINE;
                    break;
                case ConstanteMaestro.COD_CLASF_OBJ_ARGUMENT:
                    des = ConstanteMaestro.DES_CLASF_OBJ_ARGUMENT;
                    break;
            }
            return des;
        }
    }
}
