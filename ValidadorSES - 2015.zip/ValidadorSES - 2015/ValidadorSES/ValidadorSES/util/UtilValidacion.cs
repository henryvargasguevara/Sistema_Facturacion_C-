﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;

namespace ValidadorSES.util
{
    public class UtilValidacion
    {
        public const string COD_VAL_OK = "OK";
        public const string COD_VAL_NOTOK = "NOTOK";
        public const string COD_VAL_OBS = "OBS";

        public static string getEstadoValidacion(string estado, string mensaje)
        {
            if(mensaje != "")
            {
                return estado;
            }

            return COD_VAL_OK;
        }

        public static List<LogStage> getListaStagePriorizada(List<LogStage> l) 
        {
            List<LogStage> listaFinal = new List<LogStage>();
            List<LogStage> listaOK = new List<LogStage>();
            List<LogStage> listaObs = new List<LogStage>();
            List<LogStage> listaError = new List<LogStage>();

            if(l!=null && l.Count >0)
            {
                for (int i = 0; i<l.Count; i++) 
                {
                    string estado = l[i].estadoStageCodigo;
                    if(estado == ConstanteMaestro.COD_EST_VALIDACION_OK)
                    {
                        listaOK.Add(l[i]);
                    }
                    if(estado == ConstanteMaestro.COD_EST_VALIDACION_OBS)
                    {
                        listaObs.Add(l[i]);
                    }
                    if(estado == ConstanteMaestro.COD_EST_VALIDACION_ERROR)
                    {
                        listaError.Add(l[i]);
                    }
                }
            }

            listaFinal.AddRange(listaError);
            listaFinal.AddRange(listaObs);
            listaFinal.AddRange(listaOK);

            return listaFinal;
        }
    }
}
