﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ValidadorSES.util
{
    public class UtilProceso
    {
        public static string getElementoLineaValido(string linea)
        {
            //quitar los guiones y caracteres especiales de Datastage (\\(9))
            linea = linea.Trim();
            if (linea != "")
            {
                linea = linea.Replace("\\(9)", "");
                if (linea.StartsWith("-"))
                {
                    linea = linea.Substring(1, linea.Length - 1);
                    linea = linea.Trim();
                }
            }
            return linea;
        }

        public static bool estaLineaComienzaPalabra(string linea, string palabra)
        {
            string lineaValida = linea.Replace("\\(9)", "");
            string[] tokens = lineaValida.Split(':');

            if (tokens.Length >= 1)
            {
                string campo = tokens[0].Trim();

                return campo == palabra;
            }

            return false;
        }

        public static string getValorCampoLineaComienzaPalabra(string linea, string palabra)
        {
            string lineaValida = linea.Replace("\\(9)", "");
            string[] tokens = lineaValida.Split(':');

            if (tokens.Length >= 2)
            {
                string campo = tokens[0];

                string valor = lineaValida.Substring(campo.Length+1, lineaValida.Length-(campo.Length+1));
                valor = valor.Trim();
                //string valor = tokens[1].Trim();

                return valor;
            }

            return "";
        } 
    }
}
