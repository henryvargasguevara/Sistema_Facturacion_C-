﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using ValidadorSES.util;

namespace ValidadorSES.service
{
    class VariableEntornoService
    {
        private int contador { get; set; }

        public List<VariableEntorno> getListaVariableEntorno(string rutaArchivo)
        {
            List<VariableEntorno> lista = new List<VariableEntorno>();

            if (!UtilArchivo.esValidoArchivoENV(rutaArchivo))
            {
                return lista;
            }

            string lineaActual = "";
            StreamReader objArchivo = new StreamReader(rutaArchivo, System.Text.Encoding.GetEncoding("Windows-1252"), true);  //System.Text.Encoding.UTF8, true
            lineaActual = getLineaActual(objArchivo);

            while (lineaActual != null && lineaActual != "[EnvVarValues]")
            {
                lineaActual = getLineaActual(objArchivo); //avanzar las lineas innecesarias            
            }

            if (lineaActual != null) //[EnvVarValues]
            {
                while (lineaActual != null)
                {
                    VariableEntorno v = getVariableEntornoFromLinea(lineaActual);
                    lineaActual = getLineaActual(objArchivo);
                    if (v != null)
                    {
                        lista.Add(v);
                    }
                }
            }

            return lista;
        }

        private VariableEntorno getVariableEntornoFromLinea(string linea)
        {
            VariableEntorno v = null;
            if (linea != "")
            {
                string[] valores = linea.Split('\\');
                if (valores != null && valores.Length >= 3)
                {
                    v = new VariableEntorno();
                    v.nombre = valores[0].Substring(1, valores[0].Length - 2);
                    if (valores[2].Length >= 2)
                    {
                        v.valor = valores[2].Substring(1, valores[2].Length - 2);
                    }
                    else
                    {
                        v.valor = "";
                    }
                }
            }

            return v;
        }

        public static string getValueVariableEntorno(string nombre, List<VariableEntorno> lista)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                if (nombre == lista[i].nombre)
                {
                    return lista[i].valor;
                }
            }
            return "";//no existe el parametro
        }

        private string getLineaActual(StreamReader objArchivo)
        {
            contador++;
            string s = objArchivo.ReadLine();
            if (s != null)
            {
                return s.Trim();
            }
            else
            {
                return s;
            }
        }
    }
}
