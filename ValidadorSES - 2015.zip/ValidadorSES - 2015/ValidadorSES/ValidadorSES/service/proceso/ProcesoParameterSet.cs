﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.service.proceso
{
    public class ProcesoParameterSet
    {
        private const string CAMPO_VERSIONES = "VERSIONES";

        public static void setDocInterna(LogObjetoDocumentacionInterna docInt, string descripcion)
        {
            string[] arreglo = descripcion.Split('\n');
            int cont = 0;
            int fin = arreglo.Length;
            bool esIniVersion = false;
            bool esFinVersion = false;

            //obtención de las fuentes y destinos a partir de la documentación del job
            while (cont < fin)
            {
                //VERSIONES
                if (esIniVersion && !esFinVersion)
                {
                    string linea = arreglo[cont];
                    if (!esLineaCampo(linea))
                    {
                        string lineaActual = UtilCadena.eliminarCaracteresInvalidos(arreglo[cont]).Trim();
                        if (lineaActual != "")
                        {
                            docInt.listaVersion.Add(lineaActual);
                        }
                    }
                    else
                    {
                        esFinVersion = true;
                    }
                }

                //CAMPOS

                if (UtilProceso.estaLineaComienzaPalabra(arreglo[cont], CAMPO_VERSIONES))
                {
                    esIniVersion = true;
                    esFinVersion = false;
                }

                if (esIniVersion && !esFinVersion) { }
                else
                {
                    //DESCRIPCION LARGA
                    string lineaActual = UtilCadena.eliminarCaracteresInvalidos(arreglo[cont]).Trim();
                    if (lineaActual != "")
                    {
                        docInt.description += lineaActual + "\n";
                    }
                }

                cont++;
            }
        }

        private static bool esLineaCampo(string linea)
        {
            return UtilProceso.estaLineaComienzaPalabra(linea, CAMPO_VERSIONES);
        }

        public List<LogObjetoParam> getListaParamJob(string parametro)
        {
            List<LogObjetoParam> lista = new List<LogObjetoParam>();
            LogObjetoParam param = new LogObjetoParam();

            string[] arregloSecuencial = parametro.Split('\n');
            for (int i = 0; i < arregloSecuencial.Length; i++)
            {
                if (arregloSecuencial[i] == "BEGIN DSSUBRECORD")
                {
                    param = new LogObjetoParam();
                }

                if (arregloSecuencial[i].StartsWith("Name"))
                {
                    param.name = UtilArchivoDSX.getParamName(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("Prompt"))
                {
                    param.solicitud = UtilArchivoDSX.getParamPrompt(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("Default"))
                {
                    param.valorPredeterminado = UtilArchivoDSX.getParamDefault(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("ParamType"))
                {
                    param.tipo = UtilArchivoDSX.getParamType(arregloSecuencial[i]);
                }

                if (arregloSecuencial[i] == "END DSSUBRECORD")
                {
                    lista.Add(param);
                }
            }

            return lista;
        }
    }
}
