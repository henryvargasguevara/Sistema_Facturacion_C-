﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.util;
using ValidadorSES.service;
using ValidadorSES.modelo;

namespace ValidadorSES.service.validador
{
    class ValidadorJob
    {
        public static string getValidacionNomenclaturaJobODS_BDS_OTROS(LogJob job)
        {
            string validacion = "";

            //validacion si es JobParallel
            if (job.jobType == ConstanteDataStage.TYPE_JOB_PARALLEL)
            {
                Carpeta carpetaProceso = job.carpeta; //LDM_NOMBRECARPETA, LN_NOMBRECARPETA, STG_NOMBRECARPETA
                if (job.carpeta != null)
                {
                    if (!job.carpeta.nombre.StartsWith("DEL_")) //INICIO DEL_
                    {

                        if (carpetaProceso != null)
                        {
                            Carpeta carpetaFrecuencia = carpetaProceso.carpetaPadre; //PC_TABLA, ST_TABLA, CM_TABLA, RP_TABLA

                            if (carpetaFrecuencia != null)
                            {
                                string prefijoFrecuencia = UtilDataStage.getPrefijoFrecuencia(carpetaFrecuencia.nombre);
                                if (UtilDataStage.tienePrefijoFrecuencia(carpetaFrecuencia.nombre))
                                {
                                    int total = carpetaFrecuencia.nombre.Length;
                                    string tabla = carpetaFrecuencia.nombre.Substring(3, total - 3);

                                    string prefijoProceso = UtilDataStage.getPrefijoProceso(carpetaProceso.nombre);

                                    //validar 
                                    if (prefijoFrecuencia == ConstanteDataStage.PREF_FREQ_PC
                                        || prefijoFrecuencia == ConstanteDataStage.PREF_FREQ_CM
                                        || prefijoFrecuencia == ConstanteDataStage.PREF_FREQ_RP
                                        || prefijoFrecuencia == ConstanteDataStage.PREF_FREQ_CS)
                                    {
                                        if (UtilDataStage.tienePrefijoProceso(carpetaProceso.nombre))//LN_ , LDM_ , STG_
                                        {
                                            string nombreCorrectoCarpetaProceso = prefijoProceso + carpetaFrecuencia.nombre; //LN_PC_OP_D_DEPOSPLABT_CTA

                                            if (carpetaProceso.nombre == nombreCorrectoCarpetaProceso)
                                            {
                                                string nombreJobCorrecto = prefijoProceso + prefijoFrecuencia + tabla; //LN_PC_OP_D_DEPOSPLABT_CTA
                                                //validar los jobs
                                                validacion = getValidacionNomJobODS_BDS_OTROS(job, nombreJobCorrecto);
                                            }
                                            else
                                            {
                                                validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_SUB_PRINCIPAL_PROCESO_ETL_2;
                                            }
                                        }
                                        else
                                        {
                                            validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_SUB_PRINCIPAL_PROCESO_ETL;
                                        }
                                    }

                                    if (prefijoFrecuencia == ConstanteDataStage.PREF_FREQ_ST)
                                    {
                                        if (UtilDataStage.tienePrefijoProceso(carpetaProceso.nombre))//LN_ , LDM_ , STG_
                                        {
                                            string nombreCorrectoCarpetaProceso = prefijoProceso + tabla; //LN_OP_D_DEPOSPLABT_CTA

                                            if (carpetaProceso.nombre == nombreCorrectoCarpetaProceso)
                                            {
                                                string nombreJobCorrecto = prefijoProceso + tabla; //LN_OP_D_DEPOSPLABT_CTA
                                                //validar los jobs
                                                validacion = getValidacionNomJobODS_BDS_OTROS(job, nombreJobCorrecto);
                                            }
                                            else
                                            {
                                                validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_SUB_PRINCIPAL_PROCESO_ETL_2;
                                            }
                                        }
                                        else
                                        {
                                            validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_SUB_PRINCIPAL_PROCESO_ETL;
                                        }
                                    }

                                }
                                else
                                {


                                    validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA;

                                }
                            }
                            else
                            {
                                validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA_NO_EXISTE;
                            }
                        }
                    }//FIN DEL_
                    else //sino DEL_
                    {
                        Carpeta carpetaFrecuencia = job.carpeta;   //PC_TABLA, ST_TABLA, CM_TABLA, RP_TABLA
                        if (carpetaFrecuencia != null)
                        {
                            string prefijoFrecuencia = UtilDataStage.getPrefijoFrecuencia(carpetaFrecuencia.nombre);
                            if (UtilDataStage.tienePrefijoFrecuencia(carpetaFrecuencia.nombre))
                            {
                                int total = carpetaFrecuencia.nombre.Length;
                                string tabla = ConstanteDataStage.PREF_JOB_RBTL_NOMBRE_TABLA + carpetaFrecuencia.nombre.Substring(3, total - 3);
                                string tabla2 = ConstanteDataStage.PREF_JOB_WBTL_NOMBRE_TABLA + carpetaFrecuencia.nombre.Substring(3, total - 3);
                                //validar los jobs
                                if (job.identifierJob != tabla && job.identifierJob != tabla2)
                                {
                                    validacion = ConstanteCadena.MSG_VAL_JOB_NOM_INCORRECTO;
                                }
                            }
                            else
                            {

                                validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA;

                            }
                        }
                        else
                        {
                            validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA_NO_EXISTE;
                        }
                    }
                }
            }

            //validación si es JobSequence
            if (job.jobType == ConstanteDataStage.TYPE_JOB_SEQUENCE)
            {
                Carpeta carpetaFrecuencia = job.carpeta;   //PC_TABLA, ST_TABLA, CM_TABLA, RP_TABLA
                if (carpetaFrecuencia != null)
                {
                    string prefijoFrecuencia = UtilDataStage.getPrefijoFrecuencia(carpetaFrecuencia.nombre);
                    if (UtilDataStage.tienePrefijoFrecuencia(carpetaFrecuencia.nombre))
                    {
                        int total = carpetaFrecuencia.nombre.Length;
                        string tabla = carpetaFrecuencia.nombre.Substring(3, total - 3);

                        string nombreJobCorrecto = ConstanteDataStage.PRE_JOB_SEQUENCE + prefijoFrecuencia + tabla; //SEQ_PC_TABLA
                        //validar los jobs
                        validacion = getValidacionNomJobODS_BDS_OTROS(job, nombreJobCorrecto);
                    }
                    else
                    {

                        validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA;

                    }
                }
                else
                {
                    validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA_NO_EXISTE;
                }
            }

            return validacion;
        }

        public static string getValidacionNomenclaturaJobStaging(LogJob job)
        {
            string validacion = "";
            //validacion si es JobParallel
            if (job.jobType == ConstanteDataStage.TYPE_JOB_PARALLEL)
            {
                Carpeta carpetaProceso = job.carpeta; //LDM_NOMBRECARPETA, LN_NOMBRECARPETA, STG_NOMBRECARPETA
                if (carpetaProceso != null)
                {
                    Carpeta carpetaFrecuencia = carpetaProceso.carpetaPadre; //PC_TABLA, ST_TABLA, CM_TABLA, RP_TABLA
                    string carpetaSuperior = carpetaProceso.carpetaPadre.nombreFull.Split('\\').Last();
                    string carpetaProbando = job.carpeta.nombreFull.Split('\\').Last();
                    string NombreJobEsquemaTabla = carpetaSuperior + "_" + carpetaProbando;
                    int total = 0;
                    string tabla = null;
                    string prefijoProceso = null;
                    string nombreJobCorrecto = null;
                    if (carpetaFrecuencia != null)
                    {
                        //string prefijoFrecuencia = UtilDataStage.getPrefijoFrecuenciaStaging(carpetaFrecuencia.nombre);  //JT
                        string prefijoFrecuencia = UtilDataStage.getPrefijoFrecuenciaStaging(carpetaProbando);  //JT
                        //if (UtilDataStage.tienePrefijoFrecuencia(carpetaFrecuencia.nombre))
                        if (UtilDataStage.tienePrefijoFrecuencia(carpetaProbando))
                        {
                            //carpeta contenedora tiene prefijo de frecuencia (PC, ST, RP, CM...)
                            total = carpetaProceso.nombre.Length;
                            tabla = carpetaProceso.nombre.Substring(3, total - 3);
                            prefijoProceso = UtilDataStage.getPrefijoProcesoStaging(carpetaProceso.nombre);
                            nombreJobCorrecto = prefijoProceso + tabla; //LN_PC_OP_D_DEPOSPLABT_CTA
                            if (carpetaProbando.StartsWith("ST"))
                            {
                                validacion = getValidacionNomJobStagingParaleloST(job, nombreJobCorrecto);
                            }
                            else
                            {
                                validacion = getValidacionNomJobStagingParalelo(job, nombreJobCorrecto);
                            }
                        }
                        else
                        {
                            //carpeta contenedora no tiene prefijo de frecuencia
                            tabla = carpetaProceso.nombre;
                            prefijoProceso = UtilDataStage.getPrefijoProcesoStaging(carpetaProceso.nombre);
                            nombreJobCorrecto = NombreJobEsquemaTabla;
                            validacion = getValidacionNomJobStagingParaleloSinFrecuencia(job, nombreJobCorrecto);
                        }

                    }
                    else
                    {
                        validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA_NO_EXISTE;
                    }
                }
            }

            //validación si es JobSequence
            if (job.jobType == ConstanteDataStage.TYPE_JOB_SEQUENCE)
            {
                Carpeta carpetaFrecuencia = job.carpeta;   //PC_TABLA, ST_TABLA, CM_TABLA, RP_TABLA
                if (carpetaFrecuencia != null)
                {
                    //string prefijoFrecuencia = UtilDataStage.getPrefijoFrecuencia(carpetaFrecuencia.nombre);
                    //if (UtilDataStage.tienePrefijoFrecuencia(carpetaFrecuencia.nombre))
                    //{
                    //int total = carpetaFrecuencia.nombre.Length;
                    //string tabla = carpetaFrecuencia.nombre.Substring(3, total - 3);

                    //string nombreJobCorrecto = ConstanteDataStage.PRE_JOB_SEQUENCE + prefijoFrecuencia + tabla; //SEQ_PC_TABLA
                    //validar los jobs
                    //validacion = getValidacionNomJobODS_BDS_OTROS(job, nombreJobCorrecto);
                    validacion = getValidacionNomJobStaging(job/*, nombreJobCorrecto*/);
                    //}
                    //else
                    //{
                    //    validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA;
                    //}
                }
                else
                {
                    validacion = ConstanteCadena.MSG_VAL_JOB_NOM_CARPETA_PRINCIPAL_FRECUENCIA_CARGA_NO_EXISTE;
                }
            }

            return validacion;
        }


        public static string getValidacionParametroValorPredeterminado(LogJob job)
        {
            string validacion = "";

            if (job.listaParamJob != null)
            {
                for (int i = 0; i < job.listaParamJob.Count; i++)
                {
                    LogObjetoParam param = job.listaParamJob[i];
                    if (param.valorPredeterminado != ConstanteDataStage.PARAM_VALOR_PRED_DEFAULT
                        && param.valorPredeterminado != ConstanteDataStage.PARAM_VALOR_PRED_PROJDEF
                        && param.valorPredeterminado != "")
                    {
                        validacion = ValidadorService.agregarRespuesta(validacion, "El parámetro " + param.name + " tiene un valor determinado");
                    }
                }
            }

            return validacion;
        }

        private static string getValidacionNomJobODS_BDS_OTROS(LogJob job, string nombreCorrectoCarpetaProceso)
        {
            string validacion = "";

            if (job.identifierJob != nombreCorrectoCarpetaProceso)
            {
                //tiene sufijo
                if (job.identifierJob.StartsWith(nombreCorrectoCarpetaProceso))
                {
                    int posIniSuf = nombreCorrectoCarpetaProceso.Length;
                    int posFinSuf = job.identifierJob.Length - posIniSuf;
                    string sufijo = job.identifierJob.Substring(posIniSuf, posFinSuf).Trim();

                    if (sufijo.StartsWith("_"))
                    {
                        if (sufijo.Length == 1)
                        {
                            validacion = ConstanteCadena.MSG_VAL_JOB_NOM_SUFIJO_INVALIDO;
                        }
                        if (sufijo.StartsWith("__"))
                        {
                            validacion = ConstanteCadena.MSG_VAL_JOB_NOM_SUFIJO_INVALIDO;
                        }
                    }
                    else
                    {
                        validacion = ConstanteCadena.MSG_VAL_JOB_NOM_INCORRECTO;
                    }
                }
                else
                {
                    validacion = ConstanteCadena.MSG_VAL_JOB_NOM_INCORRECTO;
                }
            }

            return validacion;
        }

        private static string getValidacionNomJobStagingParalelo(LogJob job, string nombreCorrectoCarpetaProceso)
        {
            string validacion = "";
            string[] cortar;
            string FrecuenciaTabla;

            if (job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_DED) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_DIF) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_EST) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_VDU) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_FTP) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_PARS) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_ST) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_QA) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_IA))
            {
                //tiene sufijo  
                cortar = job.identifierJob.Split('_');
                FrecuenciaTabla = cortar[1] + "_";
                //if (job.identifierJob.StartsWith(nombreCorrectoCarpetaProceso))
                //{
                if (FrecuenciaTabla.StartsWith(ConstanteDataStage.PREF_FREQ_CM) ||
                    FrecuenciaTabla.StartsWith(ConstanteDataStage.PREF_FREQ_PC) ||
                    FrecuenciaTabla.StartsWith(ConstanteDataStage.PREF_FREQ_RP) ||
                    FrecuenciaTabla.StartsWith(ConstanteDataStage.PREF_FREQ_CS) ||
                    FrecuenciaTabla.StartsWith(ConstanteDataStage.PREF_FREQ_ST))
                {
                    validacion = "";
                }
                else
                {
                    validacion = ConstanteCadena.MSG_VAL_JOB_NOM_INCORRECTO;
                }
            }

            return validacion;
        }

        private static string getValidacionNomJobStagingParaleloST(LogJob job, string nombreCorrectoCarpetaProceso)
        {
            string validacion = "";
            if (job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_DED) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_DIF) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_EST) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_VDU) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_FTP) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_PARS) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_ST) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_QA) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_IA))
            {
                validacion = "";
            }
            else
            {
                validacion = ConstanteCadena.MSG_VAL_JOB_NOM_INCORRECTO;
            }
            return validacion;
        }

        private static string getValidacionNomJobStagingParaleloSinFrecuencia(LogJob job, string nombreCorrectoCarpetaProceso)
        {
            string validacion = "";

            if (job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_DED) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_DIF) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_EST) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_VDU) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_FTP) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_PARS) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_ST) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_QA) ||
                job.identifierJob.StartsWith(ConstanteDataStage.PREF_STAGING_IA))
            {
                validacion = "";
            }
            return validacion;
        }

        private static string getValidacionNomJobStaging(LogJob job)
        {
            string validacion = "";

            if (job.identifierJob.StartsWith("SEQ_" + ConstanteDataStage.PREF_FREQ_ST) ||
                job.identifierJob.StartsWith("SEQ_" + ConstanteDataStage.PREF_FREQ_CM) ||
                job.identifierJob.StartsWith("SEQ_" + ConstanteDataStage.PREF_FREQ_CS) ||
                job.identifierJob.StartsWith("SEQ_" + ConstanteDataStage.PREF_FREQ_RP) ||
                job.identifierJob.StartsWith("SEQ_" + ConstanteDataStage.PREF_FREQ_FTP) ||
                job.identifierJob.StartsWith("SEQ_" + ConstanteDataStage.PREF_PROC_DEL) ||
                job.identifierJob.StartsWith("SEQ_" + ConstanteDataStage.PREF_FREQ_PC))
            {
                validacion = "";
            }
            else
            {
                validacion = ConstanteCadena.MSG_VAL_JOB_NOM_INCORRECTO;
            }

            return validacion;
        }


        public static string getValidacionDescripcionBreve(LogJob job)
        {
            string validacion = "";

            if (job.docInterna.description == null || job.docInterna.description.Trim() == "")
            {
                validacion = ConstanteCadena.MSG_VAL_JOB_DESCRIPCION_BREVE;
            }

            return validacion;
        }

        public static string getValidacionObjetivo(LogJob job)
        {
            string validacion = "";

            if (job.docInterna.objetivo == null || job.docInterna.objetivo.Trim() == "")
            {
                validacion = ConstanteCadena.MSG_VAL_JOB_OBJETIVO;
            }

            return validacion;
        }

        //validar si tiene descripcion de version
        public static string getValidacionVersion(LogJob job)
        {
            List<string> lastlista = job.docInterna.listaVersion;

            int linea = lastlista.Count - 1;
            if (linea > 0)
            {
                int data = comienzaConNumero(lastlista[linea]);
                if (data == 1) { }
                else
                {
                    return ConstanteCadena.MSG_VAL_JOB_VERSION_NO_EXISTE;
                }
            }
            else
            {
                return ConstanteCadena.MSG_VAL_JOB_VERSION_NO_EXISTE;
            }

            return "";
        }

        public static string getValidacionJobDocumentacionNombreJob(LogJob job)
        {
            string validacion = "";

            if (job.docInterna.nombre != "")
            {
                string aa = job.identifierJob.Trim();
                if (job.docInterna.nombre != job.identifierJob.Trim())
                {
                    validacion = ConstanteCadena.MSG_VAL_JOB_NOMBRE_NO_COINCIDE;
                }
            }
            else
            {
                validacion = ConstanteCadena.MSG_VAL_JOB_NOMBRE_INCORRECTO;
            }

            return validacion;
        }

        //public static string getValidacionJobDocumentacionNombreJob(LogJob job)
        //{
        //    string validacion = "";

        //        string aa = job.identifierJob.Trim();
        //        if (aa.StartsWith("STG_"))
        //        {
        //            if(aa == "")
        //            {
        //                validacion = "";
        //            }

        //            validacion = "probando vamos";
        //            //validacion = ConstanteCadena.MSG_VAL_JOB_NOMBRE_NO_COINCIDE;
        //        }            

        //    return validacion;
        //}


        //public static string getValidaTransformerEnStg(LogJob job)
        //{
        //    string validacion = "";
        //    //if (job.identifierJob.Trim().StartsWith("STG_"))
        //    string probando = UtilArchivoDSX.getIdentifierObjeto(nombre);
        //    if(UtilArchivoDSX.getIdentifierObjeto)
        //    {

        //    }

        //}

        public static string getValidacionEstructuraDocumentacionInternaJob(LogJob job)
        {
            string validacion = "";

            if (job.jobType == ConstanteDataStage.TYPE_JOB_PARALLEL)
            {
                if (!job.docInterna.tieneCampoAplicativo)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo APLICATIVO " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoNombre)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo NOMBRE " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoDestino)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo DESTINO " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoFuentes)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo FUENTES " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoObjetivo)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo OBJETIVO " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoReprocesable)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo REPROCESABLE " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoScheduler)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo SCHEDULER " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoVersiones)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo VERSIONES " + ConstanteChk.CHK07);
                }
            }

            if (job.jobType == ConstanteDataStage.TYPE_JOB_SEQUENCE)
            {
                if (!job.docInterna.tieneCampoAplicativo)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo APLICATIVO " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoNombre)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo NOMBRE " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoDependencias)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo DEPENDENCIAS " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoObjetivo)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo OBJETIVO " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoReprocesable)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo REPROCESABLE " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoScheduler)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo SCHEDULER " + ConstanteChk.CHK07);
                }
                if (!job.docInterna.tieneCampoVersiones)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, "No se encontró el campo VERSIONES " + ConstanteChk.CHK07);
                }
            }

            return validacion;
        }

        //public static string getValidacionJobEliminacionDataset(LogJob job)
        //{
        //    string validacion = "";
        //    bool existeRutinaEliminacionDataSet = false;
        //    foreach (LogStage stage in job.listaStage) 
        //    {
        //        if (stage.objeto.codigoObjeto == ConstanteObjeto.COD_OBJ_ROUTINE_ACTIVITY) 
        //        {
        //            if (stage.stageRoutineActivity.routineName == ConstanteDataStage.ROUTINE_DELETE_DATASET) 
        //            {
        //                existeRutinaEliminacionDataSet = true;
        //            }
        //        }
        //    }

        //    if (!existeRutinaEliminacionDataSet) 
        //    {
        //        validacion = ConstanteCadena.MSG_VAL_JOB_ELIMINACION_DATASET;
        //    }

        //    return validacion;
        //}

        public static string getValidacionJobTransEnStg(LogJob job)
        {
            string validacion = "";
            string transformer = ConstanteDataStage.TIPO_TRANSFORMER + "-";
            //   bool existeTransEnStg = false;

            foreach (LogStage stage in job.listaStage)
            {
                //  if (job.identifierJob.Trim().StartsWith("STG_"))
                // {
                //if (stage.objeto.codigoObjeto == transformer)
                // if (stage.objeto.codigoObjeto.Contains(transformer))
                if (stage.objeto != null)
                {
                    if (stage.objeto.codigoObjeto.IndexOf(transformer) != -1)
                    {
                        validacion = ConstanteCadena.MSG_VAL_JOB_TRANSFORMER;
                    }
                }

                //}
                //else
                //{
                //    validacion = "";
                //}
            }
            return validacion;
        }

        public static string getValidacionJobMaximoConectores(LogJob job)
        {
            string validacion = "";
            int contador = 0;

            foreach (LogStage stage in job.listaStage)
            {
                if (stage.inputPins == null && (stage.objeto.type == ConstanteDataStage.TIPO_DB2 || stage.objeto.type == ConstanteDataStage.TIPO_ODBC))
                {
                    contador = contador + 1;
                }
            }
            if (contador > 5)
            {
                validacion = ConstanteCadena.MSG_VAL_JOB_CONEXIONES;
            }
            return validacion;
        }

        public static string getValidacionJobEliminacionDataset(LogJob job)
        {
            string validacion = "";
            bool existeRutinaEliminacionDataSet = false;
            string nombre1 = ConstanteDataStage.ROUTINE_DELETE_DATASET;
            string nombre2 = ConstanteDataStage.ROUTINE_DELETE_DATASET_2;
            string nombre3 = ConstanteDataStage.ROUTINE_DELETE_DATASET_3;
            string nombre4 = ConstanteDataStage.ROUTINE_DELETE_DATASET_4;
            foreach (LogStage stage in job.listaStage)
            {
                if (stage.objeto.codigoObjeto == ConstanteObjeto.COD_OBJ_ROUTINE_ACTIVITY)
                {
                    string aa = stage.objeto.codigoObjeto;
                    //if (stage.stageRoutineActivity.routineName.StartsWith(ConstanteDataStage.ROUTINE_DELETE_DATASET_EMPIEZA))
                    //{
                    if (stage.stageRoutineActivity.routineName.IndexOf(nombre1, StringComparison.CurrentCultureIgnoreCase) != -1 || stage.stageRoutineActivity.routineName.IndexOf(nombre2, StringComparison.CurrentCultureIgnoreCase) != -1 ||
                            stage.stageRoutineActivity.routineName.IndexOf(nombre3, StringComparison.CurrentCultureIgnoreCase) != -1 || stage.stageRoutineActivity.routineName.IndexOf(nombre4, StringComparison.CurrentCultureIgnoreCase) != -1)
                    {
                        existeRutinaEliminacionDataSet = true;
                        if (stage.stageRoutineActivity.routineName.StartsWith(ConstanteDataStage.ROUTINE_DELETE_DATASET_EMPIEZA))
                        {
                            validacion += "";
                        }
                        else
                        {
                            validacion += ConstanteCadena.MSG_VAL_JOB_ELIMINACION_DATASET_EMPIZA + " ";
                        }
                    }
                    //}
                    //else
                    //{
                    //    validacion += ConstanteCadena.MSG_VAL_JOB_ELIMINACION_DATASET_EMPIZA + " ";
                    //}
                }
            }

            if (!existeRutinaEliminacionDataSet)
            {
                validacion += ConstanteCadena.MSG_VAL_JOB_ELIMINACION_DATASET;
            }

            return validacion;
        }

        public static string getValidacionJobDocumentacionDependencias(LogJob job)
        {
            string validacion = "";

            if (job.docInterna.listaDependencias != null)
            {
                List<string> listaDependientes = job.docInterna.listaDependencias;

                //obtener la lista de jobActivities del Job sequence
                List<string> listaJobActivity = new List<string>();
                List<LogStage> listaStage = job.listaStage;
                if (listaStage != null && listaStage.Count != 0)
                {
                    for (int i = 0; i < listaStage.Count; i++)
                    {
                        LogStage stageActual = listaStage[i];

                        if (stageActual.objeto.oletype == ConstanteDataStage.OLETYPE_CJS_JOB_ACTIVITY)
                        {
                            if (stageActual.stageJobActivity.jobName != null)
                            {
                                listaJobActivity.Add(stageActual.stageJobActivity.jobName);
                            }
                        }
                    }
                }

                //realizar la validación de duplicados
                string valDup = "";
                string valJob = "";
                string valDes = "";

                List<string> listaDepSinDup = listaDependientes.Distinct().ToList<string>();
                if (listaDependientes.Count != listaDepSinDup.Count)
                {
                    valDup = ConstanteCadena.MSG_VAL_STAGE_JOB_ACTIVITY_DEPENDENCIA_DUPLI;
                }

                //validacion que los elementos de la descripcion se encuentren en los jobactivities
                for (int i = 0; i < listaDepSinDup.Count; i++)
                {
                    string elemento = listaDepSinDup[i];
                    if (!UtilLista.existeCadenaEnLista(elemento, listaJobActivity))
                    {
                        valJob = ValidadorService.agregarRespuesta(valJob, elemento);
                    }
                }

                if (valJob != "")
                {
                    valJob = "Los stages JobActivity tienen referencias a " + valJob;
                    valJob += " pero estas no se encuentran en la documentación. " + ConstanteChk.CHK07;

                    validacion = validacion + valJob;
                }


                //validar que los jobactivities se encuentren en la descripción
                for (int j = 0; j < listaJobActivity.Count; j++)
                {
                    string jobActivity = listaJobActivity[j];
                    if (!UtilLista.existeCadenaEnLista(jobActivity, listaDepSinDup))
                    {
                        valDes = ValidadorService.agregarRespuesta(valDes, jobActivity);
                    }
                }

                if (valDes != "")
                {
                    valDes = "En la documentación se señala " + valDes;
                    valDes += " pero no se encuentra referenciado en ningún stage JobActivity del Job. ";
                    validacion = validacion + valDes;
                }

                if (validacion != "")
                {
                    validacion = "Dependencias" + ": " + valDup + validacion;
                }

                return validacion;
            }

            return validacion;
        }

        public static string getValidacionJobDocumentacionFuente(LogJob job, List<VariableEntorno> listaVariableEntorno, LogDSX dsx)
        {
            string validacion = "";

            List<string> listaFuenteDes = job.docInterna.listaFuentes;

            List<string> listaFuenteJob = getListaEntrada(job).Distinct().ToList<string>();

            //cambiar los PARAM por el valor que tienen
            listaFuenteJob = getListaValueVariableEntorno(listaFuenteJob, listaVariableEntorno, dsx);

            //validación entre los stages y la documentación
            validacion = validarListaFuenteDestino(listaFuenteDes, listaFuenteJob, "Fuente");

            return validacion;
        }

        public static string getValidacionJobDocumentacionDestino(LogJob job, List<VariableEntorno> listaVariableEntorno, LogDSX dsx)
        {
            string validacion = "";

            List<string> listaDestinoDes = job.docInterna.listaDestino;

            List<string> listaDestinoJob = getListaSalida(job).Distinct().ToList<string>();

            //cambiar los PARAM por el valor que tienen
            listaDestinoJob = getListaValueVariableEntorno(listaDestinoJob, listaVariableEntorno, dsx);

            //validación entre los stages y la documentación
            validacion = validarListaFuenteDestino(listaDestinoDes, listaDestinoJob, "Destino");

            return validacion;
        }

        private static List<string> getListaValueVariableEntorno(List<string> listaElemento, List<VariableEntorno> listaVariableEntorno, LogDSX dsx)
        {
            List<string> listaSinParametro = new List<string>();
            for (int i = 0; i < listaElemento.Count; i++)
            {
                string elemento = listaElemento[i].Trim();
                if (elemento.Contains("#"))
                {
                    string[] arreglo = elemento.Split('#');

                    if (arreglo.Length == 3)
                    {
                        string parametro = arreglo[1];
                        string tabla = arreglo[2];

                        string[] arregloParam = parametro.Split('$');

                        if (arregloParam.Length == 2)
                        {
                            string varEntorno = arregloParam[1];

                            string valueVarEntorno = VariableEntornoService.getValueVariableEntorno(varEntorno, listaVariableEntorno);
                            if (valueVarEntorno != "")
                            {
                                listaSinParametro.Add(valueVarEntorno + tabla);
                            }
                            else
                            {
                                //agregar como viene
                                listaSinParametro.Add(elemento);
                                dsx.listaFaltanteVariableEntorno.Add(varEntorno); // variable de entorno que falta
                            }
                        }
                        else
                        {
                            //agregar como viene
                            listaSinParametro.Add(elemento);
                        }
                    }
                    else
                    {
                        //agregar como viene
                        listaSinParametro.Add(elemento);
                    }
                }
                else
                {
                    listaSinParametro.Add(elemento);
                }
            }
            return listaSinParametro;
        }

        private static string validarListaFuenteDestino(List<string> listaIODes, List<string> listaIOJob, string tipo)
        {
            string validacion = "";
            string valDes = "";
            string valJob = "";
            string valDup = "";


            List<string> listaSinDup = listaIODes.Distinct().ToList<string>();
            if (listaIODes.Count != listaSinDup.Count)
            {
                valDup += "Se encontraron fuentes duplicados en la documentación. " + ConstanteChk.CHK07;
            }

            //buscar si los fuentes de la documentacion se encuentran en los stages
            for (int j = 0; j < listaIODes.Count; j++)
            {
                string iodes = listaIODes[j];
                if (!UtilLista.existeCadenaEnLista(iodes, listaIOJob))
                {
                    valDes = ValidadorService.agregarRespuesta(valDes, iodes);
                }
            }

            if (valDes != "")
            {
                valDes = "En la documentación se señala " + valDes;
                valDes += " pero no se encuentra referenciado en ningún stage del Job ";
                validacion = validacion + valDes + ConstanteChk.CHK07 + ". ";
                //validacion = ValidadorService.agregarMensaje(validacion, valDes);
            }

            //buscar si los stages del job estan en la documentación
            for (int i = 0; i < listaIOJob.Count; i++)
            {
                string iojob = listaIOJob[i];
                if (!UtilLista.existeCadenaEnLista(iojob, listaIODes))
                {
                    valJob = ValidadorService.agregarRespuesta(valJob, iojob);
                }
            }

            if (valJob != "")
            {
                valJob = "Los stages tienen referencias a " + valJob;
                valJob += " pero estas no se encuentran en la documentación " + ConstanteChk.CHK07 + ". ";// +ConstanteChk.CHK07;

                validacion = validacion + valJob;
                //validacion = ValidadorService.agregarMensaje(validacion, valJob);
            }

            if (validacion != "")
            {
                validacion = tipo + ": " + valDup + validacion;
            }


            return validacion;
        }

        private static List<string> getListaEntrada(LogJob job)
        {
            List<string> listaEntrada = new List<string>();
            List<LogStage> listaStage = job.listaStage;

            if (listaStage != null && listaStage.Count > 0)
            {
                for (int i = 0; i < listaStage.Count; i++)
                {
                    LogStage stage = listaStage[i];//TODO validar todos los tipos de archivos y base de datos
                    if (stage.outputPins != null && stage.outputPins != "")
                    {
                        if (stage.stageType == ConstanteDataStage.TIPO_DATA_SET
                            || stage.stageType == ConstanteDataStage.TIPO_SEQUENTIAL_FILE)
                        {
                            string archivo = ValidadorStageArchivo.getArchivoSinExtension(stage.stageArchivo.fileName);
                            if (archivo != "")
                            {
                                string extension = ValidadorStageArchivo.getExtension(stage.stageArchivo.fileName);
                                listaEntrada.Add(archivo + extension);
                            }
                        }

                        if (stage.stageType == ConstanteDataStage.TIPO_DB2 || stage.stageType == ConstanteDataStage.TIPO_ODBC)
                        {
                            List<string> listaTabla = stage.stageBaseDato.listaTabla;
                            listaEntrada.AddRange(listaTabla);
                        }
                    }
                }
            }

            return listaEntrada;
        }

        private static List<string> getListaSalida(LogJob job)
        {
            List<string> listaSalida = new List<string>();
            List<LogStage> listaStage = job.listaStage;

            if (listaStage != null && listaStage.Count > 0)
            {
                for (int i = 0; i < listaStage.Count; i++)
                {
                    LogStage stage = listaStage[i];//TODO validar todos los tipos de archivos y base de datos
                    if (stage.inputPins != null && stage.inputPins != "")
                    {
                        if (stage.stageType == ConstanteDataStage.TIPO_DATA_SET
                            || stage.stageType == ConstanteDataStage.TIPO_SEQUENTIAL_FILE)
                        {
                            string archivo = ValidadorStageArchivo.getArchivoSinExtension(stage.stageArchivo.fileName);
                            if (archivo != "")
                            {
                                string extension = ValidadorStageArchivo.getExtension(stage.stageArchivo.fileName);
                                listaSalida.Add(archivo + extension);
                            }
                        }

                        if (stage.stageType == ConstanteDataStage.TIPO_DB2)
                        {
                            List<string> listaTabla = stage.stageBaseDato.listaTabla;
                            listaSalida.AddRange(listaTabla);
                        }
                    }
                }
            }

            return listaSalida;
        }

        private static int comienzaConNumero(String cadena)
        {
            int result = -1;
            string numeros = "0123456789";
            for (int i = 0; i < cadena.Length; i++)
            {
                if (numeros.IndexOf(cadena[0], 0) != -1)
                {
                    return result = 1;//encontro numero o _
                }
            }
            return result;
        }

        public static string getValidacionJobPuntoComprobacion(LogJob job, List<LogJob> listaJob)
        {
            string validacion = "";

            for (int i = 0; i < listaJob.Count; i++)
            {
                if (listaJob[i].jobType == ConstanteDataStage.TYPE_JOB_SEQUENCE)
                {
                    if (existeJobInOtroDesarrollo(job.identifierJob, listaJob[i]))
                    {
                        if (job.checkpoints != "")
                        {
                            validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_JOB_OPCION_COMPILACION_PUNTO_COMPROBACION_MALLA_PADRE);
                        }
                    }
                }
            }
            //se comento jt
            //if(validacion==""){
            //    if (job.checkpoints == "")
            //    {
            //        validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_JOB_OPCION_COMPILACION_PUNTO_COMPROBACION_MALLA_PADRE);
            //    }
            //}

            if (job.logjoberrors == "")
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_JOB_OPCION_COMPILACION_REGISTRAR_AVISO);
            }

            if (job.logjobreports == "")
            {
                validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_JOB_OPCION_COMPILACION_REGISTRAR_MENSAJE);
            }

            return validacion;
        }

        private static bool existeJobInOtroDesarrollo(string jobName, LogJob job)
        {
            if (job != null)
            {
                List<LogStage> listaJA = getListaJobActivity(job);
                for (int i = 0; i < listaJA.Count; i++)
                {
                    if (jobName == listaJA[i].stageJobActivity.jobName)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static List<LogStage> getListaJobActivity(LogJob job)
        {
            List<LogStage> listaStageSequence = new List<LogStage>();

            List<LogStage> listaStage = job.listaStage;
            if (listaStage != null && listaStage.Count != 0)
            {
                for (int i = 0; i < listaStage.Count; i++)
                {
                    LogStage stageActual = listaStage[i];

                    if (stageActual.objeto.oletype == ConstanteDataStage.OLETYPE_CJS_JOB_ACTIVITY)
                    {
                        if (stageActual.stageJobActivity.jobName != null)
                        {
                            listaStageSequence.Add(stageActual);
                        }
                    }
                }
            }

            return listaStageSequence;
        }
    }
}
