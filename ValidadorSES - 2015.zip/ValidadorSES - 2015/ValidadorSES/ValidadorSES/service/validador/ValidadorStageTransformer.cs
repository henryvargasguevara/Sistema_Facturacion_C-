﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.util;
using ValidadorSES.modelo;

namespace ValidadorSES.service.validador
{
    public class ValidadorStageTransformer
    {
        /*
         * Validacion de la nomenclatura de las Stage variables de un Transformer, deben empezar en "sv"
         */
        public static string getValidacionStageVariableTransformer(LogStage stage)
        {
            string validacion = "";

            List<string> listaStageVar = stage.stageTransformer.listaStageVariable;

            if (listaStageVar != null && listaStageVar.Count > 0)
            {
                for (int i = 0; i < listaStageVar.Count; i++)
                {
                    string varActual = listaStageVar[i].Trim();
                    if (varActual != "")
                    {
                        if (!varActual.StartsWith("sv"))
                        {
                            return ConstanteCadena.MSG_VAL_STAGE_TRANSFORMER_NOMENCLATURA_STAGE_VARIABLE;
                        }
                    }
                }
            }

            return validacion;
        }

        /*
         * Validacion de la nomenclatura de los Loop variables de un Transformer, deben empezar en "lv"
         */
        public static string getValidacionLoopVariableTransformer(LogStage stage)
        {
            string validacion = "";

            List<string> listaStageVar = stage.stageTransformer.listaLoopVariable;

            if (listaStageVar != null && listaStageVar.Count > 0)
            {
                for (int i = 0; i < listaStageVar.Count; i++)
                {
                    string varActual = listaStageVar[i].Trim();
                    if (varActual != "")
                    {
                        if (!varActual.StartsWith("sv"))
                        {
                            return ConstanteCadena.MSG_VAL_STAGE_TRANSFORMER_NOMENCLATURA_LOOP_VARIABLE;
                        }
                    }
                }
            }

            return validacion;
        }

    }
}
