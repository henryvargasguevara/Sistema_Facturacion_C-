﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.service.validador
{
    public class ValidadorParameterSet
    {
        public static string getValidacionNomenclatura(LogParameterSet parameter)
        {
            string validacion = "";
            bool esValidoPrefijo = false;
            bool esValidoNombre = true;
            //bool tipoEncontrado = false;
            //int comienzaNumeros = 0;
            string nombre = parameter.identifierParameterSet;

            //proceso
            if (parameter.objeto.oletype == parameter.oleType)
            {
                //tipoEncontrado = true;
                string prefijo = parameter.objeto.prefijo;
                if (nombre.StartsWith(prefijo))
                {
                    esValidoPrefijo = true;
                    string despuesPrefijo = nombre.Substring(prefijo.Length, nombre.Length - prefijo.Length);
                    esValidoNombre = (despuesPrefijo == despuesPrefijo.ToUpper());
                }

                if (!esValidoPrefijo)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_PARAMETER_SET_NOMENCLATURA_PREFIJO + " [ " + prefijo + " ]" + ConstanteChk.CHK14);
                }

                if (!esValidoNombre)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_PARAMETER_SET_NOMENCLATURA_CONTIENE_MINUSCULA + ConstanteChk.CHK14);
                }
            }

            return validacion;
        }


        public static string getValidacionDocumentacion(LogParameterSet parameter)
        {
            string validacion = "";
            string descrip = parameter.descripcion_ParameterSet;
            if (parameter.objeto.oletype == parameter.oleType)
            {
                if (!descrip.Contains("VERSIONES"))
                {
                    validacion = "No se encontró el campo versión en el parametro " + ConstanteChk.CHK07;
                }
            }
            return validacion;
        }

        public static string getValidacionDescripcionBrevePar(LogParameterSet parameter)
        {
            string validacion = "";
            string breve = parameter.docInterna.shortDesc;
            //objParameterSet.docInterna.shortDesc
            if (parameter.objeto.oletype == parameter.oleType)
            {
                if (breve.Trim() == "")
                {
                    validacion = "Descripción breve se encuentra vacia " + ConstanteChk.CHK07;
                }
            }
            return validacion;
        }
    }
}
