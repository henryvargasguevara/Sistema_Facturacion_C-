﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.service;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.service.validador
{
    /*
    * Validacion del Rutines
    * **/
    class ValidadorRoutine
    {
        public static string getValidacionNomenclaturaRoutine(LogRoutine routine)
        {
            string validacion = "";
            bool esValidoPrefijo = false;
            bool esValidoNombre = true;
            bool tipoEncontrado = false;  // puede que se encuentre otras rutinas pero no estan los datos para validar

            string nombre = routine.identifier;

            //proceso
            if (routine.objeto.type == routine.routineType)
            {
                tipoEncontrado = true;

                string prefijo = routine.objeto.prefijo;
                if (nombre.StartsWith(prefijo))
                {
                    esValidoPrefijo = true;
                    string despuesPrefijo = nombre.Substring(prefijo.Length, nombre.Length - prefijo.Length);

                    if (despuesPrefijo.Length == 0 || despuesPrefijo.Contains("_") || despuesPrefijo.Contains("-"))
                    {
                        esValidoNombre = false;
                    }
                }

                if (!esValidoPrefijo)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_ROUTINE_NOMENCLATURA_PREFIJO + " " + prefijo + ConstanteChk.CHK14);
                }

                if (!esValidoNombre)
                {
                    validacion = ValidadorService.agregarRespuesta(validacion, ConstanteCadena.MSG_VAL_ROUTINE_NOMENCLATURA_NOMBRE + ConstanteChk.CHK14);
                }

            }

            //setear valores en el stage
            if (tipoEncontrado)
            {

            }
            else
            {
                routine.routineType = ConstanteDataStage.TIPO_ROUTINE_NO_DEFINIDO;
                //routine.descripcionRoutineType = ConstanteDataStage.DES_ROUTINE_NO_DEFINIDO;
            }

            return validacion;
        }

        public static string getValidacionDescripcionBreve(LogRoutine rutinaa)
        {
            string validacion = "";
            string descrip = rutinaa.shortDesc;
            if (rutinaa.objeto.oletype == rutinaa.oleType)
            {
                if (descrip.Trim() == "")
                {
                    validacion = "Descripción breve se encuentra vacia " + ConstanteChk.CHK07;
                }
            }
            return validacion;
        }

        public static string getValidacionDescripcionVersion(LogRoutine rutinaa)
        {
            string validacion = "";
            string descrip = rutinaa.descripcion_routine;
            if (rutinaa.objeto.oletype == rutinaa.oleType)
            {
                if (!descrip.Contains("VERSIONES"))
                {
                    validacion = "No se encontró el campo VERSIONES en la documentación " + ConstanteChk.CHK07;
                }
            }
            return validacion;
        }

        public static string getValidacionDescripcionObjetivo(LogRoutine rutinaa)
        {
            string validacion = "";
            string descrip = rutinaa.descripcion_routine;
            if (rutinaa.objeto.oletype == rutinaa.oleType)
            {
                if (!descrip.Contains("OBJETIVO"))
                {
                    validacion = "No se encontró el campo OBJETIVO en la documentación " + ConstanteChk.CHK07;
                }
            }
            return validacion;
        }

        public static string validarDescripcion(LogArgument argRou)
        {
            string result = "";
            if (argRou.nameArgRoutine != null)
            {
                if (argRou.descArgRoutine == null || argRou.descArgRoutine.Trim() == "")
                {
                    result = ConstanteCadena.MSG_VAL_ARGUMENT_DESCRIPCION_NO_EXISTE;
                }
            }

            return result;
        }
    }
}
