﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;
using System.Windows.Forms;
using System.ComponentModel;
using ValidadorSES.modelo;
using ValidadorSES.dao;
using ValidadorSES.service.proceso;
using ValidadorSES.util;
using System.Reflection;

namespace ValidadorSES.service
{
    public class ProcesoService
    {
        public List<string> listaOLEType;
        public List<Objeto> listaObjetoJob;
        public List<Objeto> listaObjetoStage;
        public List<Objeto> listaObjetoRoutine;
        public List<Objeto> listaObjetoArgument;
        public List<Objeto> listaObjetoParameterSet;
        public List<Objeto> listaObjetoParam;
        private int contador { get; set; }

        public ProcesoService()
        {
            if (ConstanteSistema.TIPO_VERSION_SISTEMA == ConstanteSistema.VERSION_SISTEMA_DATABASE)
            {
                ObjetoDAO odao = new ObjetoDAO();
                listaOLEType = odao.getListaObjetoViewByOLEType();

                listaObjetoJob = odao.getListaObjetoByJob();
                listaObjetoStage = odao.getListaObjetoByStage();

                listaObjetoRoutine = odao.getListaObjetoByRoutine();
                listaObjetoArgument = odao.getListaObjetoByArgument();

                listaObjetoParameterSet = odao.getListaObjetoByParameterSet();
                listaObjetoParam = odao.getListaObjetoByParam();

                serializarProcesoService(listaOLEType, "listaOLEType");

                serializarProcesoService(listaObjetoJob, "listaObjetoJob");
                serializarProcesoService(listaObjetoStage, "listaObjetoStage");
                serializarProcesoService(listaObjetoRoutine, "listaObjetoRoutine");
                serializarProcesoService(listaObjetoArgument, "listaObjetoArgument");
                serializarProcesoService(listaObjetoParameterSet, "listaObjetoParameterSet");
                serializarProcesoService(listaObjetoParam, "listaObjetoParam");
            }
            else
            {
                desSerializarProcesoService1();
                desSerializarProcesoService2();
                desSerializarProcesoService3();
                desSerializarProcesoService4();
                desSerializarProcesoService5();
                desSerializarProcesoService6();
                desSerializarProcesoService7();
                ////listaOLEType = oledao.getListaObjetoViewByOLEType();
                //desSerializarProcesoService(listaObjetoJob,"listaObjetoJob");
                //desSerializarProcesoService(listaObjetoStage,"listaObjetoStage");
                //desSerializarProcesoService(listaObjetoRoutine,"listaObjetoRoutine");
                //desSerializarProcesoService(listaObjetoArgument,"listaObjetoArgument");
                //desSerializarProcesoService(listaObjetoParameterSet,"listaObjetoParameterSet");
                //desSerializarProcesoService(listaObjetoParam,"listaObjetoParam");

                //OleDBObjetoDAO oledao = new OleDBObjetoDAO();
                ////listaOLEType = oledao.getListaObjetoViewByOLEType();

                //listaObjetoJob = oledao.getListaObjetoByJob();
                //listaObjetoStage = oledao.getListaObjetoByStage();

                //listaObjetoRoutine = oledao.getListaObjetoByRoutine();
                //listaObjetoArgument = oledao.getListaObjetoByArgument();

                //listaObjetoParameterSet = oledao.getListaObjetoByParameterSet();
                //listaObjetoParam = oledao.getListaObjetoByParam();
            }

            contador = 0;
        }

        private void serializarProcesoService(Object o, string nombre)
        {
            string dir = @"c:\db";
            string serializationFile = Path.Combine(dir, nombre + ".bin");

            //serialize
            using (Stream stream = File.Open(serializationFile, FileMode.Create))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                bformatter.Serialize(stream, o);
            }
        }

        public void desSerializarProcesoService(List<Objeto> o, string nombre)
        {
            string dir = @"c:\db";
            string serializationFile = Path.Combine(dir, nombre + ".bin");

            //deserialize
            using (Stream stream = File.Open(serializationFile, FileMode.Open))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                o = (List<Objeto>)bformatter.Deserialize(stream);
            }
        }

        public void desSerializarProcesoService1()
        {
            //string dir = @"c:\db";
            //string dir = @"..\..\Resources\db";
            //string serializationFile = Path.Combine(dir, "listaOLEType.bin");

            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db.listaOLEType.bin";

            //string[] resources = assembly.GetManifestResourceNames();
            //string list = "";

            //// Build the string of resources.
            //foreach (string resource in resources)
            //    list += resource + "\r\n";

            //deserialize
            //using (Stream stream = File.Open(serializationFile, FileMode.Open))
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                listaOLEType = (List<string>)bformatter.Deserialize(stream);
            }
        }

        public void desSerializarProcesoService2()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db.listaObjetoJob.bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                listaObjetoJob = (List<Objeto>)bformatter.Deserialize(stream);
            }
        }
        public void desSerializarProcesoService3()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db.listaObjetoStage.bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                listaObjetoStage = (List<Objeto>)bformatter.Deserialize(stream);
            }
        }
        public void desSerializarProcesoService4()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db.listaObjetoRoutine.bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                listaObjetoRoutine = (List<Objeto>)bformatter.Deserialize(stream);
            }
        }
        public void desSerializarProcesoService5()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db.listaObjetoArgument.bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                listaObjetoArgument = (List<Objeto>)bformatter.Deserialize(stream);
            }
        }
        public void desSerializarProcesoService6()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db.listaObjetoParameterSet.bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                listaObjetoParameterSet = (List<Objeto>)bformatter.Deserialize(stream);
            }
        }
        public void desSerializarProcesoService7()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ValidadorSES.Resources.db.listaObjetoParam.bin";
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                listaObjetoParam = (List<Objeto>)bformatter.Deserialize(stream);
            }
        }

        public LogDSX getObjetoDSXFromArchivo(string rutaArchivoDSX, BackgroundWorker bw, int totalLineas)
        {
            LogDSX dsx = new LogDSX();

            //recorrer el archivo
            generarLogObjetoFromArchivoDSX(dsx, rutaArchivoDSX, bw, totalLineas);

            //setear objeto a cada Job, Stage, Routine, Argument
            setearObjetoToLog(dsx);

            //asignar carpeta a cada Job
            generarEstructuraDirectorioDSX(dsx);

            //asignar enlaces de salida para cada stage
            generarLinksOutput(dsx);

            return dsx;
        }

        private void generarLogObjetoFromArchivoDSX(LogDSX dsx, string rutaArchivo, BackgroundWorker bw, int totalLineas)
        {
            StreamReader objArchivo = new StreamReader(rutaArchivo, System.Text.Encoding.GetEncoding("Windows-1252"), true);

            LogHeader header = dsx.header;
            List<LogJob> listaJob = dsx.listaJob;
            List<LogRoutine> listaRoutine = dsx.listaRoutine;
            List<LogParameterSet> listaParameterSet = dsx.listaParameterSet;

            contador = 0;
            float avance = 0.0f;
            float totalLineaF = totalLineas + 0.0f;

            string lineaActual = getLineaActual(objArchivo);

            //Bucle para obtener el objeto Header
            while (lineaActual != null && lineaActual != "BEGIN DSJOB" && lineaActual != "BEGIN DSROUTINES" && lineaActual != "BEGIN DSPARAMETERSETS")
            {
                if (lineaActual == "BEGIN HEADER")
                {
                    lineaActual = setearHeader(header, objArchivo, lineaActual); //devolver la linea en que se quedo
                }

                lineaActual = getLineaActual(objArchivo);
            }

            //Bucle para obtener los objetos Job y Stage
            while (lineaActual != null && lineaActual != "BEGIN DSEXECJOB" && lineaActual != "BEGIN DSROUTINES" && lineaActual != "BEGIN DSPARAMETERSETS")
            {
                //encontrar job
                if (lineaActual == "BEGIN DSJOB")
                {
                    LogJob job = buscarPropiedadJob(objArchivo);
                    List<LogStage> listaStage = new List<LogStage>();

                    lineaActual = getLineaActual(objArchivo);
                    while (lineaActual != "END DSJOB")
                    {
                        //crear los stages para el job
                        if (lineaActual == "BEGIN DSRECORD")
                        {
                            string lineaIdentifier = getLineaActual(objArchivo);// Identifier
                            string lineaOletype = getLineaActual(objArchivo); // OLEType

                            if (UtilDataStage.esOLETypeValido(listaOLEType, lineaOletype))
                            {
                                if (UtilDataStage.esCJobDefn(lineaOletype))
                                {
                                    //buscar ruta y tipo de job, fuentes, destinos, nombre, dependientes
                                    job.oleType = ConstanteDataStage.OLETYPE_C_JOB_DEFN;
                                    //    setProbandoPKenDU(job, objArchivo);
                                    setPropiedadJob(job, objArchivo);
                                }
                                else
                                {
                                    //setear los valores del stage
                                    LogStage stage = new LogStage();
                                    stage.job = job;
                                    stage.identifierStage = UtilArchivoDSX.getIdentifierObjeto(lineaIdentifier);
                                    stage.oleType = UtilArchivoDSX.getOLETypeObjeto(lineaOletype);
                                    lineaActual = buscarPropiedadStage(stage, objArchivo);//retornar la linea actual por posible error //agregar job

                                    //if (stage.oleType == "CAnnotation")
                                    //{
                                    //    string tipo = "NO";
                                    //    if(stage.stageAnnotacion.type == "1")
                                    //    {
                                    //        stage.stageAnnotacion.text = job.docInterna.description;
                                    //        tipo = "Description";
                                    //    }

                                    //    System.Diagnostics.Debug.WriteLine("Job:" + job.identifierJob + " | annotation:" + stage.identifierStage+ " | tipo:"+tipo);
                                    //    System.Diagnostics.Debug.WriteLine("\n"+stage.stageAnnotacion.text+"\n");
                                    //}
                                    //else
                                    //{
                                    //    stage.job = job;
                                    //    listaStage.Add(stage);
                                    //}
                                    //agregar en la lista de stages del job actual
                                    listaStage.Add(stage);
                                }
                            }

                            while (lineaActual != "END DSRECORD" && lineaActual != "END DSJOB")
                            {
                                lineaActual = getLineaActual(objArchivo); //avanzar las lineas innecesarias
                            }
                        }
                        else
                        {
                            lineaActual = getLineaActual(objArchivo);
                        }
                    }

                    //establecer el archivo del dataset en su stage
                    setearArchivoFromLink(listaStage);

                    ////quitar los links duplicados
                    listaStage = quitarStagesDuplicados(listaStage);

                    job.dsx = dsx;
                    job.listaStage = listaStage;
                    listaJob.Add(job);
                }

                lineaActual = getLineaActual(objArchivo);

                //efecto de la barra
                avance = 100 * (contador / totalLineaF);
                bw.ReportProgress(Convert.ToInt32(avance));
            }

            //Bucle para avanzar el codigo Ejecutable
            while (lineaActual != null && lineaActual != "BEGIN DSROUTINES" && lineaActual != "BEGIN DSPARAMETERSETS")
            {
                lineaActual = getLineaActual(objArchivo); //avanzar las lineas innecesarias
            }

            //Bucle para obtener los objetos Routine y sus Argument
            while (lineaActual != null && lineaActual != "BEGIN DSPARAMETERSETS")
            {
                if (lineaActual == "BEGIN DSROUTINES")
                {
                    lineaActual = getLineaActual(objArchivo);

                    while (lineaActual != "END DSROUTINES")
                    {
                        if (lineaActual == "BEGIN DSRECORD")
                        {
                            LogRoutine objRoutine = new LogRoutine();
                            objRoutine.listaArgumentoRoutine = new List<LogArgument>();

                            lineaActual = buscarPropiedadRoutineAndArgument(objRoutine, objArchivo);

                            objRoutine.dsx = dsx;
                            //agregar la rutina a la lista
                            listaRoutine.Add(objRoutine);
                        }
                        else
                        {
                            lineaActual = getLineaActual(objArchivo);
                        }
                    }
                }

                lineaActual = getLineaActual(objArchivo);

                //efecto de la barra
                avance = 100 * (contador / totalLineaF);
                bw.ReportProgress(Convert.ToInt32(avance));
            }

            //Bucle para obtener los objetos ParameterSet
            while (lineaActual != null)
            {
                if (lineaActual == "BEGIN DSPARAMETERSETS")
                {
                    lineaActual = getLineaActual(objArchivo);

                    while (lineaActual != "END DSPARAMETERSETS")
                    {
                        if (lineaActual == "BEGIN DSRECORD")
                        {
                            LogParameterSet objParameterSet = new LogParameterSet();

                            lineaActual = buscarPropiedadParameterSet(objParameterSet, objArchivo);

                            objParameterSet.dsx = dsx;
                            //agregar el ParameterSet a la lista
                            listaParameterSet.Add(objParameterSet);
                        }
                        else
                        {
                            lineaActual = getLineaActual(objArchivo);
                        }
                    }
                }
                lineaActual = getLineaActual(objArchivo);

                //efecto de la barra
                avance = 100 * (contador / totalLineaF);
                bw.ReportProgress(Convert.ToInt32(avance));
            }
        }

        private void setearObjetoToLog(LogDSX dsx)
        {
            List<LogJob> listaJob = dsx.listaJob;
            List<LogRoutine> listaRoutine = dsx.listaRoutine;
            List<LogParameterSet> listaParameter = dsx.listaParameterSet;

            if (listaJob != null && listaJob.Count > 0)
            {
                for (int j = 0; j < listaJob.Count; j++)
                {
                    LogJob job = listaJob[j];
                    string codigoObjetoJob = job.oleType + "-" + job.jobType;
                    job.objeto = UtilDataStage.getObjetoFromLista(listaObjetoJob, codigoObjetoJob);

                    List<LogStage> listaStage = job.listaStage;
                    if (listaStage != null && listaStage.Count > 0)
                    {
                        for (int s = 0; s < listaStage.Count; s++)
                        {
                            LogStage stage = listaStage[s];
                            string codigoObjetoStage = stage.oleType + "-" + stage.stageType;
                            stage.objeto = UtilDataStage.getObjetoFromLista(listaObjetoStage, codigoObjetoStage);

                            if (stage.objeto == null)
                            {
                                //TODO crear un log para mostrar que stages no se pueden procesar
                            }
                        }
                    }

                    if (job.objeto == null)
                    {
                        //TODO crear un log para mostrar que stages no se pueden procesar
                    }
                }
            }

            if (listaRoutine != null && listaRoutine.Count > 0)
            {
                for (int r = 0; r < listaRoutine.Count; r++)
                {
                    LogRoutine routine = listaRoutine[r];
                    string codigoObjetoRoutine = routine.oleType + "-" + routine.routineType;
                    routine.objeto = UtilDataStage.getObjetoFromLista(listaObjetoRoutine, codigoObjetoRoutine);

                    List<LogArgument> listaArgument = routine.listaArgumentoRoutine;
                    if (listaArgument != null && listaArgument.Count > 0)
                    {
                        for (int a = 0; a < listaArgument.Count; a++)
                        {
                            LogArgument arg = listaArgument[a];
                            string codigoObjetoArgument = arg.oleType + "-" + arg.argumentType;
                            arg.objeto = UtilDataStage.getObjetoFromLista(listaObjetoArgument, codigoObjetoArgument);

                            if (arg.objeto == null)
                            {
                                //TODO crear un log para mostrar que stages no se pueden procesar
                            }
                        }
                    }

                    if (routine.objeto == null)
                    {
                        //TODO crear un log para mostrar que routines no se pueden procesar
                    }
                }
            }

            if (listaParameter != null && listaParameter.Count > 0)
            {
                for (int p = 0; p < listaParameter.Count; p++)
                {
                    LogParameterSet parameter = listaParameter[p];
                    string codigoObjetoParameter = parameter.oleType + "-" + parameter.parameterSetType;
                    parameter.objeto = UtilDataStage.getObjetoFromLista(listaObjetoParameterSet, codigoObjetoParameter);

                    List<LogParam> listaParam = parameter.listaParam;
                    if (listaParam != null && listaParam.Count > 0)
                    {
                        for (int a = 0; a < listaParam.Count; a++)
                        {
                            LogParam param = listaParam[a];
                            string codigoObjetoParam = param.oleType + "-" + param.paramType;
                            param.objeto = UtilDataStage.getObjetoFromLista(listaObjetoParam, codigoObjetoParam);

                            if (param.objeto == null)
                            {
                                //TODO crear un log para mostrar que stages no se pueden procesar
                            }
                        }
                    }

                    if (parameter.objeto == null)
                    {
                        //TODO crear un log para mostrar que parameterSet no se pueden procesar
                    }
                }
            }
        }

        private void generarEstructuraDirectorioDSX(LogDSX dsx)
        {
            List<LogJob> listaJob = dsx.listaJob;

            if (listaJob != null && listaJob.Count > 0)
            {
                for (int j = 0; j < listaJob.Count; j++)
                {
                    LogJob job = listaJob[j];
                    job.carpeta = UtilDataStage.getCarpeta(job.category, dsx.carpetaRaizJob);
                }
            }
        }

        private void generarLinksOutput(LogDSX dsx)
        {
            List<LogJob> listaJob = dsx.listaJob;

            if (listaJob != null && listaJob.Count > 0)
            {
                for (int j = 0; j < listaJob.Count; j++)
                {
                    LogJob job = listaJob[j];

                    if (job.jobType == ConstanteDataStage.TYPE_JOB_SEQUENCE)
                    {

                        List<LogStage> listaStage = job.listaStage;
                        if (listaStage != null && listaStage.Count > 0)
                        {
                            for (int s = 0; s < listaStage.Count; s++)
                            {
                                LogStage stage = listaStage[s];
                                stage.listaStageOutput = new List<LogStage>();

                                if (stage.oleType != ConstanteDataStage.OLETYPE_CJS_ACTIVITY_OUTPUT)
                                {
                                    //si el stage es JobActivity o un RoutineActivity

                                    //validar si el stage tiene OutputLinks
                                    if (stage.outputPins != null)
                                    {
                                        string[] outPutPins = stage.outputPins.Split('|');

                                        if (outPutPins != null)
                                        {
                                            for (int i = 0; i < outPutPins.Length; i++)
                                            {
                                                LogStage link = UtilDataStage.getStageByIdentifier(outPutPins[i], job.listaStage);

                                                if (link != null && link.oleType == ConstanteDataStage.OLETYPE_CJS_ACTIVITY_OUTPUT)
                                                {
                                                    stage.listaStageOutput.Add(link);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    //si el stage es un Link
                                    if (stage.partner != null)
                                    {
                                        string[] partnerLink = stage.partner.Split('|');

                                        LogStage stageOutput = UtilDataStage.getStageByIdentifier(partnerLink[0], job.listaStage);

                                        if (stageOutput != null)
                                        {
                                            stage.listaStageOutput.Add(stageOutput);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private string buscarPropiedadParameterSet(LogParameterSet objParameterSet, StreamReader objArchivo)
        {
            string descripcion = "";
            string parametros = "";

            string lineaActual = getLineaActual(objArchivo); //Readonly "0"
            while (lineaActual != "END DSRECORD")
            {
                if (lineaActual.StartsWith("Identifier"))
                {
                    objParameterSet.identifierParameterSet = UtilArchivoDSX.getIdentifierObjeto(lineaActual);
                }
                if (lineaActual.StartsWith("DateModified"))
                {
                    objParameterSet.dateModified = UtilArchivoDSX.getDateModifiedObjeto(lineaActual);
                }
                if (lineaActual.StartsWith("TimeModified"))
                {
                    objParameterSet.timeModified = UtilArchivoDSX.getTimeModifiedObjeto(lineaActual);
                }
                if (lineaActual.StartsWith("OLEType"))
                {
                    objParameterSet.oleType = UtilArchivoDSX.getOLETypeObjeto(lineaActual);
                }
                if (lineaActual.StartsWith("Category"))
                {
                    objParameterSet.category = UtilArchivoDSX.getCategoryObjeto(lineaActual);
                }
                if (lineaActual.StartsWith("ShortDesc"))
                {
                    objParameterSet.docInterna.shortDesc = UtilArchivoDSX.getShortDesc(lineaActual);
                }
                if (lineaActual.StartsWith("Description =+=+=+="))
                {
                    lineaActual = getLineaActual(objArchivo);
                    while (lineaActual != "=+=+=+=")
                    {
                        descripcion += lineaActual + '\n';
                        lineaActual = getLineaActual(objArchivo);
                    }
                    objParameterSet.descripcion_ParameterSet = descripcion;
                }
                if (lineaActual.StartsWith("Parameters \"CParameters\""))
                {
                    lineaActual = getLineaActual(objArchivo);
                    while (lineaActual != null && lineaActual != "END DSRECORD")
                    {
                        parametros += lineaActual + '\n';
                        lineaActual = getLineaActual(objArchivo);
                    }
                }

                if (lineaActual != "END DSRECORD")
                {
                    lineaActual = getLineaActual(objArchivo);
                }
            }

            objParameterSet.listaParam = getListaParamParameterSet(parametros, objParameterSet);
            ProcesoParameterSet.setDocInterna(objParameterSet.docInterna, descripcion);

            return lineaActual;
        }

        /**
         * Funciones para obtener datos del stage, como tambien sus DSSUBRECORD
         * 
         * **/

        private string buscarPropiedadStage(LogStage stage, StreamReader objArchivo)  //agregar job
                                                                                      // private string buscarPropiedadStage(LogStage stage, StreamReader objArchivo, List<LogStage> listaStage)
        {
            stage.stageType = "";
            stage.stageJobActivity.listaParametroJobActivity = new List<LogObjetoParam>();

            string lineaActual = getLineaActual(objArchivo); //Readonly "0"
            while (lineaActual != "END DSRECORD")
            {

                //obtener datos de Parametros JobActivity 
                if (stage.oleType == ConstanteDataStage.OLETYPE_CJS_JOB_ACTIVITY)
                {
                    if (lineaActual.StartsWith("ParameterValues \"CParamValues\""))
                    {
                        lineaActual = getLineaActual(objArchivo);
                        string valorParmSecuencial = "";
                        while (!lineaActual.StartsWith("CheckPoint"))
                        {
                            valorParmSecuencial += lineaActual + '\n';
                            lineaActual = getLineaActual(objArchivo);
                        }

                        stage.stageJobActivity.listaParametroJobActivity = getListaParamJobActivity(valorParmSecuencial);
                    }
                }
                //obtener datos de Parametros de Stage Routine 
                if (stage.oleType == ConstanteDataStage.OLETYPE_CJS_ROUTINE_ACTIVITY)
                {
                    if (lineaActual.StartsWith("ParameterValues \"CParamValues\""))
                    {
                        lineaActual = getLineaActual(objArchivo);
                        string valorParmRoutine = "";
                        while (!lineaActual.StartsWith("CheckPoint"))
                        {
                            valorParmRoutine += lineaActual + '\n';
                            lineaActual = getLineaActual(objArchivo);
                        }

                        stage.stageRoutineActivity.listaParametroRoutine = getListaParamRoutine(valorParmRoutine);
                    }
                }

                //obtener datos de Parametros de Stage CJSUserVarsActivity 
                if (stage.oleType == ConstanteDataStage.OLETYPE_CJS_USER_VAR_ACTIVITY)
                {
                    if (lineaActual.StartsWith("Variables \"CParamValues\""))
                    {
                        lineaActual = getLineaActual(objArchivo);
                        string valorParmUserVariable = "";
                        while (!lineaActual.StartsWith("StageType"))
                        {
                            valorParmUserVariable += lineaActual + '\n';
                            lineaActual = getLineaActual(objArchivo);
                        }
                        stage.stageUserVarsActivity.listaParametroVariable = ProcesoUserVarsActivity.getListaParamUserVariableActivity(valorParmUserVariable);
                    }
                }
                /*Nombre de la rutina*/
                if (lineaActual.StartsWith("Routinename"))//Name Routine"
                {
                    string routineName = UtilArchivoDSX.getNombreRoutine(lineaActual);
                    stage.stageRoutineActivity.routineName = routineName;
                }

                if (lineaActual.StartsWith("Name"))//Name "
                {
                    string nombreStage = UtilArchivoDSX.getNombreStage(lineaActual);
                    stage.nameStage = nombreStage;
                }
                if (lineaActual.StartsWith("ExecutionType"))//ExecutionType "2"
                {
                    string executionType = UtilArchivoDSX.getExecutionTypeJobActivity(lineaActual);
                    stage.stageJobActivity.executionType = executionType;
                }
                if (lineaActual.StartsWith("Jobname"))
                {
                    string nombreJobName = UtilArchivoDSX.getNombreJobActivity(lineaActual);
                    stage.stageJobActivity.jobName = nombreJobName;
                }
                /**/
                if (lineaActual.StartsWith("SourceID"))
                {
                    string valorSource = UtilArchivoDSX.getValorSource(lineaActual);
                    stage.sourceId = valorSource;
                }
                if (lineaActual.StartsWith("Partner"))
                {
                    string valorPartner = UtilArchivoDSX.getValorPartner(lineaActual);
                    stage.partner = valorPartner;
                }
                if (lineaActual.StartsWith("ConditionType"))
                {
                    string conditiontype = UtilArchivoDSX.getValorConditionType(lineaActual);
                    stage.conditionType = conditiontype;
                }

                //NextID "
                if (lineaActual.StartsWith("InputPins"))//InputPins "
                {
                    string inputPins = UtilArchivoDSX.getInputPins(lineaActual);
                    stage.inputPins = inputPins;
                }
                if (lineaActual.StartsWith("OutputPins"))//OutputPins "
                {
                    string outputPins = UtilArchivoDSX.getOutputPins(lineaActual);
                    stage.outputPins = outputPins;
                }


                if (lineaActual == "Columns \"COutputColumn\"")
                {  //PARA VALIDAR LINAJE(TABLE DEFINITION)
                    int TotalCampos;
                    int TotalTableDef;
                    TotalCampos = 0;
                    TotalTableDef = 0;

                    //while (lineaActual != "MetaBag \"CMetaProperty\"" || lineaActual != "END DSRECORD")
                    while (lineaActual != "MetaBag \"CMetaProperty\"")
                    {
                        if (lineaActual == "BEGIN DSSUBRECORD")
                        {
                            TotalCampos = TotalCampos + 1;
                        }

                        if (lineaActual.StartsWith("TableDef \"Database") || lineaActual.StartsWith("TableDef \"Relational"))
                        {
                            TotalTableDef = TotalTableDef + 1;
                        }

                        //sacar columnas
                        lineaActual = getLineaActual(objArchivo);
                        if (lineaActual == "END DSRECORD")
                        {
                            break;
                        }
                    }
                    stage.TotalColumnas = TotalCampos;
                    stage.TotalTableDef = TotalTableDef;

                }

                //if (lineaActual.StartsWith("Routinename"))//Name Routine"
                //{
                //    string routineName = UtilArchivoDSX.getNombreRoutine(lineaActual);
                //    stage.stageRoutineActivity.routineName = routineName;
                //}

                //TERMINATOR "        

                // if (lineaActual.StartsWith("Jobname"))
                // {
                //     string nombre = UtilArchivoDSX.getNombreJobActivity(lineaActual);
                //     //stage.stageJobActivity.jobName = nombre;
                // }
                // //string nombreJob = "ERR_STG_PC_SBP_CASTIGOS" + stage.stageJobActivity.jobName;
                //// string nombreJob = stage.stageJobActivity.jobName;
                if (lineaActual.StartsWith("FinalMessage"))
                {
                    string nombreDescFinal = UtilArchivoDSX.getDesFinalMessage(lineaActual);
                    stage.stageTerminatorActivity.descFinalMessage = nombreDescFinal;
                    stage.stageTerminatorActivity.finalMessage = true;
                }

                if (lineaActual.StartsWith("LogText"))
                {
                    string nombreDescLogText = UtilArchivoDSX.getDesLogText(lineaActual);
                    stage.stageTerminatorActivity.descLogText = nombreDescLogText;
                    stage.stageTerminatorActivity.logText = true;
                }

                if (lineaActual.StartsWith("FullDescription"))
                {
                    string nombreDescFullDescrip = UtilArchivoDSX.getDesFullDesciption(lineaActual);
                    stage.stageTerminatorActivity.descFullDescription = nombreDescFullDescrip;
                    stage.stageTerminatorActivity.fullDescription = true;
                }

                if (lineaActual.StartsWith("StageType"))//StageType "
                {
                    string stageType = UtilArchivoDSX.getStageType(lineaActual);
                    stage.stageType = stageType;
                }

                if (lineaActual.StartsWith("InputPins"))
                {
                    string nombreInputPings = UtilArchivoDSX.getInputPins(lineaActual);
                    stage.stageTerminatorActivity.InputPins = nombreInputPings;
                }


                //-----------para el asunto de mensajes-----------//

                if (lineaActual.StartsWith("Subject"))
                {
                    string AsuntoMensaje = UtilArchivoDSX.getAsuntoMensaje(lineaActual);
                    stage.stageNotificationActivity.asunto = AsuntoMensaje;
                }


                if (lineaActual == "Properties \"CCustomProperty\"")
                {
                    if (stage.oleType == ConstanteDataStage.OLETYPE_C_CUSTOM_INPUT //ConstanteDataStage.TIPO_LINK_INPUT_1
                        || stage.oleType == ConstanteDataStage.OLETYPE_C_TRX_INPUT //ConstanteDataStage.TIPO_LINK_INPUT_2
                        || stage.oleType == ConstanteDataStage.OLETYPE_C_CUSTOM_OUTPUT //ConstanteDataStage.TIPO_LINK_OUTPUT_1
                        || stage.oleType == ConstanteDataStage.OLETYPE_C_TRX_OUTPUT) //ConstanteDataStage.TIPO_LINK_OUTPUT_2)//links de stage de job parallel, los de sequential
                    {
                        lineaActual = getPropiedadFilenameFromLink(stage, objArchivo); //luego de setearlo en el link, pasarlo al stage dataset o sequential file
                    }

                    //obtener informacion del stage para validar despues
                    if (stage.stageType == ConstanteDataStage.TIPO_DB2
                        || stage.stageType == ConstanteDataStage.TIPO_DB2_2)
                    {
                        lineaActual = getPropiedadStageDB2(stage, objArchivo);  //agregar job
                    }

                    //obtener informacion del stage ODBC para validar despues
                    if (stage.stageType == ConstanteDataStage.TIPO_ODBC)
                    {
                        lineaActual = getPropiedadStageODBC(stage, objArchivo);
                    }

                    if (stage.stageType == ConstanteDataStage.TIPO_AGGREGATOR)
                    {
                        lineaActual = getPropiedadMethodAggregator(stage, objArchivo);
                    }


                    while (lineaActual != "END DSRECORD")
                    {
                        lineaActual = getLineaActual(objArchivo);
                    }
                }

                if (lineaActual == "MetaBag \"CMetaProperty\"")
                {
                    if (stage.oleType == ConstanteDataStage.OLETYPE_C_TRANSFORMER_STAGE)
                    {
                        lineaActual = getPropiedadVariablesTransformer(stage, objArchivo);
                    }

                    while (lineaActual != "END DSRECORD")
                    {
                        lineaActual = getLineaActual(objArchivo);
                    }
                }

                //if (lineaActual.StartsWith("Columns"))
                //{
                //    //PARA VALIDAR LINAJE(TABLE DEFINITION)

                //    int TotalCampos;
                //    int TotalTableDef;
                //    TotalCampos = 0;
                //    TotalTableDef = 0;
                //    while (lineaActual != "MetaBag \"CMetaProperty\"")
                //    //while (lineaActual != "MetaBag \"CMetaProperty\"" || lineaActual != "END DSRECORD")
                //    {
                //        if (lineaActual == "BEGIN DSSUBRECORD")
                //        {
                //            TotalCampos = TotalCampos + 1;
                //        }
                //        if (lineaActual.StartsWith("TableDef \"Database"))
                //        {
                //            TotalTableDef = TotalTableDef + 1;
                //        }
                //        lineaActual = getLineaActual(objArchivo);
                //        if (lineaActual == "END DSRECORD")
                //        {
                //            break;
                //        }
                //    }
                //    stage.TotalColumnas = TotalCampos;
                //    stage.TotalTableDef = TotalTableDef;
                //    //ValidaLinaje(stage, TotalCampos, TotalTableDef);
                //}

                //Console.WriteLine(lineaActual);
                if (lineaActual != "END DSRECORD")
                {
                    lineaActual = getLineaActual(objArchivo);
                }
            }

            return lineaActual;
        }

        //private void ValidaLinaje(LogStage stage, int TotalCampos, int TotalTableDef)
        //{
        //    stage.TotalColumnas = TotalCampos;
        //    stage.TotalTableDef = TotalTableDef;
        //}

        private List<LogObjetoParam> getListaParamJobActivity(string parametro)
        {
            List<LogObjetoParam> lista = new List<LogObjetoParam>();

            string[] arregloSecuencial = parametro.Split('\n');
            for (int i = 0; i < arregloSecuencial.Length; i++)
            {
                if (arregloSecuencial[i].StartsWith("Name"))
                {
                    LogObjetoParam param = new LogObjetoParam();
                    param.name = arregloSecuencial[i].Substring(6, arregloSecuencial[i].Length - 7);
                    lista.Add(param);
                }
            }

            return lista;
        }

        private List<LogObjetoParam> getListaParamRoutine(string parametroRoutine)
        {
            List<LogObjetoParam> lista = new List<LogObjetoParam>();
            if (parametroRoutine != null)
            {
                string[] arregloParmRoutine = parametroRoutine.Split('\n');

                for (int i = 0; i < arregloParmRoutine.Length; i++)
                {
                    int next = i;
                    if (arregloParmRoutine[i].StartsWith("Name"))
                    {
                        next++;
                        LogObjetoParam param = new LogObjetoParam();
                        param.name = arregloParmRoutine[i].Substring(6, arregloParmRoutine[i].Length - 7);

                        if (arregloParmRoutine[next].StartsWith("Description"))
                        {
                            param.description = arregloParmRoutine[next].Substring(13, arregloParmRoutine[next].Length - 14).Trim();
                        }

                        lista.Add(param);
                    }
                }
            }

            return lista;
        }

        private void setearArchivoFromLink(List<LogStage> listaStage)
        {
            if (listaStage != null && listaStage.Count > 0)
            {
                for (int i = 0; i < listaStage.Count; i++)
                {
                    LogStage s = listaStage[i];

                    if (s.stageType == ConstanteDataStage.TIPO_DATA_SET
                        || s.stageType == ConstanteDataStage.TIPO_SEQUENTIAL_FILE)
                    {
                        string id = "";
                        if (s.inputPins != null)
                        {
                            id = s.inputPins;
                        }
                        else
                        {
                            id = s.outputPins;
                        }

                        LogStage linkArchivo = UtilDataStage.getStageByIdentifier(id, listaStage);
                        if (linkArchivo != null)
                        {
                            s.stageArchivo.fileName = linkArchivo.stageArchivo.fileName;
                        }

                    }
                }
            }
        }

        private List<LogStage> quitarStagesDuplicados(List<LogStage> listaStage)
        {
            List<LogStage> listaSinDup = new List<LogStage>();
            if (listaStage != null && listaStage.Count > 0)
            {
                for (int i = 0; i < listaStage.Count; i++)
                {
                    LogStage stage = listaStage[i];
                    if (stage.oleType != ConstanteDataStage.OLETYPE_C_CUSTOM_INPUT
                        && stage.oleType != ConstanteDataStage.OLETYPE_C_TRX_INPUT
                        && stage.oleType != ConstanteDataStage.OLETYPE_CJS_ACTIVITY_INPUT)
                    {
                        listaSinDup.Add(stage);
                    }
                    //if (stage.OLEType != ConstanteDataStage.OLETYPE_C_CUSTOM_OUTPUT
                    //    && stage.OLEType != ConstanteDataStage.OLETYPE_C_TRX_OUTPUT
                    //    && stage.OLEType != ConstanteDataStage.OLETYPE_CJS_ACTIVITY_OUTPUT)
                    //{
                    //    listaSinDup.Add(stage);
                    //}
                }
            }

            return listaSinDup;
        }
        /**
         * Funciones para obtener datos del Header
         * 
         * **/
        private string setearHeader(LogHeader header, StreamReader objArchivo, string lineaActual)
        {
            while (lineaActual != "END HEADER")
            {
                if (lineaActual.StartsWith("Date"))
                {
                    header.fecha = UtilArchivoDSX.getHeaderDate(lineaActual);
                }
                if (lineaActual.StartsWith("Time"))
                {
                    header.hora = UtilArchivoDSX.getHeaderTime(lineaActual);
                }

                lineaActual = getLineaActual(objArchivo);
            }

            return lineaActual;
        }

        /**
         * Funciones para obtener datos del job
         * **/
        private LogJob buscarPropiedadJob(StreamReader objArchivo)
        {
            LogJob j = new LogJob();
            string nombre = getLineaActual(objArchivo);
            string fecha = getLineaActual(objArchivo);
            string hora = getLineaActual(objArchivo);

            j.identifierJob = UtilArchivoDSX.getIdentifierObjeto(nombre);
            j.dateModified = UtilArchivoDSX.getDateModifiedObjeto(fecha);
            j.timeModified = UtilArchivoDSX.getTimeModifiedObjeto(hora);

            return j;
        }

        private void setProbandoPKenDU(LogJob j, StreamReader objArchivo, string lineaActual2)
        {
            //string lineaActual2 = getLineaActual2(objArchivo);
            bool stageDB2DuJob = false;
            bool probandoPKJob = false;
            string vamosviendo = "";
            /*    while (lineaActual2 != "OrchestrateCode =+=+=+=")
                  {
                      lineaActual2 = getLineaActual2(objArchivo);
                  }
                  string aa = lineaActual2;
             */

            while (lineaActual2 != "=+=+=+=")
            {
                if (lineaActual2.StartsWith("#### STAGE: db2_DU") || lineaActual2.StartsWith("#### STAGE: db2_EDWSTG_DU"))
                {
                    stageDB2DuJob = true;
                    vamosviendo = lineaActual2;
                    while (lineaActual2 != "## General options")
                    {
                        if (lineaActual2.StartsWith("DSIsKey"))  //JT - Verifica si hay PK en el Stage DB2
                        {
                            probandoPKJob = true;
                        }
                        lineaActual2 = getLineaActual2(objArchivo);
                    }
                }
                lineaActual2 = getLineaActual2(objArchivo);
            }
            lineaActual2 = getLineaActual2(objArchivo);

            j.stageDB2DuJob = stageDB2DuJob;
            j.probandoPKJob = probandoPKJob;
            j.vamosviendo = vamosviendo;

        }


        //setearle valores adicionales al job, como ruta y tipo
        private void setPropiedadJob(LogJob j, StreamReader objArchivo)
        {
            string valorParmParalelo = "";
            string fullDescripcion = "";
            string jobType = "";
            string ruta = "";
            string description = "";

            bool encontradoJobType = false;
            bool encontradoCategory = false;
            bool encontradoFullDescripcion = false;
            bool encontradoParmParalelo = false;
            bool encontradoDescription = false;
            bool PKenDU = false;
            // logBase.encontradoPKenTablaDU = false;  //JT
            //bool encontradoCheck = false;
            //bool tieneDependency = false;
            //string codeOptionsJob = "";

            string lineaActual = getLineaActual(objArchivo);

            //string acumulda = null;
            //if (lineaActual.StartsWith("#### STAGE: db2_DU") || lineaActual.StartsWith("#### STAGE: db2_EDWSTG_DU"))//JT - Verifica si hay PK en el Stage DB2
            //{
            //    while (lineaActual != "## General options")
            //    {
            //        acumulda += lineaActual + "\n";
            //        stageDB2Du = true;
            //        if (lineaActual.StartsWith("DSIsKey"))  //JT - Verifica si hay PK en el Stage DB2
            //        {
            //            probandoPK = true;
            //        }
            //        lineaActual = getLineaActual(objArchivo);
            //    }
            //}
            //else
            //{
            //    lineaActual = getLineaActual(objArchivo);
            //}

            while (lineaActual != "END DSRECORD")
            {
                if (!encontradoDescription && lineaActual.StartsWith("Description"))
                {
                    description = UtilArchivoDSX.getDescriptionJob(lineaActual);
                    encontradoDescription = true;
                }

                if (!encontradoFullDescripcion && lineaActual.StartsWith("FullDescription"))
                {
                    string lineafin = getLineaActual(objArchivo);
                    while (lineafin != "=+=+=+=")
                    {
                        fullDescripcion += lineafin + '\n';
                        lineafin = getLineaActual(objArchivo);
                    }
                    encontradoFullDescripcion = true;
                }

                //obtener los valores de parametros de job paralelo
                if (!encontradoParmParalelo && lineaActual.StartsWith("Parameters \"CParameters\""))
                {
                    string lineafin = getLineaActual(objArchivo);
                    while (!lineafin.StartsWith("MetaBag \"CMetaProperty\""))
                    {
                        valorParmParalelo += lineafin + '\n';
                        lineafin = getLineaActual(objArchivo);
                    }
                    encontradoParmParalelo = true;
                }

                //
                // aca estaria lo que necesito
                //
                if (lineaActual.StartsWith("OrchestrateCode =+=+=+="))
                {
                    setProbandoPKenDU(j, objArchivo, lineaActual);
                }

                if (!encontradoJobType && lineaActual.StartsWith("JobType"))
                {
                    jobType = UtilArchivoDSX.getJobType(lineaActual);
                    encontradoJobType = true;
                }
                if (!encontradoCategory && lineaActual.StartsWith("Category"))
                {
                    ruta = UtilArchivoDSX.getCategoryObjeto(lineaActual);
                    encontradoCategory = true;
                }

                //if (lineaActual.StartsWith("Dependencies"))
                //{
                //    tieneDependency = true;
                //}

                if (lineaActual.StartsWith("JobSeqCodeGenOpts"))
                {
                    if (lineaActual.Contains("checkpoints"))
                    {
                        j.checkpoints = "checkpoints";
                    }
                    if (lineaActual.Contains("logjoberrors"))
                    {
                        j.logjoberrors = "logjoberrors";
                    }
                    if (lineaActual.Contains("logjobreports"))
                    {
                        j.logjobreports = "logjobreports";
                    }
                }
                lineaActual = getLineaActual(objArchivo);
            }

            j.jobType = jobType;
            j.category = ruta;
            j.PKenTablaDU = PKenDU;
            if (ruta == null)
            {
                //int iii = 0;
            }
            j.listaParamJob = getListaParamJob(valorParmParalelo);
            j.docInterna.description = description;

            ProcesoJob.setDocInterna(j.docInterna, fullDescripcion);
            //j.docInterna.nombre = ProcesoJob.getDocIntNombre(fullDescripcion);
            //j.docInterna.listaDependencias = ProcesoJob.getDocIntListaDependencias(fullDescripcion);
            //j.docInterna.listaFuentes = ProcesoJob.getDocIntListaFuentes(fullDescripcion);
            //j.docInterna.listaDestino = ProcesoJob.getDocIntListaDestino(fullDescripcion);
            //j.docInterna.listaVersion = ProcesoJob.getDocIntListaVersion(fullDescripcion);

            //j.dependecy = tieneDependency;
            //j.check = codeOptionsJob;
        }

        private List<LogObjetoParam> getListaParamJob(string parametro)
        {
            List<LogObjetoParam> lista = new List<LogObjetoParam>();
            LogObjetoParam param = new LogObjetoParam();

            string[] arregloSecuencial = parametro.Split('\n');
            for (int i = 0; i < arregloSecuencial.Length; i++)
            {
                if (arregloSecuencial[i] == "BEGIN DSSUBRECORD")
                {
                    param = new LogObjetoParam();
                }

                if (arregloSecuencial[i].StartsWith("Name"))
                {
                    param.name = UtilArchivoDSX.getParamName(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("Prompt"))
                {
                    param.solicitud = UtilArchivoDSX.getParamPrompt(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("Default"))
                {
                    param.valorPredeterminado = UtilArchivoDSX.getParamDefault(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("ParamType"))
                {
                    param.tipo = UtilArchivoDSX.getParamType(arregloSecuencial[i]);
                }

                if (arregloSecuencial[i] == "END DSSUBRECORD")
                {
                    lista.Add(param);
                }
            }

            return lista;
        }

        private List<LogParam> getListaParamParameterSet(string parametro, LogParameterSet parameter)
        {
            List<LogParam> lista = new List<LogParam>();
            LogParam param = null;

            string[] arregloSecuencial = parametro.Split('\n');
            for (int i = 0; i < arregloSecuencial.Length; i++)
            {
                if (arregloSecuencial[i] == "BEGIN DSSUBRECORD")
                {
                    param = new LogParam();
                    param.oleType = ConstanteDataStage.OLETYPE_C_PARAMETRO;
                    param.paramType = ConstanteDataStage.TYPE_PARAMETRO;
                    param.textoAyuda = "";
                    param.parameter = parameter;
                }

                if (arregloSecuencial[i].StartsWith("Name"))
                {
                    param.name = UtilArchivoDSX.getParamName(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("Prompt"))
                {
                    param.solicitud = UtilArchivoDSX.getParamPrompt(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("Default"))
                {
                    param.valorPredeterminado = UtilArchivoDSX.getParamDefault(arregloSecuencial[i]);
                }
                if (arregloSecuencial[i].StartsWith("ParamType"))
                {
                    param.tipo = UtilArchivoDSX.getParamType(arregloSecuencial[i]);
                }

                if (arregloSecuencial[i] == "END DSSUBRECORD")
                {
                    lista.Add(param);
                }
            }

            return lista;
        }

        private string buscarPropiedadRoutineAndArgument(LogRoutine objRoutine, StreamReader objArchivo)
        {
            bool encontradoIdentifier = false;
            bool encontradoDateModified = false;
            bool encontradoTimeModified = false;
            bool encontradoOLEType = false;
            bool encontradoCategory = false;
            bool encontradoShortDesc = false;
            bool encontradoRoutineType = false;
            string descripcion = "";
            string lineaActual = getLineaActual(objArchivo);

            while (lineaActual != "END DSRECORD")
            {
                if (!encontradoIdentifier && lineaActual.StartsWith("Identifier"))
                {
                    objRoutine.identifier = UtilArchivoDSX.getIdentifierObjeto(lineaActual);
                    encontradoIdentifier = true;
                }
                if (!encontradoDateModified && lineaActual.StartsWith("DateModified"))
                {
                    objRoutine.dateModified = UtilArchivoDSX.getDateModifiedObjeto(lineaActual);
                    encontradoDateModified = true;
                }
                if (!encontradoTimeModified && lineaActual.StartsWith("TimeModified"))
                {
                    objRoutine.timeModified = UtilArchivoDSX.getTimeModifiedObjeto(lineaActual);
                    encontradoTimeModified = true;
                }
                if (!encontradoOLEType && lineaActual.StartsWith("OLEType"))
                {
                    objRoutine.oleType = UtilArchivoDSX.getOLETypeObjeto(lineaActual);
                    encontradoOLEType = true;
                }
                if (!encontradoCategory && lineaActual.StartsWith("Category"))
                {
                    objRoutine.category = UtilArchivoDSX.getCategoryObjeto(lineaActual);
                    encontradoCategory = true;
                }
                if (!encontradoShortDesc && lineaActual.StartsWith("ShortDesc"))
                {
                    objRoutine.shortDesc = UtilArchivoDSX.getShortDescRoutine(lineaActual);
                    encontradoShortDesc = true;
                }
                if (lineaActual.StartsWith("Description =+=+=+="))
                {
                    lineaActual = getLineaActual(objArchivo);
                    while (lineaActual != "=+=+=+=")
                    {
                        descripcion += lineaActual + '\n';
                        lineaActual = getLineaActual(objArchivo);
                    }
                    //objParameterSet.descripcion_ParameterSet = descripcion;
                    objRoutine.descripcion_routine = descripcion;
                }
                if (!encontradoRoutineType && lineaActual.StartsWith("RoutineType"))
                {
                    objRoutine.routineType = UtilArchivoDSX.getRoutineType(lineaActual);
                    encontradoRoutineType = true;
                }

                //obtener valores de Argumento Routine
                if (lineaActual.StartsWith("Arguments \"CRtnArgument\""))
                {
                    List<LogArgument> listaArgRoutine = objRoutine.listaArgumentoRoutine;

                    string lineafin = getLineaActual(objArchivo);

                    while (!lineafin.StartsWith("SkipOnNull \"0\""))
                    {
                        if (lineafin.StartsWith("BEGIN DSSUBRECORD"))
                        {

                            LogArgument objArgRoutine = new LogArgument();
                            objArgRoutine.oleType = ConstanteDataStage.OLETYPE_C_ARGUMENT;
                            objArgRoutine.argumentType = "";

                            while (lineafin != "END DSSUBRECORD")
                            {
                                if (lineafin.StartsWith("Name"))
                                {
                                    objArgRoutine.nameArgRoutine = UtilArchivoDSX.getArgNameRoutine(lineafin);
                                }
                                if (lineafin.StartsWith("Desc"))
                                {
                                    objArgRoutine.descArgRoutine = UtilArchivoDSX.getArgDescRoutine(lineafin);
                                }
                                lineafin = getLineaActual(objArchivo);
                            }

                            objArgRoutine.routine = objRoutine;
                            listaArgRoutine.Add(objArgRoutine);
                        }
                        else
                        {
                            lineafin = getLineaActual(objArchivo);
                        }
                    }

                    objRoutine.listaArgumentoRoutine = listaArgRoutine;
                }


                lineaActual = getLineaActual(objArchivo);
            }

            return lineaActual;
        }

        private string getPropiedadVariablesTransformer(LogStage stage, StreamReader objArchivo)
        {
            List<string> listaVariablesStage = new List<string>();
            List<string> listaVariablesLoop = new List<string>();

            string lineaActual = getLineaActual(objArchivo);

            while (!lineaActual.Contains("END DSRECORD"))
            {
                /**
                 StageVars "CStageVar"
                 BEGIN DSSUBRECORD
                    Name "svNew"
                    ...
                 END DSSUBRECORD
                 * **/
                if (lineaActual == "StageVars \"CStageVar\"")
                {
                    while (!lineaActual.Contains("END DSRECORD")
                        && !lineaActual.StartsWith("LoopCondition")
                        && !lineaActual.StartsWith("LoopVars"))
                    {
                        if (lineaActual.StartsWith("BEGIN DSSUBRECORD"))
                        {
                            string lineaNombre = getLineaActual(objArchivo); // Name "..."
                            string nombreVar = UtilArchivoDSX.getNombreVariableTransformer(lineaNombre);
                            listaVariablesStage.Add(nombreVar);
                        }


                        lineaActual = getLineaActual(objArchivo);
                    }
                }

                if (lineaActual == "LoopVars \"CStageVar\"")
                {
                    while (!lineaActual.Contains("END DSRECORD"))
                    {
                        if (lineaActual.StartsWith("BEGIN DSSUBRECORD"))
                        {
                            string lineaNombre = getLineaActual(objArchivo); // Name "..."
                            string nombreVar = UtilArchivoDSX.getNombreVariableTransformer(lineaNombre);
                            listaVariablesLoop.Add(nombreVar);
                        }
                        lineaActual = getLineaActual(objArchivo);
                    }
                }

                lineaActual = getLineaActual(objArchivo);
            }

            stage.stageTransformer.listaStageVariable = listaVariablesStage;
            stage.stageTransformer.listaLoopVariable = listaVariablesLoop;

            //stage.propiedadTransformerStageVariable = listaVariablesStage;
            //stage.propiedadTransformerLoopVariable = listaVariablesLoop;

            return lineaActual;
        }

        private string getPropiedadStageDB2(LogStage stage, StreamReader objArchivo)
        {//propiedades a partir del orchestrate

            //propiedates a partir del link
            string propiedad = "";
            string lineaXML = "";
            string lineaFin = "";
            bool esFinal = false;

            string lineaActual = getLineaActual(objArchivo);

            while (!esFinal && !lineaActual.Contains("END DSRECORD"))
            {
                /**
                 BEGIN DSSUBRECORD
                    Name "XMLProperties"
                    ...
                 END DSSUBRECORD
                 * **/
                if (lineaActual == "Name \"XMLProperties\"")
                {
                    lineaXML = getLineaActual(objArchivo);
                    lineaFin = getLineaActual(objArchivo);
                    if (lineaFin.Contains("END DSSUBRECORD"))
                    {
                        propiedad = lineaXML;
                    }
                    else if (lineaXML == "Value =+=+=+=")
                    {
                        while (lineaFin != "=+=+=+=")
                        {
                            propiedad += "\n" + lineaFin;
                            lineaFin = getLineaActual(objArchivo);
                        }

                    }
                    esFinal = true;
                }

                lineaActual = getLineaActual(objArchivo);
            }

            ProcesoBaseDato.setearConexion(propiedad, stage.stageBaseDato);
            stage.stageBaseDato.recordCount = ProcesoBaseDato.getRecordCount(propiedad);
            stage.stageBaseDato.recordCountModidy = ProcesoBaseDato.getRecordCountModify(propiedad);  //JT
            stage.stageBaseDato.arraySize = ProcesoBaseDato.getArraySize(propiedad);  //JT
            stage.stageBaseDato.arrayZizeModidy = ProcesoBaseDato.getArraySizeModify(propiedad); //JT
            stage.stageBaseDato.LockWaitMode = ProcesoBaseDato.getLockWaitMode(propiedad);  //JT
            stage.stageBaseDato.LockWaitModeModify = ProcesoBaseDato.getLockWaitModeModify(propiedad); //JT
            stage.stageBaseDato.autoCommitMode = ProcesoBaseDato.getAutoCommitMode(propiedad);
            stage.stageBaseDato.writeMode = ProcesoBaseDato.getWriteMode(propiedad);
            stage.stageBaseDato.beforeAfter = ProcesoBaseDato.getBeforeAfter(propiedad);
            stage.stageBaseDato.keepConductorConnectionAlive = ProcesoBaseDato.getKeepConductorConnectionAlive(propiedad);


            List<string> listaSQL = ProcesoBaseDato.getListaQuery(propiedad);
            List<string> listaSQLValida = ProcesoBaseDato.getListaQueryValida(listaSQL);

            stage.stageBaseDato.estaComentario = ProcesoBaseDato.estaComentario(listaSQL);
            stage.stageBaseDato.listaSQLValida = listaSQLValida;
            stage.stageBaseDato.listaTabla = ProcesoBaseDato.getListaTablaDB2(listaSQLValida);

            return lineaActual;
        }

        private string getPropiedadStageODBC(LogStage stage, StreamReader objArchivo)
        {//propiedades a partir del orchestrate

            //propiedates a partir del link
            string propiedad = "";
            string lineaXML = "";
            string lineaFin = "";
            bool esFinal = false;

            string lineaActual = getLineaActual(objArchivo);

            while (!esFinal && !lineaActual.Contains("END DSRECORD"))
            {
                /**
                 BEGIN DSSUBRECORD
                    Name "XMLProperties"
                    ...
                 END DSSUBRECORD
                 * **/
                if (lineaActual == "Name \"XMLProperties\"")
                {
                    lineaXML = getLineaActual(objArchivo);
                    lineaFin = getLineaActual(objArchivo);
                    if (lineaFin.Contains("END DSSUBRECORD"))
                    {
                        propiedad = lineaXML;
                    }
                    else if (lineaXML == "Value =+=+=+=")
                    {
                        while (lineaFin != "=+=+=+=")
                        {
                            propiedad += "\n" + lineaFin;
                            lineaFin = getLineaActual(objArchivo);
                        }

                    }
                    esFinal = true;
                }

                lineaActual = getLineaActual(objArchivo);
            }

            ProcesoBaseDato.setearConexionODBC(propiedad, stage.stageBaseDato);
            stage.stageBaseDato.recordCount = ProcesoBaseDato.getRecordCount(propiedad);
            stage.stageBaseDato.recordCountModidy = ProcesoBaseDato.getRecordCountModify(propiedad);  //JT
            stage.stageBaseDato.arraySize = ProcesoBaseDato.getArraySize(propiedad);  //JT
            stage.stageBaseDato.arrayZizeModidy = ProcesoBaseDato.getArraySizeModify(propiedad); //JT
            // stage.stageBaseDato.LockWaitMode = ProcesoBaseDato.getLockWaitMode(propiedad);  //JT
            // stage.stageBaseDato.LockWaitModeModify = ProcesoBaseDato.getLockWaitModeModify(propiedad); //JT
            // stage.stageBaseDato.autoCommitMode = ProcesoBaseDato.getAutoCommitMode(propiedad);
            // stage.stageBaseDato.writeMode = ProcesoBaseDato.getWriteMode(propiedad);
            stage.stageBaseDato.beforeAfter = ProcesoBaseDato.getBeforeAfter(propiedad);
            // stage.stageBaseDato.keepConductorConnectionAlive = ProcesoBaseDato.getKeepConductorConnectionAlive(propiedad);


            List<string> listaSQL = ProcesoBaseDato.getListaQueryODBC(propiedad);
            List<string> listaSQLValida = ProcesoBaseDato.getListaQueryValida(listaSQL);

            stage.stageBaseDato.estaComentario = ProcesoBaseDato.estaComentario(listaSQL);
            stage.stageBaseDato.listaSQLValida = listaSQLValida;
            stage.stageBaseDato.listaTabla = ProcesoBaseDato.getListaTablaDB2(listaSQLValida);

            return lineaActual;
        }


        private string getPropiedadMethodAggregator(LogStage stage, StreamReader objArchivo)  //JT
        {
            string propiedad = "";
            //stage.propiedadDataset = "";

            string lineaActual = getLineaActual(objArchivo);

            while (lineaActual != "END DSRECORD")
            {
                /**
                    BEGIN DSRECORD
                    Identifier "V2S1P1"
                    OLEType "CCustomInput"
                     
                        BEGIN DSSUBRECORD
                            Name "method"
                            Value "hash"
                        END DSSUBRECORD
                 * **/
                if (lineaActual == "Name \"method\"")
                {
                    propiedad = getLineaActual(objArchivo);
                    propiedad = UtilArchivoDSX.getValueDataset(propiedad);
                    stage.stageAggregator.method = propiedad;
                    //stage.propiedadDataset = propiedad;
                }

                lineaActual = getLineaActual(objArchivo);
            }

            //stage.stageArchivo.fileName = propiedad;

            return lineaActual;
        }

        private string getPropiedadPKenTablaDu(LogStage stage, StreamReader objArchivo)  //JT
        {
            string propiedad = "";
            string lineaActual = getLineaActual(objArchivo);

            while (lineaActual != "END DSRECORD")
            {

                if (lineaActual == "-target 0 '{")
                {
                    propiedad = getLineaActual(objArchivo);
                    //  propiedad = UtilArchivoDSX.getValueDataset(propiedad);
                    //stage.stageAggregator.method = propiedad;
                    stage.stageBaseDato.pk_du = propiedad;
                    //stage.propiedadDataset = propiedad;
                }

                lineaActual = getLineaActual(objArchivo);
            }

            //stage.stageArchivo.fileName = propiedad;

            return lineaActual;
        }


        private string getPropiedadFilenameFromLink(LogStage stage, StreamReader objArchivo)
        {
            string propiedad = "";
            //stage.propiedadDataset = "";

            string lineaActual = getLineaActual(objArchivo);

            while (lineaActual != "END DSRECORD")
            {
                /**
                    BEGIN DSRECORD
                    Identifier "V2S1P1"
                    OLEType "CCustomInput"
                     
                        BEGIN DSSUBRECORD
                            Name "dataset"
                            Value "#PARM_PATH.$PATH_WORK#STG_01_MA_D_ESTADOCIVIL.ds"
                        END DSSUBRECORD
                 * **/
                if (lineaActual == "Name \"dataset\"")
                {
                    propiedad = getLineaActual(objArchivo);
                    propiedad = UtilArchivoDSX.getValueDataset(propiedad);
                    //stage.propiedadDataset = propiedad;
                }

                /*
                 
                      BEGIN DSSUBRECORD
                         Name "file"
                         Value "\(2)\(2)0\(1)\(3)file\(2)#PARM_CI_FTP_DMCONV.$SBP_DMCONV_FTP_FOLDER_SWITCH#REJ_QA_DMCONV_EXTENSION_EMPRESAS.txt\(2)0"
                      END DSSUBRECORD                 
                 * **/
                if (lineaActual == "Name \"file\"")
                {
                    propiedad = getLineaActual(objArchivo);
                    propiedad = UtilArchivoDSX.getValueFile(propiedad, 1);
                    //stage.propiedadFile = propiedad;
                }
                /*
                 
                      BEGIN DSSUBRECORD
                         Name "file"
                         Value "\(2)\(2)0\(1)\(3)file \(2)#PARM_CI_FTP_DMCONV.$SBP_DMCONV_FTP_FOLDER_SWITCH#QA_DMCONV_EXTENSION_EMPRESAS.txt\(2)0"
                      END DSSUBRECORD                 
                 * **/
                if (lineaActual == "Name \"file \"")
                {
                    propiedad = getLineaActual(objArchivo);
                    propiedad = UtilArchivoDSX.getValueFile(propiedad, 2);
                    //stage.propiedadFile = propiedad;
                }


                if (lineaActual == "Columns \"COutputColumn\"")
                {  //PARA VALIDAR LINAJE(TABLE DEFINITION)
                    int TotalCampos;
                    int TotalTableDef;
                    TotalCampos = 0;
                    TotalTableDef = 0;
                    //while (lineaActual != "MetaBag \"CMetaProperty\"" || lineaActual != "END DSRECORD")                    
                    while (lineaActual != "MetaBag \"CMetaProperty\"")
                    {
                        if (lineaActual == "BEGIN DSSUBRECORD")
                        {
                            TotalCampos = TotalCampos + 1;
                        }
                        if (lineaActual.StartsWith("TableDef \"Database"))
                        {
                            TotalTableDef = TotalTableDef + 1;
                        }
                        //sacar columnas
                        lineaActual = getLineaActual(objArchivo);
                        if (lineaActual == "END DSRECORD")
                        {
                            break;
                        }
                    }
                    stage.TotalColumnas = TotalCampos;
                    stage.TotalTableDef = TotalTableDef;
                    //stage.stageBaseDato.pk_du = propiedad;
                }
                if (lineaActual != "END DSRECORD")
                {
                    lineaActual = getLineaActual(objArchivo);
                }
            }

            stage.stageArchivo.fileName = propiedad;

            return lineaActual;
        }

        private string getLineaActual(StreamReader objArchivo)
        {
            contador++;
            string s = objArchivo.ReadLine();
            if (s != null)
            {
                return s.Trim();
            }
            else
            {
                return s;
            }
        }

        private string getLineaActual2(StreamReader objArchivo)
        {
            contador++;
            string s = objArchivo.ReadLine();
            if (s != null)
            {
                return s.Trim();
            }
            else
            {
                return s;
            }
        }

    }

}
