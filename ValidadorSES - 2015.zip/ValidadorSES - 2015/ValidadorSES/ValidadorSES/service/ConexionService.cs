﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ValidadorSES.modelo;
using System.IO;

namespace ValidadorSES.service
{
    class ConexionService
    {

        private int contador { get; set; }

        public Conexion getConexion()
        {
            string path = Path.GetPathRoot(Environment.CurrentDirectory);
            string rutaArchivo = path + "conexionSQL.properties";

            Conexion cnx = new Conexion();

            string lineaActual = "";
            StreamReader objArchivo = new StreamReader(rutaArchivo, System.Text.Encoding.GetEncoding("Windows-1252"), true);  //System.Text.Encoding.UTF8, true
            lineaActual = getLineaActual(objArchivo);

            while (lineaActual != null)
            {
                if (lineaActual.StartsWith("DATA_SOURCE:"))
                {
                    cnx.datasource = lineaActual.Substring(12, lineaActual.Length - 12);
                    cnx.datasource = cnx.datasource.Trim();
                }
                if (lineaActual.StartsWith("DATABASE:"))
                {
                    cnx.database = lineaActual.Substring(9, lineaActual.Length - 9);
                    cnx.database = cnx.database.Trim();
                }
                if (lineaActual.StartsWith("USER:"))
                {
                    cnx.user = lineaActual.Substring(5, lineaActual.Length - 5);
                    cnx.user = cnx.user.Trim();
                }
                if (lineaActual.StartsWith("PASS:"))
                {
                    cnx.password = lineaActual.Substring(5, lineaActual.Length - 5);
                    cnx.password = cnx.password.Trim();
                }

                lineaActual = getLineaActual(objArchivo);
            }

            return cnx;
        }

        private string getLineaActual(StreamReader objArchivo)
        {
            contador++;
            string s = objArchivo.ReadLine();
            if (s != null)
            {
                return s.Trim();
            }
            else
            {
                return s;
            }
        }
    }
}
