﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.modelo.view;

namespace ValidadorSES.form
{
    public partial class FormValidadorListadoRegla : Form
    {
        public const string TBL_REGLA_CODIGO = "Código";
        public const string TBL_REGLA_OBJETO = "Objeto";
        public const string TBL_REGLA_NOMBRE = "Nombre";
        public const string TBL_REGLA_DESCRIPCION = "Descripción";
        public const string TBL_REGLA_AMPLIAR_DESCRIPCION = "ver más descripción";
        public const int TBL_REGLA_POS_ABRIR_AMPLIAR_DESCRIPCION = 3;
        public const string TBL_REGLA_SUGERENCIA = "Sugerencia de solución";
        public const string TBL_REGLA_AMPLIAR_SUGERENCIA = "ver más sugerencia";
        public const int TBL_REGLA_POS_ABRIR_AMPLIAR_SUGERENCIA = 5;

        public string tipoValidacion { get; set; }

        public FormValidadorListadoRegla()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_VALIDADOR_LISTADO_REGLA;

            tipoValidacion = ConstanteMaestro.COD_TIP_VAL_EXPRESS;
            mostrarTablaListadoRegla();
        }
        
        private void mostrarTablaListadoRegla() {
            List<ReglaView> lista = new List<ReglaView>();

            try
            {
                ReglaDAO rdao = new ReglaDAO();
                lista = rdao.getListaReglaViewByTipoValidacion(tipoValidacion);
            }catch(Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            llenarTabla(lista);
        }

        private void llenarTabla(List<ReglaView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_CODIGO));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_OBJETO));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_DESCRIPCION));
            table.Columns.Add(UtilForm.getColumnString(TBL_REGLA_SUGERENCIA));
            
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    ReglaView rv = lista[j];
                    DataRow row = table.NewRow();
                    row[TBL_REGLA_CODIGO] = rv.codigoRegla;
                    row[TBL_REGLA_OBJETO] = rv.tipoObjeto;
                    row[TBL_REGLA_NOMBRE] = rv.nombre;
                    row[TBL_REGLA_DESCRIPCION] = rv.descripcion;
                    row[TBL_REGLA_SUGERENCIA] = rv.sugerencia;

                    table.Rows.Add(row);
                }
            }

            dataGridViewRegla.Columns.Clear();
            DataView view = new DataView(table);

            dataGridViewRegla.Visible = true;
            dataGridViewRegla.RowHeadersVisible = false;
            dataGridViewRegla.DataSource = view;
            
            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewRegla.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "";
            buttonColumn.Text = "...";
            buttonColumn.Name = TBL_REGLA_AMPLIAR_DESCRIPCION;
            buttonColumn.DisplayIndex = TBL_REGLA_POS_ABRIR_AMPLIAR_DESCRIPCION;
            buttonColumn.UseColumnTextForButtonValue = true;
            buttonColumn.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);

            DataGridViewButtonColumn buttonColumn2 = new DataGridViewButtonColumn();
            dataGridViewRegla.Columns.Add(buttonColumn2);
            buttonColumn2.HeaderText = "";
            buttonColumn2.Text = "...";
            buttonColumn2.Name = TBL_REGLA_AMPLIAR_SUGERENCIA;
            buttonColumn2.DisplayIndex = TBL_REGLA_POS_ABRIR_AMPLIAR_SUGERENCIA;
            buttonColumn2.UseColumnTextForButtonValue = true;
            buttonColumn2.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);

            dataGridViewRegla.Columns[TBL_REGLA_OBJETO].Width = 100;
            dataGridViewRegla.Columns[TBL_REGLA_NOMBRE].Width = 300;
            dataGridViewRegla.Columns[TBL_REGLA_AMPLIAR_DESCRIPCION].Width = 50;
            dataGridViewRegla.Columns[TBL_REGLA_DESCRIPCION].Width = 600;
            dataGridViewRegla.Columns[TBL_REGLA_AMPLIAR_SUGERENCIA].Width = 50;
            dataGridViewRegla.Columns[TBL_REGLA_SUGERENCIA].Width = 600;

            dataGridViewRegla.Columns[TBL_REGLA_CODIGO].Visible = false;
        }

        private void dataGridViewRegla_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewRegla.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 0) //indice del boton amplicar descripcion
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewRegla.CurrentCell.RowIndex;

                string texto = dataGridViewRegla.Rows[filaSeleccionada].Cells[TBL_REGLA_DESCRIPCION].Value.ToString();
                mostrarTexto(TBL_REGLA_DESCRIPCION, texto);
            }

            if (rowIndex > -1 && columnaSeleccionada == 1) //posición del boton ampliar sugerencia
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewRegla.CurrentCell.RowIndex;

                string texto = dataGridViewRegla.Rows[filaSeleccionada].Cells[TBL_REGLA_SUGERENCIA].Value.ToString();
                mostrarTexto(TBL_REGLA_SUGERENCIA, texto);
            }
        }

        private void mostrarTexto(string titulo, string texto)
        {
            if (texto != null && texto != "")
            {
                string desConSalto = texto;
                desConSalto = desConSalto.Replace(": ", ": \n");
                desConSalto = desConSalto.Replace(". ", ". \n\n");
                MessageBox.Show(desConSalto, titulo, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
