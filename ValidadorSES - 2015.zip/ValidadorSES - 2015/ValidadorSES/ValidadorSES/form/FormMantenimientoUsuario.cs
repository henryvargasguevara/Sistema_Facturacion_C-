﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;
using System.Data.SqlClient;
namespace ValidadorSES.form
{
    public partial class FormMantenimientoUsuario : Form
    {
        UsuarioDAO daousuario = new UsuarioDAO();
        MaestroDAO daoMaestro = new MaestroDAO();
        public Usuario usuariologeado {get; set;}
        public const string TBL_OBJ_EDITAR = "Editar";
        public const int TBL_OBJ_POS_EDITAR = 0;
        public const string TBL_USU_CODIGO = "Código";
        public const string TBL_USU_NOMBRES = "Nombre";
        public const string TBL_USU_APELLIDOS = "Apellidos";
        public const string TBL_USU_CARGOS = "Cargo";
        public const string TBL_USU_LIDER = "Lider";
        public const string TBL_USU_ESTADO = "Estado";
        public const string TBL_USU_USER = "Usuario";
        public const string TBL_USU_CONTRASEÑA = "Contraseña";
        public const string TBL_USU_FEC_CREACION = "Fecha creación";
        public const string TBL_USU_FEC_MODIFICACION = "Fecha Modificación";
        public const string TBL_USU_USUARIO_CREACION = "Usuario creación";
        public const string TBL_USU_USUARIO_MODIFICACION = "Usuario modificación";
        public const string TBL_USU_PREGUNTA= "Pregunta Secreta";
        public const string TBL_USU_RESPUESTA = "Respuesta Secreta";

        public FormMantenimientoUsuario()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_MANTENIMIENTO_USUARIO;

            mostrarTablaListadoUsuario();

            deshabilitarCampos();
            /*CARGAR LISTADO DE CARGOS*/
            cboMantCargoUser.DataSource = daoMaestro.getListaCargoNuevo();
            cboMantCargoUser.DisplayMember = "nombre";
            cboMantCargoUser.ValueMember = "valor_key";
            /*CARGAR LISTADO DE ESTADO DE USUARIO*/
            cboMantEstadoUser.DataSource= daoMaestro.getListaEstadoUsuario();
            cboMantEstadoUser.DisplayMember = "nombre";
            cboMantCargoUser.ValueMember = "valor_key";
            /*CARGAR LISTADO DE PREGUNTAS SECRETAS*/
            cboPreguntaSecreta.DataSource = daoMaestro.getListaPreguntaSecreta();
            cboPreguntaSecreta.DisplayMember = "nombre";
            cboPreguntaSecreta.ValueMember = "valor_key";
        }

#region Metodos limpieza y habilitacion de controles
        
        public void limpiarInterfaz()
        {
            txtMantApellidoUser.Clear();
            txtMantBuscarUser.Clear();
            txtMantContraseñaUser.Clear();
            txtMantNombreUser.Clear();
            txtMantUsuarioUser.Clear();
            txtcodigoUsuario.Clear();
            cboMantEstadoUser.SelectedIndex = -1;
            cboMantCargoUser.SelectedIndex = 1;
            cboMantLiderUser.SelectedIndex = 0;
            cboPreguntaSecreta.SelectedIndex = -1;
            txtRespuestaSecreta.Clear();
        }
        
        private void habilitarCampos() {
            txtMantNombreUser.Enabled = true;
            txtMantApellidoUser.Enabled = true;
            cboMantCargoUser.Enabled = true;
            cboMantLiderUser.Enabled = true;
            cboMantEstadoUser.Enabled = true;
            txtMantUsuarioUser.Enabled = true;
            txtMantContraseñaUser.Enabled = true;
            cboPreguntaSecreta.Enabled = true;
            txtRespuestaSecreta.Visible = true;
            lblRespuesta.Visible = true;
        }
        
        private void deshabilitarCampos() {

            txtMantNombreUser.Enabled = false;
            txtMantApellidoUser.Enabled = false;
            cboMantCargoUser.Enabled = false;
            cboMantLiderUser.Enabled = false;
            cboMantEstadoUser.Enabled = false;
            txtMantUsuarioUser.Enabled = false;
            txtMantContraseñaUser.Enabled = false;
            cboPreguntaSecreta.Enabled = false;
            txtRespuestaSecreta.Visible = false;
            lblRespuesta.Visible = false;
           
        }
#endregion

#region Metodos especificos
        
        private void mostrarTablaListadoUsuario()
        {
            List<UsuarioView> lista = new List<UsuarioView>();
            try
            {
                UsuarioDAO daoUsuario = new UsuarioDAO();
                lista = daousuario.getListaUsuarioView();
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de usuario");
            }
            llenarTabla(lista);
        }
        
        private void llenarTabla(List<UsuarioView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_CODIGO));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_NOMBRES));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_APELLIDOS));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_CARGOS));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_LIDER));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_USER));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_CONTRASEÑA));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_FEC_CREACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_FEC_MODIFICACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_USUARIO_CREACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_USUARIO_MODIFICACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_PREGUNTA));
            table.Columns.Add(UtilForm.getColumnString(TBL_USU_RESPUESTA));
           //table.Columns.Add(UtilForm.getColumnString(TBL_USU_USUARIO_MODIFICACION));
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                UsuarioDAO dao = new UsuarioDAO();
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    UsuarioView ov = lista[j];
                    DataRow row = table.NewRow();
                    row[TBL_USU_CODIGO] = ov.codigo;
                    row[TBL_USU_NOMBRES] = ov.nombres;
                    row[TBL_USU_APELLIDOS] = ov.apellidos;
                    row[TBL_USU_CARGOS] = ov.cargo;
                    row[TBL_USU_LIDER] = ov.lider;
                    row[TBL_USU_ESTADO] = ov.estado;
                    row[TBL_USU_USER] = ov.usuario;
                    row[TBL_USU_CONTRASEÑA] = ov.contraseña;//dao.EncriptarContraseña(ov.contraseña);
                    row[TBL_USU_FEC_CREACION] = ov.fechaCreacion;
                    row[TBL_USU_FEC_MODIFICACION] = ov.fechaModificacion;
                    row[TBL_USU_USUARIO_CREACION] = ov.usuarioCreador;
                    row[TBL_USU_USUARIO_MODIFICACION] = ov.usuarioModificador;
                    row[TBL_USU_PREGUNTA] = ov.pregunta;
                    row[TBL_USU_RESPUESTA] = ov.respuesta;
                    table.Rows.Add(row);
                }
            }
            dgMantUsuario.Columns.Clear();
            DataView view = new DataView(table);
            //DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            //dgMantUsuario.Columns.Add(buttonColumn);
            //buttonColumn.HeaderText = TBL_OBJ_EDITAR;
            //buttonColumn.Text = ">";
            //buttonColumn.Name = TBL_OBJ_EDITAR;
            //buttonColumn.DisplayIndex = 0;
            //buttonColumn.UseColumnTextForButtonValue = true;
            dgMantUsuario.Visible = true;
            dgMantUsuario.RowHeadersVisible = false;
            dgMantUsuario.DataSource = view;
            //dgMantUsuario.Columns[TBL_OBJ_EDITAR].Width = 40;
            dgMantUsuario.Columns[TBL_USU_CODIGO].Width = 50;
            dgMantUsuario.Columns[TBL_USU_NOMBRES].Width = 80;
            //dgMantUsuario.Columns[TBL_USU_APELLIDOS].Width = 150;
            //dgMantUsuario.Columns[TBL_USU_CARGOS]manuel.Width = 150;
            //dgMantUsuario.Columns[TBL_USU_LIDER].Width = 150;
            dgMantUsuario.Columns[TBL_USU_ESTADO].Width = 80;
            //dgMantUsuario.Columns[TBL_USU_USER].Width = 170;
            dgMantUsuario.Columns[TBL_USU_CONTRASEÑA].Visible=false;
            dgMantUsuario.Columns[TBL_USU_FEC_CREACION].Width = 150;
            dgMantUsuario.Columns[TBL_USU_FEC_MODIFICACION].Width = 150;
            dgMantUsuario.Columns[TBL_USU_PREGUNTA].Width = 130;
            dgMantUsuario.Columns[TBL_USU_RESPUESTA].Visible = false;
            dgMantUsuario.Columns[TBL_USU_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgMantUsuario.Columns[TBL_USU_FEC_CREACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgMantUsuario.Columns[TBL_USU_FEC_MODIFICACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

#endregion 



#region Eventos 
        
        private void btnMantUserRegistrar_Click(object sender, EventArgs e)
        {
            Usuario obj = getUsuarioValidado();

            if (obj != null)
            {
                if (obj.nombres.Trim() == "" || obj.apellidos.Trim() == "" ||
                   obj.cargo_usuario == -1 || obj.estado == "" ||
                   obj.usuario.Trim() == "" || obj.contraseña.Trim() == "" ||
                    obj.pregunta == "" || obj.respuesta.Trim() == "")
                {
                    MessageBox.Show("ingrese todos los campos", "ERROR!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                }
                else
                {
                    List<UsuarioView> lista = new List<UsuarioView>();
                    string cod = txtcodigoUsuario.Text;
                    try
                    {
                        UsuarioDAO odao = new UsuarioDAO();
                        if (cod == "" || cod == null)
                        {
                            bool existeUser = odao.getExisteUsuario(obj.usuario);
                            if (existeUser)
                            {
                                MessageBox.Show("Usuario ya existe, escoga otro!", "ERROR!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                            }
                            else
                            {
                                odao.insertarUsuario(obj);
                                MessageBox.Show("Usuario Registrado correctamente", "AVISO");
                                lista = odao.getListaUsuarioView();
                                llenarTabla(lista);
                                deshabilitarCampos();
                            }
                        }
                        else
                        {
                            Usuario estado = odao.getEstadoLider(obj.lider);
                            if (estado.estado == "2")
                            {
                                MessageBox.Show("Lider Inhabilitado, escoger a otro lider", "AVISO");
                            }
                            else
                            {
                                odao.actualizarUsuario(obj);
                                MessageBox.Show("Usuario actualizado correctamente", "AVISO");
                                lista = odao.getListaUsuarioView();
                                llenarTabla(lista);
                                deshabilitarCampos();
                            }
                        }
                        //lista = odao.getListaUsuarioView();
                        //llenarTabla(lista);
                        //deshabilitarCampos();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ocurrió un error al registrar el objeto a la BD -> " + ex);
                    }
                }
            }
        }

        private Usuario getUsuarioValidado()
        {
            string mensaje = "";
            Usuario obj = null;
            int codigo = -1;
            if (!string.IsNullOrEmpty(txtcodigoUsuario.Text))
            {
                codigo = int.Parse(txtcodigoUsuario.Text);
            }
            string nombres = txtMantNombreUser.Text;
            string apellidos = txtMantApellidoUser.Text;
            int cargo = UtilUsuario.getCodigoCargoUsuario(cboMantCargoUser.Text);
            Usuario usercombo = (Usuario)cboMantLiderUser.SelectedItem;
            int lider = usercombo.codigo_Usuario;
            string estado = UtilUsuario.getCodigoEstadoUsuario(cboMantEstadoUser.Text);
            string usuario = txtMantUsuarioUser.Text;
            string contraseña = txtMantContraseñaUser.Text;
            string Pregunta = UtilUsuario.getCodigoPreguntaSecreta(cboPreguntaSecreta.Text);
            string Respuesta = txtRespuestaSecreta.Text;
            //if (lider != 0)
            //{
                if (mensaje == "")
                {
                    obj = new Usuario();
                    obj.codigo_Usuario = codigo;
                    obj.nombres = nombres;
                    obj.apellidos = apellidos;
                    obj.cargo_usuario = cargo;
                    obj.lider = lider;
                    obj.estado = estado;
                    obj.usuario = usuario;
                    obj.contraseña = contraseña;
                    obj.fecha_creacion = DateTime.Now;
                    obj.fecha_modificacion = DateTime.Now;
                    obj.usuario_creador = usuariologeado.codigo_Usuario; ;
                    obj.usuario_modificador = usuariologeado.codigo_Usuario;
                    obj.pregunta = Pregunta;
                    obj.respuesta = Respuesta;
                }
            //}
            //else
            //{
            //    MessageBox.Show("Seleccione un lider", "ERRROR!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            //}
            return obj;
        }
        
        private void btnManUserNuevo_Click(object sender, EventArgs e)
        {
            limpiarInterfaz();
            habilitarCampos();

            cboMantCargoUser.DataSource = daoMaestro.getListaCargoNuevo();
            cboMantCargoUser.DisplayMember = "nombre";
            cboMantCargoUser.ValueMember = "valor_key";
        }
        
        private void txtMantBuscarUser_TextChanged(object sender, EventArgs e)
        {
            //txtMantBuscarUser.Text = txtMantBuscarUser.Text.Trim();
            string textoBuscar = txtMantBuscarUser.Text;

            if (textoBuscar != "")
            {
                List<UsuarioView> lista = new List<UsuarioView>();
                try
                {
                    UsuarioDAO odao = new UsuarioDAO();
                    lista = odao.getListaBuscarUsuario(textoBuscar);
                }
                catch (Exception e2)
                {
                    MessageBox.Show("Ocurrió un error de BD : "+ e2);
                }

                llenarTabla(lista);
            }
            else
            {
                List<UsuarioView> lista = new List<UsuarioView>();
                try
                {
                    UsuarioDAO odao = new UsuarioDAO();
                    lista = odao.getListaBuscarUsuario(textoBuscar);
                }
                catch (Exception e2)
                {
                    MessageBox.Show("Ocurrió un error de BD : " + e2);
                }
                llenarTabla(lista);
            }
        }
        
        private void dgMantUsuario_SelectionChanged(object sender, EventArgs e)
        {


            /*CARGAR LISTADO DE CARGOS*/
            cboMantCargoUser.DataSource = daoMaestro.getListaCargo();
            cboMantCargoUser.DisplayMember = "nombre";
            cboMantCargoUser.ValueMember = "valor_key";
            try
            {
                string codigo = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_CODIGO].Value;
                string nombres = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_NOMBRES].Value;
                string apellidos = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_APELLIDOS].Value;
                string usuario = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_USER].Value;
                string cargo = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_CARGOS].Value;
                string lider = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_LIDER].Value;
                string estado = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_ESTADO].Value;
                string contraseña = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_CONTRASEÑA].Value;
                string pregunta = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_PREGUNTA].Value;
                string respuesta = (string)dgMantUsuario.CurrentRow.Cells[TBL_USU_RESPUESTA].Value;

                txtcodigoUsuario.Text = codigo;
                txtMantNombreUser.Text = nombres;
                txtMantApellidoUser.Text = apellidos;
                txtMantUsuarioUser.Text = usuario;
                txtMantContraseñaUser.Text = contraseña;
                cboMantCargoUser.Text = cargo;
                cboMantLiderUser.Text = lider;
                cboMantEstadoUser.Text = estado;
                cboPreguntaSecreta.Text = pregunta;
                txtRespuestaSecreta.Text = respuesta;
                deshabilitarCampos();
                //int columnaSeleccionada = dgMantUsuario.CurrentCell.RowIndex;
                //int numerofila = dgMantUsuario.RowCount;
                //if (columnaSeleccionada == numerofila-1)
                //{
                //    MessageBox.Show("Seleccione fila valida", "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //}
                //    if (columnaSeleccionada == 0)
                //    {
                //        habilitarCampos();
                //    }
                //    else
                //    {
                //        deshabilitarCampos();
                //    }
            }
            catch (Exception e1) 
            {
                MessageBox.Show("error al seleccionar usuario de datagridview" + e1);
            }

        } 
        
        private void cboMantCargoUser_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            int selectvalor = UtilUsuario.getCodigoCargoUsuario(cboMantCargoUser.Text);
            if (selectvalor != 0)
            {
                //cboMantLiderUser.Enabled = true;
                List<Usuario> lista = daousuario.getListaUsuarioPorCargo(selectvalor - 1);

                //int contador=lista.Count;
                //if (contador < 1)
                //{
                //    MessageBox.Show("No hay lider de grupo, agregar al menos uno", "AVISO");
                //}
                //else
                //{
                    cboMantLiderUser.DataSource = lista;
                    cboMantLiderUser.DisplayMember = "fullName";
                    cboMantLiderUser.ValueMember = "codigo_Usuario";
                //}
            }
            //else
            //{
            //    MessageBox.Show("Seleccione un cargo para el usuario", "ERROR!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            //}
        }
        
        private void btnMantModificarUser_Click(object sender, EventArgs e)
        {
            habilitarCampos();

            cboMantCargoUser.DataSource = daoMaestro.getListaCargoNuevo();
            cboMantCargoUser.DisplayMember = "nombre";
            cboMantCargoUser.ValueMember = "valor_key";

        }

#endregion
    }
}
