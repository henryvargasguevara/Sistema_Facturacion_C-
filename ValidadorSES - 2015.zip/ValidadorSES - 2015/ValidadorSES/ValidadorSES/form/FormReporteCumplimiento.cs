﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo.view;
using ValidadorSES.util;
using ValidadorSES.dao;

namespace ValidadorSES.form
{
    public partial class FormReporteCumplimiento : Form
    {
        ReportesDAO dao = new ReportesDAO();

        public FormReporteCumplimiento()
        {
            InitializeComponent();
            this.Text = ConstanteTituloForm.TITULO_REPORTE_CUMPLIMIENTO;

            mostrarTablaReporteCumplimiento();
            gbResultado.Visible = false;
        }

        private void llenarTablaReporteCumplimiento(List<ReporteCumplimientoView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString("CODIGO"));
            table.Columns.Add(UtilForm.getColumnString("COLABORADOR"));
            table.Columns.Add(UtilForm.getColumnString("ID ASIGNACION"));
            table.Columns.Add(UtilForm.getColumnString("DESCRIPCION"));
            table.Columns.Add(UtilForm.getColumnString("FECHA ENTREGA"));
            table.Columns.Add(UtilForm.getColumnString("FECHA VALIDACIÓN"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO DSX"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO CUMPLIMIENTO"));
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                //RequerimientoDAO dao = new RequerimientoDAO();
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    ReporteCumplimientoView ov = lista[j];
                    DataRow row = table.NewRow();
                    row["CODIGO"] = ov.codigo;
                    row["COLABORADOR"] = ov.usuario;
                    row["ID ASIGNACION"] = ov.codigo_Asignacion_Requerimiento;
                    row["DESCRIPCION"] = ov.descripcion;
                    row["FECHA ENTREGA"] = ov.fecha_entrega;
                    row["FECHA VALIDACIÓN"] = ov.fecha_Validacion;
                    row["ESTADO DSX"] = ov.estado_dsx;
                    row["ESTADO CUMPLIMIENTO"] = ov.estado_Cumplimiento;
                    table.Rows.Add(row);
                }
            }

            dgReporteCumplimiento.Columns.Clear();
            DataView view = new DataView(table);

            dgReporteCumplimiento.Visible = true;
            dgReporteCumplimiento.RowHeadersVisible = false;
            dgReporteCumplimiento.DataSource = view;

            dgReporteCumplimiento.Columns["CODIGO"].Width = 70;
            dgReporteCumplimiento.Columns["COLABORADOR"].Width = 100;
            dgReporteCumplimiento.Columns["ID ASIGNACION"].Width = 115;
            dgReporteCumplimiento.Columns["DESCRIPCION"].Width = 120;
            dgReporteCumplimiento.Columns["FECHA ENTREGA"].Width = 135;
            dgReporteCumplimiento.Columns["FECHA VALIDACIÓN"].Width = 135;
            dgReporteCumplimiento.Columns["ESTADO DSX"].Width = 100;
            dgReporteCumplimiento.Columns["ESTADO CUMPLIMIENTO"].Width = 160;

        }

        private void mostrarTablaReporteCumplimiento()
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();

            try
            {
                lista = dao.getListaReportesCumplimiento();
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaReporteCumplimiento(lista);
        }

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();
            string filtro = txtFiltro.Text;

            try
            {
                lista = dao.getListaFiltroCumplimiento(filtro);
                gbResultado.Visible = false;
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaReporteCumplimiento(lista);
        }


        private void btnBuscar_Click(object sender, EventArgs e)
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();
            DateTime f1 = dtpF1.Value;
            DateTime f2 = dtpF2.Value;

            f1 = new DateTime(f1.Year, f1.Month, f1.Day, 00, 00, 00, DateTime.Now.Kind);
            f2= new DateTime(f2.Year, f2.Month, f2.Day, 23, 59, 59, DateTime.Now.Kind);
            
            try
            {
                lista = dao.getListaFiltrofecha(f1,f2);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaReporteCumplimiento(lista);
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            List<ReporteCumplimientoView> lista = new List<ReporteCumplimientoView>();
            int casteado= 0;
            string filtro = "";
            try
            {
                filtro = txtFiltro.Text;
                casteado = int.Parse(filtro);
            }
            catch (Exception)
            {
                MessageBox.Show("Ingrese el código del colaborador válido", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
               return ;
            }
            
            
            try
            {
                if (!dao.getFiltrarColaborador(casteado))
                {
                     casteado = int.Parse(filtro);
                    MessageBox.Show("El colaborado no se encuentra en lista de trabajos terminados", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    gbResultado.Visible = false;
                    mostrarTablaReporteCumplimiento();
                    txtFiltro.Text = "";
                }
                else
                {
                    casteado = int.Parse(filtro);
                    lista = dao.getListaFiltroCumplimientoPorColaborador(casteado);
                    gbResultado.Visible = true;
                    llenarTablaReporteCumplimiento(lista);
                    lblEstadoColaborador.Text = obtenerPorcentaje();
                    lblPositivo.Text = obtenerPorcentajePositivo();
                    lblNegativo.Text = obtenerPorcentajeNegativo();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }
           
            
        }

        private string obtenerPorcentaje() 
        {
            string result= "";
            int numPositivo = 0;
            int numNegativo = 0;
            int numfilas = dgReporteCumplimiento.RowCount;
            for (int i = 0; i < numfilas; i++)
            {
                string estado = (string)dgReporteCumplimiento.Rows[i].Cells["ESTADO CUMPLIMIENTO"].Value;
                if (estado == "No cumple")
                {
                    numNegativo ++;
                }
                else
                {
                    numPositivo++; ;
                }
            }
            if (numPositivo < numNegativo)
            {
                result = "Tiene un estado de cumplimiento Negativo";
            }
            else
            {
                result = "Tiene un estado de cumplimiento Positivo";
            }

            return result;
        }

        private string obtenerPorcentajePositivo()
        {
            string result = "";
            //int operacion = 0;
            float numPositivo = 0;
            int numfilas = dgReporteCumplimiento.RowCount;
            for (int i = 0; i < numfilas; i++)
            {
                string estado = (string)dgReporteCumplimiento.Rows[i].Cells["ESTADO CUMPLIMIENTO"].Value;
                if (estado == "Cumple")
                {
                    numPositivo++;
                }
            }
           float operacion = (numPositivo / numfilas) * 100;
           int pos = (int)operacion ;

           return result = pos + "";
        }
        
        private string obtenerPorcentajeNegativo()
        {
            string result = "";
            float numNegativo = 0;
            int numfilas = dgReporteCumplimiento.RowCount;
            for (int i = 0; i < numfilas; i++)
            {
                string estado = (string)dgReporteCumplimiento.Rows[i].Cells["ESTADO CUMPLIMIENTO"].Value;
                if (estado == "No cumple")
                {
                    numNegativo++;
                }
                
            }
            float operacion = (numNegativo / numfilas) * 100;
            int pos = (int)operacion;

            return result = pos + "";
        }
    }
}
