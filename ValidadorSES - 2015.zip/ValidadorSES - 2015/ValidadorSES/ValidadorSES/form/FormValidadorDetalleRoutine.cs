﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormValidadorDetalleRoutine : Form
    {
        public const string TBL_ARGUMENT_NOMBRE = "Nombre Argument";
        public const string TBL_ARGUMENT_DESCRIPCION = "Descripción";
        public const string TBL_ARGUMENT_ESTADO = "Estado";
        public const string TBL_ARGUMENT_DESCRIPCION_VALIDACION = "Descripción de validación del Argument";
        public const string TBL_ARGUMENT_NOMBRE_ROUTINE = "Nombre Routine";
        public const string TBL_ARGUMENT_TIPO_ROUTINE = "Tipo de Routine";

        public string routineDescripcionValidacion { get; set; }

        public FormValidadorDetalleRoutine()
        {
            InitializeComponent();
        }

        private void btnMostrarDesValid_Click(object sender, EventArgs e)
        {

            if (routineDescripcionValidacion != null && routineDescripcionValidacion != "")
            {
                string desConSalto = routineDescripcionValidacion;
                desConSalto = desConSalto.Replace(": ", ": \n");
                desConSalto = desConSalto.Replace(". ", ". \n\n");
                MessageBox.Show(desConSalto, "Validación de Routine", MessageBoxButtons.OK);
            }
        }

        private void dataGridViewDetalle_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewDetalle.Columns[e.ColumnIndex].Name.Equals(TBL_ARGUMENT_ESTADO))
            {
                string estado = dataGridViewDetalle.Rows[e.RowIndex].Cells[TBL_ARGUMENT_ESTADO].Value.ToString();
                if (estado.Equals("OK"))
                {
                    dataGridViewDetalle.Rows[e.RowIndex].Cells[TBL_ARGUMENT_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals("NOTOK"))
                    {
                        dataGridViewDetalle.Rows[e.RowIndex].Cells[TBL_ARGUMENT_ESTADO].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        //dataGridViewDetalle.Rows[e.RowIndex].Cells[FormPrincipal.TBL_STAGE_ESTADO].Style.ForeColor = Color.GreenYellow;
                    }

                }

            }
        }

        private void FormDetalleRoutine_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        public void cargarDetalleRoutine(LogRoutine routine)
        {
            routineDescripcionValidacion = routine.mensaje;
            Text = "Detalle de Routine - " + routine.identifier;
            lblNombreRoutine.Text = routine.identifier;
            txtRutaRoutine.Text = routine.category;
            txtDescripcionValidacionRoutine.Text = routine.mensaje;

            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView viewDetalle = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_ARGUMENT_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(TBL_ARGUMENT_DESCRIPCION));
            table.Columns.Add(UtilForm.getColumnString(TBL_ARGUMENT_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_ARGUMENT_DESCRIPCION_VALIDACION));

            //logica
            if (routine != null && routine.listaArgumentoRoutine.Count > 0)
            {
                int totalArgument = routine.listaArgumentoRoutine.Count;
                for (int j = 0; j < totalArgument; j++)
                {
                    LogArgument arg = routine.listaArgumentoRoutine[j];
                    DataRow row = table.NewRow();

                    row[TBL_ARGUMENT_NOMBRE] = arg.nameArgRoutine;
                    row[TBL_ARGUMENT_DESCRIPCION] = arg.descArgRoutine;
                    row[TBL_ARGUMENT_ESTADO] = arg.estadoArgumentDescripcion;
                    row[TBL_ARGUMENT_DESCRIPCION_VALIDACION] = arg.mensaje;

                    table.Rows.Add(row);
                }
            }

            viewDetalle = new DataView(table);

            //pintar en el detalle
            DataGridView dataViewDetalle = dataGridViewDetalle;
            dataViewDetalle.Visible = true;
            dataViewDetalle.RowHeadersVisible = false;
            dataViewDetalle.DataSource = viewDetalle;

            dataViewDetalle.Columns[TBL_ARGUMENT_NOMBRE].Width = 200;
            dataViewDetalle.Columns[TBL_ARGUMENT_DESCRIPCION].Width = 200;
            dataViewDetalle.Columns[TBL_ARGUMENT_ESTADO].Width = 90;
            dataViewDetalle.Columns[TBL_ARGUMENT_DESCRIPCION_VALIDACION].Width = 600;

            dataViewDetalle.Columns[TBL_ARGUMENT_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //totales
            txtTotalStage.Text = Convert.ToString(routine.listaArgumentoRoutine.Count);
            txtNroCorrectos.Text = Convert.ToString(routine.numArgCorrecto);
            txtNroIncorrecto.Text = Convert.ToString(routine.numArgIncorrecto);
            txtNroObservacion.Text = Convert.ToString(routine.numArgObservado);
        }
    }
}
