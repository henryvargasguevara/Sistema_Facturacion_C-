﻿namespace ValidadorSES.form
{
    partial class FormDSXListado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDSXListado));
            this.dataGridViewDSX = new System.Windows.Forms.DataGridView();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControlObjeto = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridViewJob = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridViewRoutine = new System.Windows.Forms.DataGridView();
            this.tabPageParameterSet = new System.Windows.Forms.TabPage();
            this.dataGridViewParameterSet = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSX)).BeginInit();
            this.tabControlObjeto.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewJob)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRoutine)).BeginInit();
            this.tabPageParameterSet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParameterSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewDSX
            // 
            this.dataGridViewDSX.AllowUserToAddRows = false;
            this.dataGridViewDSX.AllowUserToDeleteRows = false;
            this.dataGridViewDSX.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewDSX.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSX.Location = new System.Drawing.Point(12, 51);
            this.dataGridViewDSX.Name = "dataGridViewDSX";
            this.dataGridViewDSX.ReadOnly = true;
            this.dataGridViewDSX.Size = new System.Drawing.Size(829, 158);
            this.dataGridViewDSX.TabIndex = 3;
            this.dataGridViewDSX.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewDSX_CellFormatting);
            this.dataGridViewDSX.SelectionChanged += new System.EventHandler(this.dataGridViewDSX_SelectionChanged);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(12, 19);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(195, 20);
            this.lblTitulo.TabIndex = 4;
            this.lblTitulo.Text = "Listado de DSX validados:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 223);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Detalle de DSX:";
            // 
            // tabControlObjeto
            // 
            this.tabControlObjeto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlObjeto.Controls.Add(this.tabPage1);
            this.tabControlObjeto.Controls.Add(this.tabPage2);
            this.tabControlObjeto.Controls.Add(this.tabPageParameterSet);
            this.tabControlObjeto.Location = new System.Drawing.Point(12, 256);
            this.tabControlObjeto.Name = "tabControlObjeto";
            this.tabControlObjeto.SelectedIndex = 0;
            this.tabControlObjeto.Size = new System.Drawing.Size(829, 202);
            this.tabControlObjeto.TabIndex = 29;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridViewJob);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(821, 176);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "JOB";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridViewJob
            // 
            this.dataGridViewJob.AllowUserToAddRows = false;
            this.dataGridViewJob.AllowUserToDeleteRows = false;
            this.dataGridViewJob.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewJob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewJob.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewJob.Name = "dataGridViewJob";
            this.dataGridViewJob.ReadOnly = true;
            this.dataGridViewJob.Size = new System.Drawing.Size(789, 135);
            this.dataGridViewJob.TabIndex = 1;
            this.dataGridViewJob.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewJob_CellFormatting);
            this.dataGridViewJob.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewJob_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridViewRoutine);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(821, 176);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ROUTINE";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridViewRoutine
            // 
            this.dataGridViewRoutine.AllowUserToAddRows = false;
            this.dataGridViewRoutine.AllowUserToDeleteRows = false;
            this.dataGridViewRoutine.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewRoutine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRoutine.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewRoutine.Name = "dataGridViewRoutine";
            this.dataGridViewRoutine.ReadOnly = true;
            this.dataGridViewRoutine.Size = new System.Drawing.Size(789, 135);
            this.dataGridViewRoutine.TabIndex = 2;
            this.dataGridViewRoutine.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewRoutine_CellFormatting);
            this.dataGridViewRoutine.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRoutine_CellContentClick);
            // 
            // tabPageParameterSet
            // 
            this.tabPageParameterSet.Controls.Add(this.dataGridViewParameterSet);
            this.tabPageParameterSet.Location = new System.Drawing.Point(4, 22);
            this.tabPageParameterSet.Name = "tabPageParameterSet";
            this.tabPageParameterSet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageParameterSet.Size = new System.Drawing.Size(821, 176);
            this.tabPageParameterSet.TabIndex = 2;
            this.tabPageParameterSet.Text = "PARAMETER SET";
            this.tabPageParameterSet.UseVisualStyleBackColor = true;
            // 
            // dataGridViewParameterSet
            // 
            this.dataGridViewParameterSet.AllowUserToAddRows = false;
            this.dataGridViewParameterSet.AllowUserToDeleteRows = false;
            this.dataGridViewParameterSet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewParameterSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewParameterSet.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewParameterSet.Name = "dataGridViewParameterSet";
            this.dataGridViewParameterSet.ReadOnly = true;
            this.dataGridViewParameterSet.Size = new System.Drawing.Size(789, 135);
            this.dataGridViewParameterSet.TabIndex = 2;
            this.dataGridViewParameterSet.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewParameterSet_CellFormatting);
            this.dataGridViewParameterSet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewParameterSet_CellContentClick);
            // 
            // FormDSXListado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 470);
            this.Controls.Add(this.tabControlObjeto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.dataGridViewDSX);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormDSXListado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormDSXListado";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSX)).EndInit();
            this.tabControlObjeto.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewJob)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRoutine)).EndInit();
            this.tabPageParameterSet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParameterSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewDSX;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControlObjeto;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridViewJob;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridViewRoutine;
        private System.Windows.Forms.TabPage tabPageParameterSet;
        private System.Windows.Forms.DataGridView dataGridViewParameterSet;
    }
}