﻿namespace ValidadorSES.form
{
    partial class FormValidadorObjetoFaltante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormValidadorObjetoFaltante));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtListaVariableEntorno = new System.Windows.Forms.TextBox();
            this.txtListaJob = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtListaRoutine = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSI = new System.Windows.Forms.Button();
            this.btnNO = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(657, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Objetos DataStage faltantes necesarios para validación";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Variable de entorno:";
            // 
            // txtListaVariableEntorno
            // 
            this.txtListaVariableEntorno.Location = new System.Drawing.Point(120, 78);
            this.txtListaVariableEntorno.Multiline = true;
            this.txtListaVariableEntorno.Name = "txtListaVariableEntorno";
            this.txtListaVariableEntorno.ReadOnly = true;
            this.txtListaVariableEntorno.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtListaVariableEntorno.Size = new System.Drawing.Size(612, 78);
            this.txtListaVariableEntorno.TabIndex = 2;
            this.txtListaVariableEntorno.WordWrap = false;
            // 
            // txtListaJob
            // 
            this.txtListaJob.Location = new System.Drawing.Point(120, 178);
            this.txtListaJob.Multiline = true;
            this.txtListaJob.Name = "txtListaJob";
            this.txtListaJob.ReadOnly = true;
            this.txtListaJob.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtListaJob.Size = new System.Drawing.Size(612, 78);
            this.txtListaJob.TabIndex = 4;
            this.txtListaJob.WordWrap = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Jobs:";
            // 
            // txtListaRoutine
            // 
            this.txtListaRoutine.Location = new System.Drawing.Point(120, 274);
            this.txtListaRoutine.Multiline = true;
            this.txtListaRoutine.Name = "txtListaRoutine";
            this.txtListaRoutine.ReadOnly = true;
            this.txtListaRoutine.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtListaRoutine.Size = new System.Drawing.Size(612, 78);
            this.txtListaRoutine.TabIndex = 6;
            this.txtListaRoutine.WordWrap = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Routine:";
            // 
            // btnSI
            // 
            this.btnSI.Location = new System.Drawing.Point(425, 378);
            this.btnSI.Name = "btnSI";
            this.btnSI.Size = new System.Drawing.Size(75, 23);
            this.btnSI.TabIndex = 7;
            this.btnSI.Text = "Sí";
            this.btnSI.UseVisualStyleBackColor = true;
            this.btnSI.Click += new System.EventHandler(this.btnSI_Click);
            // 
            // btnNO
            // 
            this.btnNO.Location = new System.Drawing.Point(332, 378);
            this.btnNO.Name = "btnNO";
            this.btnNO.Size = new System.Drawing.Size(75, 23);
            this.btnNO.TabIndex = 8;
            this.btnNO.Text = "No";
            this.btnNO.UseVisualStyleBackColor = true;
            this.btnNO.Click += new System.EventHandler(this.btnNO_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(211, 383);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "¿Continuar validación?";
            // 
            // FormValidadorObjetoFaltante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 453);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnNO);
            this.Controls.Add(this.btnSI);
            this.Controls.Add(this.txtListaRoutine);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtListaJob);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtListaVariableEntorno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormValidadorObjetoFaltante";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Objetos DataStage necesarios para validación- Validador SES 2.0";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtListaVariableEntorno;
        private System.Windows.Forms.TextBox txtListaJob;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtListaRoutine;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSI;
        private System.Windows.Forms.Button btnNO;
        private System.Windows.Forms.Label label5;
    }
}