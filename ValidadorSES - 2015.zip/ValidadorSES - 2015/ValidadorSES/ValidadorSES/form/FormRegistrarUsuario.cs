﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormRegistrarUsuario : Form
    {
        UsuarioDAO daoUser = new UsuarioDAO();
        public FormRegistrarUsuario()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_REGISTRO_USUARIO;

            MaestroDAO daoMaestro = new MaestroDAO();

            cboCrearCargo.DataSource = daoMaestro.getListaCargoAnonimo();
            cboCrearCargo.DisplayMember = "nombre";
            cboCrearCargo.ValueMember = "valor_key";
            cboCrearCargo.SelectedIndex = 1;

            /*CARGAR LISTADO DE PREGUNTAS SECRETAS*/
            cboPregunta.DataSource = daoMaestro.getListaPreguntaSecreta();
            cboPregunta.DisplayMember = "nombre";
            cboPregunta.ValueMember = "valor_key";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Usuario obj = getAnonimoValidado();
            
            if (obj != null)
            {
                if (obj.apellidos == null || obj.apellidos.Trim() == "" ||
                    obj.nombres == null || obj.nombres.Trim()=="" ||
                    obj.contraseña == null || obj.contraseña.Trim()== ""||
                    obj.pregunta == null || obj.pregunta.Trim() == ""||
                    obj.respuesta == null || obj.pregunta.Trim() == "" ||
                    obj.usuario == null || obj.usuario.Trim()== "")
                {
                    MessageBox.Show("LLenar todos los campos", "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    bool existeUser = daoUser.getExisteUsuario(obj.usuario);
                    if (existeUser)
                    {
                        MessageBox.Show("Usuario ya existe, escoga otro!", "ERROR!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    }
                    else
                    {
                        try
                        {
                            UsuarioDAO odao = new UsuarioDAO();

                            odao.grabarUsuarioAnonimo(obj);
                            MessageBox.Show("Usuario Registrado correctamente", "AVISO");

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ocurrió un error al registrar el objeto a la BD." + ex);
                        }
                        limpiarInterfaz();
                    }
                }
            }

            
        }

        public void limpiarInterfaz()
        {
            txtCrearNombres.Text = "";
            txtCrearApellidos.Text = "";
            txtCrearUsuario.Text = "";
            txtCrearContraseña.Text = "";
            cboCrearCargo.SelectedIndex = 1;
            txtRespuesta.Clear();
            cboPregunta.SelectedIndex = 1;
        }

        private Usuario getAnonimoValidado()
        {
            string mensaje = "";
            Usuario obj = null;
            string nombres = txtCrearNombres.Text;
            string apellidos = txtCrearApellidos.Text;
            int cargo = UtilUsuario.getCodigoCargoUsuario(cboCrearCargo.Text);
            string usuario = txtCrearUsuario.Text;
            string contraseña = txtCrearContraseña.Text;
            string Pregunta = UtilUsuario.getCodigoPreguntaSecreta(cboPregunta.Text);
            string Respuesta = txtRespuesta.Text;

            if (mensaje == "")
            {
                obj = new Usuario();
                obj.nombres = nombres;
                obj.apellidos = apellidos;
                obj.cargo_usuario = cargo;
                obj.usuario = usuario;
                obj.contraseña = contraseña;
                obj.respuesta = Respuesta;
                obj.pregunta = Pregunta;
                obj.fecha_creacion = DateTime.Now;
                obj.fecha_modificacion = DateTime.Now;
                
                
            }

            return obj;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            limpiarInterfaz();
        }

       
    }
}
