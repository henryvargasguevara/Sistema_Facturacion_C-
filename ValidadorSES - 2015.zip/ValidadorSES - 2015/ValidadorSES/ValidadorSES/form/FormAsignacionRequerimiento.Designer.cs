﻿namespace ValidadorSES.form
{
    partial class FormAsignacionRequerimiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAsignacionRequerimiento));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboColaboradores = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCodigoAsiganción = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpFechaAsignacion = new System.Windows.Forms.DateTimePicker();
            this.btnGrabar = new System.Windows.Forms.Button();
            this.txtFiltrar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkHabilitar = new System.Windows.Forms.CheckBox();
            this.lblOtrosColaboradores = new System.Windows.Forms.Label();
            this.cboOtroLider = new System.Windows.Forms.ComboBox();
            this.lblEstadoReq = new System.Windows.Forms.Label();
            this.lblPrioridad = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTipoValidación = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.txtCodigoReq = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dgRequerimiento = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgAsignacionRequerimiento = new System.Windows.Forms.DataGridView();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRequerimiento)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgAsignacionRequerimiento)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codigo de requerimiento";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Colaborades BI";
            // 
            // cboColaboradores
            // 
            this.cboColaboradores.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboColaboradores.FormattingEnabled = true;
            this.cboColaboradores.Location = new System.Drawing.Point(174, 72);
            this.cboColaboradores.Name = "cboColaboradores";
            this.cboColaboradores.Size = new System.Drawing.Size(119, 21);
            this.cboColaboradores.TabIndex = 4;
            this.cboColaboradores.SelectedIndexChanged += new System.EventHandler(this.cboColaboradores_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(68, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Código Asignación";
            // 
            // lblCodigoAsiganción
            // 
            this.lblCodigoAsiganción.AutoSize = true;
            this.lblCodigoAsiganción.Location = new System.Drawing.Point(171, 24);
            this.lblCodigoAsiganción.Name = "lblCodigoAsiganción";
            this.lblCodigoAsiganción.Size = new System.Drawing.Size(35, 13);
            this.lblCodigoAsiganción.TabIndex = 6;
            this.lblCodigoAsiganción.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(38, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Plazo máximo de entrega";
            // 
            // dtpFechaAsignacion
            // 
            this.dtpFechaAsignacion.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFechaAsignacion.Location = new System.Drawing.Point(174, 100);
            this.dtpFechaAsignacion.Name = "dtpFechaAsignacion";
            this.dtpFechaAsignacion.Size = new System.Drawing.Size(118, 20);
            this.dtpFechaAsignacion.TabIndex = 8;
            this.dtpFechaAsignacion.Validating += new System.ComponentModel.CancelEventHandler(this.dtpFechaAsignacion_Validating);
            // 
            // btnGrabar
            // 
            this.btnGrabar.Location = new System.Drawing.Point(612, 67);
            this.btnGrabar.Name = "btnGrabar";
            this.btnGrabar.Size = new System.Drawing.Size(85, 23);
            this.btnGrabar.TabIndex = 11;
            this.btnGrabar.Text = "Grabar";
            this.btnGrabar.UseVisualStyleBackColor = true;
            this.btnGrabar.Click += new System.EventHandler(this.btnGrabar_Click);
            // 
            // txtFiltrar
            // 
            this.txtFiltrar.Location = new System.Drawing.Point(198, 396);
            this.txtFiltrar.Name = "txtFiltrar";
            this.txtFiltrar.Size = new System.Drawing.Size(269, 20);
            this.txtFiltrar.TabIndex = 15;
            this.txtFiltrar.TextChanged += new System.EventHandler(this.txtFiltrar_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 399);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Ingrese criterio de búsqueda";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(231, 47);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(61, 13);
            this.lblDescripcion.TabIndex = 2;
            this.lblDescripcion.Text = "descripción";
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Location = new System.Drawing.Point(299, 75);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(39, 13);
            this.lblCodigo.TabIndex = 14;
            this.lblCodigo.Text = "codigo";
            this.lblCodigo.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkHabilitar);
            this.groupBox2.Controls.Add(this.lblOtrosColaboradores);
            this.groupBox2.Controls.Add(this.cboOtroLider);
            this.groupBox2.Controls.Add(this.lblEstadoReq);
            this.groupBox2.Controls.Add(this.lblPrioridad);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.lblTipoValidación);
            this.groupBox2.Controls.Add(this.lblEstado);
            this.groupBox2.Controls.Add(this.txtCodigoReq);
            this.groupBox2.Controls.Add(this.lblCodigo);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblDescripcion);
            this.groupBox2.Controls.Add(this.btnGrabar);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.cboColaboradores);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.dtpFechaAsignacion);
            this.groupBox2.Controls.Add(this.lblCodigoAsiganción);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(12, 254);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(708, 132);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Asignación";
            // 
            // chkHabilitar
            // 
            this.chkHabilitar.AutoSize = true;
            this.chkHabilitar.Location = new System.Drawing.Point(302, 103);
            this.chkHabilitar.Name = "chkHabilitar";
            this.chkHabilitar.Size = new System.Drawing.Size(182, 17);
            this.chkHabilitar.TabIndex = 24;
            this.chkHabilitar.Text = "Escoger colaborador de otro lider";
            this.chkHabilitar.UseVisualStyleBackColor = true;
            this.chkHabilitar.CheckedChanged += new System.EventHandler(this.chkHabilitar_CheckedChanged);
            // 
            // lblOtrosColaboradores
            // 
            this.lblOtrosColaboradores.AutoSize = true;
            this.lblOtrosColaboradores.Location = new System.Drawing.Point(507, 101);
            this.lblOtrosColaboradores.Name = "lblOtrosColaboradores";
            this.lblOtrosColaboradores.Size = new System.Drawing.Size(30, 13);
            this.lblOtrosColaboradores.TabIndex = 23;
            this.lblOtrosColaboradores.Text = "Lider";
            // 
            // cboOtroLider
            // 
            this.cboOtroLider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOtroLider.FormattingEnabled = true;
            this.cboOtroLider.Location = new System.Drawing.Point(548, 98);
            this.cboOtroLider.Name = "cboOtroLider";
            this.cboOtroLider.Size = new System.Drawing.Size(149, 21);
            this.cboOtroLider.TabIndex = 22;
            this.cboOtroLider.SelectedIndexChanged += new System.EventHandler(this.cboOtroLider_SelectedIndexChanged);
            // 
            // lblEstadoReq
            // 
            this.lblEstadoReq.AutoSize = true;
            this.lblEstadoReq.Location = new System.Drawing.Point(558, 24);
            this.lblEstadoReq.Name = "lblEstadoReq";
            this.lblEstadoReq.Size = new System.Drawing.Size(40, 13);
            this.lblEstadoReq.TabIndex = 21;
            this.lblEstadoReq.Text = "Estado";
            // 
            // lblPrioridad
            // 
            this.lblPrioridad.AutoSize = true;
            this.lblPrioridad.Location = new System.Drawing.Point(558, 47);
            this.lblPrioridad.Name = "lblPrioridad";
            this.lblPrioridad.Size = new System.Drawing.Size(47, 13);
            this.lblPrioridad.TabIndex = 20;
            this.lblPrioridad.Text = "prioridad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(472, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Tipo Validación";
            // 
            // lblTipoValidación
            // 
            this.lblTipoValidación.AutoSize = true;
            this.lblTipoValidación.Location = new System.Drawing.Point(558, 72);
            this.lblTipoValidación.Name = "lblTipoValidación";
            this.lblTipoValidación.Size = new System.Drawing.Size(43, 13);
            this.lblTipoValidación.TabIndex = 19;
            this.lblTipoValidación.Text = "TipoVal";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(512, 24);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(40, 13);
            this.lblEstado.TabIndex = 16;
            this.lblEstado.Text = "Estado";
            // 
            // txtCodigoReq
            // 
            this.txtCodigoReq.Location = new System.Drawing.Point(174, 44);
            this.txtCodigoReq.Name = "txtCodigoReq";
            this.txtCodigoReq.ReadOnly = true;
            this.txtCodigoReq.Size = new System.Drawing.Size(51, 20);
            this.txtCodigoReq.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(505, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "prioridad";
            // 
            // dgRequerimiento
            // 
            this.dgRequerimiento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRequerimiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRequerimiento.Location = new System.Drawing.Point(17, 19);
            this.dgRequerimiento.Name = "dgRequerimiento";
            this.dgRequerimiento.Size = new System.Drawing.Size(868, 211);
            this.dgRequerimiento.TabIndex = 16;
            this.dgRequerimiento.SelectionChanged += new System.EventHandler(this.dgRequerimiento_SelectionChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.dgRequerimiento);
            this.groupBox3.Location = new System.Drawing.Point(12, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(896, 236);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Requerimientos pendientes";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.dgAsignacionRequerimiento);
            this.groupBox4.Location = new System.Drawing.Point(12, 422);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(885, 228);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Requerimientos asignados por lider";
            // 
            // dgAsignacionRequerimiento
            // 
            this.dgAsignacionRequerimiento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgAsignacionRequerimiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAsignacionRequerimiento.Location = new System.Drawing.Point(17, 19);
            this.dgAsignacionRequerimiento.Name = "dgAsignacionRequerimiento";
            this.dgAsignacionRequerimiento.Size = new System.Drawing.Size(857, 203);
            this.dgAsignacionRequerimiento.TabIndex = 0;
            // 
            // FormAsignacionRequerimiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 662);
            this.Controls.Add(this.txtFiltrar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAsignacionRequerimiento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asignacion de Requerimientos - Validador SES 2.0";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRequerimiento)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgAsignacionRequerimiento)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboColaboradores;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnGrabar;
        private System.Windows.Forms.TextBox txtFiltrar;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label lblCodigoAsiganción;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox txtCodigoReq;
        public System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblEstado;
        public System.Windows.Forms.DataGridView dgRequerimiento;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblPrioridad;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label lblTipoValidación;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblEstadoReq;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgAsignacionRequerimiento;
        public System.Windows.Forms.DateTimePicker dtpFechaAsignacion;
        private System.Windows.Forms.Label lblOtrosColaboradores;
        private System.Windows.Forms.ComboBox cboOtroLider;
        private System.Windows.Forms.CheckBox chkHabilitar;
    }
}