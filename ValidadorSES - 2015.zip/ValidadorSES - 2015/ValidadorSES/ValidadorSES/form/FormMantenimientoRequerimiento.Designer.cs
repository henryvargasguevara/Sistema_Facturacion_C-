﻿namespace ValidadorSES.form
{
    partial class FormMantenimientoRequerimiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMantenimientoRequerimiento));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboTipoCargaJob = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cboTipoValidacion = new System.Windows.Forms.ComboBox();
            this.cboPrioridadRequerimiento = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cboLiderResponsable = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnModificar = new System.Windows.Forms.Button();
            this.txtCodigoRequerimiento = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cboCliente = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.dtpFechaFin = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaIni = new System.Windows.Forms.DateTimePicker();
            this.cboEstadoReq = new System.Windows.Forms.ComboBox();
            this.txtDescripcionReq = new System.Windows.Forms.TextBox();
            this.txtNumPase = new System.Windows.Forms.TextBox();
            this.lblEstado = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtFiltro = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dgListadoRequerimiento = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgListadoRequerimiento)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox1.Controls.Add(this.cboTipoCargaJob);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cboTipoValidacion);
            this.groupBox1.Controls.Add(this.cboPrioridadRequerimiento);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cboLiderResponsable);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnModificar);
            this.groupBox1.Controls.Add(this.txtCodigoRequerimiento);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.cboCliente);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.btnRegistrar);
            this.groupBox1.Controls.Add(this.btnNuevo);
            this.groupBox1.Controls.Add(this.dtpFechaFin);
            this.groupBox1.Controls.Add(this.dtpFechaIni);
            this.groupBox1.Controls.Add(this.cboEstadoReq);
            this.groupBox1.Controls.Add(this.txtDescripcionReq);
            this.groupBox1.Controls.Add(this.txtNumPase);
            this.groupBox1.Controls.Add(this.lblEstado);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(14, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(751, 208);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos de Requerimiento";
            // 
            // cboTipoCargaJob
            // 
            this.cboTipoCargaJob.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipoCargaJob.Enabled = false;
            this.cboTipoCargaJob.FormattingEnabled = true;
            this.cboTipoCargaJob.Location = new System.Drawing.Point(177, 170);
            this.cboTipoCargaJob.Name = "cboTipoCargaJob";
            this.cboTipoCargaJob.Size = new System.Drawing.Size(197, 21);
            this.cboTipoCargaJob.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(94, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 13);
            this.label8.TabIndex = 32;
            this.label8.Text = "Tipo de Carga:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(441, 173);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "Tipo validación";
            // 
            // cboTipoValidacion
            // 
            this.cboTipoValidacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipoValidacion.Enabled = false;
            this.cboTipoValidacion.FormattingEnabled = true;
            this.cboTipoValidacion.Location = new System.Drawing.Point(526, 170);
            this.cboTipoValidacion.Name = "cboTipoValidacion";
            this.cboTipoValidacion.Size = new System.Drawing.Size(102, 21);
            this.cboTipoValidacion.TabIndex = 9;
            // 
            // cboPrioridadRequerimiento
            // 
            this.cboPrioridadRequerimiento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPrioridadRequerimiento.Enabled = false;
            this.cboPrioridadRequerimiento.FormattingEnabled = true;
            this.cboPrioridadRequerimiento.Location = new System.Drawing.Point(526, 90);
            this.cboPrioridadRequerimiento.Name = "cboPrioridadRequerimiento";
            this.cboPrioridadRequerimiento.Size = new System.Drawing.Size(102, 21);
            this.cboPrioridadRequerimiento.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(472, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "Prioridad";
            // 
            // cboLiderResponsable
            // 
            this.cboLiderResponsable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLiderResponsable.Enabled = false;
            this.cboLiderResponsable.FormattingEnabled = true;
            this.cboLiderResponsable.Location = new System.Drawing.Point(177, 143);
            this.cboLiderResponsable.Name = "cboLiderResponsable";
            this.cboLiderResponsable.Size = new System.Drawing.Size(197, 21);
            this.cboLiderResponsable.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Lider Responsable";
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(375, 66);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(75, 23);
            this.btnModificar.TabIndex = 25;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // txtCodigoRequerimiento
            // 
            this.txtCodigoRequerimiento.Location = new System.Drawing.Point(177, 19);
            this.txtCodigoRequerimiento.Name = "txtCodigoRequerimiento";
            this.txtCodigoRequerimiento.Size = new System.Drawing.Size(111, 20);
            this.txtCodigoRequerimiento.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(127, 72);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "N° SAR";
            // 
            // cboCliente
            // 
            this.cboCliente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCliente.Enabled = false;
            this.cboCliente.FormattingEnabled = true;
            this.cboCliente.Location = new System.Drawing.Point(177, 43);
            this.cboCliente.Name = "cboCliente";
            this.cboCliente.Size = new System.Drawing.Size(111, 21);
            this.cboCliente.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(132, 46);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 13);
            this.label16.TabIndex = 20;
            this.label16.Text = "Cliente";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Location = new System.Drawing.Point(375, 41);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(75, 23);
            this.btnRegistrar.TabIndex = 19;
            this.btnRegistrar.Text = "Grabar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(375, 16);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(75, 23);
            this.btnNuevo.TabIndex = 18;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // dtpFechaFin
            // 
            this.dtpFechaFin.Location = new System.Drawing.Point(495, 117);
            this.dtpFechaFin.Name = "dtpFechaFin";
            this.dtpFechaFin.Size = new System.Drawing.Size(224, 20);
            this.dtpFechaFin.TabIndex = 6;
            // 
            // dtpFechaIni
            // 
            this.dtpFechaIni.Location = new System.Drawing.Point(177, 117);
            this.dtpFechaIni.Name = "dtpFechaIni";
            this.dtpFechaIni.Size = new System.Drawing.Size(224, 20);
            this.dtpFechaIni.TabIndex = 5;
            // 
            // cboEstadoReq
            // 
            this.cboEstadoReq.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstadoReq.Enabled = false;
            this.cboEstadoReq.FormattingEnabled = true;
            this.cboEstadoReq.Location = new System.Drawing.Point(526, 143);
            this.cboEstadoReq.Name = "cboEstadoReq";
            this.cboEstadoReq.Size = new System.Drawing.Size(102, 21);
            this.cboEstadoReq.TabIndex = 15;
            this.cboEstadoReq.Visible = false;
            // 
            // txtDescripcionReq
            // 
            this.txtDescripcionReq.Location = new System.Drawing.Point(177, 94);
            this.txtDescripcionReq.Name = "txtDescripcionReq";
            this.txtDescripcionReq.Size = new System.Drawing.Size(273, 20);
            this.txtDescripcionReq.TabIndex = 4;
            // 
            // txtNumPase
            // 
            this.txtNumPase.Location = new System.Drawing.Point(177, 69);
            this.txtNumPase.Name = "txtNumPase";
            this.txtNumPase.Size = new System.Drawing.Size(111, 20);
            this.txtNumPase.TabIndex = 3;
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(480, 146);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(40, 13);
            this.lblEstado.TabIndex = 5;
            this.lblEstado.Text = "Estado";
            this.lblEstado.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(423, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Fecha de fin";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(92, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Fecha de inicio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nombre de requerimiento";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "N° de Requerimiento";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox2.Controls.Add(this.txtFiltro);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Location = new System.Drawing.Point(14, 226);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(751, 44);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Búsqueda";
            // 
            // txtFiltro
            // 
            this.txtFiltro.Location = new System.Drawing.Point(175, 15);
            this.txtFiltro.Name = "txtFiltro";
            this.txtFiltro.Size = new System.Drawing.Size(273, 20);
            this.txtFiltro.TabIndex = 15;
            this.txtFiltro.TextChanged += new System.EventHandler(this.txtFiltro_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(140, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Filtro";
            // 
            // dgListadoRequerimiento
            // 
            this.dgListadoRequerimiento.AllowUserToAddRows = false;
            this.dgListadoRequerimiento.AllowUserToDeleteRows = false;
            this.dgListadoRequerimiento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgListadoRequerimiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgListadoRequerimiento.Location = new System.Drawing.Point(14, 276);
            this.dgListadoRequerimiento.Name = "dgListadoRequerimiento";
            this.dgListadoRequerimiento.Size = new System.Drawing.Size(751, 201);
            this.dgListadoRequerimiento.TabIndex = 3;
            this.dgListadoRequerimiento.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgListadoRequerimiento_CellFormatting);
            this.dgListadoRequerimiento.SelectionChanged += new System.EventHandler(this.dgListadoRequerimiento_SelectionChanged);
            this.dgListadoRequerimiento.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgListadoRequerimiento_CellContentClick);
            // 
            // FormMantenimientoRequerimiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 489);
            this.Controls.Add(this.dgListadoRequerimiento);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMantenimientoRequerimiento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mantenimiento de Requerimiento - Validador SES 2.0";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgListadoRequerimiento)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtpFechaFin;
        private System.Windows.Forms.DateTimePicker dtpFechaIni;
        private System.Windows.Forms.ComboBox cboEstadoReq;
        private System.Windows.Forms.TextBox txtDescripcionReq;
        private System.Windows.Forms.TextBox txtNumPase;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtFiltro;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dgListadoRequerimiento;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.ComboBox cboCliente;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCodigoRequerimiento;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.ComboBox cboLiderResponsable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboPrioridadRequerimiento;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboTipoValidacion;
        private System.Windows.Forms.ComboBox cboTipoCargaJob;
        private System.Windows.Forms.Label label8;
    }
}