﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo;
using ValidadorSES.dao;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormRecuperarContraseña : Form
    {
        //public Usuario usuarioOlvidado { get; set; }
        //public Singleton sesion { get; set; }
        public FormRecuperarContraseña()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_CAMBIAR_CONTRASENIA;
        }
        private void btnValidarRespuesta_Click(object sender, EventArgs e)
        {
            UsuarioDAO dao = new UsuarioDAO();
            Usuario obj = new Usuario();
            obj.respuesta = txtRespuesta.Text;

            if (string.IsNullOrEmpty(txtRespuesta.Text))
            {
                MessageBox.Show("Ingrese respuesta secreta", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                Usuario usu = dao.ValidarPreguntaSecreta(obj);

                if (usu != null)
                {
                    txtUsuarioOlvidado.ReadOnly = true;
                    gbActualizarClave.Visible = true;
                    //txtNuevaContraseña.Text = usu.contraseña;
                    //txtConfirmarContraseña.Text = usu.contraseña;
                    txtcodigo.Text = usu.codigo_Usuario.ToString();
                }
                else
                {
                    MessageBox.Show("Respuesta incorrecta ", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtRespuesta.Text = string.Empty;
                }
            }
        }

        private void btnGrabarContraseña_Click(object sender, EventArgs e)
        {
            UsuarioDAO dao = new UsuarioDAO();
            Usuario obj = new Usuario();
           
            string pass1 = txtNuevaContraseña.Text;
            string pass2 = txtConfirmarContraseña.Text;
            obj.contraseña = pass1;
            obj.codigo_Usuario = int.Parse(txtcodigo.Text);
            if (string.IsNullOrEmpty(pass1))
            {
                MessageBox.Show("Ingresa contraseña Nueva", "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (pass1 != pass2)
                {
                    MessageBox.Show("Contraseña no coinciden ", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    dao.actualizarContraseña(obj);
                    MessageBox.Show("Contraseña actualizado correctamente", "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Hide();
                }
            }
        }

        private void btnObtenerPregunta_Click(object sender, EventArgs e)
        {
            UsuarioDAO dao = new UsuarioDAO();
            Usuario obj = new Usuario();
            obj.usuario = txtUsuarioOlvidado.Text;

            if (string.IsNullOrEmpty(txtUsuarioOlvidado.Text))
            {
                MessageBox.Show("Ingrese Usuario", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                Usuario usu = dao.ObtenerPreguntaSecreta(obj);

                if (usu != null)
                {
                    txtUsuarioOlvidado.ReadOnly = true;
                    gbValidarRespuesta.Visible = true;
                    txtPregunta.Text = dao.descripcionDpregunta(usu.pregunta);
                }
                else
                {
                    MessageBox.Show("No existe Usuario Ingresado ", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsuarioOlvidado.Text = string.Empty;
                }
            }
        }
    }
}
