﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.dao;
using ValidadorSES.service;

namespace ValidadorSES.form
{
    public partial class FormValidadorCerrarValidacion : Form
    {
        public const string TBL_TIPO_OBJETO = "Tipo de objeto";
        public const string TBL_NOMBRE_OBJETO = "Nombre objeto";
        public const string TBL_TIPO_DETALLE_OBJETO = "Subtipo de objeto";
        public const string TBL_DETALLE_OBJETO = "Detalle de subtipo";
        public const string TBL_ESTADO = "Estado";
        public const string TBL_MENSAJE = "Descripción";
        public const string TBL_DET_JOB_AMPLIAR_DESCRIPCION = "ver más";
        public const int TBL_DET_JOB_POS_ABRIR = 0;
        public const int TBL_DET_JOB_POS_DISPLAY_ABRIR = 5;

        public LogDSX dsx;
        public bool cerrarFormValidador;

        public FormValidadorCerrarValidacion()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_VALIDADOR_CERRAR_VALIDACION;
        }

        public void cargarPantalla() 
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_TIPO_OBJETO));
            table.Columns.Add(UtilForm.getColumnString(TBL_NOMBRE_OBJETO));
            table.Columns.Add(UtilForm.getColumnString(TBL_TIPO_DETALLE_OBJETO));
            table.Columns.Add(UtilForm.getColumnString(TBL_DETALLE_OBJETO));
            table.Columns.Add(UtilForm.getColumnString(TBL_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_MENSAJE));

            //creacion de la tabla
            //** jobs
            for (int j = 0; j < dsx.listaJob.Count; j++)
            {
                LogJob job = dsx.listaJob[j];

                //validación de documentación interna
                for (int d = 0; d<job.listaValidacion.Count; d++) 
                {
                    LogObjetoValidacion val = job.listaValidacion[d];

                    if (val.mensaje != "")
                    {
                        DataRow row = table.NewRow();

                        row[TBL_NOMBRE_OBJETO] = job.identifierJob;
                        row[TBL_TIPO_OBJETO] = job.objeto.nombre;
                        row[TBL_TIPO_DETALLE_OBJETO] = "Doc. Interna y otros";
                        row[TBL_DETALLE_OBJETO] = val.regla.nombreRegla;
                        row[TBL_ESTADO] = val.estado;
                        row[TBL_MENSAJE] = val.mensaje;

                        table.Rows.Add(row);
                    }
                }
                
                //validación de stages
                for (int s = 0; s< job.listaStage.Count; s++)
                {
                    LogStage stage = job.listaStage[s];

                    if (stage.mensaje != "")
                    {
                        DataRow row = table.NewRow();

                        row[TBL_NOMBRE_OBJETO] = job.identifierJob;
                        row[TBL_TIPO_OBJETO] = job.objeto.nombre;
                        row[TBL_TIPO_DETALLE_OBJETO] = stage.objeto.nombre;
                        row[TBL_DETALLE_OBJETO] = stage.nameStage;
                        row[TBL_ESTADO] = stage.estadoStageDescripcion;
                        row[TBL_MENSAJE] = stage.mensaje;

                        table.Rows.Add(row);
                    }                    
                }
            }

            //**routines
            for (int r = 0; r<dsx.listaRoutine.Count; r++) 
            {
                LogRoutine routine = dsx.listaRoutine[r];
                if(routine.mensaje != "")
                {
                    DataRow row = table.NewRow();

                    row[TBL_NOMBRE_OBJETO] = routine.identifier;
                    row[TBL_TIPO_OBJETO] = routine.objeto.nombre;
                    row[TBL_TIPO_DETALLE_OBJETO] = "Nomenclatura";
                    row[TBL_DETALLE_OBJETO] = "";
                    row[TBL_ESTADO] = routine.estadoRutinaDescripcion;
                    row[TBL_MENSAJE] = routine.mensaje;

                    table.Rows.Add(row);
                }

                //**argumentos
                for (int a = 0; a<routine.listaArgumentoRoutine.Count; a++) 
                {
                    LogArgument arg = routine.listaArgumentoRoutine[a];
                    if(arg.mensaje!="")
                    {
                        DataRow row = table.NewRow();

                        row[TBL_NOMBRE_OBJETO] = routine.identifier;
                        row[TBL_TIPO_OBJETO] = routine.objeto.nombre;
                        row[TBL_TIPO_DETALLE_OBJETO] = arg.objeto.nombre;
                        row[TBL_DETALLE_OBJETO] = arg.nameArgRoutine;
                        row[TBL_ESTADO] = arg.estadoArgumentDescripcion;
                        row[TBL_MENSAJE] = arg.mensaje;

                        table.Rows.Add(row);
                    }
                }
            }

            //**parameterSet
            for (int p = 0; p<dsx.listaParameterSet.Count; p++)
            {
                LogParameterSet ps = dsx.listaParameterSet[p];
                if (ps.mensaje != "")
                {
                    DataRow row = table.NewRow();

                    row[TBL_NOMBRE_OBJETO] = ps.identifierParameterSet;
                    row[TBL_TIPO_OBJETO] = ps.objeto.nombre;
                    row[TBL_TIPO_DETALLE_OBJETO] = "Nomenclatura";
                    row[TBL_DETALLE_OBJETO] = "";
                    row[TBL_ESTADO] = ps.estadoParameterDescripcion;
                    row[TBL_MENSAJE] = ps.mensaje;

                    table.Rows.Add(row);
                }

                //**param
                for (int a = 0; a < ps.listaParam.Count; a++)
                {
                    LogParam param = ps.listaParam[a];
                    if (param.mensaje != "")
                    {
                        DataRow row = table.NewRow();

                        row[TBL_NOMBRE_OBJETO] = ps.identifierParameterSet;
                        row[TBL_TIPO_OBJETO] = ps.objeto.nombre;
                        row[TBL_TIPO_DETALLE_OBJETO] = param.objeto.nombre;
                        row[TBL_DETALLE_OBJETO] = param.name;
                        row[TBL_ESTADO] = param.estadoParamDescripcion;
                        row[TBL_MENSAJE] = param.mensaje;

                        table.Rows.Add(row);
                    }
                }
            }

            dataGridViewNotok.Columns.Clear();
            view = new DataView(table);

            dataGridViewNotok.Visible = true;
            dataGridViewNotok.RowHeadersVisible = false;
            dataGridViewNotok.DataSource = view;

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewNotok.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "";
            buttonColumn.Text = "...";
            buttonColumn.Name = TBL_DET_JOB_AMPLIAR_DESCRIPCION;
            buttonColumn.DisplayIndex = TBL_DET_JOB_POS_DISPLAY_ABRIR;
            buttonColumn.UseColumnTextForButtonValue = true;
            buttonColumn.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);

            dataGridViewNotok.Columns[TBL_TIPO_OBJETO].Width = 110;
            dataGridViewNotok.Columns[TBL_NOMBRE_OBJETO].Width = 300;
            dataGridViewNotok.Columns[TBL_TIPO_DETALLE_OBJETO].Width = 120;
            dataGridViewNotok.Columns[TBL_ESTADO].Width = 74;
            dataGridViewNotok.Columns[TBL_DETALLE_OBJETO].Width = 300;
            dataGridViewNotok.Columns[TBL_DET_JOB_AMPLIAR_DESCRIPCION].Width = 40;
            dataGridViewNotok.Columns[TBL_MENSAJE].Width = 650;

            dataGridViewNotok.Columns[TBL_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void btnCerrarValidacion_Click(object sender, EventArgs e)
        {
            txtNota.Text = txtNota.Text.Trim();

            string nota = txtNota.Text;
            cerrarFormValidador = false;

            if (nota != "")
            {
                try
                {
                    dsx.nota = nota;
                    ValidadorService.aniadirNotaToDSX(dsx);
                    MessageBox.Show("Se añadio la nota correctamente", "¡Éxito!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cerrarFormValidador = true;
                    this.Hide();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se pudo añadir la nota", "¡Érror!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("No se ha escrito la nota correspondiente a la validación", "¡Érror!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridViewNotok_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewNotok.Columns[e.ColumnIndex].Name.Equals(TBL_ESTADO))
            {
                string estado = dataGridViewNotok.Rows[e.RowIndex].Cells[TBL_ESTADO].Value.ToString();
                if (estado == ConstanteMaestro.DES_EST_VALIDACION_OK)
                {
                    dataGridViewNotok.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado == ConstanteMaestro.DES_EST_VALIDACION_ERROR)
                    {
                        dataGridViewNotok.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

        private void dataGridViewNotok_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewNotok.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 0) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewNotok.CurrentCell.RowIndex;

                string mensaje = dataGridViewNotok.Rows[filaSeleccionada].Cells[TBL_MENSAJE].Value.ToString();
                if (mensaje != null && mensaje != "")
                {
                    string desConSalto = mensaje;
                    desConSalto = desConSalto.Replace(": ", ": \n");
                    desConSalto = desConSalto.Replace(". ", ". \n\n");
                    MessageBox.Show(desConSalto, "Mensaje de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                dataGridViewNotok.Rows[filaSeleccionada].Cells[columnaSeleccionada].Selected = false;
                dataGridViewNotok.Rows[filaSeleccionada].Cells[TBL_TIPO_OBJETO].Selected = true;
            }
        }
    }
}
