﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo.view;
using ValidadorSES.util;
using ValidadorSES.dao;

namespace ValidadorSES.form
{
    public partial class FormTasaEfectividad : Form
    {
        ReportesDAO dao = new ReportesDAO();
        public FormTasaEfectividad()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_REPORTE_TASA_EFECTIVIDAD;

            mostrarTablaReporteEfectividad();
            gbEstadistica.Visible = false;

            dgReporteEfectividad.Location = new Point(dgReporteEfectividad.Location.X, 149);
            dgReporteEfectividad.Height = 474;
        }

        private void llenarTablaReporteEfectividad(List<ReporteEfectividadView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString("ID REQUERIMIENTO ASIGNADO"));
            table.Columns.Add(UtilForm.getColumnString("DESCRIPCIÓN DE REQUERIMIENTO"));
            table.Columns.Add(UtilForm.getColumnString("NOMBRE COLABORADOR"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO DE VALIDACIÓN"));
            table.Columns.Add(UtilForm.getColumnString("FECHA CREACIÓN"));
            table.Columns.Add(UtilForm.getColumnString("N° DE OBJETOS VALIDADOS"));
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                //RequerimientoDAO dao = new RequerimientoDAO();
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    ReporteEfectividadView ov = lista[j];
                    DataRow row = table.NewRow();
                    row["ID REQUERIMIENTO ASIGNADO"] = ov.codigoAsignacion;
                    row["DESCRIPCIÓN DE REQUERIMIENTO"] = ov.descripcion;
                    row["NOMBRE COLABORADOR"] = ov.colaborador;
                    row["ESTADO DE VALIDACIÓN"] = ov.estadoDsx;
                    row["FECHA CREACIÓN"] = ov.fechaCreacion;
                    row["N° DE OBJETOS VALIDADOS"] = ov.numJobValidado;
                    table.Rows.Add(row);
                }
            }

            dgReporteEfectividad.Columns.Clear();
            DataView view = new DataView(table);

            dgReporteEfectividad.Visible = true;
            dgReporteEfectividad.RowHeadersVisible = false;
            dgReporteEfectividad.DataSource = view;

            dgReporteEfectividad.Columns["ID REQUERIMIENTO ASIGNADO"].Width = 120;
            dgReporteEfectividad.Columns["DESCRIPCIÓN DE REQUERIMIENTO"].Width = 150;
            dgReporteEfectividad.Columns["NOMBRE COLABORADOR"].Width = 100;
            dgReporteEfectividad.Columns["ESTADO DE VALIDACIÓN"].Width = 80;
            dgReporteEfectividad.Columns["FECHA CREACIÓN"].Width = 140;
            dgReporteEfectividad.Columns["N° DE OBJETOS VALIDADOS"].Width = 123;

        }

        private void mostrarTablaReporteEfectividad()
        {
            List<ReporteEfectividadView> lista = new List<ReporteEfectividadView>();

            try
            {
                lista = dao.getListaReportesEfectividad();
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Reporte de efectividad");
            }

            llenarTablaReporteEfectividad(lista);
        }

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {
            List<ReporteEfectividadView> lista = new List<ReporteEfectividadView>();
            string filtro = txtFiltro.Text;

            try
            {
                lista = dao.getListaFiltroEfectividad(filtro);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaReporteEfectividad(lista);
            dgReporteEfectividad.Height = 474;
            dgReporteEfectividad.Location = new Point(dgReporteEfectividad.Location.X, 149);
            gbEstadistica.Visible = false;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            List<ReporteEfectividadView> lista = new List<ReporteEfectividadView>();

            DateTime f1 = dtp1.Value;
            DateTime f2 = dtp2.Value;

            f1 = new DateTime(f1.Year, f1.Month, f1.Day, 00, 00, 00, DateTime.Now.Kind);
            f2 = new DateTime(f2.Year, f2.Month, f2.Day, 23, 59, 59, DateTime.Now.Kind);

            try
            {
                lista = dao.getListaFiltrofechaEfectividad(f1, f2);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaReporteEfectividad(lista);
            dgReporteEfectividad.Height = 474;
            dgReporteEfectividad.Location = new Point(dgReporteEfectividad.Location.X, 149);
            gbEstadistica.Visible = false;
        }

        private void dgReporteEfectividad_SelectionChanged(object sender, EventArgs e)
        {
            string colaborador = (string)dgReporteEfectividad.CurrentRow.Cells["NOMBRE COLABORADOR"].Value;
            string idRequerimiento = (string)dgReporteEfectividad.CurrentRow.Cells["ID REQUERIMIENTO ASIGNADO"].Value;
            //int numValidaciones = dgReporteEfectividad.RowCount - 1;
            //string numObjetos = (string)dgReporteEfectividad.CurrentRow.Cells["N° DE OBJETOS VALIDADOS"].Value;

            lblUsuario.Text = colaborador;
            lblRequerimiento.Text = idRequerimiento;
            lblDescripcion.Text = dao.getDescripcionRequerimiento(idRequerimiento);
            lblFechaEntrega.Text = dao.getFechaEntrega(idRequerimiento).Substring(0, 10);
            
        }

        private string getUltimaValidacionOk()
        {
            string fecha = "";
            int numFilas = dgReporteEfectividad.RowCount;
            for (int i = 0; i < numFilas; i++)
            {
                string estado = (string)dgReporteEfectividad.Rows[i].Cells["ESTADO DE VALIDACIÓN"].Value;
                if (estado == "OK")
                {
                    fecha = (string)dgReporteEfectividad.CurrentRow.Cells["FECHA CREACIÓN"].Value;
                }
                else
                {
                    fecha = (string)dgReporteEfectividad.CurrentRow.Cells["FECHA CREACIÓN"].Value;
                }
            }
            return fecha;
        }

        private string getNivelColaborador()
        {
            int countFail = 0;
            int numFilas = dgReporteEfectividad.RowCount;
            string estado = "";
            for (int i = 0; i < numFilas; i++)
            {
                estado = (string)dgReporteEfectividad.Rows[i].Cells["ESTADO DE VALIDACIÓN"].Value;
                if (estado == "ERROR")
                {
                    //nivel = (string)dgReporteEfectividad.CurrentRow.Cells["FECHA CREACIÓN"].Value;
                    countFail++;
                }
            }
            if (countFail <= 2)
            {
                estado = "ALTO";
                btnBueno.BackColor = Color.Green;
                btnRegular.BackColor = Color.Green;
                btnMalo.BackColor = Color.Green;
                btnBueno.Visible = true;
                btnRegular.Visible = true;
                btnMalo.Visible = true;
            }
            else if (countFail <= 4)
            {
                estado = "REGULAR";
                btnRegular.BackColor = Color.Yellow;
                btnMalo.BackColor = Color.Yellow;
                btnBueno.Visible = false;
                btnRegular.Visible = true;
                btnMalo.Visible = true;
            }
            else
            {
                estado = "BAJO";
                btnMalo.BackColor = Color.Red;
                btnBueno.Visible = false;
                btnMalo.Visible = true;
                btnRegular.Visible = false;
            }
            return estado;
        }

        private void btnFiltroReq_Click(object sender, EventArgs e)
        {
            
            List<ReporteEfectividadView> lista = new List<ReporteEfectividadView>();
            string filtro = txtFiltro.Text;
            if (!dao.getExisteRequerimiento(filtro))
            {
                gbEstadistica.Visible = false;
                MessageBox.Show("No existe Asignación de Requerimiento ingresado", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                mostrarTablaReporteEfectividad();
            }
            else
            {
                gbEstadistica.Visible = true;
                try
                {
                    lista = dao.getListaFiltroEfectividad(filtro);
                }
                catch (Exception)
                {
                    MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
                }
                int tamañolista = lista.Count;
                int countError = 0;
                for(int j=0; j < tamañolista;j++)
                {
                    if (lista[j].estadoDsx == "OK")
                    {
                        countError++;
                    }
                }
                if (countError > 0)
                {
                    llenarTablaReporteEfectividad(lista);
                }
                else
                {
                    MessageBox.Show("No se ha completado los trabajos del requerimiento", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    gbEstadistica.Visible = false;
                    mostrarTablaReporteEfectividad();
                }
                int numValidaciones = dgReporteEfectividad.RowCount;
                lblNumeroVecesValidado.Text = "" + numValidaciones;

                lblFechaValidacionOK.Text = getUltimaValidacionOk().Substring(0, 10);
                lblNivel.Text = getNivelColaborador();

                dgReporteEfectividad.Height = 253;
                dgReporteEfectividad.Location = new Point(dgReporteEfectividad.Location.X, 325);

                gbEstadistica.Visible = true;
            }
        }
   
    
    }
}
