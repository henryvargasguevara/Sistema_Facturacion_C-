﻿namespace ValidadorSES.form
{
    partial class FormValidador
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormValidador));
            this.lblruta = new System.Windows.Forms.Label();
            this.txtRutaDSX = new System.Windows.Forms.TextBox();
            this.progressBar_Load = new System.Windows.Forms.ProgressBar();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.backgroundWorker_Carga = new System.ComponentModel.BackgroundWorker();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRutaENV = new System.Windows.Forms.TextBox();
            this.labelENV = new System.Windows.Forms.Label();
            this.btnSeleccionarENV = new System.Windows.Forms.Button();
            this.seleccionarDSX = new System.Windows.Forms.Button();
            this.checkBoxENV = new System.Windows.Forms.CheckBox();
            this.tabControlObjeto = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridViewJob = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridViewRoutine = new System.Windows.Forms.DataGridView();
            this.tabPageParameterSet = new System.Windows.Forms.TabPage();
            this.dataGridViewParameterSet = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNroParameterSet = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtNroRoutine = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNroServer = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNroParallel = new System.Windows.Forms.TextBox();
            this.txtNroSequence = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExportarResultadoValidacion = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCargarDSX = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.comboBoxTipoValidacion = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxRequerimiento = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lnkVerReglaValidacion = new System.Windows.Forms.LinkLabel();
            this.groupBoxArchivoAdicional = new System.Windows.Forms.GroupBox();
            this.txtRutaDSXAdicional = new System.Windows.Forms.TextBox();
            this.btnSeleccionarDSXAdicional = new System.Windows.Forms.Button();
            this.lblDSXAdicional = new System.Windows.Forms.Label();
            this.lnkVerTipoObjeto = new System.Windows.Forms.LinkLabel();
            this.comboBoxTipoCargaJob = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lnkCerrarValidacion = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.chkDesaNuevo = new System.Windows.Forms.CheckBox();
            this.lnk_cerrar_sesion = new System.Windows.Forms.LinkLabel();
            this.tabControlObjeto.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewJob)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRoutine)).BeginInit();
            this.tabPageParameterSet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParameterSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBoxArchivoAdicional.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblruta
            // 
            this.lblruta.AutoSize = true;
            this.lblruta.Location = new System.Drawing.Point(26, 121);
            this.lblruta.Name = "lblruta";
            this.lblruta.Size = new System.Drawing.Size(139, 13);
            this.lblruta.TabIndex = 2;
            this.lblruta.Text = "Ubicación de archivo DSX :";
            this.lblruta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtRutaDSX
            // 
            this.txtRutaDSX.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRutaDSX.Enabled = false;
            this.txtRutaDSX.Location = new System.Drawing.Point(171, 118);
            this.txtRutaDSX.Name = "txtRutaDSX";
            this.txtRutaDSX.ReadOnly = true;
            this.txtRutaDSX.Size = new System.Drawing.Size(591, 20);
            this.txtRutaDSX.TabIndex = 24;
            this.txtRutaDSX.TextChanged += new System.EventHandler(this.txtRutaDSX_TextChanged);
            // 
            // progressBar_Load
            // 
            this.progressBar_Load.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar_Load.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.progressBar_Load.Location = new System.Drawing.Point(171, 212);
            this.progressBar_Load.Name = "progressBar_Load";
            this.progressBar_Load.Size = new System.Drawing.Size(699, 23);
            this.progressBar_Load.TabIndex = 5;
            // 
            // backgroundWorker_Carga
            // 
            this.backgroundWorker_Carga.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_Carga_DoWork);
            this.backgroundWorker_Carga.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_Carga_RunWorkerCompleted);
            this.backgroundWorker_Carga.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_Carga_ProgressChanged);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(287, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(615, 39);
            this.label5.TabIndex = 19;
            this.label5.Text = "Validador de Objetos DataStage";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtRutaENV
            // 
            this.txtRutaENV.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRutaENV.Enabled = false;
            this.txtRutaENV.Location = new System.Drawing.Point(566, 18);
            this.txtRutaENV.Name = "txtRutaENV";
            this.txtRutaENV.ReadOnly = true;
            this.txtRutaENV.Size = new System.Drawing.Size(180, 20);
            this.txtRutaENV.TabIndex = 3;
            this.txtRutaENV.TextChanged += new System.EventHandler(this.txtRutaENV_TextChanged);
            // 
            // labelENV
            // 
            this.labelENV.AutoSize = true;
            this.labelENV.Location = new System.Drawing.Point(462, 20);
            this.labelENV.Name = "labelENV";
            this.labelENV.Size = new System.Drawing.Size(98, 13);
            this.labelENV.TabIndex = 24;
            this.labelENV.Text = "Ubicación de ENV:";
            // 
            // btnSeleccionarENV
            // 
            this.btnSeleccionarENV.Location = new System.Drawing.Point(752, 15);
            this.btnSeleccionarENV.Name = "btnSeleccionarENV";
            this.btnSeleccionarENV.Size = new System.Drawing.Size(102, 23);
            this.btnSeleccionarENV.TabIndex = 25;
            this.btnSeleccionarENV.Text = "Seleccionar ENV";
            this.btnSeleccionarENV.UseVisualStyleBackColor = true;
            this.btnSeleccionarENV.Click += new System.EventHandler(this.btnSeleccionarENV_Click);
            // 
            // seleccionarDSX
            // 
            this.seleccionarDSX.Location = new System.Drawing.Point(768, 116);
            this.seleccionarDSX.Name = "seleccionarDSX";
            this.seleccionarDSX.Size = new System.Drawing.Size(102, 23);
            this.seleccionarDSX.TabIndex = 26;
            this.seleccionarDSX.Text = "Seleccionar DSX";
            this.seleccionarDSX.UseVisualStyleBackColor = true;
            this.seleccionarDSX.Click += new System.EventHandler(this.seleccionarDSX_Click);
            // 
            // checkBoxENV
            // 
            this.checkBoxENV.AutoSize = true;
            this.checkBoxENV.Location = new System.Drawing.Point(906, 113);
            this.checkBoxENV.Name = "checkBoxENV";
            this.checkBoxENV.Size = new System.Drawing.Size(180, 17);
            this.checkBoxENV.TabIndex = 27;
            this.checkBoxENV.Text = "¿Requiere archivos adicionales?";
            this.checkBoxENV.UseVisualStyleBackColor = true;
            this.checkBoxENV.CheckedChanged += new System.EventHandler(this.checkBoxENV_CheckedChanged);
            // 
            // tabControlObjeto
            // 
            this.tabControlObjeto.Controls.Add(this.tabPage1);
            this.tabControlObjeto.Controls.Add(this.tabPage2);
            this.tabControlObjeto.Controls.Add(this.tabPageParameterSet);
            this.tabControlObjeto.Location = new System.Drawing.Point(12, 241);
            this.tabControlObjeto.Name = "tabControlObjeto";
            this.tabControlObjeto.SelectedIndex = 0;
            this.tabControlObjeto.Size = new System.Drawing.Size(890, 423);
            this.tabControlObjeto.TabIndex = 28;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridViewJob);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(882, 397);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "JOB";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridViewJob
            // 
            this.dataGridViewJob.AllowUserToAddRows = false;
            this.dataGridViewJob.AllowUserToDeleteRows = false;
            this.dataGridViewJob.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewJob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewJob.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewJob.Name = "dataGridViewJob";
            this.dataGridViewJob.ReadOnly = true;
            this.dataGridViewJob.Size = new System.Drawing.Size(850, 356);
            this.dataGridViewJob.TabIndex = 1;
            this.dataGridViewJob.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewJob_CellFormatting);
            this.dataGridViewJob.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewJob_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridViewRoutine);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(882, 397);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ROUTINE";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridViewRoutine
            // 
            this.dataGridViewRoutine.AllowUserToAddRows = false;
            this.dataGridViewRoutine.AllowUserToDeleteRows = false;
            this.dataGridViewRoutine.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewRoutine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRoutine.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewRoutine.Name = "dataGridViewRoutine";
            this.dataGridViewRoutine.ReadOnly = true;
            this.dataGridViewRoutine.Size = new System.Drawing.Size(850, 356);
            this.dataGridViewRoutine.TabIndex = 2;
            this.dataGridViewRoutine.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewRoutine_CellFormatting);
            this.dataGridViewRoutine.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRoutine_CellContentClick);
            // 
            // tabPageParameterSet
            // 
            this.tabPageParameterSet.Controls.Add(this.dataGridViewParameterSet);
            this.tabPageParameterSet.Location = new System.Drawing.Point(4, 22);
            this.tabPageParameterSet.Name = "tabPageParameterSet";
            this.tabPageParameterSet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageParameterSet.Size = new System.Drawing.Size(882, 397);
            this.tabPageParameterSet.TabIndex = 2;
            this.tabPageParameterSet.Text = "PARAMETER SET";
            this.tabPageParameterSet.UseVisualStyleBackColor = true;
            // 
            // dataGridViewParameterSet
            // 
            this.dataGridViewParameterSet.AllowUserToAddRows = false;
            this.dataGridViewParameterSet.AllowUserToDeleteRows = false;
            this.dataGridViewParameterSet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewParameterSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewParameterSet.Location = new System.Drawing.Point(16, 21);
            this.dataGridViewParameterSet.Name = "dataGridViewParameterSet";
            this.dataGridViewParameterSet.ReadOnly = true;
            this.dataGridViewParameterSet.Size = new System.Drawing.Size(850, 356);
            this.dataGridViewParameterSet.TabIndex = 2;
            this.dataGridViewParameterSet.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewParameterSet_CellFormatting);
            this.dataGridViewParameterSet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewParameterSet_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.txtNroParameterSet);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtNroRoutine);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtNroServer);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtNroParallel);
            this.groupBox1.Controls.Add(this.txtNroSequence);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(908, 263);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(174, 209);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Total Objetos";
            // 
            // txtNroParameterSet
            // 
            this.txtNroParameterSet.Enabled = false;
            this.txtNroParameterSet.Location = new System.Drawing.Point(96, 164);
            this.txtNroParameterSet.Name = "txtNroParameterSet";
            this.txtNroParameterSet.Size = new System.Drawing.Size(48, 20);
            this.txtNroParameterSet.TabIndex = 9;
            this.txtNroParameterSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 167);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "ParameterSet:";
            // 
            // txtNroRoutine
            // 
            this.txtNroRoutine.Enabled = false;
            this.txtNroRoutine.Location = new System.Drawing.Point(96, 122);
            this.txtNroRoutine.Name = "txtNroRoutine";
            this.txtNroRoutine.Size = new System.Drawing.Size(48, 20);
            this.txtNroRoutine.TabIndex = 7;
            this.txtNroRoutine.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Routine:";
            // 
            // txtNroServer
            // 
            this.txtNroServer.Enabled = false;
            this.txtNroServer.Location = new System.Drawing.Point(96, 82);
            this.txtNroServer.Name = "txtNroServer";
            this.txtNroServer.Size = new System.Drawing.Size(48, 20);
            this.txtNroServer.TabIndex = 5;
            this.txtNroServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Server:";
            // 
            // txtNroParallel
            // 
            this.txtNroParallel.Enabled = false;
            this.txtNroParallel.Location = new System.Drawing.Point(96, 56);
            this.txtNroParallel.Name = "txtNroParallel";
            this.txtNroParallel.Size = new System.Drawing.Size(48, 20);
            this.txtNroParallel.TabIndex = 3;
            this.txtNroParallel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNroSequence
            // 
            this.txtNroSequence.Enabled = false;
            this.txtNroSequence.Location = new System.Drawing.Point(96, 30);
            this.txtNroSequence.Name = "txtNroSequence";
            this.txtNroSequence.Size = new System.Drawing.Size(48, 20);
            this.txtNroSequence.TabIndex = 2;
            this.txtNroSequence.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Parallel:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sequence:";
            // 
            // btnExportarResultadoValidacion
            // 
            this.btnExportarResultadoValidacion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportarResultadoValidacion.Image = global::ValidadorSES.Properties.Resources.icono_Excel;
            this.btnExportarResultadoValidacion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportarResultadoValidacion.Location = new System.Drawing.Point(908, 492);
            this.btnExportarResultadoValidacion.Name = "btnExportarResultadoValidacion";
            this.btnExportarResultadoValidacion.Size = new System.Drawing.Size(174, 57);
            this.btnExportarResultadoValidacion.TabIndex = 23;
            this.btnExportarResultadoValidacion.Text = "     RESULTADOS DE        VALIDACIÓN";
            this.btnExportarResultadoValidacion.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExportarResultadoValidacion.UseVisualStyleBackColor = true;
            this.btnExportarResultadoValidacion.Click += new System.EventHandler(this.btnExportarResultadoValidacion_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ValidadorSES.Properties.Resources.logo_ses;
            this.pictureBox1.Location = new System.Drawing.Point(32, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 80);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // btnCargarDSX
            // 
            this.btnCargarDSX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCargarDSX.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCargarDSX.Font = new System.Drawing.Font("Vrinda", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCargarDSX.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCargarDSX.Image = global::ValidadorSES.Properties.Resources.Folder_Mac_Documents;
            this.btnCargarDSX.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCargarDSX.Location = new System.Drawing.Point(908, 156);
            this.btnCargarDSX.Name = "btnCargarDSX";
            this.btnCargarDSX.Size = new System.Drawing.Size(136, 46);
            this.btnCargarDSX.TabIndex = 4;
            this.btnCargarDSX.Text = "PROCESAR";
            this.btnCargarDSX.UseVisualStyleBackColor = true;
            this.btnCargarDSX.Click += new System.EventHandler(this.buttonCargar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.AllowDrop = true;
            this.btnLimpiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLimpiar.Font = new System.Drawing.Font("Vrinda", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLimpiar.Image = global::ValidadorSES.Properties.Resources.edit_clear;
            this.btnLimpiar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiar.Location = new System.Drawing.Point(1050, 156);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(32, 48);
            this.btnLimpiar.TabIndex = 1;
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // comboBoxTipoValidacion
            // 
            this.comboBoxTipoValidacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTipoValidacion.Enabled = false;
            this.comboBoxTipoValidacion.FormattingEnabled = true;
            this.comboBoxTipoValidacion.Location = new System.Drawing.Point(906, 85);
            this.comboBoxTipoValidacion.Name = "comboBoxTipoValidacion";
            this.comboBoxTipoValidacion.Size = new System.Drawing.Size(176, 21);
            this.comboBoxTipoValidacion.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(905, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "Tipo de Validación:";
            // 
            // comboBoxRequerimiento
            // 
            this.comboBoxRequerimiento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRequerimiento.FormattingEnabled = true;
            this.comboBoxRequerimiento.Location = new System.Drawing.Point(171, 84);
            this.comboBoxRequerimiento.Name = "comboBoxRequerimiento";
            this.comboBoxRequerimiento.Size = new System.Drawing.Size(499, 21);
            this.comboBoxRequerimiento.TabIndex = 31;
            this.comboBoxRequerimiento.SelectedValueChanged += new System.EventHandler(this.comboBoxRequerimiento_SelectedValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(87, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 32;
            this.label7.Text = "Requerimiento:";
            // 
            // lnkVerReglaValidacion
            // 
            this.lnkVerReglaValidacion.AutoSize = true;
            this.lnkVerReglaValidacion.Location = new System.Drawing.Point(1023, 67);
            this.lnkVerReglaValidacion.Name = "lnkVerReglaValidacion";
            this.lnkVerReglaValidacion.Size = new System.Drawing.Size(59, 13);
            this.lnkVerReglaValidacion.TabIndex = 33;
            this.lnkVerReglaValidacion.TabStop = true;
            this.lnkVerReglaValidacion.Text = "Ver Reglas";
            this.lnkVerReglaValidacion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkVerReglaValidacion_LinkClicked);
            // 
            // groupBoxArchivoAdicional
            // 
            this.groupBoxArchivoAdicional.Controls.Add(this.txtRutaDSXAdicional);
            this.groupBoxArchivoAdicional.Controls.Add(this.btnSeleccionarDSXAdicional);
            this.groupBoxArchivoAdicional.Controls.Add(this.lblDSXAdicional);
            this.groupBoxArchivoAdicional.Controls.Add(this.txtRutaENV);
            this.groupBoxArchivoAdicional.Controls.Add(this.btnSeleccionarENV);
            this.groupBoxArchivoAdicional.Controls.Add(this.labelENV);
            this.groupBoxArchivoAdicional.Location = new System.Drawing.Point(16, 154);
            this.groupBoxArchivoAdicional.Name = "groupBoxArchivoAdicional";
            this.groupBoxArchivoAdicional.Size = new System.Drawing.Size(882, 54);
            this.groupBoxArchivoAdicional.TabIndex = 34;
            this.groupBoxArchivoAdicional.TabStop = false;
            this.groupBoxArchivoAdicional.Text = "Archivos adicionales";
            // 
            // txtRutaDSXAdicional
            // 
            this.txtRutaDSXAdicional.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRutaDSXAdicional.Enabled = false;
            this.txtRutaDSXAdicional.Location = new System.Drawing.Point(155, 17);
            this.txtRutaDSXAdicional.Name = "txtRutaDSXAdicional";
            this.txtRutaDSXAdicional.ReadOnly = true;
            this.txtRutaDSXAdicional.Size = new System.Drawing.Size(180, 20);
            this.txtRutaDSXAdicional.TabIndex = 26;
            this.txtRutaDSXAdicional.TextChanged += new System.EventHandler(this.txtRutaDSXAdicional_TextChanged);
            // 
            // btnSeleccionarDSXAdicional
            // 
            this.btnSeleccionarDSXAdicional.Location = new System.Drawing.Point(344, 15);
            this.btnSeleccionarDSXAdicional.Name = "btnSeleccionarDSXAdicional";
            this.btnSeleccionarDSXAdicional.Size = new System.Drawing.Size(102, 23);
            this.btnSeleccionarDSXAdicional.TabIndex = 28;
            this.btnSeleccionarDSXAdicional.Text = "Seleccionar DSX";
            this.btnSeleccionarDSXAdicional.UseVisualStyleBackColor = true;
            this.btnSeleccionarDSXAdicional.Click += new System.EventHandler(this.btnSeleccionarDSXAdicional_Click);
            // 
            // lblDSXAdicional
            // 
            this.lblDSXAdicional.AutoSize = true;
            this.lblDSXAdicional.Location = new System.Drawing.Point(6, 21);
            this.lblDSXAdicional.Name = "lblDSXAdicional";
            this.lblDSXAdicional.Size = new System.Drawing.Size(143, 13);
            this.lblDSXAdicional.TabIndex = 27;
            this.lblDSXAdicional.Text = "Ubicación de DSX adicional:";
            // 
            // lnkVerTipoObjeto
            // 
            this.lnkVerTipoObjeto.AutoSize = true;
            this.lnkVerTipoObjeto.Location = new System.Drawing.Point(976, 45);
            this.lnkVerTipoObjeto.Name = "lnkVerTipoObjeto";
            this.lnkVerTipoObjeto.Size = new System.Drawing.Size(106, 13);
            this.lnkVerTipoObjeto.TabIndex = 35;
            this.lnkVerTipoObjeto.TabStop = true;
            this.lnkVerTipoObjeto.Text = "Ver Tipos de Objetos";
            this.lnkVerTipoObjeto.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkVerTipoObjeto_LinkClicked);
            // 
            // comboBoxTipoCargaJob
            // 
            this.comboBoxTipoCargaJob.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTipoCargaJob.FormattingEnabled = true;
            this.comboBoxTipoCargaJob.Location = new System.Drawing.Point(713, 82);
            this.comboBoxTipoCargaJob.Name = "comboBoxTipoCargaJob";
            this.comboBoxTipoCargaJob.Size = new System.Drawing.Size(157, 21);
            this.comboBoxTipoCargaJob.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(710, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "Tipo de Carga de Jobs:";
            // 
            // lnkCerrarValidacion
            // 
            this.lnkCerrarValidacion.AutoSize = true;
            this.lnkCerrarValidacion.Location = new System.Drawing.Point(908, 616);
            this.lnkCerrarValidacion.Name = "lnkCerrarValidacion";
            this.lnkCerrarValidacion.Size = new System.Drawing.Size(166, 13);
            this.lnkCerrarValidacion.TabIndex = 38;
            this.lnkCerrarValidacion.TabStop = true;
            this.lnkCerrarValidacion.Text = "Añadir nota para cerrar validación";
            this.lnkCerrarValidacion.Visible = false;
            this.lnkCerrarValidacion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCerrarValidacion_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(976, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(102, 13);
            this.linkLabel1.TabIndex = 39;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Validar Objetos SQL";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // chkDesaNuevo
            // 
            this.chkDesaNuevo.AutoSize = true;
            this.chkDesaNuevo.Location = new System.Drawing.Point(906, 131);
            this.chkDesaNuevo.Name = "chkDesaNuevo";
            this.chkDesaNuevo.Size = new System.Drawing.Size(146, 17);
            this.chkDesaNuevo.TabIndex = 40;
            this.chkDesaNuevo.Text = "¿Es un desarrollo nuevo?";
            this.chkDesaNuevo.UseVisualStyleBackColor = true;
            this.chkDesaNuevo.Visible = false;
            // 
            // lnk_cerrar_sesion
            // 
            this.lnk_cerrar_sesion.AutoSize = true;
            this.lnk_cerrar_sesion.Location = new System.Drawing.Point(990, 29);
            this.lnk_cerrar_sesion.Name = "lnk_cerrar_sesion";
            this.lnk_cerrar_sesion.Size = new System.Drawing.Size(70, 13);
            this.lnk_cerrar_sesion.TabIndex = 41;
            this.lnk_cerrar_sesion.TabStop = true;
            this.lnk_cerrar_sesion.Text = "Cerrar Sesión";
            this.lnk_cerrar_sesion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_cerrar_sesion_LinkClicked);
            // 
            // FormValidador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1094, 676);
            this.Controls.Add(this.lnk_cerrar_sesion);
            this.Controls.Add(this.chkDesaNuevo);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.lnkCerrarValidacion);
            this.Controls.Add(this.comboBoxTipoCargaJob);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lnkVerTipoObjeto);
            this.Controls.Add(this.groupBoxArchivoAdicional);
            this.Controls.Add(this.lnkVerReglaValidacion);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxRequerimiento);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxTipoValidacion);
            this.Controls.Add(this.btnExportarResultadoValidacion);
            this.Controls.Add(this.tabControlObjeto);
            this.Controls.Add(this.checkBoxENV);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.seleccionarDSX);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.progressBar_Load);
            this.Controls.Add(this.btnCargarDSX);
            this.Controls.Add(this.txtRutaDSX);
            this.Controls.Add(this.lblruta);
            this.Controls.Add(this.btnLimpiar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1100, 700);
            this.MinimumSize = new System.Drawing.Size(1100, 700);
            this.Name = "FormValidador";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validador SES v2.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControlObjeto.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewJob)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRoutine)).EndInit();
            this.tabPageParameterSet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParameterSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBoxArchivoAdicional.ResumeLayout(false);
            this.groupBoxArchivoAdicional.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label lblruta;
        private System.Windows.Forms.TextBox txtRutaDSX;
        private System.Windows.Forms.Button btnCargarDSX;
        private System.Windows.Forms.ProgressBar progressBar_Load;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.ComponentModel.BackgroundWorker backgroundWorker_Carga;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtRutaENV;
        private System.Windows.Forms.Label labelENV;
        private System.Windows.Forms.Button btnSeleccionarENV;
        private System.Windows.Forms.Button seleccionarDSX;
        private System.Windows.Forms.CheckBox checkBoxENV;
        private System.Windows.Forms.TabControl tabControlObjeto;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnExportarResultadoValidacion;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNroServer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNroParallel;
        private System.Windows.Forms.TextBox txtNroSequence;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewJob;
        private System.Windows.Forms.TextBox txtNroRoutine;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridViewRoutine;
        private System.Windows.Forms.ComboBox comboBoxTipoValidacion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxRequerimiento;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPageParameterSet;
        private System.Windows.Forms.DataGridView dataGridViewParameterSet;
        private System.Windows.Forms.TextBox txtNroParameterSet;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.LinkLabel lnkVerReglaValidacion;
        private System.Windows.Forms.GroupBox groupBoxArchivoAdicional;
        private System.Windows.Forms.TextBox txtRutaDSXAdicional;
        private System.Windows.Forms.Button btnSeleccionarDSXAdicional;
        private System.Windows.Forms.Label lblDSXAdicional;
        private System.Windows.Forms.LinkLabel lnkVerTipoObjeto;
        private System.Windows.Forms.ComboBox comboBoxTipoCargaJob;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.LinkLabel lnkCerrarValidacion;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.CheckBox chkDesaNuevo;
        private System.Windows.Forms.LinkLabel lnk_cerrar_sesion;
    }
}

