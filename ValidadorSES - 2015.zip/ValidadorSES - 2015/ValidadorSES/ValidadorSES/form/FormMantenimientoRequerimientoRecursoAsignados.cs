﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.util;
using ValidadorSES.dao;
using ValidadorSES.modelo.view;

namespace ValidadorSES.form
{
    public partial class FormMantenimientoRequerimientoRecursoAsignados : Form
    {
        public string codigoRequerimiento { get; set; }
        List<AsignarRequerimientoView> listaAsig = new List<AsignarRequerimientoView>();

        public FormMantenimientoRequerimientoRecursoAsignados()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_MANTENIMIENTO_REQUERIMIENTO_RECURSOS_ASIGNADOS;
        }

        public void cargarPantalla() 
        {
            RequerimientoDAO rdao = new RequerimientoDAO();
            RequerimientoView rv = rdao.getRequerimientoByCodigo(codigoRequerimiento);
            this.lblCodigoReq.Text = "" + rv.codigo;
            this.lblDes.Text = rv.descripcion;

            listaAsig = new List<AsignarRequerimientoView>();

            try { 
                AsignacionReqDAO ardao = new AsignacionReqDAO();
                listaAsig = ardao.getListaRequerimientoAsignadosPorRequerimiento(codigoRequerimiento);                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error consulta BD: " + ex);
            }

            cargarTabla();
        }

        public void cargarTabla()
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString("CODIGO"));
            table.Columns.Add(UtilForm.getColumnString("RESPONSABLE"));
            table.Columns.Add(UtilForm.getColumnString("FECHA ENTREGA"));
            table.Columns.Add(UtilForm.getColumnString("CREADO EL"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO VALIDACIÓN"));
            //creacion de la tabla
            if (listaAsig != null && listaAsig.Count > 0)
            {
                int total = listaAsig.Count;
                for (int j = 0; j < total; j++)
                {
                    AsignarRequerimientoView ov = listaAsig[j];
                    DataRow row = table.NewRow();
                    row["CODIGO"] = ov.codigo;
                    row["RESPONSABLE"] = ov.fullName;
                    row["FECHA ENTREGA"] = ov.fecha_asignacion;
                    row["CREADO EL"] = ov.fecha_creacion;
                    row["ESTADO"] = ov.estado;
                    row["ESTADO VALIDACIÓN"] = ov.estadoValidacion;

                    table.Rows.Add(row);
                }
            }

            dataGridViewAsigReq.Columns.Clear();
            DataView view = new DataView(table);

            dataGridViewAsigReq.Visible = true;
            dataGridViewAsigReq.RowHeadersVisible = false;
            dataGridViewAsigReq.DataSource = view;

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewAsigReq.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = "DSX válidados";
            buttonColumn.Name = "Abrir";
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewAsigReq.Columns["Abrir"].Width = 100;
            dataGridViewAsigReq.Columns["CODIGO"].Width = 60;
            dataGridViewAsigReq.Columns["RESPONSABLE"].Width = 95;
            dataGridViewAsigReq.Columns["FECHA ENTREGA"].Width = 150;
            dataGridViewAsigReq.Columns["CREADO EL"].Width = 140;
            dataGridViewAsigReq.Columns["ESTADO"].Width = 170;
            dataGridViewAsigReq.Columns["ESTADO VALIDACIÓN"].Width = 170;
        }

        private void dataGridViewAsigReq_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewAsigReq.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 0) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewAsigReq.CurrentCell.RowIndex;

                string codigoAsigReq = dataGridViewAsigReq.Rows[filaSeleccionada].Cells["CODIGO"].Value.ToString();
                
                FormDSXListado formListado = new FormDSXListado();
                formListado.codAsigReq = codigoAsigReq;
                formListado.cargarPantalla();
                formListado.ShowDialog();

                dataGridViewAsigReq.Rows[filaSeleccionada].Cells["CODIGO"].Selected = true;
            }
        }

        private void dataGridViewAsigReq_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewAsigReq.Columns[e.ColumnIndex].Name.Equals("ESTADO"))
            {
                string estado = dataGridViewAsigReq.Rows[e.RowIndex].Cells["ESTADO"].Value.ToString();
                if (estado.Equals(ConstanteMaestro.DES_EST_ASIG_FINALIZADO) || estado.Equals(ConstanteMaestro.DES_EST_ASIG_FINALIZADO_JUSTIFICACION))
                {
                    dataGridViewAsigReq.Rows[e.RowIndex].Cells["ESTADO"].Style.ForeColor = Color.Green;
                }
                else
                {
                    dataGridViewAsigReq.Rows[e.RowIndex].Cells["ESTADO"].Style.ForeColor = Color.Red;
                }
            }
        }
    }
}
