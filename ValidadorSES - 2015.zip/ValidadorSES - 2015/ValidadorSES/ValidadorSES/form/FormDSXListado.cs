﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.dao;

namespace ValidadorSES.form
{
    public partial class FormDSXListado : Form
    {
        public const string TBL_CODIGO_DSX = "Código";
        public const string TBL_ARCHIVO_DSX = "Archivo";
        public const string TBL_NUM_JOB_SEQ = "# Sequence";
        public const string TBL_NUM_JOB_PARALLEL = "# Parallel";
        public const string TBL_NUM_JOB_SERVER = "# Server";
        public const string TBL_NUM_ROUTINE = "# Routine";
        public const string TBL_NUM_PARAMETER_SET = "# ParameterSet";
        public const string TBL_FECHA_EXPORTACION = "Fecha Exportación";
        public const string TBL_FECHA_MOD = "Fecha últ. mod.";
        public const string TBL_FECHA_VALIDACION = "Fecha validación";
        public const string TBL_ESTADO = "Estado";
        public const string TBL_NOTA = "Justificación";

        public string codAsigReq { get; set; }
        private List<LogDSX> listaDSX = new List<LogDSX>();
        private LogDSX dsxSeleccionado = null;

        public FormDSXListado()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_REQUERIMIENTO_LISTADO_DSX;


        }

        public void cargarPantalla()
        {
            listaDSX = new List<LogDSX>();
            try 
            {
                ValidacionDAO vdao = new ValidacionDAO();
                listaDSX = vdao.getListaDSXByCodAsigReq(codAsigReq);            
            }
            catch (Exception ex)
            {
                Console.WriteLine("Excepcion cargar lista DSX " + ex);
            }

            cargarTabla();
            cargarDSXSeleccionado();
        }

        public void cargarTabla()
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(TBL_CODIGO_DSX));
            table.Columns.Add(UtilForm.getColumnString(TBL_ARCHIVO_DSX));
            table.Columns.Add(UtilForm.getColumnString(TBL_FECHA_VALIDACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_NUM_JOB_SEQ));
            table.Columns.Add(UtilForm.getColumnString(TBL_NUM_JOB_PARALLEL));
            table.Columns.Add(UtilForm.getColumnString(TBL_NUM_JOB_SERVER));
            table.Columns.Add(UtilForm.getColumnString(TBL_NUM_ROUTINE));
            table.Columns.Add(UtilForm.getColumnString(TBL_NUM_PARAMETER_SET));
            table.Columns.Add(UtilForm.getColumnString(TBL_FECHA_EXPORTACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_FECHA_MOD));
            table.Columns.Add(UtilForm.getColumnString(TBL_NOTA));

            //creacion de la tabla
            if (listaDSX != null && listaDSX.Count > 0)
            {
                int totalDSX = listaDSX.Count;
                for (int j = 0; j < totalDSX; j++)
                {
                    DataRow row = table.NewRow();
                    row[TBL_CODIGO_DSX] = listaDSX[j].codigoDSX;
                    row[TBL_ARCHIVO_DSX] = listaDSX[j].descripcion;
                    row[TBL_NUM_JOB_SEQ] = listaDSX[j].numJobSequence;
                    row[TBL_NUM_JOB_PARALLEL] = listaDSX[j].numJobParallel;
                    row[TBL_NUM_JOB_SERVER] = listaDSX[j].numJobServer;
                    row[TBL_NUM_ROUTINE] = listaDSX[j].numRoutine;
                    row[TBL_NUM_PARAMETER_SET] = listaDSX[j].numParameterSet;
                    row[TBL_FECHA_EXPORTACION] = listaDSX[j].cadenaFechaExportacion;
                    row[TBL_FECHA_MOD] = listaDSX[j].cadenaFechaUltimaModificacion;
                    row[TBL_FECHA_VALIDACION] = listaDSX[j].cadenaFechaValidacion;
                    row[TBL_ESTADO] = listaDSX[j].descripcionEstado;
                    row[TBL_NOTA] = listaDSX[j].nota;

                    table.Rows.Add(row);
                }
            }

            dataGridViewDSX.Columns.Clear();
            view = new DataView(table);

            dataGridViewDSX.Visible = true;
            dataGridViewDSX.RowHeadersVisible = false;
            dataGridViewDSX.DataSource = view;

            dataGridViewDSX.Columns[TBL_CODIGO_DSX].Width = 50;
            dataGridViewDSX.Columns[TBL_ARCHIVO_DSX].Width = 200;
            dataGridViewDSX.Columns[TBL_NUM_JOB_SEQ].Width = 110;
            dataGridViewDSX.Columns[TBL_NUM_JOB_PARALLEL].Width = 110;
            dataGridViewDSX.Columns[TBL_NUM_JOB_SERVER].Width = 110;
            dataGridViewDSX.Columns[TBL_NUM_ROUTINE].Width = 110;
            dataGridViewDSX.Columns[TBL_NUM_PARAMETER_SET].Width = 110;
            dataGridViewDSX.Columns[TBL_ESTADO].Width = 74;
            dataGridViewDSX.Columns[TBL_FECHA_EXPORTACION].Width = 140;
            dataGridViewDSX.Columns[TBL_FECHA_MOD].Width = 140;
            dataGridViewDSX.Columns[TBL_FECHA_VALIDACION].Width = 140;
            dataGridViewDSX.Columns[TBL_NOTA].Width = 300;

            dataGridViewDSX.Columns[TBL_NUM_JOB_SEQ].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewDSX.Columns[TBL_NUM_JOB_PARALLEL].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewDSX.Columns[TBL_NUM_JOB_SERVER].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewDSX.Columns[TBL_NUM_ROUTINE].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewDSX.Columns[TBL_NUM_PARAMETER_SET].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewDSX.Columns[TBL_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewDSX.Columns[TBL_FECHA_EXPORTACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewDSX.Columns[TBL_FECHA_MOD].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewDSX.Columns[TBL_FECHA_VALIDACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;       
        }

        private void cargarDSXSeleccionado()
        {
            dataGridViewJob.DataSource = null;
            dataGridViewJob.Visible = false;
            dataGridViewRoutine.DataSource = null;
            dataGridViewRoutine.Visible = false;
            dataGridViewParameterSet.DataSource = null;
            dataGridViewParameterSet.Visible = false;

            if (dsxSeleccionado != null)
            {
                cargarTablaJob(dsxSeleccionado);
                cargarTablaRoutine(dsxSeleccionado);
                cargarTablaParameterSet(dsxSeleccionado);
            }
        }
        
        private void cargarTablaJob(LogDSX dsx)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_NOMBRE_JOB));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_TIPO_JOB));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_TOTAL_STAGES));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_TOTAL_STAGES_CORRECTOS));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_TOTAL_STAGES_ERRORES));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_TOTAL_STAGES_OBSERVACIONES));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_JOB_RUTA));

            //creacion de la tabla
            List<LogJob> listaJob = dsx.listaJob;
            if (listaJob != null && listaJob.Count > 0)
            {
                int totalJobs = listaJob.Count;
                for (int j = 0; j < totalJobs; j++)
                {
                    DataRow row = table.NewRow();
                    row[FormValidador.TBL_JOB_NOMBRE_JOB] = listaJob[j].identifierJob;
                    row[FormValidador.TBL_JOB_TIPO_JOB] = listaJob[j].objeto.nombre;
                    row[FormValidador.TBL_JOB_TOTAL_STAGES] = listaJob[j].listaStage.Count;
                    row[FormValidador.TBL_JOB_TOTAL_STAGES_CORRECTOS] = listaJob[j].numStageCorrecto;
                    row[FormValidador.TBL_JOB_TOTAL_STAGES_ERRORES] = listaJob[j].numStageIncorrecto;
                    row[FormValidador.TBL_JOB_TOTAL_STAGES_OBSERVACIONES] = listaJob[j].numStageObservado;
                    row[FormValidador.TBL_JOB_ESTADO] = listaJob[j].estadoJobDescripcion;
                    row[FormValidador.TBL_JOB_RUTA] = listaJob[j].category;

                    table.Rows.Add(row);
                }
            }

            dataGridViewJob.Columns.Clear();
            view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewJob.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = ">";
            buttonColumn.Name = FormValidador.TBL_JOB_ABRIR_DETALLE;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewJob.Visible = true;
            dataGridViewJob.RowHeadersVisible = false;
            dataGridViewJob.DataSource = view;

            dataGridViewJob.Columns[FormValidador.TBL_JOB_ABRIR_DETALLE].Width = 40;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_NOMBRE_JOB].Width = 301;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TIPO_JOB].Width = 90;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES].Width = 110;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES_CORRECTOS].Width = 110;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES_ERRORES].Width = 110;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES_OBSERVACIONES].Width = 130;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_ESTADO].Width = 74;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_RUTA].Width = 500;

            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES_CORRECTOS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES_ERRORES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_TOTAL_STAGES_OBSERVACIONES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewJob.Columns[FormValidador.TBL_JOB_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void cargarTablaRoutine(LogDSX dsx)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_NOMBRE_ROUTINE));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_TIPO_ROUTINE));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_TOTAL_ARGUMENTOS));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_CORRECTOS));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_ERRORES));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_OBSERVACIONES));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_ROUTINE_RUTA));

            //creacion de la tabla
            List<LogRoutine> listaRoutine = dsx.listaRoutine;
            if (listaRoutine != null && listaRoutine.Count > 0)
            {
                int totalRoutine = listaRoutine.Count;
                for (int j = 0; j < totalRoutine; j++)
                {
                    DataRow row = table.NewRow();
                    row[FormValidador.TBL_ROUTINE_NOMBRE_ROUTINE] = listaRoutine[j].identifier;
                    row[FormValidador.TBL_ROUTINE_TIPO_ROUTINE] = listaRoutine[j].objeto.nombre;
                    row[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENTOS] = listaRoutine[j].listaArgumentoRoutine.Count;
                    row[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_CORRECTOS] = listaRoutine[j].numArgCorrecto;
                    row[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_ERRORES] = listaRoutine[j].numArgIncorrecto;
                    row[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_OBSERVACIONES] = listaRoutine[j].numArgObservado;
                    row[FormValidador.TBL_ROUTINE_ESTADO] = listaRoutine[j].estadoRutinaDescripcion;
                    row[FormValidador.TBL_ROUTINE_RUTA] = listaRoutine[j].category; 

                    table.Rows.Add(row);
                }
            }

            dataGridViewRoutine.Columns.Clear();
            view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewRoutine.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = ">";
            buttonColumn.Name = FormValidador.TBL_ROUTINE_ABRIR_DETALLE;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewRoutine.Visible = true;
            dataGridViewRoutine.RowHeadersVisible = false;
            dataGridViewRoutine.DataSource = view;

            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_ABRIR_DETALLE].Width = 40;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_NOMBRE_ROUTINE].Width = 301;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TIPO_ROUTINE].Width = 110;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENTOS].Width = 110;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_CORRECTOS].Width = 110;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_ERRORES].Width = 110;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_OBSERVACIONES].Width = 130;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_ESTADO].Width = 74;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_RUTA].Width = 500;

            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENTOS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_CORRECTOS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_ERRORES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_TOTAL_ARGUMENT_OBSERVACIONES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewRoutine.Columns[FormValidador.TBL_ROUTINE_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void cargarTablaParameterSet(LogDSX dsx)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            DataView view = new DataView();

            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_PARAMETER_SET_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_PARAMETER_SET_TOTAL_PARAMETROS));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_CORRECTOS));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_ERRORES));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_OBSERVACIONES));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_PARAMETER_SET_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(FormValidador.TBL_PARAMETER_SET_RUTA));

            //creacion de la tabla
            List<LogParameterSet> listaParameterSet = dsx.listaParameterSet;
            int totalParameterSet = 0;
            if (listaParameterSet != null && listaParameterSet.Count > 0)
            {
                totalParameterSet = listaParameterSet.Count;
                for (int j = 0; j < totalParameterSet; j++)
                {
                    DataRow row = table.NewRow();
                    row[FormValidador.TBL_PARAMETER_SET_NOMBRE] = listaParameterSet[j].identifierParameterSet;
                    row[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAMETROS] = listaParameterSet[j].listaParam.Count;
                    row[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_CORRECTOS] = listaParameterSet[j].numParamCorrecto;
                    row[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_ERRORES] = listaParameterSet[j].numParamIncorrecto;
                    row[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_OBSERVACIONES] = listaParameterSet[j].numParamObservado;
                    row[FormValidador.TBL_PARAMETER_SET_ESTADO] = listaParameterSet[j].estadoParameterDescripcion;
                    row[FormValidador.TBL_PARAMETER_SET_RUTA] = listaParameterSet[j].category;

                    table.Rows.Add(row);
                }
            }

            dataGridViewParameterSet.Columns.Clear();
            view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewParameterSet.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "Abrir";
            buttonColumn.Text = ">";
            buttonColumn.Name = FormValidador.TBL_PARAMETER_SET_ABRIR_DETALLE;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewParameterSet.Visible = true;
            dataGridViewParameterSet.RowHeadersVisible = false;
            dataGridViewParameterSet.DataSource = view;

            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_ABRIR_DETALLE].Width = 40;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_NOMBRE].Width = 371;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAMETROS].Width = 110;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_CORRECTOS].Width = 110;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_ERRORES].Width = 110;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_OBSERVACIONES].Width = 130;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_ESTADO].Width = 74;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_RUTA].Width = 500;

            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAMETROS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_CORRECTOS].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_ERRORES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_TOTAL_PARAM_OBSERVACIONES].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewParameterSet.Columns[FormValidador.TBL_PARAMETER_SET_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void dataGridViewDSX_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewDSX.CurrentRow != null)
            {
                Object o = dataGridViewDSX.CurrentRow.Cells[TBL_CODIGO_DSX];

                if (o != null)
                {
                    string codigoDSXTexto = (string)dataGridViewDSX.CurrentRow.Cells[TBL_CODIGO_DSX].Value;
                    int codigoDSX = Convert.ToInt32(codigoDSXTexto);
                    ValidacionDAO vdao = new ValidacionDAO();

                    dsxSeleccionado = vdao.getDSXByCodigo(codigoDSX);
                }
            }

            cargarDSXSeleccionado();
        }

        private void dataGridViewJob_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewJob.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 0) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewJob.CurrentCell.RowIndex;

                string nombreJob = dataGridViewJob.Rows[filaSeleccionada].Cells[FormValidador.TBL_JOB_NOMBRE_JOB].Value.ToString();
                List<LogJob> listaJob = dsxSeleccionado.listaJob;
                LogJob job = UtilObjeto.getJobByName(nombreJob, listaJob);

                this.Hide();

                FormValidadorDetalleJob formDetalle = new FormValidadorDetalleJob();
                formDetalle.cargarDetalleJob(job);
                formDetalle.ShowDialog();

                this.Show();

                dataGridViewJob.Rows[filaSeleccionada].Cells[FormValidador.TBL_JOB_ABRIR_DETALLE].Selected = false;
                dataGridViewJob.Rows[filaSeleccionada].Selected = true;
                dataGridViewJob.Rows[filaSeleccionada].Cells[FormValidador.TBL_JOB_NOMBRE_JOB].Selected = true;
            }
        }

        private void dataGridViewRoutine_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewRoutine.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 0) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewRoutine.CurrentCell.RowIndex;

                string nombreRoutine = dataGridViewRoutine.Rows[filaSeleccionada].Cells[FormValidador.TBL_ROUTINE_NOMBRE_ROUTINE].Value.ToString();
                List<LogRoutine> listaRoutine = dsxSeleccionado.listaRoutine;
                LogRoutine routine = UtilObjeto.getRoutineByName(nombreRoutine, listaRoutine);

                FormValidadorDetalleRoutine formDetalle = new FormValidadorDetalleRoutine();
                formDetalle.cargarDetalleRoutine(routine);
                formDetalle.ShowDialog();

                dataGridViewRoutine.Rows[filaSeleccionada].Selected = false;
            }
        }

        private void dataGridViewParameterSet_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int columnaSeleccionada = dataGridViewParameterSet.CurrentCell.ColumnIndex;

            if (rowIndex > -1 && columnaSeleccionada == 0) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewParameterSet.CurrentCell.RowIndex;

                string nombreParameter = dataGridViewParameterSet.Rows[filaSeleccionada].Cells[FormValidador.TBL_PARAMETER_SET_NOMBRE].Value.ToString();
                List<LogParameterSet> listaParameter = dsxSeleccionado.listaParameterSet;
                LogParameterSet parameter = UtilObjeto.getParameterSetByName(nombreParameter, listaParameter);

                FormValidadorDetalleParameterSet formDetalle = new FormValidadorDetalleParameterSet();
                formDetalle.cargarDetalleParameterSet(parameter);
                formDetalle.ShowDialog();

                dataGridViewParameterSet.Rows[filaSeleccionada].Selected = false;
            }
        }

        private void dataGridViewDSX_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewDSX.Columns[e.ColumnIndex].Name.Equals(TBL_ESTADO))
            {
                string estado = dataGridViewDSX.Rows[e.RowIndex].Cells[TBL_ESTADO].Value.ToString();
                if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_OK))
                {
                    dataGridViewDSX.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_ERROR))
                    {
                        dataGridViewDSX.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

        private void dataGridViewJob_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewJob.Columns[e.ColumnIndex].Name.Equals(TBL_ESTADO))
            {
                string estado = dataGridViewJob.Rows[e.RowIndex].Cells[TBL_ESTADO].Value.ToString();
                if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_OK))
                {
                    dataGridViewJob.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_ERROR))
                    {
                        dataGridViewJob.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

        private void dataGridViewRoutine_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewRoutine.Columns[e.ColumnIndex].Name.Equals(TBL_ESTADO))
            {
                string estado = dataGridViewRoutine.Rows[e.RowIndex].Cells[TBL_ESTADO].Value.ToString();
                if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_OK))
                {
                    dataGridViewRoutine.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_ERROR))
                    {
                        dataGridViewRoutine.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

        private void dataGridViewParameterSet_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridViewParameterSet.Columns[e.ColumnIndex].Name.Equals(TBL_ESTADO))
            {
                string estado = dataGridViewParameterSet.Rows[e.RowIndex].Cells[TBL_ESTADO].Value.ToString();
                if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_OK))
                {
                    dataGridViewParameterSet.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals(ConstanteMaestro.DES_EST_VALIDACION_ERROR))
                    {
                        dataGridViewParameterSet.Rows[e.RowIndex].Cells[TBL_ESTADO].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

    }
}
