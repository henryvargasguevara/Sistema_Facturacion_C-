﻿namespace ValidadorSES.form
{
    partial class FormObjetoRegistroModificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormObjetoRegistroModificacion));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblOLEType = new System.Windows.Forms.Label();
            this.comboBoxClasificacionObjeto = new System.Windows.Forms.ComboBox();
            this.lblPrefijo = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.txtOLEType = new System.Windows.Forms.TextBox();
            this.txtPrefijo = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.btnAccion = new System.Windows.Forms.Button();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.txtType = new System.Windows.Forms.TextBox();
            this.lblType = new System.Windows.Forms.Label();
            this.txtMnemonico = new System.Windows.Forms.TextBox();
            this.lblMnemonico = new System.Windows.Forms.Label();
            this.comboBoxEstado = new System.Windows.Forms.ComboBox();
            this.lblEstado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(291, 21);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(209, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Registro de Objeto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(174, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Clasificación de objeto:";
            // 
            // lblOLEType
            // 
            this.lblOLEType.AutoSize = true;
            this.lblOLEType.Location = new System.Drawing.Point(235, 89);
            this.lblOLEType.Name = "lblOLEType";
            this.lblOLEType.Size = new System.Drawing.Size(55, 13);
            this.lblOLEType.TabIndex = 2;
            this.lblOLEType.Text = "OLEType:";
            // 
            // comboBoxClasificacionObjeto
            // 
            this.comboBoxClasificacionObjeto.DisplayMember = "Job";
            this.comboBoxClasificacionObjeto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxClasificacionObjeto.FormattingEnabled = true;
            this.comboBoxClasificacionObjeto.Items.AddRange(new object[] {
            "Job",
            "Stage",
            "Routine"});
            this.comboBoxClasificacionObjeto.Location = new System.Drawing.Point(296, 59);
            this.comboBoxClasificacionObjeto.Name = "comboBoxClasificacionObjeto";
            this.comboBoxClasificacionObjeto.Size = new System.Drawing.Size(188, 21);
            this.comboBoxClasificacionObjeto.TabIndex = 3;
            this.comboBoxClasificacionObjeto.Tag = "";
            this.comboBoxClasificacionObjeto.SelectedValueChanged += new System.EventHandler(this.comboBoxClasificacionObjeto_SelectedValueChanged);
            // 
            // lblPrefijo
            // 
            this.lblPrefijo.AutoSize = true;
            this.lblPrefijo.Location = new System.Drawing.Point(251, 141);
            this.lblPrefijo.Name = "lblPrefijo";
            this.lblPrefijo.Size = new System.Drawing.Size(39, 13);
            this.lblPrefijo.TabIndex = 4;
            this.lblPrefijo.Text = "Prefijo:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(243, 167);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(47, 13);
            this.lblNombre.TabIndex = 5;
            this.lblNombre.Text = "Nombre:";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(225, 219);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(66, 13);
            this.lblDescripcion.TabIndex = 6;
            this.lblDescripcion.Text = "Descripción:";
            // 
            // txtOLEType
            // 
            this.txtOLEType.Location = new System.Drawing.Point(296, 86);
            this.txtOLEType.Name = "txtOLEType";
            this.txtOLEType.Size = new System.Drawing.Size(188, 20);
            this.txtOLEType.TabIndex = 7;
            // 
            // txtPrefijo
            // 
            this.txtPrefijo.Location = new System.Drawing.Point(296, 138);
            this.txtPrefijo.Name = "txtPrefijo";
            this.txtPrefijo.Size = new System.Drawing.Size(188, 20);
            this.txtPrefijo.TabIndex = 9;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(296, 164);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(188, 20);
            this.txtNombre.TabIndex = 10;
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(296, 216);
            this.txtDescripcion.Multiline = true;
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(447, 82);
            this.txtDescripcion.TabIndex = 13;
            // 
            // btnAccion
            // 
            this.btnAccion.Location = new System.Drawing.Point(296, 327);
            this.btnAccion.Name = "btnAccion";
            this.btnAccion.Size = new System.Drawing.Size(81, 23);
            this.btnAccion.TabIndex = 14;
            this.btnAccion.Text = "REGISTRAR";
            this.btnAccion.UseVisualStyleBackColor = true;
            this.btnAccion.Click += new System.EventHandler(this.btnAccion_Click);
            // 
            // btnBorrar
            // 
            this.btnBorrar.Location = new System.Drawing.Point(409, 327);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(75, 23);
            this.btnBorrar.TabIndex = 15;
            this.btnBorrar.Text = "BORRAR";
            this.btnBorrar.UseVisualStyleBackColor = true;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(296, 112);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(188, 20);
            this.txtType.TabIndex = 8;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(225, 115);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(62, 13);
            this.lblType.TabIndex = 14;
            this.lblType.Text = "StageType:";
            // 
            // txtMnemonico
            // 
            this.txtMnemonico.Location = new System.Drawing.Point(296, 190);
            this.txtMnemonico.Name = "txtMnemonico";
            this.txtMnemonico.Size = new System.Drawing.Size(188, 20);
            this.txtMnemonico.TabIndex = 11;
            // 
            // lblMnemonico
            // 
            this.lblMnemonico.AutoSize = true;
            this.lblMnemonico.Location = new System.Drawing.Point(225, 193);
            this.lblMnemonico.Name = "lblMnemonico";
            this.lblMnemonico.Size = new System.Drawing.Size(65, 13);
            this.lblMnemonico.TabIndex = 16;
            this.lblMnemonico.Text = "Mnemónico:";
            // 
            // comboBoxEstado
            // 
            this.comboBoxEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEstado.FormattingEnabled = true;
            this.comboBoxEstado.Items.AddRange(new object[] {
            "ACTIVO",
            "INACTIVO"});
            this.comboBoxEstado.Location = new System.Drawing.Point(622, 190);
            this.comboBoxEstado.Name = "comboBoxEstado";
            this.comboBoxEstado.Size = new System.Drawing.Size(121, 21);
            this.comboBoxEstado.TabIndex = 12;
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(573, 193);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(43, 13);
            this.lblEstado.TabIndex = 18;
            this.lblEstado.Text = "Estado:";
            // 
            // FormObjetoRegistroModificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 416);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.comboBoxEstado);
            this.Controls.Add(this.lblMnemonico);
            this.Controls.Add(this.txtMnemonico);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.btnAccion);
            this.Controls.Add(this.txtDescripcion);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.txtPrefijo);
            this.Controls.Add(this.txtOLEType);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblPrefijo);
            this.Controls.Add(this.comboBoxClasificacionObjeto);
            this.Controls.Add(this.lblOLEType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormObjetoRegistroModificacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro de Objeto DataStage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblOLEType;
        private System.Windows.Forms.ComboBox comboBoxClasificacionObjeto;
        private System.Windows.Forms.Label lblPrefijo;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.TextBox txtOLEType;
        private System.Windows.Forms.TextBox txtPrefijo;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Button btnAccion;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label lblType;
        public System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox txtMnemonico;
        private System.Windows.Forms.Label lblMnemonico;
        private System.Windows.Forms.ComboBox comboBoxEstado;
        private System.Windows.Forms.Label lblEstado;
    }
}