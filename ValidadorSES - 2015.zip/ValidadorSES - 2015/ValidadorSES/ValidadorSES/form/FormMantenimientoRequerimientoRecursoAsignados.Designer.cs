﻿namespace ValidadorSES.form
{
    partial class FormMantenimientoRequerimientoRecursoAsignados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMantenimientoRequerimientoRecursoAsignados));
            this.dataGridViewAsigReq = new System.Windows.Forms.DataGridView();
            this.lblCodigoReq = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblDes = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAsigReq)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewAsigReq
            // 
            this.dataGridViewAsigReq.AllowUserToAddRows = false;
            this.dataGridViewAsigReq.AllowUserToDeleteRows = false;
            this.dataGridViewAsigReq.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewAsigReq.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAsigReq.Location = new System.Drawing.Point(15, 75);
            this.dataGridViewAsigReq.Name = "dataGridViewAsigReq";
            this.dataGridViewAsigReq.ReadOnly = true;
            this.dataGridViewAsigReq.Size = new System.Drawing.Size(891, 361);
            this.dataGridViewAsigReq.TabIndex = 2;
            this.dataGridViewAsigReq.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewAsigReq_CellFormatting);
            this.dataGridViewAsigReq.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAsigReq_CellContentClick);
            // 
            // lblCodigoReq
            // 
            this.lblCodigoReq.AutoSize = true;
            this.lblCodigoReq.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoReq.Location = new System.Drawing.Point(139, 18);
            this.lblCodigoReq.Name = "lblCodigoReq";
            this.lblCodigoReq.Size = new System.Drawing.Size(45, 16);
            this.lblCodigoReq.TabIndex = 3;
            this.lblCodigoReq.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Descripción:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Requerimiento:";
            // 
            // lblDes
            // 
            this.lblDes.AutoSize = true;
            this.lblDes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDes.Location = new System.Drawing.Point(139, 43);
            this.lblDes.Name = "lblDes";
            this.lblDes.Size = new System.Drawing.Size(45, 16);
            this.lblDes.TabIndex = 6;
            this.lblDes.Text = "label1";
            // 
            // FormMantenimientoRequerimientoRecursoAsignados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 448);
            this.Controls.Add(this.lblDes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCodigoReq);
            this.Controls.Add(this.dataGridViewAsigReq);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMantenimientoRequerimientoRecursoAsignados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormMantenimientoRequerimientoRecursoAsignados";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAsigReq)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewAsigReq;
        public System.Windows.Forms.Label lblCodigoReq;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label lblDes;
    }
}