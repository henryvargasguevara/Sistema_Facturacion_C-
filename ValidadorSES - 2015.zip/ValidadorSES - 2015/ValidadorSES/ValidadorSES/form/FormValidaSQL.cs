﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.service;

namespace ValidadorSES.form
{
    public partial class FormValidaSQL : Form
    {
        private LogJob job { get; set; }

        public FormValidaSQL()
        {                        
            InitializeComponent();
           
            this.Text = ConstanteTituloForm.TITULO_APP_ABREV;
        }
        
        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string mensaje = "";
            try
            {                
            if (!UtilArchivo.esValidoArchivoSQL(txtRutaSQL.Text))
            {
                mensaje += ConstanteCadena.MSG_VAL_ARCHIVO_SQL;
                MessageBox.Show(mensaje);
            }
                else
                {
                    string archivosql = UtilValidaSQL.lineasArchivoSql(txtRutaSQL.Text);
                    aaa(archivosql);
                    validar_tablas(txtRutaSQL.Text);
                }

            contador();            
            }
            catch (Exception ex)
            {
                mensaje = ex.ToString();
                MessageBox.Show(mensaje);
            }
        }

        private void contador()
        {            
            int cantiGrid1 = DataGridSQL.Rows.Cast<DataGridViewRow>().Where(x => Convert.ToString(x.Cells[2].Value) == "NOTOK").Count();
            int cantiGrid2 = dgvTablas.Rows.Cast<DataGridViewRow>().Where(x => Convert.ToString(x.Cells[2].Value) == "NOTOK").Count();

            String tituloTag1 = "";
            String tituloTag2 = "";

            if (cantiGrid1 > 0)
            {
                if (tituloTag1 != "")
                {
                    tituloTag1 += ", ";
                }
                if (cantiGrid1 == 1)
                {
                    tituloTag1 += cantiGrid1 + " error";
                }
                else
                {
                    tituloTag1 += cantiGrid1 + " errores";
                }
            }
            if (tituloTag1 != "")
            {
                tituloTag1 = "(" + tituloTag1 + ")";
            }
            tabValidaccion.Text = "Validación " + tituloTag1;

            if (cantiGrid2 > 0)
            {
                if (tituloTag2 != "")
                {
                    tituloTag2 += ", ";
                }
                if (cantiGrid2 == 1)
                {
                    tituloTag2 += cantiGrid2 + " error";
                }
                else
                {
                    tituloTag2 += cantiGrid2 + " errores";
                }
            }
            if (tituloTag2 != "")
            {
                tituloTag2 = "(" + tituloTag2 + ")";
            }
            tabtablas.Text = "Nomenclatura de tablas " + tituloTag2;
        }


        private void seleccionarSQL_Click(object sender, EventArgs e)
        {
            DataGridSQL.Rows.Clear();
            dgvTablas.Rows.Clear();
            tabtablas.Text = "Validación";
            tabValidaccion.Text = "Nomenclatura de Tablas";
            txtRutaSQL.Text = "";
            OpenFileDialog path = new OpenFileDialog();

            if (path.ShowDialog() == DialogResult.OK)
            {
                txtRutaSQL.Text = path.FileName;
            }
            
        }

        private void validar_tablas(string archivo)
        {
            dgvTablas.Rows.Clear();
            LogSql logsql = UtilValidaSQL.probando_vamos(archivo);

            for (int i = 0; i < logsql.listatablas.Count; i++)
            {
                string tabla = logsql.listatablas[i];
                string resultado = logsql.listaFinal[i];
                string estado = logsql.listaEstado[i];                
                this.dgvTablas.Rows.Add(tabla, resultado, estado);
            }

            //DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            //dgvTablas.Columns.Add(buttonColumn);
            //buttonColumn.HeaderText = "";
            //buttonColumn.Text = "...";
            //buttonColumn.Name = "ver";
            //buttonColumn.DisplayIndex = 1;
            //buttonColumn.UseColumnTextForButtonValue = true;
            //buttonColumn.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);

            //dgvTablas.Columns["ver"].Width = 50;

            

        }

        //private void mostrarMensajeStage(LogStage stage)
        //{
        //    if (stage.mensaje != null && stage.mensaje != "")
        //    {
        //        string desConSalto = stage.mensaje;
        //        desConSalto = desConSalto.Replace(": ", ": \n");
        //        desConSalto = desConSalto.Replace(". ", ". \n\n");
        //        MessageBox.Show(desConSalto, "Validación de Stage", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //}

        private void aaa(string archivo)
        {          
            DataGridSQL.Rows.Clear();
            string grant = "Permisos para usuarios (GRANT)";
            string insert = "Insertar data (INSERT)";
            string truncate = "Eliminación de data (TRUNCATE)";
            string delete = "Eliminación de data(DELETE)";
            string update = "Actualización de data(UPDATE)";
            string compres = "Sentencia 'COMPRESS YES'";
            string logged = "Sentencia 'NOT LOGGED INITIALLY'";
            string du = "Llaves primarias para tablas DU";

            string result_grant = UtilValidaSQL.verificar_grant(archivo);
            string result_insert = UtilValidaSQL.verificar_insert(archivo);
            string result_truncate = UtilValidaSQL.verificar_truncate(archivo);
            string result_delete = UtilValidaSQL.verificar_delete(archivo);
            string result_update = UtilValidaSQL.verificar_update(archivo);
            string result_compres = UtilValidaSQL.verificar_compress(txtRutaSQL.Text);
            string result_logged = UtilValidaSQL.verificar_logged(txtRutaSQL.Text);
            string result_du = UtilValidaSQL.verificar_pk_tablas_du(archivo);
            //    string aa = UtilValidaSQL.probando_vamos(txtRutaSQL.Text);

            string estado_grant = null;
            string estado_insert = null;
            string estado_truncate = null;
            string estado_delete = null;
            string estado_update = null;
            string estado_compres = null;
            string estado_logged = null;
            string estado_du = null;

            if (result_grant != "")
            { estado_grant = "NOTOK"; }
            else { estado_grant = "OK"; }
            if (result_insert != "")
            { estado_insert = "NOTOK"; }
            else { estado_insert = "OK"; }
            if (result_truncate != "")
            { estado_truncate = "NOTOK"; }
            else { estado_truncate = "OK"; }
            if (result_delete != "")
            { estado_delete = "NOTOK"; }
            else { estado_delete = "OK"; }
            if (result_update != "")
            { estado_update = "NOTOK"; }
            else { estado_update = "OK"; }
            if (result_compres != "")
            { estado_compres = "NOTOK"; }
            else { estado_compres = "OK"; }
            if (result_logged != "")
            { estado_logged = "NOTOK"; }
            else { estado_logged = "OK"; }
            if (result_du != "")
            { estado_du = "NOTOK"; }
            else { estado_du = "OK"; }

            this.DataGridSQL.Rows.Add(grant, result_grant, estado_grant);
            this.DataGridSQL.Rows.Add(insert, result_insert, estado_insert);
            this.DataGridSQL.Rows.Add(truncate, result_truncate, estado_truncate);
            this.DataGridSQL.Rows.Add(delete, result_delete, estado_delete);
            this.DataGridSQL.Rows.Add(update, result_update, estado_update);
            this.DataGridSQL.Rows.Add(compres, result_compres, estado_compres);
            this.DataGridSQL.Rows.Add(logged, result_logged, estado_logged);
            this.DataGridSQL.Rows.Add(du, result_du, estado_du);


            //this.DataGridSQL.Rows.Add(logsql.listatablas, logsql.listaFinal);

            //for (int i = 0; i < logsql.listatablas.Count; i++)
            //{
            //    string tabla = logsql.listatablas[i];
            //    string resultado = logsql.listaFinal[i];
            //    string estado = logsql.listaEstado[i];
            //   // this.DataGridSQL.Rows.Add(tabla, resultado, estado);
            //    this.dgvTablas.Rows.Add(tabla, resultado, estado);
            //}

            this.DataGridSQL.Sort(this.DataGridSQL.Columns[2], ListSortDirection.Ascending);
        }

        private void txtRutaSQL_TextChanged(object sender, EventArgs e)
        {
        //    limpiar();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormValidador fvalidador = new FormValidador();
            this.Hide();
            fvalidador.ShowDialog();
            this.Close();
        }

        private void FormValidaSQL_Load(object sender, EventArgs e)
        {            

        }

        private void DataGridSQL_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (DataGridSQL.Columns[e.ColumnIndex].Name.Equals("ESTADO"))
            {
                string estado = DataGridSQL.Rows[e.RowIndex].Cells["ESTADO"].Value.ToString();
                if (estado.Equals("OK"))
                {
                    DataGridSQL.Rows[e.RowIndex].Cells["ESTADO"].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals("NOTOK"))
                    {
                        DataGridSQL.Rows[e.RowIndex].Cells["ESTADO"].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        DataGridSQL.Rows[e.RowIndex].Cells["ESTADO"].Style.ForeColor = Color.YellowGreen;
                    }
                }
            }
        }

        private void dgvTablas_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {            
            if (dgvTablas.Columns[e.ColumnIndex].Name.Equals("ESTADO2"))
            {
                string estado = dgvTablas.Rows[e.RowIndex].Cells["ESTADO2"].Value.ToString();
                if (estado.Equals("OK"))
                {
                    dgvTablas.Rows[e.RowIndex].Cells["ESTADO2"].Style.ForeColor = Color.Green;
                }
                else
                {
                    if (estado.Equals("NOTOK"))
                    {
                        dgvTablas.Rows[e.RowIndex].Cells["ESTADO2"].Style.ForeColor = Color.Red;
                    }
                    else
                    {
                        dgvTablas.Rows[e.RowIndex].Cells["ESTADO2"].Style.ForeColor = Color.YellowGreen;
                    }
                }
            }
        }

        private void dgvTablas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //int rowIndex = e.RowIndex;
            //int columnaSeleccionada = dgvTablas.CurrentCell.ColumnIndex;

            //if (rowIndex > -1 && columnaSeleccionada == 0) //posición del boton
            //{
            //    //obtener de la fila seleccionada la columna oculta
            //    int filaSeleccionada = dgvTablas.CurrentCell.RowIndex;

            //    string identifierStage = dgvTablas.Rows[filaSeleccionada].Cells[0].Value.ToString();

            //    LogStage stage = UtilDataStage.getStageByIdentifier(identifierStage, job.listaStage);
            //    mostrarMensajeStage(stage);

            //    dgvTablas.Rows[filaSeleccionada].Cells[columnaSeleccionada].Selected = false;
            //    dgvTablas.Rows[filaSeleccionada].Cells["Nombre"].Selected = true;
            //}
        }
    }
}
