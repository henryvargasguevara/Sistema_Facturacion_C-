﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.util;

namespace ValidadorSES.form
{
    public partial class FormReportes : Form
    {
        public FormReportes()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_REPORTES;
        }

        private void btn_Reportes_Cumplimiento_Click(object sender, EventArgs e)
        {
            FormReporteCumplimiento reporteCumplimiento = new FormReporteCumplimiento();
            reporteCumplimiento.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormTasaEfectividad tasaEfectividad = new FormTasaEfectividad();
            tasaEfectividad.Show();
        }
    }
}
