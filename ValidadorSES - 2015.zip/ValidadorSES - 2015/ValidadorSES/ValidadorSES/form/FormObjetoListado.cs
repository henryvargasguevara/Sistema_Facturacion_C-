﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;

namespace ValidadorSES.form
{
    public partial class FormObjetoListado : Form
    {
        public Usuario usuarioLogueado { get; set; }

        public const string TBL_OBJ_EDITAR= "Editar";
        public const int TBL_OBJ_POS_EDITAR = 0;
        public const string TBL_OBJ_CLASIFICACION = "Objeto";
        public const string TBL_OBJ_NOMBRE = "Nombre";
        public const string TBL_OBJ_OLETYPE = "OLEType";
        public const string TBL_OBJ_TYPE = "Type";
        public const string TBL_OBJ_PREFIJO = "Prefijo";
        public const string TBL_OBJ_MNEMONICO = "Mnemónico";
        public const string TBL_OBJ_ESTADO = "Estado";
        public const string TBL_OBJ_DESCRIPCION = "Descripción";
        public const string TBL_OBJ_USUARIO_REGISTRO = "Usuario creación";
        public const string TBL_OBJ_FECHA_REGISTRO = "Fecha creación";
        public const string TBL_OBJ_USUARIO_MODIFICACION = "Usuario modificación";
        public const string TBL_OBJ_FECHA_MODIFICACION = "Fecha modificación";
        
        public FormObjetoListado()
        {
            InitializeComponent();
            mostrarTablaListadoObjeto();
        }


        private void lnkRegistroObjeto_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormObjetoRegistroModificacion formRegistro = new FormObjetoRegistroModificacion();
            formRegistro.ShowDialog();

            txtBuscar.Text = txtBuscar.Text.Trim();
            string textoBuscar = txtBuscar.Text;

            if (textoBuscar == "")
            {
                mostrarTablaListadoObjeto();
            }
        }

        private void mostrarTablaListadoObjeto() {
            List<ObjetoView> lista = new List<ObjetoView>();

            try
            {
                ObjetoDAO odao = new ObjetoDAO();
                lista = odao.getListaObjetoView();
            }catch(Exception)
            {
                MessageBox.Show("Ocurrió un error de BD");
            }

            llenarTabla(lista);
        }

        private void llenarTabla(List<ObjetoView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_CLASIFICACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_NOMBRE));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_OLETYPE));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_TYPE));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_PREFIJO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_MNEMONICO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_ESTADO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_DESCRIPCION));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_USUARIO_REGISTRO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_FECHA_REGISTRO));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_USUARIO_MODIFICACION));
            table.Columns.Add(UtilForm.getColumnString(TBL_OBJ_FECHA_MODIFICACION));
            
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    ObjetoView ov = lista[j];
                    DataRow row = table.NewRow();
                    row[TBL_OBJ_CLASIFICACION] = ov.clasificacion;
                    row[TBL_OBJ_NOMBRE] = ov.nombre;
                    row[TBL_OBJ_OLETYPE] = ov.oletype;
                    row[TBL_OBJ_TYPE] = ov.type;
                    row[TBL_OBJ_PREFIJO] = ov.prefijo;
                    row[TBL_OBJ_MNEMONICO] = ov.mnemonico;
                    row[TBL_OBJ_ESTADO] = ov.estado;
                    row[TBL_OBJ_DESCRIPCION] = ov.descripcion;
                    row[TBL_OBJ_USUARIO_REGISTRO] = ov.usuarioCreador;
                    row[TBL_OBJ_FECHA_REGISTRO] = ov.fechaCreacion;
                    row[TBL_OBJ_USUARIO_MODIFICACION] = ov.usuarioModificador;
                    row[TBL_OBJ_FECHA_MODIFICACION] = ov.fechaModificacion;

                    table.Rows.Add(row);
                }
            }

            dataGridViewObjeto.Columns.Clear();
            DataView view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dataGridViewObjeto.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = TBL_OBJ_EDITAR;
            buttonColumn.Text = ">";
            buttonColumn.Name = TBL_OBJ_EDITAR;
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dataGridViewObjeto.Visible = true;
            dataGridViewObjeto.RowHeadersVisible = false;
            dataGridViewObjeto.DataSource = view;

            dataGridViewObjeto.Columns[TBL_OBJ_EDITAR].Width = 40;
            dataGridViewObjeto.Columns[TBL_OBJ_CLASIFICACION].Width = 100;
            dataGridViewObjeto.Columns[TBL_OBJ_NOMBRE].Width = 150;
            dataGridViewObjeto.Columns[TBL_OBJ_OLETYPE].Width = 150;
            dataGridViewObjeto.Columns[TBL_OBJ_TYPE].Width = 150;
            dataGridViewObjeto.Columns[TBL_OBJ_PREFIJO].Width = 50;
            dataGridViewObjeto.Columns[TBL_OBJ_MNEMONICO].Width = 140;
            dataGridViewObjeto.Columns[TBL_OBJ_ESTADO].Width = 100;
            dataGridViewObjeto.Columns[TBL_OBJ_DESCRIPCION].Width = 600;
            dataGridViewObjeto.Columns[TBL_OBJ_USUARIO_REGISTRO].Width = 150;
            dataGridViewObjeto.Columns[TBL_OBJ_FECHA_REGISTRO].Width = 150;
            dataGridViewObjeto.Columns[TBL_OBJ_USUARIO_MODIFICACION].Width = 150;
            dataGridViewObjeto.Columns[TBL_OBJ_FECHA_MODIFICACION].Width = 150;

            dataGridViewObjeto.Columns[TBL_OBJ_EDITAR].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewObjeto.Columns[TBL_OBJ_ESTADO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewObjeto.Columns[TBL_OBJ_FECHA_REGISTRO].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewObjeto.Columns[TBL_OBJ_FECHA_MODIFICACION].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void dataGridViewObjeto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnaSeleccionada = dataGridViewObjeto.CurrentCell.ColumnIndex;
            int f = dataGridViewObjeto.CurrentCell.RowIndex;

            if (columnaSeleccionada == TBL_OBJ_POS_EDITAR) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dataGridViewObjeto.CurrentCell.RowIndex;

                string OleTypeObjeto = dataGridViewObjeto.Rows[filaSeleccionada].Cells[TBL_OBJ_OLETYPE].Value.ToString();
                string typeObjeto = dataGridViewObjeto.Rows[filaSeleccionada].Cells[TBL_OBJ_TYPE].Value.ToString();

                try
                {
                    ObjetoDAO odao = new ObjetoDAO();
                    ObjetoView obj = odao.getObjetoViewByCodigoObjeto(OleTypeObjeto + "-" + typeObjeto);

                    FormObjetoRegistroModificacion formModificacion = new FormObjetoRegistroModificacion();
                    formModificacion.usuarioLogueado = usuarioLogueado;
                    formModificacion.cargarObjetoView(obj);
                    formModificacion.ShowDialog();

                    dataGridViewObjeto.Rows[filaSeleccionada].Cells[TBL_OBJ_EDITAR].Selected = false;

                    mostrarTablaListadoObjeto();
                    txtBuscar.Text = "";
                    this.Visible = true;
                }
                catch (Exception)
                {
                    MessageBox.Show("Ocurrió un error de BD");
                }

            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            mostrarListadoBuscar();
        }

        private void mostrarListadoBuscar()
        {
            txtBuscar.Text = txtBuscar.Text.Trim();
            string textoBuscar = txtBuscar.Text;

            if (textoBuscar != "")
            {
                List<ObjetoView> lista = new List<ObjetoView>();

                try
                {
                    ObjetoDAO odao = new ObjetoDAO();
                    lista = odao.getListaObjetoViewByKeyWord(textoBuscar);
                }
                catch (Exception)
                {
                    MessageBox.Show("Ocurrió un error de BD");
                }

                llenarTabla(lista);
            }
            else
            {
                mostrarTablaListadoObjeto();
                //string mensaje = "Debe ingresar un texto a buscar";
                //MessageBox.Show(mensaje, "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
