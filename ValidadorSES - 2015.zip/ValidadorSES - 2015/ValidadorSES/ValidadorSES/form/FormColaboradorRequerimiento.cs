﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using ValidadorSES.util;
using ValidadorSES.modelo;

namespace ValidadorSES.form
{
    public partial class FormColaboradorRequerimiento : Form
    {
        public Form formPrincipal { get; set; }

        public Usuario usuariologeado { get; set; }

        public FormColaboradorRequerimiento()
        {
            InitializeComponent();

            this.Text = ConstanteTituloForm.TITULO_COLABORADOR_REQUERIMIENTO;
        }
        
        public void mostrarPantalla()
        {
            mostrarAsignacionesPorColaborador();
        }

        private void mostrarAsignacionesPorColaborador()
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();

            try
            {
                AsignacionReqDAO dao = new AsignacionReqDAO();

                lista = dao.getListaRequerimientoAsignadosPorColaborador(usuariologeado.codigo_Usuario);
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error de BD al cargar listado de Asignacion");
            }

            llenarTablaAsignacion(lista);
        }

        private void llenarTablaAsignacion(List<AsignarRequerimientoView> lista)
        {
            //declaración de tabla y columnas
            DataTable table = new DataTable();
            table.Columns.Add(UtilForm.getColumnString("CODIGO"));
            table.Columns.Add(UtilForm.getColumnString("RESPONSABLE"));
            table.Columns.Add(UtilForm.getColumnString("ID REQ"));
            table.Columns.Add(UtilForm.getColumnString("DESCRIPCION REQ"));
            table.Columns.Add(UtilForm.getColumnString("FECHA ENTREGA"));
            table.Columns.Add(UtilForm.getColumnString("CREADO EL"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO ASIGNACIÓN"));
            table.Columns.Add(UtilForm.getColumnString("ESTADO VALIDACIÓN"));
            //creacion de la tabla
            if (lista != null && lista.Count > 0)
            {
                int total = lista.Count;
                for (int j = 0; j < total; j++)
                {
                    AsignarRequerimientoView ov = lista[j];
                    DataRow row = table.NewRow();
                    row["CODIGO"] = ov.codigo;
                    row["RESPONSABLE"] = ov.fullName;
                    row["ID REQ"] = ov.codigo_requerimiento;
                    row["DESCRIPCION REQ"] = ov.descripcionRequerimiento;
                    row["FECHA ENTREGA"] = ov.fecha_asignacion;
                    row["CREADO EL"] = ov.fecha_creacion;
                    row["ESTADO ASIGNACIÓN"] = ov.estado;
                    row["ESTADO VALIDACIÓN"] = ov.estadoValidacion;

                    table.Rows.Add(row);
                }
            }

            dgColaboradorReq.Columns.Clear();
            DataView view = new DataView(table);

            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            dgColaboradorReq.Columns.Add(buttonColumn);
            buttonColumn.HeaderText = "OPCIÓN";
            buttonColumn.Text = "Validar DSX";
            buttonColumn.Name = "OPCIÓN";
            buttonColumn.DisplayIndex = 0;
            buttonColumn.UseColumnTextForButtonValue = true;

            dgColaboradorReq.Visible = true;
            dgColaboradorReq.RowHeadersVisible = false;
            dgColaboradorReq.DataSource = view;

            dgColaboradorReq.Columns["OPCIÓN"].Width = 100;
            dgColaboradorReq.Columns["CODIGO"].Width = 70;
            dgColaboradorReq.Columns["RESPONSABLE"].Width = 95;
            dgColaboradorReq.Columns["ID REQ"].Width = 70;
            dgColaboradorReq.Columns["DESCRIPCION REQ"].Width = 250;
            dgColaboradorReq.Columns["FECHA ENTREGA"].Width = 160;
            dgColaboradorReq.Columns["CREADO EL"].Width = 160;
            dgColaboradorReq.Columns["ESTADO ASIGNACIÓN"].Width = 150;
            dgColaboradorReq.Columns["ESTADO VALIDACIÓN"].Width = 150;

            dgColaboradorReq.Columns["CODIGO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgColaboradorReq.Columns["ID REQ"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgColaboradorReq.Columns["FECHA ENTREGA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgColaboradorReq.Columns["CREADO EL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }

        private void dgColaboradorReq_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnaSeleccionada = dgColaboradorReq.CurrentCell.ColumnIndex;
            int f = dgColaboradorReq.CurrentCell.RowIndex;

            if (columnaSeleccionada == 0) //posición del boton
            {
                //obtener de la fila seleccionada la columna oculta
                int filaSeleccionada = dgColaboradorReq.CurrentCell.RowIndex;

                string codigoAsignacion = dgColaboradorReq.Rows[filaSeleccionada].Cells[1].Value.ToString();

                AsignacionReqDAO ardao = new AsignacionReqDAO();
                AsignarRequerimientoView arv = ardao.getAsigReqByCodigo(codigoAsignacion);
                if (arv.estado == ConstanteMaestro.COD_EST_ASIG_FINALIZADO
                    || arv.estado == ConstanteMaestro.COD_EST_ASIG_FINALIZADO_JUSTIFICACION)//Finalizado
                {
                    MessageBox.Show("La asignación del requerimiento se encuentra Finalizada", "¡Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                this.Hide();
                FormValidador formValidador = new FormValidador();
                //cargarDetalleJob(codigoAsignacion, formValidador);
                formValidador.codigoAsignacion=codigoAsignacion;
                formValidador.usuariologeado = usuariologeado;
                formValidador.iniciarPantalla();
                formValidador.ShowDialog();
                dgColaboradorReq.Rows[filaSeleccionada].Cells[0].Selected = false;
            }
        }

        private void dgColaboradorReq_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgColaboradorReq.Columns[e.ColumnIndex].Name.Equals("ESTADO ASIGNACIÓN"))
            {
                string estado = dgColaboradorReq.Rows[e.RowIndex].Cells["ESTADO ASIGNACIÓN"].Value.ToString();
                if (estado.Equals(ConstanteMaestro.DES_EST_ASIG_FINALIZADO) || estado.Equals(ConstanteMaestro.DES_EST_ASIG_FINALIZADO_JUSTIFICACION))
                {
                    dgColaboradorReq.Rows[e.RowIndex].Cells["ESTADO ASIGNACIÓN"].Style.ForeColor = Color.Green;
                }
                else
                {
                    dgColaboradorReq.Rows[e.RowIndex].Cells["ESTADO ASIGNACIÓN"].Style.ForeColor = Color.Red;
                }
            }
        }
    }
}
