﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Principal;
using Microsoft.VisualBasic.ApplicationServices;

namespace ValidadorSES.form
{
    public partial class FormLoginGeneral : Form
    {
        SqlConnection cnn = ValidadorGNX.Clases.Conexion.ConexionSQL();
        public FormLoginGeneral()
        {
            InitializeComponent();
        } 
         
        private void btnIngresar_Click_1(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string clave = txtContraseña.Text;
            String vUserLogin = Environment.UserName;
            WindowsIdentity nombre = WindowsIdentity.GetCurrent();
            string identidad = nombre.Name;


            string sel = "SELECT logueo,contraseña,usuario,acceso_DS,acceso_GX,admi_DT,admi_GX from TB_USUARIOS where logueo = '" + usuario.ToUpper().ToString() + "' and contraseña = '" + clave.ToString() + "'";
            //                      0       1         2        3        4         5      6
            DataTable dt = new DataTable();
            SqlDataAdapter da;

            da = new SqlDataAdapter(sel, cnn);
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                if ((dt.Rows[0][6].ToString().ToUpper() == "1" && dt.Rows[0][5].ToString().ToUpper() == "1") || (dt.Rows[0][6].ToString().ToUpper() == "1"))
                {
                    //ValidadorGNX.Formularios.Form1 Form1 = new ValidadorSES.ValidadorGNX.Formularios.Form1();
                    //Form1.referencia = usuario;
                    //this.Hide();
                    //Form1.ShowDialog();
                    //this.Close();
                    DataTable dtFecha = new DataTable();
                    sel = "dbo.SP_Recuperar_FechaVig";
                    da = new SqlDataAdapter(sel, cnn);
                    da.Fill(dtFecha);
                    if (dtFecha.Rows.Count != 0)
                    {
                        DateTime fecha = Convert.ToDateTime(dtFecha.Rows[0][0].ToString());
                        fecha = Convert.ToDateTime(fecha.ToString("d"));
                        DateTime fechaActual = Convert.ToDateTime(DateTime.Now.ToString("d"));
                        int x = DateTime.Compare(fechaActual, fecha);

                        FormEscogerValidacion fescoger = new FormEscogerValidacion();
                        fescoger.valor = x;
                        fescoger.usuario = usuario;
                        fescoger.admiGX = dt.Rows[0][6].ToString();
                        fescoger.admiDS = dt.Rows[0][5].ToString();
                        fescoger.fecha = fecha;

                        this.Hide();
                        fescoger.ShowDialog();
                        this.Close();
                    }
                }
                else if (dt.Rows[0][3].ToString().ToUpper() == "1" && dt.Rows[0][4].ToString().ToUpper() == "1")
                {
                    FormEscogerValidacion fescoger = new FormEscogerValidacion();
                    this.Hide();
                    fescoger.ShowDialog();
                    this.Close();
                }
                else if (dt.Rows[0][5].ToString().ToUpper() == "1" && dt.Rows[0][6].ToString().ToUpper() == "1")
                {
                    FormEscogerValidacion fescoger = new FormEscogerValidacion();
                    this.Hide();
                    fescoger.ShowDialog();
                    this.Close();
                }
                else if (dt.Rows[0][3].ToString().ToUpper() == "1")
                {
                    FormValidador fvalidador = new FormValidador();
                    this.Hide();
                    fvalidador.ShowDialog();
                    this.Close();
                }
                else if (dt.Rows[0][4].ToString().ToUpper() == "1")
                {
                    ValidadorGNX.Formularios.Form1 Form1 = new ValidadorSES.ValidadorGNX.Formularios.Form1();
                    Form1.referencia = usuario;
                    this.Hide();
                    Form1.ShowDialog();
                    this.Close();
                }
                else if (dt.Rows[0][5].ToString().ToUpper() == "1")
                {
                    FormPrincipal fPrincipal = new FormPrincipal();
                    this.Hide();
                    fPrincipal.ShowDialog();
                    this.Close();
                }
                else
                {
                    FormEscogerValidacion fescoger = new FormEscogerValidacion();
                    this.Hide();
                    fescoger.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("USUARIO O CONTRASEÑA INCORRECTO");
            }
        }
    }
}
