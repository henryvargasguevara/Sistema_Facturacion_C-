﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ValidadorSES.modelo;
using System.Data.SqlClient;
using System.Data;

namespace ValidadorSES.dao
{
    class MaestroDAO
    {

        public List<DetalleMaestro> getListaCargoAnonimo()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=2 where valor_key<>1 and valor_key<>4";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<DetalleMaestro> getListaCargo()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=2";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<DetalleMaestro> getListaCargoNuevo()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=2 where d.valor_key<>1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<DetalleMaestro> getListaTipoValidacion()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.codigo_Maestro=m.codigo_Maestro and d.codigo_Maestro=13";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<DetalleMaestro> getListaEstadoUsuario()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=3";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<DetalleMaestro> getListaClientes()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=10";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }


        public List<DetalleMaestro> getListaEstadoRequerimiento()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro= '5'";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<DetalleMaestro> getListaPrioridad()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=11";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<DetalleMaestro> getListaEstadoAsignacion()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=12";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }


        public List<DetalleMaestro> getListaCargoAlone()  //JT trae los tipo de carga
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select nombre_Detalle_Maestro, valor_key from dbo.DETALLEMAESTRO where codigo_Maestro = 15";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }




        public List<DetalleMaestro> getListaPreguntaSecreta()
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                string sql = "select d.valor_key,d.nombre_Detalle_Maestro from dbo.DETALLEMAESTRO  d inner join dbo.MAESTRO m on d.valor_key=m.codigo_Maestro and d.codigo_Maestro=9";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        /*Agregaciones por parte de alan*/
        public List<DetalleMaestro> getListaTipoCargaJob()
        {
            return getListaDetalleMaestro(15);
        }

        public List<DetalleMaestro> getListaClasificacion()
        {
            return getListaDetalleMaestro(1);
        }

        public List<DetalleMaestro> getListaEstadoObjeto()
        {
            return getListaDetalleMaestro(4);
        }

        public List<DetalleMaestro> getListaEstadoRegla()
        {
            return getListaDetalleMaestro(6);
        }

        public List<DetalleMaestro> getListaEstadoValidacionFull()
        {
            return getListaDetalleMaestro(7);
        }
        public List<DetalleMaestro> getListaEstadoValidacionExpress()
        {
            return getListaDetalleMaestro(8);
        }
        private List<DetalleMaestro> getListaDetalleMaestro(int codMaestro)
        {
            List<DetalleMaestro> lista = new List<DetalleMaestro>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT";
                sql += " [valor_key]";
                sql += ",[nombre_Detalle_Maestro]";
                sql += " FROM dbo.DETALLEMAESTRO";
                sql += " WHERE [codigo_Maestro] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = codMaestro;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DetalleMaestro ov = new DetalleMaestro();
                    ov.valor_key = reader.GetString(0);
                    ov.nombre = reader.GetString(1);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista cargo " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }


        /*Fin Agregaciones por parte de alan*/
    }
}
