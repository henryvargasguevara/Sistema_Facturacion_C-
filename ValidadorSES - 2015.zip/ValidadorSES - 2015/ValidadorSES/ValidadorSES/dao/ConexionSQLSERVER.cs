﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using ValidadorSES.service;
using ValidadorSES.modelo;
using ValidadorSES.util;

namespace ValidadorSES.dao
{
    class ConexionSQLSERVER
    {

        public static SqlConnection getSqlConnection()
        {
            SqlConnection conn = new SqlConnection();

            //conn.ConnectionString = "integrated security=SSPI; data source = 10.237.98.95\\SQL2008R2,50205; initial Catalog=BDVALIDADOR_DEV;User Id=sa;Password=Agencia350";

            if (ConstanteSistema.TIPO_CONEXION == ConstanteSistema.CONEXION_CONSTANTE)
            {
                //conn.ConnectionString = "data source = 10.237.98.95\\SQL2008R2,50205; initial Catalog=BDVALIDADOR_DEV;User Id=sa;Password=Agencia350";
                //conn.ConnectionString = "data source = F-CHAVIN-WD\\SBP; initial Catalog=VALIDADORES-DESARROLLO;User Id=valuserses;Password=VALhG9sRdO";
                conn.ConnectionString = "data source = F-CHAVIN-WD\\SBP; initial Catalog=VALIDADORES-DESARROLLO;Integrated Security=SSPI";
                //conn.ConnectionString = "data source = S-CHAVIN-WDT\\SQL2016DESA; initial Catalog=VALIDADORES-DESARROLLO;Integrated Security=SSPI";
            }

            if (ConstanteSistema.TIPO_CONEXION == ConstanteSistema.CONEXION_PROPERTIES)
            {
                ConexionService cs = new ConexionService();
                Conexion cnx = cs.getConexion();

                conn.ConnectionString = "data source = " + cnx.datasource + "; initial Catalog=" + cnx.database + ";User Id=" + cnx.user + ";Password=" + cnx.password;
            }

            return conn;
        }

    }
}
