﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.dao
{
    public class ValidacionDAO
    {
        public int insertarDSX(LogDSX dsx)
        {
            int codigoDSX = 0;

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSBERT INTO [dbo].[ARCHIVODSX]";
                sql += "([descripcion_dsx]";
                sql += ",[num_job_seq]";
                sql += ",[num_job_paralelo]";
                sql += ",[num_job_server]";
                sql += ",[num_rutina]";//5
                sql += ",[num_parameter_set]";
                sql += ",[fecha_Exportacion]";
                sql += ",[fecha_validacion]";
                sql += ",[codigo_usuario_requerimiento]";
                sql += ",[fecha_creacion]";//10
                sql += ",[fecha_modificacion]";
                sql += ",[usuario_creador]";
                sql += ",[usuario_modificador]";
                sql += ",[estado_dsx]";
                sql += ",[nota])";
                sql += " OUTPUT INSERTED.codigo_dsx";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ",@param13";
                sql += ",@param14";
                sql += ",@param15";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(dsx.descripcion);
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(dsx.numJobSequence);
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(dsx.numJobParallel);
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(dsx.numJobServer);
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(dsx.numRoutine);
                cmd.Parameters.Add("@param6",  SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(dsx.numParameterSet);
                cmd.Parameters.Add("@param7",  SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(dsx.fechaDSXExportacion);
                cmd.Parameters.Add("@param8",  SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(dsx.fechaDSXValidacion);
                cmd.Parameters.Add("@param9",  SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(dsx.codigoUsuarioRequerimiento);
                cmd.Parameters.Add("@param10", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(dsx.fechaCreacion);
                cmd.Parameters.Add("@param11", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(null);
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(dsx.usuarioCreador);
                cmd.Parameters.Add("@param13", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(null);
                cmd.Parameters.Add("@param14", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(dsx.codigoEstado);
                cmd.Parameters.Add("@param15", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(dsx.nota);

                //cmd.ExecuteNonQuery();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    codigoDSX = UtilSQL.getIntOrNull(reader, 0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return codigoDSX;
        }

        public void actualizarDSXNota(LogDSX dsx)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[ARCHIVODSX] SET ";
                sql += " [nota] = @param2";
                sql += " WHERE [codigo_dsx] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(dsx.codigoDSX);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(dsx.nota);
                
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void insertarJob(LogJob job)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[JOB]";
                sql += "([codigo_Job]";
                sql += ",[nombre_job]";
                sql += ",[ruta_job]";
                sql += ",[num_stage_observado]";
                sql += ",[num_stage_correcto]";
                sql += ",[num_stage_incorrecto]";//6
                sql += ",[estado]";
                sql += ",[cod_dsx]";
                sql += ",[mensaje]";
                sql += ",[codigo_objeto]";//9
                sql += ",[fecha_creacion]";
                sql += ",[usuario_creador])";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(job.codigoJob);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(job.identifierJob);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(job.category);
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(job.numStageObservado);
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(job.numStageCorrecto);
                cmd.Parameters.Add("@param6", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(job.numStageIncorrecto);
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(job.estadoJobCodigo);
                cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(job.dsx.codigoDSX);
                cmd.Parameters.Add("@param9", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(job.mensaje);
                cmd.Parameters.Add("@param10", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(job.objeto.codigoObjeto);
                cmd.Parameters.Add("@param11", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(job.fechaCreacion);
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(job.usuarioCreador);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void insertarStage(LogStage stage)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[STAGE]";
                sql += "([name_stage]";
                sql += ",[identifier_stage]";
                sql += ",[estado]";
                sql += ",[mensaje]";
                sql += ",[codigo_job]";
                sql += ",[codigo_objeto]";//5
                sql += ",[fecha_creacion]";
                sql += ",[usuario_creador])";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(stage.nameStage);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(stage.identifierStage);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(stage.estadoStageCodigo);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(stage.mensaje);
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(stage.job.codigoJob);
                cmd.Parameters.Add("@param6", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(stage.objeto.codigoObjeto);
                cmd.Parameters.Add("@param7", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(stage.fechaCreacion);
                cmd.Parameters.Add("@param8", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(stage.usuarioCreador);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void insertaResultadoValidacion(LogObjetoValidacion resVal)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[RESULTADO_VALIDACION]";
                sql += "([mensaje]";
                sql += ",[estado]";
                sql += ",[codigo_job]";
                sql += ",[codigo_objeto_regla])";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(resVal.mensaje);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(resVal.estado);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(resVal.job.codigoJob);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(resVal.regla.codigoObjetoRegla);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void insertarRoutine(LogRoutine routine)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[RUTINA]";
                sql += "([codigo_rutina]";
                sql += ",[nombre_rutina]";
                sql += ",[ruta_rutina]";
                sql += ",[num_argumento_observado]";
                sql += ",[num_argumento_correcto]";
                sql += ",[num_argumento_incorrecto]";
                sql += ",[estado]";//7
                sql += ",[mensaje]";
                sql += ",[cod_dsx]";
                sql += ",[codigo_objeto]";
                sql += ",[fecha_creacion]";//11
                sql += ",[usuario_creador])";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(routine.codigoRoutine);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(routine.identifier);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(routine.category);
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(routine.numArgObservado);
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(routine.numArgCorrecto);
                cmd.Parameters.Add("@param6", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(routine.numArgIncorrecto);
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(routine.estadoRutinaCodigo);
                cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(routine.mensaje);
                cmd.Parameters.Add("@param9", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(routine.dsx.codigoDSX);
                cmd.Parameters.Add("@param10", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(routine.objeto.codigoObjeto);
                cmd.Parameters.Add("@param11", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(routine.fechaCreacion);
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(routine.usuarioCreador);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void insertarArgument(LogArgument argument)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[ARGUMENTO]";
                sql += "([nombre_argumento]";
                sql += ",[descripcion]";
                sql += ",[estado]";
                sql += ",[mensaje]";
                sql += ",[codigo_rutina]";
                sql += ",[codigo_objeto]";
                sql += ",[fecha_creacion]";//7
                sql += ",[usuario_creador])";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(argument.nameArgRoutine);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(argument.descArgRoutine);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(argument.estadoArgumentCodigo);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(argument.mensaje);
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(argument.routine.codigoRoutine);
                cmd.Parameters.Add("@param6", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(argument.objeto.codigoObjeto);
                cmd.Parameters.Add("@param7", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(argument.fechaCreacion);
                cmd.Parameters.Add("@param8", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(argument.usuarioCreador);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }


        public void insertarParameterSet(LogParameterSet parameter)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[PARAMETER_SET]";
                sql += "([codigo_parameter]";
                sql += ",[nombre_parameter]";
                sql += ",[ruta_parameter]";
                sql += ",[num_param_observado]";
                sql += ",[num_param_correcto]";
                sql += ",[num_param_incorrecto]";
                sql += ",[estado]";//7
                sql += ",[mensaje]";
                sql += ",[cod_dsx]";
                sql += ",[codigo_objeto]";
                sql += ",[fecha_creacion]";//11
                sql += ",[usuario_creador])";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(parameter.codigoParameter);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(parameter.identifierParameterSet);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(parameter.category);
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(parameter.numParamObservado);
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(parameter.numParamCorrecto);
                cmd.Parameters.Add("@param6", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(parameter.numParamIncorrecto);
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(parameter.estadoParameterCodigo);
                cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(parameter.mensaje);
                cmd.Parameters.Add("@param9", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(parameter.dsx.codigoDSX);
                cmd.Parameters.Add("@param10", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(parameter.objeto.codigoObjeto);
                cmd.Parameters.Add("@param11", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(parameter.fechaCreacion);
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(parameter.usuarioCreador);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }


        public void insertarParam(LogParam param)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[PARAM]";
                sql += "([nombre_param]";
                sql += ",[descripcion]";
                sql += ",[estado]";
                sql += ",[mensaje]";
                sql += ",[codigo_parameter]";
                sql += ",[codigo_objeto]";
                sql += ",[fecha_creacion]";//7
                sql += ",[usuario_creador])";
                sql += " VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(param.name);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(param.textoAyuda);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(param.estadoParamCodigo);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(param.mensaje);
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(param.parameter.codigoParameter);
                cmd.Parameters.Add("@param6", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(param.objeto.codigoObjeto);
                cmd.Parameters.Add("@param7", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(param.fechaCreacion);
                cmd.Parameters.Add("@param8", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(param.usuarioCreador);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<LogDSX> getListaDSXByCodAsigReq(string codAsigReq)
        {
            List<LogDSX> lista = new List<LogDSX>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT";
                sql += "  [codigo_dsx]"; //0
                sql += " ,[descripcion_dsx]";
                sql += " ,[num_job_seq]";
                sql += " ,[num_job_paralelo]";
                sql += " ,[num_job_server]";
                sql += " ,[num_rutina]";//5
                sql += " ,[num_parameter_set]";
                sql += " ,[fecha_Exportacion]";
                sql += " ,[fecha_validacion]";
                sql += " ,[fecha_ultima_modificacion]";
                sql += " ,det.nombre_Detalle_Maestro";
                sql += " ,[NOTA]";
                sql += " FROM [dbo].[ARCHIVODSX] dsx";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det";
                sql += " ON det.codigo_Maestro = 16 AND dsx.estado_dsx = det.valor_key";
                sql += " WHERE codigo_usuario_requerimiento = @param";
                sql += " ORDER BY fecha_validacion desc";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = codAsigReq;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LogDSX dsx = new LogDSX();
                    dsx.codigoDSX = UtilSQL.getIntOrNull(reader, 0);
                    dsx.descripcion = UtilSQL.getStringOrNull(reader, 1);
                    dsx.numJobSequence = UtilSQL.getIntOrNull(reader, 2);
                    dsx.numJobParallel = UtilSQL.getIntOrNull(reader, 3);
                    dsx.numJobServer = UtilSQL.getIntOrNull(reader, 4);
                    dsx.numRoutine = UtilSQL.getIntOrNull(reader, 5);
                    dsx.numParameterSet = UtilSQL.getIntOrNull(reader, 6);
                    dsx.cadenaFechaExportacion = UtilSQL.getStringDateTimeOrNull(reader, 7);
                    dsx.cadenaFechaValidacion = UtilSQL.getStringDateTimeOrNull(reader, 8);
                    dsx.cadenaFechaUltimaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 9);
                    dsx.descripcionEstado = UtilSQL.getStringOrNull(reader, 10);
                    dsx.nota = UtilSQL.getStringOrNull(reader, 11);

                    lista.Add(dsx);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: lista DSX " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public LogDSX getDSXByCodigo(int codigoDSX) 
        {
            LogDSX dsx = new LogDSX();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();

                //Listar todos los Jobs
                string sqlJob = "SELECT";
                sqlJob += "  [codigo_Job]";
                sqlJob += " ,[nombre_job]";
                sqlJob += " ,[ruta_job]";
                sqlJob += " ,[num_stage_observado]";
                sqlJob += " ,[num_stage_correcto]";
                sqlJob += " ,[num_stage_incorrecto]";
                sqlJob += " ,det.nombre_Detalle_Maestro";
                sqlJob += " ,obj.nombre";
                sqlJob += " FROM [dbo].[JOB] job";
                sqlJob += " INNER JOIN [dbo].[OBJETO] obj";
                sqlJob += " on obj.codigo_objeto = job.codigo_objeto";
                sqlJob += " INNER JOIN [dbo].[DETALLEMAESTRO] det";
                sqlJob += " ON det.codigo_Maestro = 16 AND job.estado = det.valor_key";
                sqlJob += " WHERE cod_dsx = @param";


                SqlCommand cmd = new SqlCommand(sqlJob, conexion);
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = codigoDSX;
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LogJob job = new LogJob();
                    job.codigoJob = UtilSQL.getStringOrNull(reader, 0);
                    job.identifierJob = UtilSQL.getStringOrNull(reader, 1);
                    job.category = UtilSQL.getStringOrNull(reader, 2);
                    job.numStageObservado = UtilSQL.getIntOrNull(reader, 3);
                    job.numStageCorrecto = UtilSQL.getIntOrNull(reader, 4);
                    job.numStageIncorrecto = UtilSQL.getIntOrNull(reader, 5);
                    job.estadoJobDescripcion = UtilSQL.getStringOrNull(reader, 6);
                    job.objeto = new Objeto();
                    job.objeto.nombre = UtilSQL.getStringOrNull(reader, 7);

                    dsx.listaJob.Add(job);
                }

                reader.Close();

                //Listar todos los stages por Job
                for (int j = 0; j<dsx.listaJob.Count; j++)
                {
                    LogJob job = dsx.listaJob[j];
                    string sqlStage = "SELECT";
                    sqlStage += "  [name_stage]";
                    sqlStage += " ,[identifier_stage]";
                    sqlStage += " ,det.nombre_Detalle_Maestro";
                    sqlStage += " ,[mensaje]";
                    sqlStage += " ,stg.estado";
                    sqlStage += " ,obj.nombre";
                    sqlStage += " FROM [dbo].[STAGE] stg";
                    sqlStage += " INNER JOIN [dbo].[OBJETO] obj";
                    sqlStage += " on obj.codigo_objeto = stg.codigo_objeto";
                    sqlStage += " INNER JOIN [dbo].[DETALLEMAESTRO] det";
                    sqlStage += " ON det.codigo_Maestro = 16 AND stg.estado = det.valor_key";
                    sqlStage += " WHERE codigo_job = @param";

                    cmd = new SqlCommand(sqlStage, conexion);
                    cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = job.codigoJob;
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        LogStage stage = new LogStage();
                        stage.nameStage = UtilSQL.getStringOrNull(reader, 0);
                        stage.identifierStage = UtilSQL.getStringOrNull(reader, 1);
                        stage.estadoStageDescripcion = UtilSQL.getStringOrNull(reader, 2);
                        stage.mensaje = UtilSQL.getStringOrNull(reader, 3);
                        stage.estadoStageCodigo = UtilSQL.getStringOrNull(reader, 4);
                        
                        stage.objeto = new Objeto();
                        stage.objeto.nombre = UtilSQL.getStringOrNull(reader, 5);

                        job.listaStage.Add(stage);
                    }

                    reader.Close();
                }

                //Listar todos las validaciones
                for (int j = 0; j < dsx.listaJob.Count; j++)
                {
                    LogJob job = dsx.listaJob[j];
                    string sqlResVal = "SELECT";
                    sqlResVal += "  reg.nombre";
                    sqlResVal += " ,res.[estado]";
                    sqlResVal += " ,res.[mensaje]";
                    sqlResVal += " FROM [dbo].[RESULTADO_VALIDACION] res";
                    sqlResVal += " INNER JOIN [dbo].[OBJETO_REGLA] objReg";
                    sqlResVal += " ON res.[codigo_objeto_regla] = objReg.codigo_objeto_regla";
                    sqlResVal += " INNER JOIN [dbo].[REGLA] reg";
                    sqlResVal += " ON objReg.codigo_regla = reg.codigo_regla";
                    sqlResVal += " WHERE res.codigo_job = @param";

                    cmd = new SqlCommand(sqlResVal, conexion);
                    cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = job.codigoJob;
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        LogObjetoValidacion resVal = new LogObjetoValidacion();
                        resVal.regla = new ObjetoReglaView();
                        resVal.regla.nombreRegla = UtilSQL.getStringOrNull(reader, 0);
                        resVal.estado = UtilSQL.getStringOrNull(reader, 1);
                        resVal.mensaje = UtilSQL.getStringOrNull(reader, 2);

                        job.listaValidacion.Add(resVal);
                    }

                    reader.Close();
                }

                //Listar todos los Routine
                string sqlRoutine = "SELECT [codigo_rutina]";
                sqlRoutine += " ,[nombre_rutina]";
                sqlRoutine += " ,[ruta_rutina]";
                sqlRoutine += " ,[num_argumento_observado]";
                sqlRoutine += " ,[num_argumento_correcto]";
                sqlRoutine += " ,[num_argumento_incorrecto]";
                sqlRoutine += " ,det.nombre_Detalle_Maestro";
                sqlRoutine += " ,rou.[mensaje]";
                sqlRoutine += " ,obj.nombre";
                sqlRoutine += " FROM [dbo].[RUTINA] rou";
                sqlRoutine += " INNER JOIN [dbo].[OBJETO] obj";
                sqlRoutine += " on obj.codigo_objeto = rou.codigo_objeto";
                sqlRoutine += " INNER JOIN [dbo].[DETALLEMAESTRO] det";
                sqlRoutine += " ON det.codigo_Maestro = 16 AND rou.estado = det.valor_key";
                sqlRoutine += " WHERE cod_dsx = @param";

                cmd = new SqlCommand(sqlRoutine, conexion);
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = codigoDSX;
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LogRoutine routine = new LogRoutine();
                    routine.codigoRoutine = UtilSQL.getStringOrNull(reader, 0);
                    routine.identifier = UtilSQL.getStringOrNull(reader, 1);
                    routine.category = UtilSQL.getStringOrNull(reader, 2);
                    routine.numArgObservado = UtilSQL.getIntOrNull(reader, 3);
                    routine.numArgCorrecto = UtilSQL.getIntOrNull(reader, 4);
                    routine.numArgIncorrecto = UtilSQL.getIntOrNull(reader, 5);
                    routine.estadoRutinaDescripcion = UtilSQL.getStringOrNull(reader, 6);
                    routine.mensaje = UtilSQL.getStringOrNull(reader, 7);
                    routine.objeto = new Objeto();
                    routine.objeto.nombre = UtilSQL.getStringOrNull(reader, 8);

                    dsx.listaRoutine.Add(routine);
                }

                reader.Close();

                //Listar todos los Argument por Routine
                for (int j = 0; j < dsx.listaRoutine.Count; j++)
                {
                    LogRoutine routine = dsx.listaRoutine[j];
                    string sqlArgument = "SELECT";
                    sqlArgument += "  [nombre_argumento]";
                    sqlArgument += " ,arg.[descripcion]";
                    sqlArgument += " ,det.nombre_Detalle_Maestro";
                    sqlArgument += " ,[mensaje]";
                    sqlArgument += " ,obj.nombre";
                    sqlArgument += " FROM [dbo].[ARGUMENTO] arg";
                    sqlArgument += " INNER JOIN [dbo].[OBJETO] obj";
                    sqlArgument += " on obj.codigo_objeto = arg.codigo_objeto";
                    sqlArgument += " INNER JOIN [dbo].[DETALLEMAESTRO] det";
                    sqlArgument += " ON det.codigo_Maestro = 16 AND arg.estado = det.valor_key";
                    sqlArgument += " WHERE codigo_rutina = @param";

                    cmd = new SqlCommand(sqlArgument, conexion);
                    cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = routine.codigoRoutine;
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        LogArgument argument = new LogArgument();
                        argument.nameArgRoutine = UtilSQL.getStringOrNull(reader, 0);
                        argument.descArgRoutine = UtilSQL.getStringOrNull(reader, 1);
                        argument.estadoArgumentDescripcion = UtilSQL.getStringOrNull(reader, 2);
                        argument.mensaje = UtilSQL.getStringOrNull(reader, 3);
                        argument.objeto = new Objeto();
                        argument.objeto.nombre = UtilSQL.getStringOrNull(reader, 4);

                        routine.listaArgumentoRoutine.Add(argument);
                    }

                    reader.Close();
                }

                //Listar todos los ParameterSet
                string sqlParameterSet = "SELECT [codigo_parameter]";
                sqlParameterSet += " ,[nombre_parameter]";
                sqlParameterSet += " ,[ruta_parameter]";
                sqlParameterSet += " ,[num_param_observado]";
                sqlParameterSet += " ,[num_param_correcto]";
                sqlParameterSet += " ,[num_param_incorrecto]";
                sqlParameterSet += " ,det.nombre_Detalle_Maestro";
                sqlParameterSet += " ,[mensaje]";
                sqlParameterSet += " ,obj.nombre";
                sqlParameterSet += " FROM [dbo].[PARAMETER_SET] ps";
                sqlParameterSet += " INNER JOIN [dbo].[OBJETO] obj";
                sqlParameterSet += " on obj.codigo_objeto = ps.codigo_objeto";
                sqlParameterSet += " INNER JOIN [dbo].[DETALLEMAESTRO] det";
                sqlParameterSet += " ON det.codigo_Maestro = 16 AND ps.estado = det.valor_key";
                sqlParameterSet += " WHERE cod_dsx = @param";

                cmd = new SqlCommand(sqlParameterSet, conexion);
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = codigoDSX;
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LogParameterSet parameterSet = new LogParameterSet();
                    parameterSet.codigoParameter = UtilSQL.getStringOrNull(reader, 0);
                    parameterSet.identifierParameterSet = UtilSQL.getStringOrNull(reader, 1);
                    parameterSet.category = UtilSQL.getStringOrNull(reader, 2);
                    parameterSet.numParamObservado = UtilSQL.getIntOrNull(reader, 3);
                    parameterSet.numParamCorrecto = UtilSQL.getIntOrNull(reader, 4);
                    parameterSet.numParamIncorrecto = UtilSQL.getIntOrNull(reader, 5);
                    parameterSet.estadoParameterDescripcion = UtilSQL.getStringOrNull(reader, 6);
                    parameterSet.mensaje = UtilSQL.getStringOrNull(reader, 7);
                    parameterSet.objeto = new Objeto();
                    parameterSet.objeto.nombre = UtilSQL.getStringOrNull(reader, 8);

                    dsx.listaParameterSet.Add(parameterSet);
                }

                reader.Close();


                //Listar todos los Param por ParameterSet
                for (int j = 0; j < dsx.listaParameterSet.Count; j++)
                {
                    LogParameterSet parameterSet = dsx.listaParameterSet[j];
                    string sqlParam = "SELECT";
                    sqlParam += "  [nombre_param]";
                    sqlParam += " ,p.[descripcion]";
                    sqlParam += " ,det.nombre_Detalle_Maestro";
                    sqlParam += " ,[mensaje]";
                    sqlParam += " ,obj.nombre";
                    sqlParam += " FROM [dbo].[PARAM] p";
                    sqlParam += " INNER JOIN [dbo].[OBJETO] obj";
                    sqlParam += " on obj.codigo_objeto = p.codigo_objeto";
                    sqlParam += " INNER JOIN [dbo].[DETALLEMAESTRO] det";
                    sqlParam += " ON det.codigo_Maestro = 16 AND p.estado = det.valor_key";
                    sqlParam += " WHERE codigo_parameter = @param";

                    cmd = new SqlCommand(sqlParam, conexion);
                    cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = parameterSet.codigoParameter;
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        LogParam param = new LogParam();
                        param.name = UtilSQL.getStringOrNull(reader, 0);
                        param.textoAyuda = UtilSQL.getStringOrNull(reader, 1);
                        param.estadoParamDescripcion = UtilSQL.getStringOrNull(reader, 2);
                        param.mensaje = UtilSQL.getStringOrNull(reader, 3);
                        param.objeto = new Objeto();
                        param.objeto.nombre = UtilSQL.getStringOrNull(reader, 4);

                        parameterSet.listaParam.Add(param);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: getDSX " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return dsx;
        }

    }
}
