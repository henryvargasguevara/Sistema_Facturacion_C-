﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using ValidadorSES.modelo.view;
using ValidadorSES.dao;
using System.Data.SqlClient;
using ValidadorSES.util;
using System.Data;
using ValidadorSES.modelo;

namespace ValidadorSES.dao
{
    class AsignacionReqDAO
    {


        public List<RequerimientoView> getListaRequerimientoView(int cod)
        {
            List<RequerimientoView> lista = new List<RequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select r.codigo,";
                sql += " r.descripcion,";
                sql += " r.fecha_inicio,";
                sql += " r.fecha_fin,";
                sql += " d2.nombre_Detalle_Maestro,";
                sql += " u.nombres_Usuario+' '+u.apellidos_usuario,";
                sql += " d3.nombre_Detalle_Maestro,";
                sql += " d.nombre_Detalle_Maestro";
                sql += " from dbo.REQUERIMIENTO r";
                sql += " inner join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key = r.estado and d2.codigo_Maestro=5";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario = r.usuario_creador";
                sql += " left join dbo.DETALLEMAESTRO d3";
                sql += " on d3.valor_key = r.prioridad and d3.codigo_Maestro = 11";
                sql += " left join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key = r.tipoValidacion and d.codigo_Maestro = 13";
                sql += " where r.liderResponsable = @param";
                sql += " ORDER BY r.fecha_creacion desc;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(cod);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    RequerimientoView ov = new RequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.descripcion = UtilSQL.getStringOrNull(reader, 1);
                    ov.fecha_inicio = UtilSQL.getStringDateTimeOrNull(reader, 2);
                    ov.fecha_fin = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.estado = UtilSQL.getStringOrNull(reader, 4);
                    ov.usuario_creador = UtilSQL.getStringOrNull(reader, 5);
                    ov.prioridad = UtilSQL.getStringOrNull(reader, 6);
                    ov.tipoValidacion = UtilSQL.getStringOrNull(reader, 7);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public List<AsignarRequerimientoView> getListaRequerimientoAsignadosView(int cod)
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT a.[codigo_usuario_requerimiento]";
                sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                sql += " ,a.[codigo_requerimiento]";
                sql += " ,a.[fecha_entrega_trabajo]";
                sql += " ,a.[fecha_creacion]";
                sql += " ,d.nombre_Detalle_Maestro";
                sql += " ,d2.nombre_Detalle_Maestro";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO] a";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario= a.codigo_colaborador_Asignado";
                sql += " inner join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key= a.estado and d.codigo_Maestro=12";
                sql += " inner join dbo.REQUERIMIENTO r";
                sql += " on r.codigo= a.codigo_requerimiento";
                sql += " inner join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key = a.estadoValidacion and d2.codigo_Maestro=14";
                sql += " where r.liderResponsable = @param";
                sql += " order by a.[fecha_creacion] desc;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(cod);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    AsignarRequerimientoView ov = new AsignarRequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.fullName = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.fecha_asignacion = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.fecha_creacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.estado = UtilSQL.getStringOrNull(reader, 5);
                    ov.estadoValidacion = UtilSQL.getStringOrNull(reader, 6);
                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public void insertarAsignacionRequerimiento(AsignarRequerimiento requered)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[ASIGNARREQUERIMIENTO]";
                sql += "([codigo_usuario_requerimiento]";//1
                sql += ",[codigo_colaborador_Asignado]";
                sql += ",[codigo_requerimiento]";
                sql += ",[fecha_entrega_trabajo]";
                sql += ",[fecha_creacion]";
                sql += ",[estado])";//6
                //sql += ",[prioridad]";
                //sql += ",[tipoValidacion])";//8
                sql += "VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                //sql += ",@param7";
                //sql += ",@param8";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = requered.codigo;
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = requered.codigo_usuario;
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = requered.codigo_requerimiento;
                cmd.Parameters.Add("@param4", SqlDbType.DateTime).Value = requered.fecha_asignacion;
                cmd.Parameters.Add("@param5", SqlDbType.DateTime).Value = requered.fecha_creacion;
                cmd.Parameters.Add("@param6", SqlDbType.VarChar).Value = "1";
                //cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = requered.prioridad;
                //cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = requered.TipoValidacion;


                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<AsignarRequerimientoView> getListaRequerimientoAsignadosPorColaborador(int cod)
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT a.[codigo_usuario_requerimiento]";
                sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                sql += " ,a.[codigo_requerimiento]";
                sql += " ,r.descripcion";
                sql += " ,a.[fecha_entrega_trabajo]";
                sql += " ,a.[fecha_creacion]";
                sql += " ,d.nombre_Detalle_Maestro as ESTADO_ASIGNACION";
                sql += " ,d2.nombre_Detalle_Maestro as ESTADO_VALIDACION";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO] a";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario= a.codigo_colaborador_Asignado";
                sql += " inner join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key= a.estado and d.codigo_Maestro=12";
                sql += " inner join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key= a.estadoValidacion and d2.codigo_Maestro=14";
                sql += " inner join dbo.REQUERIMIENTO r";
                sql += " on r.codigo= a.codigo_requerimiento";
                sql += " where a.codigo_colaborador_Asignado = @param";
                sql += " order by fecha_entrega_trabajo desc";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(cod);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    AsignarRequerimientoView ov = new AsignarRequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.fullName = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcionRequerimiento = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_asignacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_creacion = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado = UtilSQL.getStringOrNull(reader, 6);
                    ov.estadoValidacion = UtilSQL.getStringOrNull(reader, 7);
                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public List<AsignarRequerimientoView> getListaRequerimientoAsignadosPorRequerimiento(string codigoReq)
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT a.[codigo_usuario_requerimiento]";
                sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                sql += " ,a.[codigo_requerimiento]";
                sql += " ,r.descripcion";
                sql += " ,a.[fecha_entrega_trabajo]";
                sql += " ,a.[fecha_creacion]";
                sql += " ,d.nombre_Detalle_Maestro as ESTADO_ASIGNACION";
                sql += " ,d2.nombre_Detalle_Maestro as ESTADO_EJECUCION";
                sql += " ,a.estado";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO] a";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario= a.codigo_colaborador_Asignado";
                sql += " inner join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key= a.estado and d.codigo_Maestro=12";
                sql += " inner join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key = a.estadoValidacion and d2.codigo_Maestro=14";
                sql += " inner join dbo.REQUERIMIENTO r";
                sql += " on r.codigo= a.codigo_requerimiento";
                sql += " where r.codigo = @param;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codigoReq);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    AsignarRequerimientoView ov = new AsignarRequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.fullName = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.descripcionRequerimiento = UtilSQL.getStringOrNull(reader, 3);
                    ov.fecha_asignacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.fecha_creacion = UtilSQL.getStringDateTimeOrNull(reader, 5);
                    ov.estado = UtilSQL.getStringOrNull(reader, 6);
                    ov.estadoValidacion = UtilSQL.getStringOrNull(reader, 7);
                    ov.codigoEstado = UtilSQL.getStringOrNull(reader, 8);
                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public List<AsignarRequerimientoView> getListaRequerimientoAsignadosPorColaboradorParaValidador(int cod)
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT a.[codigo_usuario_requerimiento]";
                sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                sql += " ,a.[codigo_requerimiento]";
                sql += " ,a.[fecha_entrega_trabajo]";
                sql += " ,a.[fecha_creacion]";
                sql += " ,d.nombre_Detalle_Maestro";
                sql += " ,r.descripcion";
                sql += " ,r.tipoValidacion";
                sql += " ,r.tipoCargaJob";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO] a";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario= a.codigo_colaborador_Asignado";
                sql += " inner join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key= a.estado and d.codigo_Maestro=14";
                sql += " inner join dbo.REQUERIMIENTO r";
                sql += " on r.codigo= a.codigo_requerimiento";
                sql += " where a.codigo_colaborador_Asignado = @param and a.estado <> '4'";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(cod);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    AsignarRequerimientoView ov = new AsignarRequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.fullName = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.fecha_asignacion = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.fecha_creacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.estado = UtilSQL.getStringOrNull(reader, 5);
                    ov.descripcionRequerimiento = UtilSQL.getStringOrNull(reader, 6);
                    ov.tipoValidacion = UtilSQL.getStringOrNull(reader, 7);
                    ov.tipoCargaJob = UtilSQL.getStringOrNull(reader, 8);
                    ov.descripcionAndCodigoRequerimiento = ov.codigo_requerimiento + " - " + ov.descripcionRequerimiento;
                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public bool getExisteAsignacion(string cod)
        {
            //List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            bool existe = false;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT a.[codigo_usuario_requerimiento]";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO] a";
                sql += " where a.codigo_usuario_requerimiento = @param;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(cod);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    AsignarRequerimientoView ov = new AsignarRequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    existe = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return existe;
        }

        public List<AsignarRequerimientoView> getListaRequerimientoAsignadoPorFiltro(string b)
        {
            List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT a.[codigo_usuario_requerimiento]";
                sql += " ,u.nombres_Usuario+', '+u.apellidos_usuario";
                sql += " ,a.[codigo_requerimiento]";
                sql += " ,a.[fecha_entrega_trabajo]";
                sql += " ,a.[fecha_creacion]";
                sql += " ,d.nombre_Detalle_Maestro";
                sql += " ,d2.nombre_Detalle_Maestro";
                sql += " FROM [dbo].[ASIGNARREQUERIMIENTO] a";
                sql += " inner join dbo.USUARIO u";
                sql += " on u.codigo_Usuario= a.codigo_colaborador_Asignado";
                sql += " inner join dbo.DETALLEMAESTRO d";
                sql += " on d.valor_key= a.estado and d.codigo_Maestro=12";
                sql += " inner join dbo.REQUERIMIENTO r";
                sql += " on r.codigo= a.codigo_requerimiento";
                sql += " inner join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key = a.estadoValidacion and d2.codigo_Maestro=14";
                sql += " WHERE a.[codigo_usuario_requerimiento] like '%'+ @param1 + '%'";
                sql += " or u.nombres_Usuario+', '+u.apellidos_usuario like '%'+ @param1 + '%'";
                sql += " or a.[codigo_requerimiento] like '%'+ @param1 + '%'";
                sql += " or d.nombre_Detalle_Maestro like '%'+ @param1 + '%'";
                sql += " or d2.nombre_Detalle_Maestro like '%'+ @param1 + '%'";

                //u.fecha_creacion,u.fecha_modificacion,
                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = b;
                buscar = buscar.Replace("_", "\\_");

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    AsignarRequerimientoView ov = new AsignarRequerimientoView();
                    ov.codigo = UtilSQL.getStringOrNull(reader, 0);
                    ov.fullName = UtilSQL.getStringOrNull(reader, 1);
                    ov.codigo_requerimiento = UtilSQL.getStringOrNull(reader, 2);
                    ov.fecha_asignacion = UtilSQL.getStringDateTimeOrNull(reader, 3);
                    ov.fecha_creacion = UtilSQL.getStringDateTimeOrNull(reader, 4);
                    ov.estado = UtilSQL.getStringOrNull(reader, 5);
                    ov.estadoValidacion = UtilSQL.getStringOrNull(reader, 6);
                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<Usuario> getListaLideres()
        {
            List<Usuario> lista = new List<Usuario>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_Usuario]";
                sql += ",[nombres_Usuario]";
                sql += ",[apellidos_usuario]";
                sql += "FROM [dbo].[USUARIO]";
                sql += " WHERE [cargo_usuario] = 2";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                //cmd.Parameters.Add("@param", SqlDbType.Int).Value = cod;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Usuario ov = new Usuario();
                    ov.codigo_Usuario = reader.GetInt32(0);
                    ov.nombres = reader.GetString(1);
                    ov.apellidos = reader.GetString(2);
                    ov.fullName = ov.nombres + ", " + ov.apellidos;

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<Usuario> getListaColaboradoresPorLider(int cod)
        {
            List<Usuario> lista = new List<Usuario>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_Usuario]";
                sql += ",[nombres_Usuario]";
                sql += ",[apellidos_usuario]";
                sql += "FROM [dbo].[USUARIO]";
                sql += " WHERE [lider] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = cod;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Usuario ov = new Usuario();
                    ov.codigo_Usuario = reader.GetInt32(0);
                    ov.nombres = reader.GetString(1);
                    ov.apellidos = reader.GetString(2);
                    ov.fullName = ov.nombres + ", " + ov.apellidos;

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public int getCodigoPorNombreLider(string nombre)
        {
            int cod = 0;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_Usuario]";
                sql += "FROM [dbo].[USUARIO]";
                sql += " WHERE [nombres_Usuario] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = nombre;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Usuario ov = new Usuario();
                    ov.codigo_Usuario = reader.GetInt32(0);

                    cod = ov.codigo_Usuario;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return cod;
        }

        public void actualizarAsigReqByArchivoDSX(AsignarRequerimiento ar)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[ASIGNARREQUERIMIENTO] SET";
                sql += " estadoValidacion = @param1";
                sql += ",estado = @param2";
                sql += " WHERE codigo_usuario_requerimiento = @param3";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(ar.estadoValidacion);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(ar.estado);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(ar.codigo_requerimiento);

                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public AsignarRequerimientoView getAsigReqByCodigo(string codAsigReq)
        {
            AsignarRequerimientoView req = new AsignarRequerimientoView();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select ar.codigo_usuario_requerimiento,";
                sql += " ar.estado";
                sql += " FROM dbo.ASIGNARREQUERIMIENTO ar";
                sql += " WHERE codigo_usuario_requerimiento = @param";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                commmand.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codAsigReq);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    req = new AsignarRequerimientoView();
                    req.codigo = UtilSQL.getStringOrNull(reader, 0);
                    req.estado = UtilSQL.getStringOrNull(reader, 1);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return req;
        }


    }
}
