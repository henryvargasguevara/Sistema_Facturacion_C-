﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using System.Windows.Forms;
using ValidadorSES.util;

namespace ValidadorSES.dao
{
    class UsuarioDAO
    {

        public int getObtenerUltimoCodigo()
        {
            int cod = 0;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = " select MAX(codigo_Usuario) from [dbo].[USUARIO]";

                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    cod = reader.GetInt32(0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return cod;
        }

        public void grabarUsuarioAnonimo(Usuario user)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[USUARIO]";
                // sql += "([codigo_Usuario]";//1
                sql += "([nombres_Usuario]";
                sql += ",[apellidos_usuario]";
                sql += ",[cargo_usuario]";
                sql += ",[lider]";
                sql += ",[estado]";
                sql += ",[usuario]";
                sql += ",[contraseña]";
                sql += ",[pregunta]";
                sql += ",[respuesta]";
                sql += ",[fecha_creacion]";
                sql += ",[fecha_modificacion]";
                sql += ",[usuario_creador]";
                sql += ",[usuario_modificador])";
                sql += "VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ",@param13";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                // cmd.Parameters.Add("@param1", SqlDbType.Int).Value = user.codigo_Usuario;
                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = user.nombres;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = user.apellidos;
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = user.cargo_usuario;
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = 1;
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = "2";
                cmd.Parameters.Add("@param6", SqlDbType.VarChar).Value = user.usuario;
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = user.contraseña;
                cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = user.pregunta;
                cmd.Parameters.Add("@param9", SqlDbType.VarChar).Value = user.respuesta;
                cmd.Parameters.Add("@param10", SqlDbType.DateTime).Value = user.fecha_creacion;
                cmd.Parameters.Add("@param11", SqlDbType.DateTime).Value = DBNull.Value;
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = getObtenerUltimoCodigo() + 1;
                cmd.Parameters.Add("@param13", SqlDbType.Int).Value = DBNull.Value;


                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public void insertarUsuario(Usuario user)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "INSERT INTO [dbo].[USUARIO]";
                // sql += "([codigo_Usuario]";//1
                sql += "([nombres_Usuario]";
                sql += ",[apellidos_usuario]";
                sql += ",[cargo_usuario]";
                sql += ",[lider]";
                sql += ",[estado]";
                sql += ",[usuario]";
                sql += ",[contraseña]";
                sql += ",[fecha_creacion]";
                sql += ",[fecha_modificacion]";
                sql += ",[usuario_creador]";
                sql += ",[usuario_modificador]";
                sql += ",[pregunta]";
                sql += ",[respuesta])";
                sql += "VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ",@param9";
                sql += ",@param10";
                sql += ",@param11";
                sql += ",@param12";
                sql += ",@param13";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                // cmd.Parameters.Add("@param1", SqlDbType.Int).Value = user.codigo_Usuario;
                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = user.nombres;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = user.apellidos;
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = user.cargo_usuario;
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = user.lider;
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = user.estado;
                cmd.Parameters.Add("@param6", SqlDbType.VarChar).Value = user.usuario;
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = user.contraseña;
                cmd.Parameters.Add("@param8", SqlDbType.DateTime).Value = user.fecha_creacion;
                cmd.Parameters.Add("@param9", SqlDbType.DateTime).Value = DBNull.Value;
                cmd.Parameters.Add("@param10", SqlDbType.Int).Value = user.usuario_creador;
                cmd.Parameters.Add("@param11", SqlDbType.Int).Value = DBNull.Value;
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = user.pregunta;
                cmd.Parameters.Add("@param13", SqlDbType.VarChar).Value = user.respuesta;


                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public List<Usuario> getListaUsuarioPorCargo(int cod)
        {
            List<Usuario> lista = new List<Usuario>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_Usuario]";
                sql += ",[nombres_Usuario]";
                sql += ",[apellidos_usuario]";
                sql += "FROM [dbo].[USUARIO]";
                sql += " WHERE [cargo_usuario] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = cod;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Usuario ov = new Usuario();
                    ov.codigo_Usuario = reader.GetInt32(0);
                    ov.nombres = reader.GetString(1);
                    ov.apellidos = reader.GetString(2);
                    ov.fullName = ov.nombres + ", " + ov.apellidos;

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<UsuarioView> getListaUsuarioView()
        {
            List<UsuarioView> lista = new List<UsuarioView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "select u.codigo_Usuario";
                sql += " ,u.nombres_Usuario";
                sql += " ,u.apellidos_usuario";
                sql += " ,d.nombre_Detalle_Maestro as cargo";
                sql += " ,u2.nombres_Usuario as lider";
                sql += " ,d2.nombre_Detalle_Maestro as estado";
                sql += " ,u.usuario,u.contraseña,u.fecha_creacion";
                sql += " ,u.fecha_modificacion,u3.nombres_Usuario";
                sql += " ,u4.nombres_Usuario ";
                sql += " ,d3.nombre_Detalle_Maestro";
                sql += " ,u.respuesta";
                sql += " from dbo.USUARIO u ";
                sql += " left join dbo.DETALLEMAESTRO d ";
                sql += " on d.valor_key = u.cargo_usuario and d.codigo_Maestro = 2 ";
                sql += " left join dbo.DETALLEMAESTRO d2 ";
                sql += " on d2.valor_key = u.estado and d2.codigo_Maestro = 3 ";
                sql += " left join dbo.USUARIO u2 ";
                sql += " on u2.codigo_Usuario = u.lider ";
                sql += " left join dbo.USUARIO u3 ";
                sql += " on u.usuario_creador = u3.codigo_Usuario ";
                sql += " left join dbo.USUARIO u4 on u.usuario_modificador = u4.codigo_Usuario";
                sql += " left join dbo.DETALLEMAESTRO d3 on d3.valor_key = u.pregunta and d3.codigo_Maestro = 9";
                sql += " where d.valor_key <> 1";
                sql += " order by u.codigo_Usuario asc;";
                SqlCommand commmand = new SqlCommand(sql, conexion);
                SqlDataReader reader = commmand.ExecuteReader();

                while (reader.Read())
                {
                    UsuarioView ov = new UsuarioView();
                    ov.codigo = reader.GetInt32(0);
                    ov.nombres = UtilSQL.getStringOrNull(reader, 1);
                    ov.apellidos = UtilSQL.getStringOrNull(reader, 2);
                    ov.cargo = UtilSQL.getStringOrNull(reader, 3);
                    ov.lider = UtilSQL.getStringOrNull(reader, 4);
                    ov.estado = UtilSQL.getStringOrNull(reader, 5);
                    ov.usuario = UtilSQL.getStringOrNull(reader, 6);
                    ov.contraseña = UtilSQL.getStringOrNull(reader, 7);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 8);
                    ov.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 9);
                    ov.usuarioCreador = UtilSQL.getStringOrNull(reader, 10);
                    ov.usuarioModificador = UtilSQL.getStringOrNull(reader, 11);
                    ov.pregunta = UtilSQL.getStringOrNull(reader, 12);
                    ov.respuesta = UtilSQL.getStringOrNull(reader, 13);

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return lista;
        }

        public List<UsuarioView> getListaBuscarUsuario(string b)
        {
            List<UsuarioView> lista = new List<UsuarioView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "select u.codigo_Usuario";
                sql += ",u.nombres_Usuario";
                sql += ",u.apellidos_usuario";
                sql += ",d.nombre_Detalle_Maestro as cargo";
                sql += ",u2.nombres_Usuario as lider";
                sql += ",d2.nombre_Detalle_Maestro as estado";
                sql += ",u.usuario";
                sql += ",u.contraseña";
                sql += ",u.fecha_creacion";
                sql += ",u.fecha_modificacion";
                sql += ",u3.nombres_Usuario";
                sql += ",u4.nombres_Usuario";
                sql += ",d3.nombre_Detalle_Maestro";
                sql += " ,u.respuesta";
                sql += " from dbo.DETALLEMAESTRO d";
                sql += " right join dbo.USUARIO u";
                sql += " on d.valor_key = u.cargo_usuario and d.codigo_Maestro = 2";
                sql += " left join dbo.DETALLEMAESTRO d2";
                sql += " on d2.valor_key = u.estado and d2.codigo_Maestro = 3";
                sql += " left join dbo.USUARIO u2";
                sql += " on u2.codigo_Usuario = u.lider";
                sql += " left join dbo.USUARIO u3";
                sql += " on u.usuario_creador = u3.codigo_Usuario";
                sql += " left join dbo.USUARIO u4";
                sql += " on u.usuario_modificador = u4.codigo_Usuario";
                sql += " left join dbo.DETALLEMAESTRO d3 on d3.valor_key = u.pregunta and d3.codigo_Maestro = 9";
                sql += " WHERE u.nombres_Usuario like '%'+ @param + '%'";
                sql += " or u.codigo_Usuario like '%'+ @param + '%'";
                sql += " or u.apellidos_usuario like '%'+ @param + '%'";
                sql += " or d.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " or u2.nombres_Usuario like '%'+ @param + '%'";
                sql += " or d2.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " or u.usuario like '%'+ @param + '%'";
                sql += " or u3.nombres_Usuario like '%'+ @param + '%'";
                sql += " or u.usuario_modificador like '%'+ @param + '%'";
                sql += " or d3.nombre_Detalle_Maestro like '%'+ @param + '%'";
                sql += " AND d.valor_key <> 1";

                //u.fecha_creacion,u.fecha_modificacion,
                SqlCommand cmd = new SqlCommand(sql, conexion);
                string buscar = b;
                buscar = buscar.Replace("_", "\\_");
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(buscar);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    UsuarioView ov = new UsuarioView();
                    ov.codigo = reader.GetInt32(0);
                    ov.nombres = UtilSQL.getStringOrNull(reader, 1);
                    ov.apellidos = UtilSQL.getStringOrNull(reader, 2);
                    ov.cargo = UtilSQL.getStringOrNull(reader, 3);
                    ov.lider = UtilSQL.getStringOrNull(reader, 4);
                    ov.estado = UtilSQL.getStringOrNull(reader, 5);
                    ov.usuario = UtilSQL.getStringOrNull(reader, 6);
                    ov.contraseña = UtilSQL.getStringOrNull(reader, 7);
                    ov.fechaCreacion = UtilSQL.getStringDateTimeOrNull(reader, 8);
                    ov.fechaModificacion = UtilSQL.getStringDateTimeOrNull(reader, 9);
                    ov.usuarioCreador = UtilSQL.getStringOrNull(reader, 10);
                    ov.usuarioModificador = UtilSQL.getStringOrNull(reader, 11);
                    ov.pregunta = UtilSQL.getStringOrNull(reader, 12);
                    ov.respuesta = UtilSQL.getStringOrNull(reader, 13);


                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public void actualizarUsuario(Usuario obj)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[USUARIO] SET ";
                //sql += "[type_objeto] = @param1";//1
                sql += " [nombres_Usuario] = @param2";
                sql += ",[apellidos_usuario] = @param3";
                sql += ",[cargo_usuario]= @param4";
                sql += ",[lider] = @param5";
                sql += ",[estado] = @param6";
                sql += ",[usuario]= @param7";
                sql += ",[contraseña] = @param8";
                sql += ",[fecha_modificacion] = @param10";
                sql += ",[usuario_modificador] = @param12";
                sql += " WHERE [codigo_Usuario] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.codigo_Usuario);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.nombres);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.apellidos);
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.cargo_usuario);
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.lider);
                cmd.Parameters.Add("@param6", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.estado);
                cmd.Parameters.Add("@param7", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.usuario);
                cmd.Parameters.Add("@param8", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.contraseña);
                cmd.Parameters.Add("@param10", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(obj.fecha_modificacion);
                cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.usuario_modificador);
                //cmd.Parameters.Add("@param12", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.codigo_Usuario);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        public Usuario Login(Usuario obj)
        {
            Usuario resultado = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select codigo_Usuario,nombres_Usuario,cargo_usuario FROM [dbo].[USUARIO] ";
                sql += " WHERE usuario = @param1 AND contraseña = @param2 AND estado = 1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.usuario);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.contraseña);
                SqlDataReader read = null;
                read = cmd.ExecuteReader();

                if (read.Read())
                {
                    Usuario user = new Usuario();
                    user.codigo_Usuario = read.GetInt32(0);
                    user.nombres = read.GetString(1);
                    user.cargo_usuario = read.GetInt32(2);

                    resultado = user;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return resultado;
        }

        public Usuario ObtenerPreguntaSecreta(Usuario obj)
        {
            Usuario resultado = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select pregunta FROM [dbo].[USUARIO]";
                sql += " WHERE usuario = @param1";
                //codigo_Usuario,nombres_Usuario,
                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.usuario);
                SqlDataReader read = null;
                read = cmd.ExecuteReader();

                if (read.Read())
                {
                    Usuario user = new Usuario();
                    //user.codigo_Usuario = read.GetInt32(0);
                    //user.nombres = read.GetString(1);
                    user.pregunta = read.GetString(0);

                    resultado = user;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return resultado;
        }

        public string descripcionDpregunta(string cod)
        {
            string result = "";

            switch (cod)
            {
                case "1":
                    result = "Nombre de tu mascota";
                    break;
                case "2":
                    result = "Deporte favorito";
                    break;
                case "3":
                    result = "comida favorita";
                    break;
                case "4":
                    result = "Artista o grupo favorito";
                    break;
                case "5":
                    result = "Color de tu preferencia";
                    break;

            }

            return result;
        }

        public Usuario ValidarPreguntaSecreta(Usuario obj)
        {
            Usuario resultado = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "select codigo_Usuario";
                sql += ",contraseña ";
                sql += "FROM [dbo].[USUARIO] ";
                sql += "WHERE respuesta = @param1";
                //codigo_Usuario,nombres_Usuario,
                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.respuesta);
                SqlDataReader read = null;
                read = cmd.ExecuteReader();

                if (read.Read())
                {
                    Usuario user = new Usuario();
                    user.codigo_Usuario = read.GetInt32(0);
                    //user.nombres = read.GetString(1);
                    user.contraseña = read.GetString(1);

                    resultado = user;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return resultado;
        }

        public void actualizarContraseña(Usuario obj)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "UPDATE [dbo].[USUARIO] SET ";
                sql += " [contraseña] = @param2";
                sql += " WHERE [codigo_Usuario] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(obj.codigo_Usuario);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(obj.contraseña);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error update BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

        }

        public UsuarioView getCodigoUsuarioPorNombre(string nombre)
        {
            UsuarioView ov = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_Usuario]";
                sql += " FROM [dbo].[USUARIO]";
                sql += " WHERE nombres_Usuario+', '+apellidos_usuario = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(nombre);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ov = new UsuarioView();
                    ov.codigo = UtilSQL.getIntOrNull(reader, 0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return ov;
        }

        public List<Usuario> getListaLideres()
        {
            List<Usuario> lista = new List<Usuario>();

            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_Usuario]";
                sql += ",[nombres_Usuario]";
                sql += ",[apellidos_usuario]";
                sql += "FROM [dbo].[USUARIO]";
                sql += " WHERE [cargo_usuario] = 2 ";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Usuario ov = new Usuario();
                    ov.codigo_Usuario = reader.GetInt32(0);
                    ov.nombres = reader.GetString(1);
                    ov.apellidos = reader.GetString(2);
                    ov.fullName = ov.nombres + ", " + ov.apellidos;

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public List<Usuario> getListaColaboradoresDeLideres(int cod)
        {
            List<Usuario> lista = new List<Usuario>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();

            try
            {
                conexion.Open();
                string sql = "SELECT [codigo_Usuario]";
                sql += ",[nombres_Usuario]";
                sql += ",[apellidos_usuario]";
                sql += "FROM [dbo].[USUARIO]";
                sql += " WHERE [lider] = @param OR codigo_Usuario = @param ";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.Int).Value = cod;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Usuario ov = new Usuario();
                    ov.codigo_Usuario = reader.GetInt32(0);
                    ov.nombres = reader.GetString(1);
                    ov.apellidos = reader.GetString(2);
                    ov.fullName = ov.nombres + ", " + ov.apellidos;

                    lista.Add(ov);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }

        public Usuario getEstadoLider(int codigo)
        {
            Usuario ov = null;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT [estado]";
                sql += " FROM [dbo].[USUARIO]";
                sql += " WHERE codigo_Usuario = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(codigo);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ov = new Usuario();
                    ov.estado = UtilSQL.getStringOrNull(reader, 0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return ov;
        }

        public bool getExisteUsuario(string user)
        {
            //List<AsignarRequerimientoView> lista = new List<AsignarRequerimientoView>();
            bool existe = false;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT u.[USUARIO]";
                sql += " FROM [dbo].[USUARIO] u";
                sql += " where u.[USUARIO] = @param;";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(user);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    UsuarioView ov = new UsuarioView();
                    ov.usuario = UtilSQL.getStringOrNull(reader, 0);
                    existe = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return existe;
        }
    }

}

