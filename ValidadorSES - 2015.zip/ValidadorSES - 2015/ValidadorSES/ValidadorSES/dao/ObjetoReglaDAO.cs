﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using ValidadorSES.modelo;
using ValidadorSES.modelo.view;
using ValidadorSES.util;

namespace ValidadorSES.dao
{
    public class ObjetoReglaDAO
    {
        public void guardarListaObjetoRegla(List<ObjetoRegla> lista)
        {
            try
            {
                for (int i = 0; i < lista.Count; i++)
                {
                    if (existeReglaObjeto(lista[i]))
                    {
                        actualizarObjetoRegla(lista[i]);
                    }
                    else
                    {
                        insertarObjetoRegla(lista[i]);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error guardar BD: " + ex);
                throw ex;
            }
        }

        private void insertarObjetoRegla(ObjetoRegla objRegla)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "INSERT INTO [dbo].[OBJETO_REGLA]";
                sql += "([codigo_objeto_regla]";
                sql += ",[codigo_objeto]";
                sql += ",[codigo_regla]";
                sql += ",[estado]";
                sql += ",[usuario_creador]";//5
                sql += ",[fecha_creacion]";
                sql += ",[usuario_modificador]";
                sql += ",[fecha_modificacion])";
                sql += "VALUES";
                sql += "(@param1";
                sql += ",@param2";
                sql += ",@param3";
                sql += ",@param4";
                sql += ",@param5";
                sql += ",@param6";
                sql += ",@param7";
                sql += ",@param8";
                sql += ")";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(objRegla.codigoObjetoRegla);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(objRegla.codigoObjeto);
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(objRegla.codigoRegla);
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(objRegla.estado);
                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(objRegla.usuarioCreador);
                cmd.Parameters.Add("@param6", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(objRegla.fechaCreacion);
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(null);
                cmd.Parameters.Add("@param8", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(null);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        private void actualizarObjetoRegla(ObjetoRegla objRegla)
        {
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "UPDATE [dbo].[OBJETO_REGLA] SET";
                sql += " [estado] = @param2";
                sql += ",[usuario_modificador] = @param3";
                sql += ",[fecha_modificacion] = @param4";
                sql += " WHERE [codigo_objeto_regla] = @param1";

                SqlCommand cmd = new SqlCommand(sql, conexion);

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(objRegla.codigoObjetoRegla);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(objRegla.estado);
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(objRegla.usuarioModificador);
                cmd.Parameters.Add("@param4", SqlDbType.DateTime).Value = UtilSQL.getObjectOrSQLNull(objRegla.fechaModificacion);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
        }

        private bool existeReglaObjeto(ObjetoRegla objRegla)
        {
            bool existe = false;
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();

                string sql = "SELECT TOP 1 [codigo_objeto_regla]";
                sql += " FROM [dbo].[OBJETO_REGLA]";
                sql += " WHERE [codigo_objeto_regla] = @param";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                cmd.Parameters.Add("@param", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(objRegla.codigoObjetoRegla);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    existe = true;
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error insert BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return existe;
        }

        public List<ObjetoReglaView> getListaObjetoReglaViewByRegla(int codRegla, string tipoObjeto)
        {
            List<ObjetoReglaView> lista = new List<ObjetoReglaView>();
            SqlConnection conexion = ConexionSQLSERVER.getSqlConnection();
            try
            {
                conexion.Open();
                string sql = "SELECT obj.[codigo_objeto]";
                sql += ",[type_objeto]";
                sql += ",det_clas.nombre_Detalle_Maestro as [clasificacion]";
                sql += ",obj.[nombre]";
                sql += ",objRegla.[estado]";
                sql += ",@param1 as codigo_regla";

                sql += " FROM [dbo].[OBJETO] obj";
                sql += " INNER JOIN [dbo].[DETALLEMAESTRO] det_clas";
                sql += " ON det_clas.codigo_Maestro = 1 AND obj.[clasificacion] = det_clas.valor_key";
                sql += " LEFT JOIN [dbo].[OBJETO_REGLA] objRegla";
                sql += " ON obj.codigo_objeto = objRegla.[codigo_objeto] AND objRegla.codigo_regla = @param1";

                sql += " WHERE (objRegla.[estado] is null or objRegla.[estado]<> '3')   and obj.estado = '1'  and obj.clasificacion = @param2";

                sql += " ORDER BY det_clas.nombre_Detalle_Maestro , obj.[nombre] , obj.[type_objeto]";

                SqlCommand cmd = new SqlCommand(sql, conexion);
                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = UtilSQL.getObjectOrSQLNull(codRegla);
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = UtilSQL.getObjectOrSQLNull(tipoObjeto);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ObjetoReglaView orv = new ObjetoReglaView();
                    orv.codigoObjeto = UtilSQL.getStringOrNull(reader, 0);
                    orv.typeObjeto = UtilSQL.getStringOrNull(reader, 1);
                    orv.clasificacion = UtilSQL.getStringOrNull(reader, 2);
                    orv.nombreObjeto = UtilSQL.getStringOrNull(reader, 3);
                    orv.estadoObjRegla = UtilSQL.getStringOrNull(reader, 4);
                    orv.codigoRegla = UtilSQL.getIntOrNull(reader, 5);
                    orv.clasificacionAndType = orv.clasificacion + " | " + orv.nombreObjeto + " | " + orv.typeObjeto;

                    if (orv.estadoObjRegla == null || orv.estadoObjRegla == "")
                    {
                        orv.estadoObjRegla = "2";
                    }
                    lista.Add(orv);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error select BD: " + ex);
                throw ex;
            }
            finally
            {
                conexion.Close();
            }

            return lista;
        }
    }
}
